# Brevo Email API Setup for OTP

Render may timeout on SMTP ports. Brevo HTTPS API avoids SMTP ports.

## Render Variables

```env
APP_NAME=Global Exchanger
BREVO_API_KEY=your_brevo_api_key
SMTP_FROM=Global Exchanger <your_verified_sender_email@gmail.com>
```

You can keep old SMTP variables, but when `BREVO_API_KEY` is present, backend uses Brevo API first.

## Brevo Steps

1. Create account at https://www.brevo.com
2. Verify sender email.
3. Go to SMTP & API > API Keys.
4. Generate API key.
5. Add API key to Render as `BREVO_API_KEY`.
6. Add `SMTP_FROM` with your verified sender email.
7. Redeploy Render service.

Logs should show:

```text
[EMAIL OTP SENT VIA BREVO]
```
