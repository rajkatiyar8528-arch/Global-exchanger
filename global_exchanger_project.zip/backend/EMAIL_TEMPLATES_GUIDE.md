# Email Notification Templates — Polish Guide

Ye guide batati hai ki backend se bheje jaane wale saare emails (OTP, payment updates, KYC status, withdrawal, broadcast, etc.) ko is round me kaise professional aur secure banaya gaya.

## Kya Badla

### 1. Professional Branded Design
Pehle emails bahut basic the — sirf ek plain box me title + message. Ab har email me:
- **Colored top accent bar** — email ke type ke hisaab se color badalta hai:
  - 🟢 **Green** — success (payment success, KYC approved, exchange completed)
  - 🔴 **Red** — failure (payment failed, KYC rejected, withdrawal rejected)
  - 🟠 **Orange** — warning (scheduled payment paused, price alert triggered)
  - 🔵 **Blue** — general info (broadcast, support reply)
- **Icon + Title header** — emoji icon (✅/❌/⚠️/🔔) ke saath clear title
- **Footer** — support email (`support@globalexchanger.com`), aur Privacy Policy/Terms/Grievance Redressal ke direct links
- Design automatically adapt hota hai — kisi bhi naye notification type ke liye bhi reasonable dikhega bina extra code likhe

### 2. Security Fix (Zaroori)
**Bug jo fix hua**: Pehle agar koi user ya admin apne message me HTML-jaisa text likhta (jaise `<script>` ya koi formatting characters), to wo bina escape kiye seedha email ke HTML me chala jaata tha — ye ek "stored XSS via email" risk tha. Jaise:
- Withdrawal reject karte waqt admin ka "Reason" text
- Complaint/support chat replies
- Broadcast notification ka title/message

**Fix**: Ab har jagah jahan bhi dynamic (user/admin-supplied) text email ke HTML me jaata hai, use pehle `escapeHtml()` se sanitize kiya jaata hai — matlab agar koi `<script>` likhega, wo email me literal text ke roop me dikhega (`&lt;script&gt;`), execute nahi hoga.

**Verified via automated testing**: Maine khaas taur par is scenario ko test kiya — ek user ne complaint me `<script>alert("xss")</script>` jaisa payload bheja, admin ne reply kiya isi tarah ke payload ke saath — server crash nahi hua, email safely (escaped) bheja gaya, poora system normal kaam karta raha.

### 3. OTP Emails Bhi Upgrade Hue
- Login OTP, Email Verification OTP, aur Password Reset OTP — teeno ab same professional template use karte hain
- **Password Reset OTP** ka special treatment: agar koi user reset request nahi karta phir bhi email aaye, to email me clearly likha hota hai "agar ye request aapne nahi ki, to ignore karein" — taaki confusion na ho

## Technical Summary

- `src/notifications.js` — naya `emailShell()` function (branded wrapper), `categoryForType()` (notification type se color/icon auto-detect), `escapeHtml()` export kiya gaya
- `src/notifications_json.js` — `escapeHtml()` use karke message sanitize
- `src/otp.js` — naya branded template use karta hai, purpose-specific subject/content (`login`, `email_verification`, `password_reset`)
- Koi naya API endpoint nahi (pure backend/email-content polish round) — route count same raha (124, dono backends match)
- **18+ automated tests** (dono backends) — forgot-password flow regression, XSS-safety scenario, aur 2FA/broadcast/account-export regression — sab pass

## Kya Nahi Badla

- Email bhejne ka tareeka (Brevo/Resend/SMTP/console-fallback) same hai
- Koi naya environment variable zaroori nahi hai — existing `SMTP_*`/`BREVO_API_KEY`/`RESEND_API_KEY` setup jaisa hai waisa hi kaam karega
- App/API responses same hain — sirf email ka HTML content professional/secure hua hai
