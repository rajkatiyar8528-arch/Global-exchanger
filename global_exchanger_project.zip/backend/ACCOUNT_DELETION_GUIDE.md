# Account Data Export & Deletion — Guide (Privacy)

Ye guide batati hai ki naya **"Download My Data"** aur **"Delete My Account"** feature kaise kaam karta hai, aur ye design decision kyun liya gaya.

## User Ke Liye — Kaise Use Karein

App me **Profile** screen kholein — neeche "Privacy & Data" section dikhega:

### 1. Download My Data
- Click karte hi aapka **poora data** (profile, wallet, transactions, KYC, complaints, disputes, referrals, price alerts, watchlist, scheduled payments, notifications) ek JSON format me screen par dikhega
- **"Copy Poora Data (JSON)"** dabakar clipboard me copy kar sakte hain, phir kahin bhi (Notes app, email, etc.) paste kar sakte hain

### 2. Delete My Account
- **Shart**: Delete karne se pehle wallet ka balance **zero** hona chahiye, aur koi pending withdrawal nahi honi chahiye (pehle paisa withdraw/transfer kar lein)
- Apna current password daalein
- "DELETE" (bade letters me) type karke confirm karein
- Final confirmation dialog aayega, "Haan, Delete Karein" dabayein
- Account turant deactivate ho jayega — dobara login nahi ho sakta

## ⚠️ Bahut Zaroori: "Delete" Ka Matlab Kya Hai (Anonymize, Not Hard-Delete)

Ye ek **regulated financial app** hai — RBI/FIU-IND ke rules (PMLA — Prevention of Money Laundering Act) ke mutabik, KYC records aur transaction data **kam se kam 5 saal** tak record me rakhna **legally zaroori** hai. Ye humari khud ki Privacy Policy (Section 11 "Data Retention") me bhi likha hai.

Isliye "Delete Account" ka matlab hai **anonymization**, hard-delete nahi:

| Kya Hota Hai | Kya Nahi Hota |
|---|---|
| ✅ Naam → "Deleted User XXXXXXXX" | ❌ Transaction history delete nahi hoti |
| ✅ Email → random anonymized address | ❌ KYC records delete nahi hote |
| ✅ Phone number → hata diya jaata hai | ❌ Wallet record delete nahi hota (structure rehta hai) |
| ✅ Address → hata diya jaata hai | |
| ✅ Password → random, kisi ko pata nahi (dobara login IMPOSSIBLE) | |
| ✅ 2FA/backup codes → hata diye jaate hain | |
| ✅ Sabhi devices se logout | |
| ✅ Push notification tokens hata diye jaate hain | |

**In short**: Aapki **personal pehchaan** (kaun ho aap) mit jaati hai, lekin transactions ka anonymous record (bina naam ke) regulatory reason se kuch saal rehta hai — bilkul waise hi jaise bank account "close" karne par bank record turant nahi bhoolta.

## Safety Checks (Backend Enforced)

1. **Wallet balance zero honi chahiye** — agar koi balance bacha hai, request reject hoti hai clear error message ke saath
2. **Koi pending withdrawal nahi honi chahiye** — agar ek chal rahi hai, delete block ho jaata hai jab tak wo resolve na ho
3. **Current password verify** hota hai — koi aur (stolen/left-open device) chupke se delete nahi kar sakta

## Audit Trail

Har deletion `audit_logs` me `account.deleted_anonymized` action ke naam se record hoti hai, jisme **original email** bhi metadata me save hota hai (compliance record ke liye — ye normal hai, banks bhi apne audit trail me closed account ki details rakhte hain).

## Technical Summary

- `GET /api/account/export` — poora data ek JSON response me
- `POST /api/account/delete` — password required, balance/pending-withdrawal checks, phir anonymize
- Dono endpoints dono backends (JSON demo + PostgreSQL production) me identical, 15+12=27 automated tests se verify kiye gaye
- `users.deleted_at` column add kiya gaya — NULL matlab active account, timestamp matlab anonymized
