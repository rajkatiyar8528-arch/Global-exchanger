# Unread Support Chat Badges + Dark Mode Visual Polish (v1.10.1+20)

Follow-up round to the User Features Pack (v1.10.0+19), addressing two of
the three items explicitly flagged as "not done" in that round's guide
(`USER_FEATURES_PACK_GUIDE.md`) — everything except real Firebase push
notifications, which was deliberately deferred again this round since it
requires the user to create and configure their own free Firebase project
first (a manual step outside this codebase).

## 1. Unread Support Chat Badges

**What it does:** both the user's Help tab (bottom navigation) and the
Admin Panel's dashboard/complaints table now show a live "unread" signal
whenever the *other* side has sent a chat message that hasn't been read
yet — so neither a user nor an admin has to manually re-open every
complaint just to check for new replies.

**How "unread" is determined (no extra state to keep in sync):**
Every complaint already tracks three timestamps (added in the previous
round for this exact purpose, but unused until now):
`last_message_at`, `last_user_read_at`, `last_admin_read_at`. A new pure
helper function, `complaintHasUnread(complaint, side)` (duplicated
identically in both `server.js` and `server_pg.js`, same logic, same
variable names, to keep them from drifting), simply checks: *"is
`last_message_at` newer than this side's own last-read timestamp?"*
Every message-SEND endpoint also stamps the **sender's own** last-read
pointer to the same moment as the message — so the side that just sent a
message never sees their own message flagged as "unread" to themselves.

**New/changed endpoints (both backends):**
- `GET /api/complaints` (user) — each complaint object now includes a
  `hasUnread: true/false` field.
- `GET /api/complaints/unread-count` (user, new) — lightweight
  `{ unreadCount: N }` response, used to badge the Help bottom-nav tab
  without fetching/diffing the full complaints list.
- `GET /api/admin/complaints` (admin) — same `hasUnread` field added.
- `GET /api/admin/complaints/unread-count` (admin, new) — same idea for
  the admin dashboard.

**Flutter app:**
- `MainNavigationScreen` now polls `myComplaintsUnreadCount()` every 20
  seconds while the app is open (via a `Timer.periodic`, cancelled in
  `dispose()`) and shows a Material `Badge` with the live count on the
  Help tab's icon. Tapping into the Help tab also triggers an immediate
  refresh (rather than waiting for the next 20-second tick).
- The Complaints list (`_ComplaintsTabState`) highlights complaints with
  `hasUnread == true`: a blue dot next to the subject, a thicker blue
  border on the card, and the trailing "Chat" label changes to "New
  reply". Opening a complaint's chat (which marks it read server-side via
  the existing `GET /api/complaints/:id/messages` call) and returning
  triggers `reload()` so the highlight disappears once actually read.

**Admin Panel:**
- The "Complaints" dashboard metric card now shows a small red "`N
  unread`" label next to the total count (`loadComplaintsUnreadBadge()`).
- Each complaint row in the Complaints table gets a blue "NEW" pill next
  to the subject and a 🔴 next to the "💬 Chat" button when unread — both
  clear automatically the next time `loadComplaints()` runs after the
  admin opens that chat (since opening the chat modal calls
  `GET /api/admin/complaints/:id/messages`, which marks it read).

**Why polling (again) instead of websockets/push:** consistent with the
rest of this app's support-chat design (see `USER_FEATURES_PACK_GUIDE.md`)
— keeps the Render free-tier deployment simple, no extra infrastructure,
no sticky-session concerns behind Render's load balancer / Cloudflare.
20 seconds for a badge count (vs. 8 seconds for messages *within* an open
chat) is a deliberately longer interval since it runs continuously in the
background across the whole app, not just while a chat screen is open.

**Testing:** a new 14-check automated test script exercises the full
unread lifecycle (new complaint → no unread → user sends message → user
still not-unread but admin now sees unread → admin reads it → clears →
admin replies → user now sees unread → user reads it → clears) against
**both backends** — 14/14 passed on each, plus route-count parity
re-verified (95 matching routes on both `server.js` and `server_pg.js`
after this round's 4 new endpoints, up from 93 before this round — 2 new
`GET .../unread-count` routes per backend for user + admin).

## 2. Dark Mode Visual Polish

**What it does:** the previous round (v1.10.0+19) added `AppTheme.dark()`
and theme-aware helper functions (`cardColor`, `borderColor`, `mutedText`,
`subtleText`, `faintText`, `warningBg`, `isDark` in
`lib/theme/app_theme.dart`) and applied them to the shared reusable
widgets (`InfoCard`, `FeatureTile`, `WarningBox`, `ErrorRetryView`,
`EmptyStateView`, `ProfessionalCard`, `AppPage`) plus the five brand-new
screens from that round — but explicitly flagged that **most pre-existing
screens still had hardcoded light-mode colors** (`Colors.white` card
backgrounds, `Color(0xFFE5EDFF)` borders, `Colors.black54`/`black45`/
`black38` muted text) as a known, deliberately-scoped gap. This round
closes that gap across essentially the entire app.

**What changed (mechanical, screen-by-screen sweep of `main.dart`):**
- Every `Container` card decoration of the form `color: Colors.white, ...
  border: Border.all(color: const Color(0xFFE5EDFF))` (appearing in
  KYC document slots, referral history rows, bank account cards,
  withdrawal cards, transaction history rows, transaction detail receipts,
  complaint cards, dispute cards, and more) now uses
  `color: cardColor(context)` / `border: Border.all(color:
  borderColor(context))` instead — these automatically resolve to the
  dark-mode card/border colors when Dark Mode is active.
- Every `TextStyle(color: Colors.black54/black45/black38)` muted-text
  style across the app (subtitle lines, timestamps, secondary details) now
  uses `mutedText(context)` / `subtleText(context)` / `faintText(context)`
  respectively.
- `TextField`/`DropdownButtonFormField` input decorations that had
  `fillColor: Colors.white` hardcoded (search box on History screen, bank
  account picker on Withdraw screen, related-transaction picker on
  Dispute screen, the Support Chat message input box) now use
  `fillColor: cardColor(context)`.
- The Notifications list's unread-highlight background (previously a flat
  `Color(0xFFEFF5FF)` light-blue that would look wrong on a dark
  background) now branches: light blue in Light Mode, a darker
  blue-tinted `Color(0xFF1A2A45)` in Dark Mode.
- The Support Chat message bubbles (`ComplaintChatScreen`) now use
  `cardColor(context)`/`borderColor(context)` for the "other side"
  bubble, and the message text color switches to white-on-dark-background
  automatically via `isDark(context)` so text stays readable against the
  dark bubble color.
- **Deliberately left unchanged (correct as-is, not a gap):** the Splash
  screen, `GradientHeader`, and other gradient-background elements (App
  Logo, Referral Code card, notification bell icon) — these use white
  text/icons directly on a fixed blue/green gradient background that
  doesn't change with the system theme, so `Colors.white` there is
  intentional and correct in both Light and Dark Mode. Similarly, the QR
  code's `backgroundColor: Colors.white` in `QrImageView` is intentional
  — QR codes need a plain white background to remain scannable regardless
  of app theme.

**Verification approach:** since this sandbox has no Flutter SDK installed
(no `flutter analyze`/`flutter build` available), verification was done
via (a) a Python brace/bracket/paren balance checker across `main.dart`,
`api_service.dart`, `app_theme.dart`, and `pro_widgets.dart` (all balanced
after every edit), and (b) a systematic `grep` sweep after each bulk
edit confirming zero remaining unintended `Colors.white`/`Colors.black*`
occurrences outside the deliberately-excluded gradient/QR-code contexts
listed above. **Recommend the user visually spot-check a few screens
(History, Complaints, Withdraw, Notifications) after installing the new
APK with Dark Mode turned on**, since this was not verified against an
actual running Flutter build in this sandbox.

## Testing performed this round

- New `test_unread_badges.py` (14 checks) — full unread lifecycle, run
  against both `server.js` (JSON) and `server_pg.js` (Postgres) — **14/14
  passed on both**.
- Route-count parity re-verified: **95 matching routes** on both backends
  (up from 93 in v1.10.0+19, +2 for the new unread-count endpoints per
  backend).
- Full regression re-check of core pre-existing flows (register, login,
  `/api/me`, wallet, watchlist, price-alerts, settings, statement token,
  notifications, referrals, complaints list) — all still return `200` on
  both backends, no regression introduced.
- `node -c` syntax check passed on both `server.js` and `server_pg.js`.
- Python brace/bracket/paren balance check passed on all 4 touched Dart
  files.

## Deferred / not done this round

- **Real OS-level push notifications (Firebase Cloud Messaging)** — still
  deferred. Requires the user to create their own free Firebase project
  (Firebase Console → Add Project → enable Cloud Messaging), then provide
  two files back to be wired into the app (`google-services.json` for
  Android) and a server-side FCM server key/service-account for the
  backend to send push payloads. This is a manual, external, one-time
  setup step on the user's side before any code can be written for it —
  offer to walk the user through it step-by-step in Hinglish whenever
  they're ready to do it.
- Full Flutter-build visual verification of Dark Mode (no Flutter SDK in
  this sandbox — see verification note above; ask the user to spot-check
  after their next Codemagic build + APK install).
