# Push Notifications (Firebase) — Setup Guide

Ye guide batati hai ki app me **real background push notifications** (jab app band ho tab bhi phone par notification aaye — jaise WhatsApp/Paytm) kaise activate karein.

## Ye feature already build ho chuka hai, bas "ON" karna hai

Backend aur Flutter app dono me pura code taiyaar hai. Jab tak aap Firebase setup nahi karte, tab tak app **bilkul normal kaam karega** — sirf background push disabled rahega, baaki sab (in-app notification bell, email, etc.) already kaam kar raha hai. Kuch bhi crash nahi hoga.

Activate karne ke liye aapko sirf **2 cheezein** karni hain (dono FREE hain, koi paisa nahi lagega):

1. Firebase Console pe ek project banana
2. 2 files/values nikalna aur mujhe (ya seedha GitHub/Render pe) dena

---

## Step 1: Firebase Project Banayein

1. Apne phone/computer se browser me jaayein: **https://console.firebase.google.com**
2. Google account se login karein (jo bhi aapka email hai)
3. **"Add project" / "Create a project"** par click karein
4. Project ka naam daalein — jaise `Global Exchanger` (kuch bhi rakh sakte hain)
5. Google Analytics ka option aayega — **"Disable"** kar sakte hain (zaroori nahi hai), phir **"Create project"**
6. Project create hone ka wait karein (30 second lagta hai), phir **"Continue"**

## Step 2: Android App Register Karein

1. Firebase project ke dashboard me, **Android icon** (🤖) par click karein "Add app" ke liye
2. **"Android package name"** field me EXACTLY ye likhein:
   ```
   com.example.global_exchanger
   ```
   ⚠️ Ye bahut important hai — spelling bilkul same honi chahiye, warna push kaam nahi karega.
3. App nickname (optional) — kuch bhi likh sakte hain, jaise "Global Exchanger Android"
4. **"Register app"** par click karein
5. Agla screen "Download google-services.json" dikhayega — **is file ko download karein** (phone me Downloads folder me save hogi)
6. Baaki steps ("Add Firebase SDK", "Add initialization code") ko **SKIP/Next** kar dein — wo sab maine already code me kar diya hai, aapko kuch nahi karna
7. **"Continue to console"** par click karke finish karein

## Step 3: `google-services.json` File Mujhe Dena

Aapke paas ab ek file hai: **`google-services.json`**. Ise GitHub repo ke **ROOT** me upload karna hai (bilkul same jagah jahan `codemagic.yaml` aur `global_exchanger_project.zip` hain — kisi folder ke andar NAHI).

**Kaise karein (phone se GitHub app ya browser se)**:
1. GitHub repo kholein: `https://github.com/rajkatiyar8528-arch/Global-exchanger`
2. Repo ke root me "Add file" → "Upload files" par click karein
3. Downloaded `google-services.json` file select karke upload karein
4. Commit karein (message likh sakte hain "Add Firebase config")

Bas! Agli baar jab Codemagic build chalega, ye file automatically pick ho jaayegi aur push notifications ke liye zaroori Gradle settings apply ho jaayengi.

## Step 4: Service Account Key Banayein (Backend ke liye)

Ye wo cheez hai jisse HAMARA BACKEND SERVER Firebase ko bata sakta hai "is phone ko ye notification bhejo".

1. Firebase Console me, gear icon (⚙️) par click karein → **"Project settings"**
2. Upar **"Service accounts"** tab par click karein
3. **"Generate new private key"** button dabayein
4. Confirmation popup aayega — **"Generate key"** par click karein
5. Ek `.json` file download hogi (naam kuch aisa hoga: `global-exchanger-firebase-adminsdk-xxxxx.json`)

⚠️ **Ye file BAHUT SENSITIVE hai** — isse kisi ko mat bhejein, kisi public jagah upload mat karein (GitHub repo me bhi nahi). Ye seedha Render.com ke "Environment Variables" me jaani chahiye (jo private/secret hoti hain).

## Step 5: Render.com Environment Variable Set Karein

1. Render.com dashboard me login karein
2. Apni `global-exchanger` service (backend) kholein
3. **"Environment"** tab par jaayein
4. **"Add Environment Variable"** par click karein:
   - **Key**: `FIREBASE_SERVICE_ACCOUNT_JSON`
   - **Value**: Downloaded service account `.json` file ka **poora content** — file ko text editor/notepad se kholkar, sab kuch copy karke ek hi line me paste karein (JSON file waise bhi ek object hoti hai, isse alag se minify karne ki zaroorat nahi, seedha paste kar sakte hain)
5. **"Save Changes"** — Render automatically service ko restart kar dega naye environment variable ke saath

## Step 6: Verify Karein Ki Push Activate Ho Gaya

1. Admin Panel kholein: `https://rajkatiyar8528-arch.github.io/Global-exchanger/admin_panel/`
2. Login karein
3. Dashboard ke top par ab ek naya card dikhega: **"🔔 Push Notifications (Firebase)"**
   - Agar green "ACTIVE ✅" pill dikhta hai → Firebase set up ho gaya, push notifications live hain
   - Agar orange "NOT CONFIGURED ⚠️" dikhta hai → abhi FIREBASE_SERVICE_ACCOUNT_JSON set nahi hua ya galat hai, dobara check karein

## Step 7: Naya APK Build Karayein

Google-services.json GitHub root me daalne ke baad, Codemagic pe naya build trigger karein (ya naya commit push hone par automatically ho jaayega). Naya APK install karke test karein — App Settings me "Push / In-App Notifications" toggle ab "App band hone par bhi phone par notification aayegi" wala message dikhayega (pehle wala "abhi configure nahi hai" wala warning gayab ho jaayega).

---

## Ye Feature Kya Karta Hai (Technical Summary)

- Har user jab app khol ke login karta hai, unka phone ek unique "push token" backend ko register karta hai (`POST /api/push-tokens`)
- Jab bhi koi important event hota hai — KYC approve/reject, payment success/fail, complaint ka reply, referral bonus, price alert trigger, scheduled payment run, etc. — backend automatically us user ke registered devices ko FCM (Firebase Cloud Messaging) ke through push notification bhejta hai
- User "App Settings" me push notifications OFF bhi kar sakta hai (toggle already maujood hai) — tab unhe sirf in-app bell me dikhega, phone par push nahi aayega
- Agar koi purana/invalid token FCM reject kar de (app uninstall ho gaya, ya bahut purana token), backend automatically use apne database se hata deta hai — koi manual cleanup ki zaroorat nahi
- Jab tak Firebase configure nahi hota, ye poora system safely "sleep mode" me rehta hai — koi error nahi aata, baaki app 100% normal kaam karta hai

## Cost — Kitna Kharcha Hoga?

**Bilkul FREE.** Firebase Cloud Messaging (FCM) completely free hai, chahe kitne bhi users/notifications ho. Koi credit card bhi nahi maangi jaati Firebase project banane ke liye is basic setup ke liye.

## Agar Kuch Galat Ho Jaaye

- Agar `google-services.json` galat package name ke saath register hui, to Codemagic build fail ho sakta hai ya push silently kaam nahi karega — package name **`com.example.global_exchanger`** exactly match hona chahiye
- Agar Render environment variable me JSON galat paste hui (incomplete/corrupted), backend admin panel me "NOT CONFIGURED" hi dikhayega, koi crash nahi hoga
- Kabhi bhi kuch bhi galat lage, mujhe screenshot bhejein — main dekh ke bata dunga
