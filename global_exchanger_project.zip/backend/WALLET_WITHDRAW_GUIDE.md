# Wallet Withdraw & Bank Account Management

## What Was Missing

Previously "Add Bank Account" and "Withdraw" were both non-functional
buttons (`onTap: () {}`) — clicking them did nothing. The backend had a
`bank_accounts` table and a `POST /api/bank-accounts` endpoint to create
one, but no way to list, verify, or remove accounts, and no withdrawal
system existed at all.

## What's New

### Bank Account Management
- **Add**: existing endpoint, now with proper validation (all fields required).
- **List** (`GET /api/bank-accounts`): users can see their own saved accounts.
- **Remove** (`DELETE /api/bank-accounts/:id`): soft-deletes an account (kept
  in the database for audit trail, just hidden from the user and excluded
  from future withdrawals). Blocked if the account has an active
  (pending/approved/processing) withdrawal in progress.
- **Admin verification**: a new admin section lets an admin mark a bank
  account as Verified/Unverified with an optional note. **Withdrawals are
  only allowed against verified accounts** — this is the platform's control
  point against sending money to a fraudulent or mistyped account.

### Withdrawals
Modeled on the same "escrow" pattern already used for currency exchange
orders — money is locked immediately, not just marked pending, so a user
can never withdraw the same balance twice while a request is in flight.

**Requirements enforced before a withdrawal is accepted:**
1. User's KYC must be `approved` (a legal/compliance requirement for a
   forex/crypto exchange platform — see `LEGAL_COMPLIANCE_CHECKLIST.md`
   if building one, or the `KYC_DOCUMENT_UPLOAD_GUIDE.md` for how KYC
   works here).
2. The selected bank account must belong to the requesting user and be
   **verified** by an admin.
3. Amount must meet a per-currency minimum (₹100 for INR, $5 for USD/EUR by
   default — configurable in code).
4. Sufficient spendable balance must be available.

**Flow:**
1. User requests a withdrawal → amount moves from `balances` to `locked` in
   their wallet immediately, and a `withdrawals` row is created with status
   `pending`.
2. Admin reviews it in the web panel and can move it through
   `approved → processing → completed`, or `reject` it at any point before
   completion.
3. **Rejected**: the locked amount is returned to the user's spendable
   balance, and they're notified with the reason.
4. **Completed**: the locked amount is cleared (money has now actually left
   the platform to the user's bank account) and the user is notified.
5. **User can self-cancel** a still-`pending` withdrawal (before an admin
   has acted on it), which also returns the locked funds.

Rate-limited to 10 withdrawal requests per hour per user to prevent abuse.

## A Bug Found & Fixed While Testing

While manually testing the full flow (request → admin completes it), the
withdrawal's locked amount was not actually being cleared from the wallet
on completion — only a ledger entry was posted. This meant a completed
withdrawal would leave the wallet showing a stale "locked" balance forever.
Fixed in both backend implementations (`server_pg.js` and `server.js`) by
also updating `wallets.locked` when a withdrawal reaches `completed`.

## New Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/bank-accounts` | User | List my saved bank accounts |
| DELETE | `/api/bank-accounts/:id` | User | Remove (soft-delete) a bank account |
| POST | `/api/withdrawals` | User | Request a withdrawal (locks funds) |
| GET | `/api/withdrawals` | User | My withdrawal history |
| POST | `/api/withdrawals/:id/cancel` | User | Cancel a still-pending withdrawal |
| GET | `/api/admin/bank-accounts` | Admin (`payments:read`) | All bank accounts, for verification |
| PATCH | `/api/admin/bank-accounts/:id/verify` | Admin (`payments:read`) | Mark verified/unverified |
| GET | `/api/admin/withdrawals` | Admin (`refunds:manage`) | All withdrawal requests |
| PATCH | `/api/admin/withdrawals/:id` | Admin (`refunds:manage`) | Move status forward or reject |

## Where It Shows Up

- **Wallet screen**: "Manage Bank Accounts" and "Withdraw to Bank" buttons
  (previously did nothing) now open real, working screens.
- **Bank Accounts screen**: add/view/remove accounts, each showing a
  Verified/Pending Verification badge.
- **Withdraw screen**: dropdown to pick a verified bank account, amount
  input, and a full history of past withdrawal requests with status and
  admin notes. Pending requests show a "Cancel Request" button.
- **Admin panel**: new "Bank Accounts" section (verify/unverify) and
  "Withdrawals" section (approve → processing → complete, or reject) with
  full status tracking.
