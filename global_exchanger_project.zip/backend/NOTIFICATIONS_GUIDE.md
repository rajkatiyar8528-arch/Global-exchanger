# Notifications (In-App + Email)

Users ko ab automatically notify kiya jata hai jab:

| Event | Notification Type | Email Bhi Jata Hai? |
|---|---|---|
| Payment successful (wallet top-up) | `payment_success` | Haan |
| Payment failed/verification failed | `payment_failed` | Haan |
| KYC approved | `kyc_approved` | Haan |
| KYC rejected | `kyc_rejected` | Haan |
| Exchange order completed | `exchange_completed` | Haan |
| Exchange order cancelled | `exchange_cancelled` | Haan |
| 0.2% reward credited (on exchange order creation) | `reward_credited` | Nahi (sirf in-app, taaki har chhote convert par extra email na jaye) |

## Kaise Kaam Karta Hai

- Har notification **`notifications` table (Postgres)** ya **`db.notifications` (JSON demo backend)** mein turant save hoti hai — app kabhi bhi list fetch kar sakta hai, email delivery ka wait nahi karna padta.
- Email bhejna **best-effort** hai — agar email provider (Brevo/Resend/SMTP) configure nahi hai, ya email fail ho jaye, toh **main business action (payment/KYC/exchange) fail nahi hota**. Email sirf console mein log hota hai dev mode mein.
- Email ke liye wahi providers reuse hote hain jo OTP ke liye already configured hain: `BREVO_API_KEY`, `RESEND_API_KEY`, ya `SMTP_*` env vars (dekhiye `BREVO_EMAIL_API_SETUP.md`).

## Endpoints

| Method | Path | Kaam |
|---|---|---|
| GET | `/api/notifications?limit=30&offset=0` | Apni notifications ki list + unread count |
| POST | `/api/notifications/:id/read` | Ek notification ko read mark karna |
| POST | `/api/notifications/read-all` | Sab notifications ko read mark karna |

## App Mein Kahan Dikhta Hai

- **Home screen** ke top-right corner mein ek 🔔 bell icon hai jisme unread count ka red badge dikhta hai
- Bell pe tap karne se **Notifications screen** khulta hai — sab notifications list mein, unread wale highlighted (halka blue background)
- "Mark All as Read" button bhi hai jab unread notifications hon

## Naye Notification Types Add Karna (Future)

Backend mein kahin bhi naya notification trigger karna ho, bas yeh call karein:

```js
// Postgres backend (server_pg.js)
await notifyUser(pool, {
  userId,
  userEmail,       // optional — sirf tab email jayega jab yeh diya ho
  type: 'your_new_type',
  title: 'Notification Title',
  message: 'User-facing message here',
  metadata: { anything: 'extra data' },
  sendEmail: true, // false karke sirf in-app rakh sakte hain
});
```

```js
// JSON demo backend (server.js)
notifyUserJson(db, { userId, userEmail, type, title, message, metadata, sendEmail });
```
