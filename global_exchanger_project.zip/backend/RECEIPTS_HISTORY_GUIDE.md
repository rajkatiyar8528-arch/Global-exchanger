# Transaction Receipts & Better History

## What's New

### 1. Filterable/Searchable Transaction History
`GET /api/transactions` now accepts query params:

```
GET /api/transactions?type=send&status=completed&search=abc123&limit=50&offset=0
```

| Param | Meaning |
|---|---|
| `type` | e.g. `send`, `wallet_topup`, `exchange_complete`, `refund` |
| `status` | e.g. `completed`, `pending`, `failed` |
| `search` | matches transaction ID or currency (case-insensitive) |
| `from` / `to` | ISO date range on `created_at` |
| `limit` / `offset` | pagination (max 200 per page) |

The Flutter History screen now has a search box and quick filter chips
(Sent / Top-up / Exchange / Refund / Completed / Pending / Failed).

### 2. Users Can Now See Their Own Exchange Order History
Previously only admins could list exchange orders (`/api/admin/exchange/orders`).
Users had no way to see their own convert/exchange history beyond the generic
transactions list. New endpoint:

```
GET /api/exchange/orders/mine?status=completed
```

Shown in the app via **Convert screen → "My Exchange Order History"**, including
each order's 0.2% reward amount.

### 3. Printable/Downloadable Receipts (No New Backend Dependency)
Rather than adding a PDF-generation library to the Node backend (which would
add build complexity/risk to the Codemagic pipeline), receipts are rendered
as a clean, print-optimized HTML page. The user's phone browser handles
"Save as PDF" via its native print dialog — this works identically on
Android and iOS without any extra app permissions or packages beyond a
lightweight link launcher.

**Flow:**
1. App calls `POST /api/receipts/token` with either `transactionId` or
   `exchangeOrderId` (ownership is verified server-side).
2. Backend returns a short-lived (15 minute), single-purpose token — never
   the user's real JWT.
3. App opens `GET /api/receipts/:token` in the external browser
   (`url_launcher` package).
4. The page shows a formatted receipt with a "Print / Save as PDF" button.

Exchange order receipts include a full **commission breakdown**: total 1%
fee, the 0.8% platform share, and the 0.2% reward credited to the user.

**Why a token instead of just using the JWT in the URL:** JWTs are
long-lived (7 days) and grant full account access. If one leaked (e.g. via
browser history, a screenshot, or a shared link), the attacker could do
much more than view one receipt. Receipt tokens are scoped to exactly one
record, expire in 15 minutes, and are stored server-side so they can also be
revoked/audited independently of the user's login session.

## New Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/transactions` | User | Filterable/searchable transaction list |
| GET | `/api/exchange/orders/mine` | User | User's own exchange order history |
| POST | `/api/receipts/token` | User | Get a short-lived receipt link for one transaction/order |
| GET | `/api/receipts/:token` | None (token-scoped) | View/print the receipt HTML page |

## Where It Shows Up In The App

- **History screen**: search box + filter chips, tap any transaction → **"View / Download Receipt"** button on the detail screen.
- **Convert screen → "My Exchange Order History"**: lists all your exchange orders with status and reward amount, each with its own **"View / Download Receipt"** button showing the full commission breakdown.
