# UI/UX Polish Guide (v1.8.0+10)

This round of work did **not** touch the backend (`server.js` / `server_pg.js` /
`schema.sql`) — it is a 100% Flutter-app (frontend) polish pass focused on making
the app feel solid on flaky mobile networks and giving users clear feedback
instead of blank screens or raw error text.

## 1. Network layer hardening (`lib/services/api_service.dart`)

- Every HTTP call now goes through a **25-second timeout** (`_requestTimeout`).
  Previously a slow/dead connection could hang forever with a spinning loader.
- A new `_guarded()` wrapper catches the common network failure types and
  converts them into friendly Hinglish messages instead of leaking raw
  Dart/HTTP exception text to the user:
  - `TimeoutException` → "Server is taking too long to respond. Please try again."
  - `SocketException` (no internet / DNS failure) → "No internet connection. Please check your network and try again."
  - `HttpException` / `FormatException` (bad/garbled response) → generic friendly fallback.
- All ~56 raw `http.get/post/patch/delete(...)` call sites across the file were
  routed through new `_get()/_post()/_patch()/_delete()` helpers, which all use
  `_guarded()` internally. This means **every single API call in the app** now
  has consistent timeout + friendly-error behavior, not just a few screens.
- Generic server error message improved: `Something went wrong (error <code>).
  Please try again.` instead of a bare `API error <code>`.

## 2. Two new reusable UI widgets (`lib/main.dart`)

### `ErrorRetryView`
Shown whenever a screen's data fetch fails (network down, server error, etc.)
instead of a blank/broken screen or a plain line of red error text. Shows a
wifi-off icon, a friendly message (customizable per-screen), and a **Retry**
button that re-runs the screen's fetch.

### `EmptyStateView`
Shown whenever a list screen successfully loads but there is genuinely no data
yet (e.g. no notifications, no transactions, no referrals). Replaces
inconsistent ad-hoc "No data" `InfoCard`/`Text` widgets that different screens
had accumulated over time, with one consistent icon + title + subtitle look.

## 3. Pull-to-refresh + Retry + Empty-state added to every major list/data screen

Every screen below now wraps its list content in `RefreshIndicator` (swipe
down to refresh), shows `ErrorRetryView` on fetch failure (with a working
Retry button wired to that screen's own reload function), and shows
`EmptyStateView` with a relevant icon/message when there is no data:

| Screen | Reload function used |
|---|---|
| `UserDashboard` (Home) | `reload()` |
| `NotificationsScreen` | `reload()` |
| `ReferralScreen` | `reload()` |
| `ExchangeHistoryScreen` | `reload()` |
| `HistoryScreen` | `_applyFilters()` (its filter-aware reload) |
| `BankAccountsScreen` | `reload()` |
| `WithdrawScreen` | `reloadWithdrawals()` |
| `WalletScreen` | `refreshWallet()` |
| `ProfileScreen` (converted from `StatelessWidget` to `StatefulWidget` to support this) | `reload()` |
| `SupportScreen` → `_ComplaintsTab` | `reload()` |
| `SupportScreen` → `_DisputesTab` | `reload()` |

Notes:
- `ProfileScreen` and `UserDashboard` (Home) were previously `StatelessWidget`s
  that called `ApiService.me()` fresh on every rebuild with no way to recover
  from a failed fetch except force-closing the app. Both were converted to
  `StatefulWidget` with their own cached `Future` + `reload()` method so the
  new Retry button and pull-to-refresh actually work.
- `WalletScreen` already had a manual "Refresh Wallet" button — this was kept
  (some users may prefer a visible button over swipe gesture) alongside the
  new `RefreshIndicator` swipe-to-refresh and the new error/retry handling
  (which it previously lacked entirely — a failed wallet fetch used to just
  show empty/zero balances silently).

## 4. What this means for testing

After installing the new APK:
- Turn on Airplane Mode, open any list screen (Notifications, History,
  Wallet, Bank Accounts, Withdrawals, Complaints, Disputes, Referrals, Home) →
  you should see the friendly "No internet connection..." message with a
  **Retry** button, not a crash or blank white screen.
- Turn Airplane Mode back off and tap **Retry** → the screen should load
  normally.
- On any of these screens, pull down from the top → a refresh spinner should
  appear and the data should reload.
- On a brand-new account with no notifications / no referrals / no
  transactions / no bank accounts / no withdrawals / no complaints / no
  disputes / no exchange orders yet, each screen should show a clean
  "No X Yet" empty state with an icon, instead of a blank list.

## 5. Version

Bumped app version to **v1.8.0+10** in `pubspec.yaml` and both hardcoded
"Build vX.Y.Z+N" strings in `main.dart` (splash screen + Profile screen App
Build Version card, whose changelog string now also mentions "UI/UX Polish").

No backend redeploy is strictly required for this round since `server.js`/
`server_pg.js`/`schema.sql` were not modified — but it is harmless to
re-upload the zip and let Render redeploy anyway, and required to trigger a
new Codemagic build since Flutter code changed.
