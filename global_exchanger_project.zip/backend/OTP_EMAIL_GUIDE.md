# OTP Login and Email Verification

Implemented APIs:

- `POST /api/auth/request-otp`
- `POST /api/auth/verify-email-otp`
- `POST /api/auth/login-otp`

## Request Email Verification OTP

```json
POST /api/auth/request-otp
{
  "email": "user@example.com",
  "purpose": "email_verification"
}
```

## Verify Email OTP

```json
POST /api/auth/verify-email-otp
{
  "email": "user@example.com",
  "otp": "123456"
}
```

## OTP Login

First request login OTP:

```json
POST /api/auth/request-otp
{
  "email": "user@example.com",
  "purpose": "login"
}
```

Then login:

```json
POST /api/auth/login-otp
{
  "email": "user@example.com",
  "otp": "123456"
}
```

## Email Sending

Currently OTP console me print hota hai. Production me SMTP/SendGrid/AWS SES add karein in `src/otp.js`.
