# Payment Gateway Integration Structure

Implemented files:

- `src/payments/provider.js`
- `POST /api/payments/orders`
- `POST /api/payments/verify`
- `POST /api/payments/webhook`

## Providers

Set in `.env`:

```env
PAYMENT_PROVIDER=mock
```

Supported structure:

```env
PAYMENT_PROVIDER=razorpay
RAZORPAY_KEY_ID=your_key_id
RAZORPAY_KEY_SECRET=your_key_secret
```

or

```env
PAYMENT_PROVIDER=cashfree
CASHFREE_CLIENT_ID=your_client_id
CASHFREE_CLIENT_SECRET=your_client_secret
```

## Flow

1. App calls `POST /api/payments/orders`
2. Backend creates gateway order
3. Flutter opens gateway checkout SDK screen
4. Gateway returns payment id/signature
5. App calls `POST /api/payments/verify`
6. Backend verifies signature/status
7. If paid, wallet top-up transaction is created

## Production Required

- Real provider SDK/API call
- Webhook signature verification
- Idempotency key
- Double-entry wallet ledger
- Refund API
- Dispute handling
- PCI/security review
- RBI/NPCI/payment compliance

## Razorpay Webhook Signature Verification

Added endpoint:

```text
POST /api/payments/webhook
```

Set:

```env
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret
```

Backend verifies `x-razorpay-signature` using HMAC SHA256 of raw request body.

## Refund API

Admin-only API:

```text
POST /api/payments/refund
Authorization: Bearer <adminToken>
{
  "orderId": "payment_order_id",
  "gatewayPaymentId": "pay_xxx_optional",
  "amount": 500,
  "reason": "admin_refund"
}
```

Refund creates refund record, updates payment order status, updates wallet balance, creates refund transaction, and posts ledger entries.
