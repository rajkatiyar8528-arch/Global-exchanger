# Double-Entry Wallet Ledger

Added ledger structure:

- `ledger_accounts`
- `ledger_entries`

Each financial movement creates two equal entries:

- Debit user wallet account
- Credit platform/gateway settlement account

Example wallet top-up:

```text
Debit: user_wallet:<userId>:INR +500
Credit: platform_cash:gateway_settlement:INR -500
```

Admin API:

```text
GET /api/admin/ledger
```

Production recommendation:

- Never update wallet balance without ledger entries
- Use DB transactions and row locks
- Add idempotency keys for payment webhooks
- Add reconciliation reports for gateway settlements

## Ledger Applied To

Now ledger entries are posted for:

- Wallet top-up
- User send/receive wallet transfer
- Payment refund
- Exchange commission accrual
- 0.8% admin commission split
- 0.2% user/seller commission split

Note: For production, exchange completion should use escrow locked balances and settlement ledger entries.
