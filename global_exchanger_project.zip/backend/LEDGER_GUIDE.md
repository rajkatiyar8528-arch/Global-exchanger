# Double-Entry Wallet Ledger

Added ledger structure:

- `ledger_accounts`
- `ledger_entries`

Each financial movement creates two equal entries:

- Debit user wallet account
- Credit platform/gateway settlement account

Example wallet top-up:

```text
Debit: user_wallet:<userId>:INR +500
Credit: platform_cash:gateway_settlement:INR -500
```

Admin API:

```text
GET /api/admin/ledger
```

Production recommendation:

- Never update wallet balance without ledger entries
- Use DB transactions and row locks
- Add idempotency keys for payment webhooks
- Add reconciliation reports for gateway settlements

## Ledger Applied To

Now ledger entries are posted for:

- Wallet top-up
- User send/receive wallet transfer
- Payment refund
- Exchange commission accrual
- 0.8% admin commission split
- 0.2% user/seller commission split
- 0.2% reward credited to the user's `reward_balances` (wallets table) at order creation time
- 0.2% reward reversed automatically if the exchange order is later cancelled by admin
- Reward wallet redeem (`POST /api/wallet/redeem-rewards`) into the main spendable wallet balance

Note: For production, exchange completion should use escrow locked balances and settlement ledger entries.

## Reward Wallet (0.2% User Commission)

The `wallets` table has a `reward_balances` JSONB column (same shape as `balances`).
When a user creates an exchange order:

1. `commission` (1%), `admin_commission` (0.8%), `seller_commission` (0.2%) are calculated on the order amount.
2. The 0.8% admin share is tracked in `commissions` + ledger only (platform revenue).
3. The 0.2% user share is **immediately credited** into `wallets.reward_balances[fromCurrency]`,
   so it is visible to the user in the app right away (not just an accounting entry).
4. If the admin cancels that exchange order later, the same 0.2% is automatically
   reversed out of `reward_balances` (capped at what is still available) to keep
   the reward wallet consistent with real completed exchanges.
5. Users can call `POST /api/wallet/redeem-rewards` to move their reward balance
   for a given currency into their main spendable `balances`.
