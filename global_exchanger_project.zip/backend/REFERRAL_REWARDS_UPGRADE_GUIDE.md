# Referral/Rewards System Upgrade — Guide

Ye guide batati hai ki naya **Milestone Bonus** aur **WhatsApp/SMS Share** feature kaise kaam karta hai.

## Naya Feature #1: Milestone Bonuses

Pehle: har successful referral (jab refer kiya hua friend apna pehla transaction complete karta hai) par sirf **₹100 flat reward** milta tha.

**Ab**: Isी ₹100 ke upar, jab aapke successful referrals ek khaas number tak pahunchte hain, ek **extra bonus** bhi milta hai:

| Milestone | Bonus |
|---|---|
| 5 Successful Referrals | ₹250 |
| 10 Successful Referrals | ₹600 |
| 25 Successful Referrals | ₹2,000 |
| 50 Successful Referrals | ₹5,000 |
| 100 Successful Referrals | ₹15,000 |

**Example**: Agar aapke 5 referrals successful ho jaate hain, to aapko milta hai:
- 5 × ₹100 (normal reward) = ₹500
- + ₹250 (5-milestone bonus)
- **Total = ₹750**

Ye bonus **sirf ek baar** milta hai har milestone ke liye — dobara nahi milega usi threshold ke liye.

## Naya Feature #2: WhatsApp/SMS Share Button

Pehle sirf "Copy Code" button tha. Ab **"Refer & Earn"** screen par 2 naye buttons hain:
- 🟢 **WhatsApp** — direct WhatsApp me ek pre-filled message khulta hai jisme aapka referral code + app link hota hai, bas contact choose karke bhej dein
- 💬 **SMS** — phone ki default SMS app khulti hai, message pehle se likha hota hai

Dono buttons ek click me pura kaam kar dete hain — copy-paste ki zaroorat nahi.

## Milestone Progress UI

"Refer & Earn" screen par ab dikhta hai:
- **Agla Milestone kya hai** aur **kitne aur referrals chahiye** (progress bar ke saath)
- **Sabhi 5 milestones ki list** — jo complete ho chuke hain wo green tick ke saath dikhte hain, baaki lock icon ke saath
- **Total Milestone Bonuses Earned** — alag se dikhaya jaata hai

## Technical Summary

- Naya shared module `referral_milestones.js` — milestone thresholds/amounts ek hi jagah define hain (dono backends use karte hain, drift nahi ho sakta)
- Naya `referral_milestones_paid` table/array — track karta hai kaunse milestones already paid ho chuke hain (double-payment se bachne ke liye — chahe koi bug ho ya retry ho, ek milestone kabhi dobara paid nahi hoga)
- PostgreSQL me `UNIQUE(user_id, milestone_count)` constraint hai — extra safety layer
- `GET /api/referrals/mine` response me naye fields: `totalEarnedFromReferrals`, `totalEarnedFromMilestones`, `milestonesReached`, `allMilestones`, `nextMilestone`, `referralsUntilNextMilestone`
- **51 automated tests** (dono backends) — 5 referred users ne apna pehla transaction complete kiya, verify kiya gaya ki referrer ko sahi ₹750 (₹500 referral + ₹250 milestone) mila, wallet balance sahi, aur milestone dobara na mile
- Koi naya API endpoint nahi add hua — existing `/api/referrals/mine` hi enrich hua hai, route count same (124, dono backends match)
- WhatsApp/SMS share `url_launcher` package (already app me maujood) use karta hai — koi naya dependency nahi

## Business Note

Ye referral program ko zyada engaging banata hai — users ko sirf ek-do logo ko refer karne ke bajaye, zyada logo ko refer karne ke liye incentive milta hai. Jaise-jaise app grow karega, milestone amounts ko admin/business decision se adjust kiya ja sakta hai (`referral_milestones.js` file me ek hi jagah change karna hoga).
