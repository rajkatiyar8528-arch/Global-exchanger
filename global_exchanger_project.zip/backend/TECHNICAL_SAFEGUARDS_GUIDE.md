# Technical Safeguards Guide (v1.8.2+12)

This round implements the technical/engineering half of the risk-reduction
plan from `LEGAL_COMPLIANCE_CHECKLIST.md`: **KYC-tier transaction limits**,
**AML large-transaction flagging**, and **crypto (VDA) TDS deduction**.
These do NOT replace formal RBI/FIU-IND licensing — they reduce operational
and financial exposure while that process is pursued, and are good practice
regardless.

A **critical, unrelated production bug** was also found and fixed during
testing this round — see "Bonus Fix" section below, as it's arguably more
important than the new features.

## 1. New shared module: `backend/src/limits.js`

A single, dependency-free, pure-function module imported by BOTH
`server.js` (JSON) and `server_pg.js` (Postgres), so the actual regulatory
numbers/logic live in exactly one place and can't drift between the two
backends. Configurable via environment variables (see `.env.example`).

## 2. KYC-tier transaction limits

Modeled loosely on RBI's Small-PPI vs Full-KYC-PPI wallet framework
(see `LEGAL_COMPLIANCE_CHECKLIST.md` section 1):

| Tier | Wallet balance cap | Monthly top-up cap | Per-transaction cap | Daily cap | Monthly P2P send cap | Can send money? | Can exchange? | Can withdraw? |
|---|---|---|---|---|---|---|---|---|
| **Not KYC'd** (`kycStatus != 'approved'`) | ₹10,000 | ₹10,000 | — | — | — | ❌ No | ❌ No | ❌ No |
| **KYC Approved** | ₹2,00,000 | (no cap) | ₹2,00,000 | ₹2,00,000 | ₹25,000 | ✅ Yes | ✅ Yes | ✅ Yes |

Enforced at the exact points where money moves:
- **Wallet top-up** (`POST /api/payments/orders` + credit step in
  `POST /api/payments/verify`): blocks orders that would exceed the
  monthly-load cap (non-KYC) or wallet-balance cap (either tier). If a
  payment is somehow already captured by Razorpay before the cap check
  runs (edge case), the credit is rolled back and the incident is logged
  to `auditLogs`/`audit_logs` for manual admin refund/resolution — **this
  is a rare edge case, not the normal flow**, since the check happens
  before crediting in the common path.
- **Send Money** (`POST /api/transactions/send`): blocks if not KYC'd,
  or if the per-transaction/monthly-P2P/daily caps would be exceeded.
- **Currency/Crypto Exchange** (`POST /api/exchange/orders`): blocks if
  not KYC'd, or if the per-transaction cap would be exceeded.
- **Withdrawals** (`POST /api/withdrawals`): blocks if not KYC'd (this
  check already existed; now also subject to the daily aggregate cap).

All limit-breach responses return **HTTP 403** with a clear, actionable
message (e.g. "Monthly send-money limit of ₹25000 reached...").

## 3. AML large-transaction flagging

**Does not block anything** — purely creates an admin-reviewable audit log
entry (`action: 'aml.flag.large_transaction'`) whenever:
- A single transaction's INR-equivalent value is ≥ `AML_SINGLE_TXN_THRESHOLD_INR`
  (default ₹2,00,000), or
- A user's same-day cumulative transaction total is ≥
  `AML_DAILY_AGGREGATE_THRESHOLD_INR` (default ₹3,00,000).

Wired into: wallet top-up, send money, exchange order creation, exchange
completion, and withdrawal request.

**New admin endpoint**: `GET /api/admin/aml-flags` — lists flagged
transactions with the flagged user's identity and the specific reason(s).
**New admin panel section**: "⚠️ AML Flags (Large/Unusual Transactions)"
shows this list directly, no separate tool needed.

## 4. Crypto (VDA) TDS — Section 194S, Income Tax Act 1961

When a user's exchange order **disposes of** a VDA currency (BTC/ETH/XRP as
the `fromCurrency`, converting into anything else), the platform now:

1. Tracks the user's **cumulative gross VDA-transfer value per Indian
   financial year** (April 1 – March 31) in a new `tdsRecords`/`tds_records`
   store.
2. Once cumulative value crosses `CRYPTO_TDS_THRESHOLD_INR` (default
   ₹10,000/year — a deliberately conservative choice, see code comments in
   `limits.js` for why), deducts **1% TDS** (`CRYPTO_TDS_RATE`) on the
   portion above the threshold, from what's credited to the user.
3. Posts a ledger entry: debit the user's wallet, credit a
   `tds_payable_194s` account — so the withheld amount is tracked
   separately and doesn't just vanish from the books.
4. Logs an audit entry (`action: 'tds.crypto.deducted'`) and records a
   detailed entry (gross amount, TDS amount, reference) for that user's
   financial-year TDS record.

**New admin endpoint**: `GET /api/admin/tds-records` — per-user,
per-financial-year cumulative gross value + TDS withheld + individual
deduction entries, which is exactly the data your CA needs to prepare
**Form 26QE** filings (the government form for depositing TDS on VDA
transfers).
**New admin panel section**: "🧾 Crypto TDS Records (Section 194S)".

⚠️ **Important caveat**: this only covers TDS on crypto disposed of
*within this app's exchange feature*. It does NOT cover: (a) TDS on P2P
crypto trades outside the app, (b) the user's own 30%+cess income tax
liability on VDA gains (a separate, much larger tax — TDS is just a
withholding mechanism, not the final tax), or (c) actually filing/
depositing the withheld TDS with the government (Form 26QE) — that
remains a manual finance/compliance operational step using the data this
feature now tracks. Consult your CA.

## 5. Bonus fix: Node.js process crash on malformed input (found during testing)

While testing the above features, direct testing against `server_pg.js`
revealed that **a single malformed request (e.g. a non-UUID value in a URL
parameter) crashed the entire Node.js process**, taking the whole API down
for every user simultaneously until Render restarted it (with cold-start
delay). This is unrelated to the new features above — it was a
pre-existing gap in most `async (req, res) => {...}` route handlers not
having their own try/catch, combined with Express 4's behavior of not
automatically catching async rejections.

**Fixed in both `server.js` and `server_pg.js`** by:
1. Monkey-patching Express's route-registration methods (`get/post/patch/
   put/delete/use`) so every handler is automatically wrapped to forward
   both synchronous throws and async rejections to a proper error handler,
   instead of crashing the process — with zero changes needed to the
   hundreds of existing route definitions.
2. Adding a global Express error-handling middleware (registered last) that
   returns a clean `400`/`500` JSON error instead of Express's default
   HTML error page (which was leaking internal stack traces to clients —
   a security issue in its own right).
3. Adding top-level `process.on('uncaughtException'/'unhandledRejection')`
   handlers as a final safety net that logs loudly instead of silently
   dying, for anything outside the request lifecycle.

**Verified via direct testing**: sent a request that previously crashed the
server (`PATCH /api/admin/kyc/NOT-A-VALID-UUID` with valid admin auth) —
confirmed the server now stays up, returns a clean `400 {"error":"Invalid
request data."}`, and logs the underlying error server-side for
diagnostics, instead of taking the whole app down.

## 6. Testing performed this round

- **Local unit-style test** of `limits.js` (`node -e`): tier limits, FY
  calculation, TDS calculation with sub-threshold/at-threshold/over-
  threshold amounts — all correct.
- **Full local end-to-end test suite (17 new checks)** covering: non-KYC
  monthly-load cap, non-KYC blocked from sending, KYC per-transaction/
  monthly-P2P caps, AML flag creation + retrieval, crypto TDS deduction +
  retrieval — run against BOTH `server.js` (JSON) and `server_pg.js`
  (PostgreSQL, using a real local Postgres instance) — **all 17/17 passed
  on both backends**.
- **Re-ran the original 40-check full-app E2E test suite** (registration
  through referral rewards, exchange, withdrawals, disputes, receipts,
  notifications, admin dashboard, rate limiting) against both backends
  after all these changes — **all 40/40 still passed on both**, confirming
  no regressions.
- **Crash-fix verification**: confirmed the malformed-UUID request that
  previously killed the server no longer does, on the PostgreSQL backend
  (where the bug was found).
- Confirmed both backends still have **exactly the same route count** (69)
  and confirmed `schema.sql`'s new `tds_records` table auto-migrates
  correctly via the existing `autoMigrate()` startup hook.

## 7. What changed in the database

- **New table** `tds_records` (Postgres) / **new array** `tdsRecords`
  (JSON) — auto-migrates via the existing `autoMigrate()` mechanism, no
  manual migration needed.
- No changes to any existing table/array structure.

## 8. What this means for your existing users

- Anyone already using the app with an **approved KYC status** is
  unaffected in practice unless they exceed the new ₹2,00,000 caps (which
  are generous for typical usage).
- Anyone **without approved KYC** will now be blocked from sending money,
  exchanging currency, or withdrawing — they were likely already blocked
  from withdrawing (pre-existing check), but sending/exchanging without
  KYC is a NEW restriction as of this version. If you have real non-KYC'd
  users relying on send/exchange today, they will need to complete KYC to
  continue.
- No existing data is deleted or modified — this is purely new guardrails
  going forward.

## 9. Tuning these limits

All thresholds are environment variables (see `.env.example` /
`.env.postgres.example`) — you can adjust them on Render without a code
change if your risk tolerance or business needs differ from the defaults
suggested here. They are intentionally conservative starting points, not
prescribed legal minimums (except the crypto TDS rate/threshold, which
should stay aligned with actual Section 194S rules unless your CA advises
otherwise).
