# Launch Readiness Checklist (v1.9.4+18)

This is the consolidated, final pre-launch review of Global Exchanger,
pulling together everything built across every previous round (features,
UI/UX polish, legal documents, technical safeguards, FIU-IND compliance
prep) into one actionable checklist. Read this before treating the app as
ready for real users at real scale.

## 1. What was tested this round

A comprehensive **59-check automated launch-readiness test suite** was
written and run against BOTH backends (`server.js` JSON demo backend and
`server_pg.js` real PostgreSQL backend), covering:

- **Security**: weak passwords rejected, duplicate emails rejected, wrong
  login rejected, admin endpoints properly blocked for non-admins,
  security headers present, admin login rate-limiting triggers correctly.
- **Auth**: registration, login, refresh token rotation.
- **KYC & Sanctions**: submission, admin approval, sanctions dataset has
  multiple sources configured (OFAC + UN + India MHA).
- **Tiered limits**: non-KYC users correctly blocked from large top-ups.
- **Wallet & Payments**: top-up, balance reflects correctly.
- **Security PIN**: sequential PINs (1234) correctly rejected, repeated-
  digit PINs (1111) correctly rejected, non-sequential PINs accepted, wrong
  PIN blocks a send, correct PIN allows it, self-send blocked.
- **Referral system**: reward fires only after referred user's first
  qualifying transaction (not at signup).
- **Currency exchange**: order creation, escrow lock, admin completion,
  wallet correctly shows converted balance + reward credit.
- **Bank accounts & Withdrawals**: full lifecycle — add account, blocked
  until admin-verified, request → approve → processing → completed, locked
  amount correctly appears then correctly clears.
- **Support**: complaints, disputes, receipt generation (short-lived
  public token).
- **Notifications**: correctly generated from prior actions.
- **Admin dashboard/analytics**: load correctly.
- **Technical safeguards**: AML flags, TDS records, sanctions flags,
  Travel Rule records, STR reports — all endpoints accessible and
  returning data.
- **Crash safety**: a deliberately malformed request (invalid UUID) is
  handled gracefully with a structured error, and the server remains alive
  and responsive immediately afterward.

**Result: 59/59 passed on `server.js`, 59/59 passed on `server_pg.js`**
(after one real bug fix found and corrected during this testing — see
below).

## 2. Bug found and fixed this round

**Inconsistent HTTP status code for wrong Security PIN between backends.**
`server.js` (JSON) correctly returned `403 Forbidden` when a user entered
the wrong Security PIN while sending money. `server_pg.js` (PostgreSQL)
was returning `400 Bad Request` for the same scenario, because the
generic error-handling logic in that endpoint only distinguished
"tier-limit errors" (403) from "everything else" (400), and didn't
separately track a wrong-PIN error as also being a 403-appropriate
(permission-denied) case rather than a 400-appropriate (bad-request) case.

**Fixed** by explicitly tracking a `pinError` flag alongside the existing
`limitError` flag in `server_pg.js`'s send-money handler, so both backends
now consistently return `403` for an incorrect PIN. This matters for any
future client code (mobile app, admin panel, or third-party integrations)
that might branch logic on the specific status code returned.

## 3. Route & schema parity (re-confirmed)

- `server.js` and `server_pg.js`: **exactly 78 matching API routes** —
  zero drift between the JSON demo backend and the production PostgreSQL
  backend.
- `db.json`'s 24 top-level array keys match `schema.sql`'s 24
  `CREATE TABLE IF NOT EXISTS` statements — no missing migrations.
- All source files (`server.js`, `server_pg.js`, and all 11 supporting
  modules in `backend/src/`) pass `node -c` syntax validation.
- `main.dart` and `api_service.dart` pass brace/parenthesis balance
  checks.

## 4. Feature completeness summary (everything built to date)

| Area | Status |
|---|---|
| Registration, login, JWT + refresh token rotation | ✅ Complete |
| Admin login with RBAC (role-based permissions) | ✅ Complete |
| KYC submission with document upload + admin review | ✅ Complete |
| Sanctions/PEP screening at KYC time (OFAC+UN+India MHA, 20,000+ entries) | ✅ Complete |
| Multi-currency wallet (INR/USD/EUR/BTC/ETH/XRP) | ✅ Complete |
| Send money (P2P) with Security PIN | ✅ Complete |
| QR code payment requests | ✅ Complete |
| Wallet top-up via Razorpay (confirmed LIVE mode) | ✅ Complete |
| Currency/crypto exchange with escrow | ✅ Complete |
| Commission split (1% total: 0.8% platform / 0.2% user reward) | ✅ Complete |
| Reward wallet + redeem-to-main-wallet | ✅ Complete |
| Referral program (fraud-resistant: rewards on first real transaction only) | ✅ Complete |
| Bank account management + withdrawal lifecycle | ✅ Complete |
| Complaints & disputes (user-facing + admin management) | ✅ Complete |
| Transaction receipts (short-lived public tokens) | ✅ Complete |
| In-app + email notifications | ✅ Complete |
| Admin dashboard with analytics/charts | ✅ Complete |
| Security hardening (rate limiting, CORS, security headers, strong password enforcement) | ✅ Complete |
| KYC-tier transaction limits (non-KYC vs approved-KYC caps) | ✅ Complete |
| AML large-transaction flagging | ✅ Complete |
| Crypto TDS calculation (Section 194S, 1%) | ✅ Complete |
| Sanctions/PEP screening (OFAC + UN + India MHA, auto-updating) | ✅ Complete |
| Travel Rule data capture for VDA transfers | ✅ Complete |
| Suspicious Transaction Report (STR) case tracking | ✅ Complete |
| Server crash-safety (global error handling, no single bad request can take down the app) | ✅ Complete |
| UI/UX polish (pull-to-refresh, retry-on-error, empty states) | ✅ Complete |
| Legal documents (Terms, Privacy, Refund, Grievance) drafted + published | ✅ Complete (needs lawyer review — see below) |
| FIU-IND registration guide | ✅ Complete (registration itself not yet done — see below) |

## 5. What is NOT yet done — read this before real launch

Being direct, as in every previous round's guides:

### Legal / Regulatory (business-critical, not just technical)
- [ ] **No RBI licensing** for the wallet/PPI functionality — see
  `LEGAL_COMPLIANCE_CHECKLIST.md` section 1.
- [ ] **No RBI Authorised Dealer status** for forex conversion — see
  `LEGAL_COMPLIANCE_CHECKLIST.md` section 2.
- [ ] **No FIU-IND registration completed** for the crypto/VDA features —
  the technical prerequisites (KYC, sanctions screening, Travel Rule, STR
  tracking, TDS) are now built, but formal registration itself requires an
  in-person meeting and a CA/compliance firm's involvement — see
  `FIU_IND_REGISTRATION_GUIDE.md`.
- [ ] **Legal documents need a lawyer's review** and the bracketed
  placeholders (`[INSERT LEGAL ENTITY NAME]`, Grievance Officer's real
  name, etc.) filled in — see `LEGAL_DOCUMENTS_UPDATE_GUIDE.md`.
- [ ] **Sanctions dataset is a starter/demo dataset by default** in the
  shipped ZIP (42 entries) until the first sync runs — make sure a sync
  has actually completed successfully on your live Render deployment
  before considering sanctions screening "live" (check the admin panel's
  sanctions metadata — should show 20,000+ entries and multiple sources).

### Operational
- [ ] **Withdrawals are 100% manual** — marking a withdrawal "completed"
  in the admin panel does NOT move real money; you must manually transfer
  funds via your bank's NEFT/IMPS/UPI outside the app. Any delay here is a
  trust and potential legal issue at scale.
- [ ] **No automated STR filing** — the STR case-tracking feature helps
  organize the process, but actually submitting a Suspicious Transaction
  Report to FIU-IND remains a manual action by your Principal Officer via
  their FINGate portal.
- [ ] **Admin default credentials** (`admin@globalexchanger.com` /
  `Admin@12345` / `GX-SUPER-KEY-2026`) — confirm these have been changed
  via Render environment variables (`ADMIN_EMAIL`, `ADMIN_PASSWORD`,
  `ADMIN_SPECIAL_KEY`) on your live deployment, since these defaults are
  now public knowledge (documented in multiple guides across this
  project's history).
- [ ] **`SANCTIONS_CRON_SECRET`** — set this on Render if you want the
  weekly GitHub Actions auto-sync to work (optional but recommended — see
  `AUTOMATIC_SANCTIONS_SYNC_SETUP_GUIDE.md`).
- [ ] **`CORS_ALLOWED_ORIGINS`** — currently allows all origins if unset
  (logged as a warning on every server start). Recommended to lock this
  down to your actual admin panel domain before scaling up traffic.

### Testing gaps this automated suite CANNOT cover
- Real Razorpay payment flow with actual money (only mock/test mode
  tested here).
- Real device testing of the Flutter APK (camera KYC upload, biometric
  lock, push notifications, actual UI rendering across different Android
  versions/screen sizes).
- Load/stress testing under concurrent real users.
- Actual email/SMS delivery (OTP, notifications) via your configured
  provider (Brevo/Resend/SMTP) — verify these are actually configured and
  delivering on the live Render deployment, not just the mock/dev fallback.

## 6. Recommended pre-launch action sequence

If you intend to launch to real users processing real money soon, in
priority order:

1. **Talk to a lawyer and a CA/compliance firm** about the RBI/FEMA/
   FIU-IND licensing gaps — this is the single most important non-technical
   item, given real Razorpay payments are already live.
2. **Fill in the legal document placeholders** and get them lawyer-reviewed
   before treating them as binding.
3. **Manually verify on your live Render deployment**: admin credentials
   changed, `JWT_SECRET` set to a real random value, `PAYMENT_PROVIDER`
   and Razorpay keys correctly configured, `CORS_ALLOWED_ORIGINS` locked
   down, sanctions list successfully synced (20,000+ entries visible in
   admin panel).
4. **Do a real end-to-end test with a small real payment** (₹10-50) via
   the actual Razorpای checkout on a real device, to confirm the live
   payment flow works exactly as the mock-mode tests suggest.
5. **Test the actual Android APK** on 2-3 different real devices/Android
   versions, focusing on KYC document camera upload, biometric lock, and
   notification delivery — none of which the automated backend test suite
   can verify.
6. **Set up the weekly GitHub Actions sanctions sync** (5-minute one-time
   setup, see `AUTOMATIC_SANCTIONS_SYNC_SETUP_GUIDE.md`) so your sanctions
   screening stays current without manual intervention.
7. Consider a **small, controlled soft-launch** (friends/family, small
   transaction limits) before opening broadly, given the outstanding
   licensing gaps — this reduces both regulatory and reputational risk
   while you work through item 1.

## 7. Version

Bumped to **v1.9.4+18**.
