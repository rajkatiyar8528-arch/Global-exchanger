# Admin Panel Upgrade: Search/Filter/Pagination, CSV Export, New Feature Views, Better Roles UI

Four admin-panel improvements requested together in one go. All backend
changes are implemented in **both** backends (`server.js` JSON demo and
`server_pg.js` PostgreSQL production) with matching behaviour.

## 1. Search / Filter / Pagination

**Problem:** the Users, KYC, and (missing entirely) Transactions tables
always loaded and rendered EVERY matching record in one response — fine
with a handful of test users, but would get slow and unwieldy once the
platform has hundreds/thousands of real users.

**What changed:**
- `GET /api/admin/users` now accepts `?search=` (matches name/email/phone/
  referral code), `?kycStatus=` filter, and `?limit=`/`?offset=`
  pagination. Returns a `X-Total-Count` response header with the total
  matched count (before pagination) so the UI can render "Page 2 of 14".
- `GET /api/admin/kyc-requests` now accepts `?search=` and `?status=`
  filters (KYC lists tend to be smaller, so no pagination was added here
  — filtering alone keeps it manageable).
- **New endpoint** `GET /api/admin/transactions` — previously there was
  **no way at all** to see individual transactions in the admin panel,
  only aggregate dashboard metrics. Supports `?search=` (transaction ID
  fragment, currency, or either party's email), `?type=`/`?status=`
  filters, and `?limit=`/`?offset=` pagination with the same
  `X-Total-Count` header convention.
- Admin Panel: Users and Transactions tables now have a search box,
  relevant filter dropdowns, and Prev/Next pagination controls showing
  "Page X of Y (Z total)". KYC table has search + status filter (no
  pagination, per above).

## 2. Admin Views for Price Alerts, Watchlist, Referral Leaderboard

**Problem:** three recently-added user-facing features (Price Alerts,
Watchlist, Referral Leaderboard) had zero admin-side visibility — no way
for admin/support staff to see what's happening with them platform-wide.

**New endpoints (both backends):**
- `GET /api/admin/price-alerts?status=` — every user's price alerts,
  with `userEmail` attached, optional status filter. Useful for gauging
  interest in specific pairs and helping a user troubleshoot "why didn't
  my alert fire".
- `GET /api/admin/watchlist-summary` — aggregate count of how many times
  each currency/crypto pair is pinned across all users (`{ summary: [{pair,
  count}], totalPins }`). Useful signal for which live-rate sources matter
  most to keep reliable.
- `GET /api/admin/referral-leaderboard?limit=` — the **unmasked** full
  leaderboard (real names/emails), unlike the user-facing
  `GET /api/referrals/leaderboard` which deliberately masks names for
  privacy (see `FEATURE_PACK_3_GUIDE.md`). Lets support/admin staff
  actually identify and reach out to top referrers (e.g. a manual bonus).

**Admin Panel:** three new sections — "🔔 Price Alerts" (with status
filter + CSV export), "⭐ Watchlist Summary" (pair-ranked table + total
pins count), "🏆 Full Referral Leaderboard" (rank/name/email/count table).

## 3. CSV Export

**What changed:** a single, dependency-free `exportToCsv(filename, rows,
columns)` JS helper function, entirely client-side (builds a CSV string,
creates a `Blob`, triggers a download via a temporary `<a download>`
element — no new backend endpoint needed). Added a "⬇️ Export CSV" button
to essentially every data table in the panel: Users, KYC Requests,
Transactions, Payment Orders, Disputes, Referrals, Bank Accounts,
Withdrawals, Audit Logs, AML Flags, TDS Records, Price Alerts.

For the paginated tables (Users, Transactions), a separate
`fetchAllPages()` helper re-fetches **every** matching page (up to a
2000-row safety cap) specifically for the export, so the downloaded CSV
always has every matching record — not just whatever fits on the
currently-visible page (the on-screen table intentionally stays paginated
for speed; export intentionally does the extra work to be complete).

## 4. Staff Roles / Permissions — Better UI (+ a real safety bug found & fixed)

**Problem:** editing an admin's role previously used raw browser
`prompt()` dialogs asking the admin to type a role name and
comma-separated permission strings **from memory**, with zero indication
of what any role or permission actually grants.

**What changed:**
- New proper modal (`openRoleModal`): a role-preset dropdown
  (`super_admin`/`kyc_manager`/`finance_manager`/`support_agent`/`custom`)
  that auto-fills matching permission checkboxes when a preset is picked,
  with each permission checkbox showing a plain-language label and
  description (e.g. "Manage Admin Roles — Change other admins' roles and
  permissions (sensitive...)"). Manually toggling any checkbox
  auto-switches the dropdown to "Custom".
- A separate "📖 View Role Definitions" reference modal explains what each
  of the 4 preset roles is for and exactly which permissions it includes
  — useful before ever opening the edit modal.

**🐛 Real bug found and fixed during testing:** while testing the new
checkbox UI, an admin's `admin:manage` permission was removed via a
"custom" role update — and the account was **instantly locked out** of
role management (and thus of fixing the mistake), since Render's free
tier has no Shell access to directly edit the database. This would have
been genuinely unrecoverable without a manual data-fix deploy.

**Fix:** both `PATCH /api/admin/admins/:id/role` endpoints (JSON and
Postgres) now check, before applying any role/permission change, whether
the update would leave the platform with **zero** admins holding
`admin:manage` (via `role === 'super_admin'`, `permissions` containing
`'*'`, or `permissions` containing `'admin:manage'` directly). If so, the
request is rejected with `400` and a clear Hinglish explanation, and the
admin's existing role/permissions are left completely unchanged. This
only blocks the specific case where doing so would remove the *last*
admin with this permission — if at least one other admin already holds
`admin:manage`, the change goes through normally (so legitimate
role-narrowing is never blocked).

**Verified via automated testing (both backends):** confirmed the exact
lockout scenario is now blocked with `400` (and the admin's role/
permissions remain unchanged afterward), while a role change that keeps
`admin:manage` is still allowed.

## Testing performed this round

- New automated test suite (`test_admin_panel.py`, 26 checks) covering:
  users search/filter/pagination (with `X-Total-Count` header
  verification), KYC search/filter, transactions list/search/type-filter/
  status-filter/pagination, non-admin access correctly blocked,
  price-alerts admin view + status filter, watchlist summary, full
  referral leaderboard, role presets endpoint, and the lockout-safety
  behavior (both the blocked case and the allowed case) — **26/26 passed
  on both backends**.
- Separate focused test (`test_admin_lockout_safety.py`, 4 checks)
  specifically exercising the admin-lockout bug found during this round —
  **4/4 passed on both backends**, confirming: (a) removing the last
  `admin:manage` holder is blocked with `400`, (b) the admin's role is
  verifiably unchanged after the blocked attempt (re-fetched and
  compared), (c) a custom role that retains `admin:manage` is still
  allowed, (d) restoring to `super_admin` works.
- Route-count parity re-verified: **108 matching routes** on both
  backends (up from 104, +4 for `/api/admin/transactions`,
  `/api/admin/price-alerts`, `/api/admin/watchlist-summary`,
  `/api/admin/referral-leaderboard`).
- Full regression re-check of core pre-existing flows (register, login,
  `/api/me`, watchlist, price-alerts, settings, scheduled-payments,
  analytics, leaderboard, complaints) — all still return `200` on both
  backends, no regression introduced.
- `node -c` syntax check passed on both `server.js` and `server_pg.js`.
- Admin Panel JavaScript extracted and validated via `node -c`.

## Not changed / deferred

- The Flutter mobile app was **not touched** this round — this was a
  pure backend + Admin Panel (web) round. App version stays at
  `v1.11.1+23`.
- Full-text search here is simple substring matching (`ILIKE`/
  `.includes()`), not a proper search index — fine at the current/
  near-term scale, would need revisiting (e.g. Postgres full-text search
  or a dedicated search service) at much larger user counts.
