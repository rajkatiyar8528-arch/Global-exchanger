# Security Hardening — What Changed and Why

This pass focused on real, exploitable issues found by auditing the actual
backend/admin-panel code — not generic advice. Each item below is something
that was verified in the code before being fixed.

## ⚠️ ACTION REQUIRED BEFORE YOU DEPLOY

### 1. `JWT_SECRET` is now mandatory
Previously, if `JWT_SECRET` was missing from the environment, the server
silently fell back to the hardcoded string `'dev_secret_change_me'`. Since
this repo is public, that default is now public knowledge — anyone could
have forged valid login tokens (including **admin** tokens) against your
live backend.

**The server now refuses to start at all if `JWT_SECRET` is not set.**

➡️ On Render: go to your backend service → Environment → add `JWT_SECRET`
with a long random value (e.g. generate one with `openssl rand -hex 32`).
**Do this before your next deploy, or the backend will crash on startup.**

### 2. `RAZORPAY_WEBHOOK_SECRET` is now mandatory when live
If `PAYMENT_PROVIDER=razorpay` and `RAZORPAY_WEBHOOK_SECRET` is not set, the
webhook endpoint now **rejects all webhook calls** (returns 500) instead of
silently accepting unverified ones. Set this in Razorpay Dashboard → Webhooks
→ your webhook's secret, and add it to Render env vars.

### 3. Admin panel login form no longer pre-fills credentials
The admin panel HTML used to have the default admin email/password/special
key **pre-typed into the login form** — visible to anyone who opened the
page's source. This has been removed; you must type your real credentials
each time (or use a password manager).

## What Else Was Fixed

| Issue | Fix |
|---|---|
| No rate limiting anywhere | Added in-memory rate limiting on login, admin login, OTP request/verify, registration, send-money PIN attempts, and a general 120 req/min per-IP limit on all `/api/*` routes |
| OTP could leak in API response in production | `devOtp` in the response now requires explicitly setting `ALLOW_DEV_OTP_IN_RESPONSE=true` — never inferred from `NODE_ENV` (which Render doesn't reliably set) |
| Weak/no password policy | Registration now requires 8+ characters with letters and numbers |
| Guessable security PIN allowed (`0000`, `1234`, etc.) | PIN creation now rejects all-same-digit and simple sequential PINs |
| Login responses could reveal whether an email is registered (timing attack) | Login now always runs a bcrypt comparison (against a dummy hash if the user doesn't exist) so response timing doesn't leak account existence |
| Stored XSS in the admin panel | Every place that renders user-supplied data (names, emails, complaint text, KYC fields, dispute messages, audit log fields) now goes through an `escapeHtml()` helper before being inserted into the page |
| Broken HTML structure in admin panel (`</html>` appeared mid-file, followed by more markup) | Rewrote the file as one valid HTML document |
| No security response headers | Added `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy` to every response |
| CORS allowed any origin unconditionally | Added `CORS_ALLOWED_ORIGINS` env var (comma-separated). If unset, still allows all origins (so nothing breaks by default) but logs a warning |
| `req.ip` unreliable behind Render's proxy | Added `app.set('trust proxy', 1)` so rate limiting keys on the real client IP, not Render's proxy IP |

## New Environment Variables

Add these in Render → Environment:

```env
JWT_SECRET=<a long random string>              # REQUIRED, server won't start without it
CORS_ALLOWED_ORIGINS=https://your-username.github.io   # optional but recommended
ALLOW_DEV_OTP_IN_RESPONSE=false                # keep false in production
```

## Rate Limits Applied

| Endpoint | Limit |
|---|---|
| `POST /api/auth/register` | 10 per hour per IP |
| `POST /api/auth/login` | 10 per 15 min per IP+email |
| `POST /api/admin/login` | 5 per 15 min per IP+email |
| `POST /api/auth/request-otp` | 5 per 10 min per IP+email |
| `POST /api/auth/verify-email-otp`, `/login-otp` | 10 per 10 min per IP+email |
| `POST /api/transactions/send` (wrong PIN attempts) | 8 per 15 min per user |
| All other `/api/*` routes | 120 per minute per IP |

These are in-memory (per server process). If you later scale to multiple
Render instances, move this to a shared store (e.g. Redis) so limits are
enforced consistently across instances.

## Still Recommended (Not Done In This Pass)

- Move from long-lived 7-day JWTs to short-lived access tokens + refresh
  tokens, so a leaked token has a smaller window of misuse.
- Add 2FA for admin accounts specifically (beyond the existing special key).
- Set up a Web Application Firewall / DDoS protection (e.g. Cloudflare) in
  front of Render for production traffic.
- Regularly rotate `JWT_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, and admin
  credentials, especially since this repo has been public.
