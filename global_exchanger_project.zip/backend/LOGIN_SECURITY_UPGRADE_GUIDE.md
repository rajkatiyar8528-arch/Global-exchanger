# Login Security Upgrade — Access + Refresh Tokens

## The Problem With The Old Design

Every login (user or admin) issued a single JWT valid for **7 days**, with
absolutely no way to invalidate it before it naturally expired. If a token
ever leaked — a stolen/unlocked phone, a compromised device, a token
accidentally logged somewhere — the attacker had up to **7 days of full,
unstoppable account access**. "Logout" only deleted the token from the app;
the token itself remained valid on the server the whole time.

## The New Design

| | Old | New |
|---|---|---|
| Token lifetime | 7 days | Access token: **15 minutes**. Refresh token: 30 days |
| Revocable before expiry? | No | Yes — logout, "logout everywhere", or automatic theft detection |
| What's used for API calls | The 7-day JWT itself | The 15-minute access token |
| What happens after 15 min | Nothing (still valid for days) | Access token expires; app **silently** exchanges the refresh token for a new one — no re-login needed |

### Access Token
A normal JWT (unchanged mechanism), now valid for only 15 minutes. Used in
the `Authorization: Bearer <token>` header for every API call, exactly as
before.

### Refresh Token
A high-entropy random string (not a JWT), valid for 30 days. Used **only**
to call `POST /api/auth/refresh` and obtain a new access token. It is:
- **Stored server-side** as a SHA-256 hash in the new `refresh_tokens` table (never in plaintext, never in the JWT itself).
- **Rotating**: every time it's used, it's immediately marked revoked and a brand new one is issued in its place.
- **Theft-detectable**: if an already-revoked (already-rotated-away) refresh token is ever presented again, that's a strong signal someone has a stale copy of it (e.g. it leaked earlier and is being replayed). The server responds by revoking the **entire token family**, logging out every session that descended from that original login — both the attacker and the legitimate user will need to log in again, but the account is immediately secured.

## New Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/refresh` | None (refresh token in body) | Exchange a valid refresh token for a new access + refresh token pair |
| POST | `/api/auth/logout` | None (refresh token in body) | Revoke one refresh token (real server-side logout) |
| POST | `/api/auth/logout-all` | Access token | Revoke **all** refresh tokens for the current user/admin — "logout everywhere" |

All existing login endpoints (`/api/auth/register`, `/api/auth/login`,
`/api/auth/login-otp`, `/api/admin/login`) now return **both** `token`
(access) and `refreshToken`, plus `refreshTokenExpiresAt`.

## How The App Handles This (Automatically — No User-Visible Change)

- `ApiService` now stores both `token` and `refreshToken` (separately for
  user vs admin sessions).
- Every authenticated API call is wrapped so that if the server responds
  with `401` and `code: "TOKEN_EXPIRED"`, the app **silently** calls
  `/api/auth/refresh`, updates its stored tokens, and retries the original
  request once — the calling screen never even knows the token expired.
- If the refresh token itself is invalid/expired/revoked (e.g. it's been 30+
  days, or theft was detected), the refresh call fails and the session is
  cleared — the user is routed back to login, exactly as if any login
  session had simply ended.
- **Logout** now calls `POST /api/auth/logout` to properly revoke the
  refresh token server-side, in addition to clearing it locally.
- **"Logout From All Devices"** (new button on the Profile screen) calls
  `POST /api/auth/logout-all`, revoking every active session for the
  account — useful if the user suspects their account or another device is
  compromised.

## Admin Panel

The standalone web admin panel (`admin_panel/index.html`) was updated the
same way: it now stores a refresh token alongside the access token in
`localStorage`, and automatically refreshes on `TOKEN_EXPIRED` responses so
a long admin session isn't interrupted every 15 minutes. Logging out from
the panel now also revokes the refresh token server-side.

## Database

New table: `refresh_tokens` (Postgres) / `db.refreshTokens` (JSON demo
backend). Each row/entry tracks: token hash, family ID (links a chain of
rotations back to the original login), owner type/ID, revoked flag, and
expiry. Old, expired/revoked rows are safe to periodically prune if the
table grows large, but are otherwise harmless to keep for audit purposes.
