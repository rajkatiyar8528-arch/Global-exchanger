# Two-Factor Authentication (2FA) — Guide

Ye guide batati hai ki app me naya **Two-Factor Authentication (2FA)** feature kaise kaam karta hai — Google Authenticator, Microsoft Authenticator, ya Authy jaisi kisi bhi standard authenticator app ke saath compatible.

## Ye Feature Kya Karta Hai

Normally login sirf **email + password** se hota hai. Agar kisi tarah se password leak ho jaaye (data breach, phishing, kisi aur app se reuse), to attacker seedha login kar sakta hai.

2FA on karne ke baad, login ke 2 steps ho jaate hain:
1. **Email + Password** (jaisa pehle tha)
2. **6-digit code** jo har 30 second me badalta hai, aur sirf user ke phone ke authenticator app me dikhta hai

Matlab attacker ko sirf password se kaam nahi chalega — usko user ka physical phone bhi chahiye hoga.

## User Ke Liye — Kaise Enable Karein

1. App me **Profile → App Settings** kholein
2. Neeche **"Two-Factor Authentication (2FA)"** section dikhega
3. **"Enable 2FA"** button dabayein
4. Screen par ek **QR code** dikhega
5. Phone me **Google Authenticator** (ya koi bhi authenticator app) install karein (agar pehle se nahi hai)
6. Authenticator app me "+" button dabakar QR code scan karein
   - Agar scan na ho paaye, to neeche diya "Setup Key" manually type kar sakte hain
7. Authenticator app me ek 6-digit code dikhega — wo code app me daalke **"Confirm & Enable 2FA"** dabayein
8. Ab **8 Backup Codes** dikhenge — inhe kahin safe jagah save/likh lein (screenshot bhi le sakte hain), ye sirf ek hi baar dikhte hain!
9. Ab se login karte waqt password ke baad ek 6-digit code bhi maangega

## Agar Phone Kho Jaaye Ya Authenticator App Delete Ho Jaaye

Isi liye **Backup Codes** diye jaate hain — login screen par "Authenticator kho gaya? Backup code use karein" par click karke, saved backup codes me se koi bhi ek daal dein (har code sirf ek baar chal sakta hai).

## Emergency Unlock — Agar Backup Codes Bhi Na Hon (Admin Panel Se)

Agar user apna authenticator app **aur** backup codes dono kho de, to wo khud login nahi kar payega — ye 2FA ka poora point hai (koi bhi bina second factor ke andar na aa sake). Is situation ke liye Admin Panel me ek **Emergency Unlock** feature hai:

1. Admin Panel → **Users** section kholein
2. Locked-out user ko dhoondein (naam/email se search kar sakte hain)
3. Us user ki row me "2FA" column me **"ON"** dikhega, saath me **"🔓 Unlock"** button
4. Button dabayein, confirm karein
5. Us user ka 2FA turant OFF ho jayega — ab wo sirf password se login kar sakega

⚠️ **Zaroori**: Ye button dabane se pehle user ki identity verify kar lein (phone call, email confirm, KYC details match karke) — kyunki jo bhi is button ko access kar sakta hai, wo kisi bhi user ka 2FA hata sakta hai. Isliye ye action sirf admin panel access wale logon (aap khud) ke paas hai, aur har use `admin.audit_logs` me record hota hai (kaunse admin ne, kis user ka, kab 2FA off kiya) — "Admin Audit Logs" section me dikh jayega.

**Agar aap khud locked out ho gaye hain** (apna hi account): admin panel se apne user account ka bhi 2FA isi tarah unlock kar sakte hain — apna email search karke "🔓 Unlock" dabayein, phir normal password se login ho jayega. Chahen to baad me dobara 2FA enable kar sakte hain aur is baar backup codes ka screenshot zaroor save kar lein.

## 2FA Disable Kaise Karein

Settings me "Manage 2FA" → "Disable 2FA" → apna current password confirm karein. Password isliye maanga jaata hai taaki koi aur (jisne phone utha liya, session already khula hai) chupke se 2FA band na kar sake.

## Technical Details (Developer/Compliance Reference)

- **Algorithm**: TOTP (RFC 6238) — HMAC-SHA1, 6-digit codes, 30-second time step. Same standard jo Google/Microsoft/Authy authenticator apps use karte hain — koi custom/proprietary format nahi.
- **Verified against official RFC 6238 test vectors** — implementation ko 5 known-correct test cases se match karke verify kiya gaya hai.
- **Secret storage**: TOTP secret database me **AES-256-GCM encrypted** store hota hai (plaintext me kabhi nahi) — encryption key `TOTP_ENCRYPTION_KEY` environment variable se aati hai (agar set nahi hai, to `JWT_SECRET` se derive hoti hai, taaki feature bina extra config ke bhi kaam kare).
- **Backup codes**: bcrypt-hashed store hote hain (password jaisa) — server unhe kabhi plaintext me wapas nahi padh sakta, sirf compare kar sakta hai.
- **Clock drift tolerance**: ±30 seconds ki window rakhi gayi hai, taaki agar phone/server ka time thoda alag ho to bhi valid code accept ho jaaye.
- **Pending login tokens**: Password sahi hone ke baad, real session turant nahi milta — ek short-lived (5 minute) "pending" token milta hai jo sirf 2FA verification ke liye use ho sakta hai. Galat code try karne se ye token khatam nahi hota (user dobara try kar sakta hai), lekin sahi code milte hi turant consume ho jaata hai — replay attack se surakshit.
- **Rate limiting**: 2FA verification attempts bhi existing OTP-verification rate limiter (`otpVerifyLimiter`) se protected hain — brute-force se bachne ke liye.

## Optional: Extra Security ke Liye `TOTP_ENCRYPTION_KEY`

Render.com pe agar aap chahte hain ki TOTP secret ki encryption key `JWT_SECRET` se bilkul alag ho (defense-in-depth — agar kabhi `JWT_SECRET` leak ho, to bhi TOTP secrets surakshit rahein), to Render Environment me ek naya variable add kar sakte hain:
- Key: `TOTP_ENCRYPTION_KEY`
- Value: koi bhi lambi random string (jaise 32+ characters)

Ye optional hai — bina iske bhi feature poori tarah kaam karega.

## Business/Compliance Note

RBI/FIU-IND guidelines financial apps ke liye strong authentication recommend karte hain. 2FA add karna is direction me ek positive step hai, khaaskar high-value users (jinke wallet me zyada balance hai) ke liye. Future me isse "mandatory 2FA above ₹X balance" jaisi policy bhi banayi ja sakti hai agar zaroorat pade.
