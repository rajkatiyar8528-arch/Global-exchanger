# Forgot Password — Guide

Ye guide batati hai ki naya **"Forgot Password"** feature kaise kaam karta hai — agar user apna login password bhool jaaye, to wo khud email OTP verify karke naya password set kar sakta hai, bina admin ki help ke.

## User Ke Liye — Kaise Use Karein

1. App ke **Login screen** par, password field ke neeche **"Password bhool gaye?"** link dikhega
2. Us par click karein
3. Apna **registered email** daalein
4. **"Send OTP"** dabayein — email par ek 6-digit OTP aayega
5. OTP daalein, phir **naya password** set karein (2 baar — confirm karne ke liye)
6. **"Reset Password"** dabayein
7. Ab naye password se login ho jaayega

## Security Design (Zaroori Baatein)

- **OTP sirf 10 minute ke liye valid hai**, aur sirf **ek baar** use ho sakta hai
- **Account-enumeration se bachne ke liye**: chahe email registered ho ya na ho, app hamesha wahi generic message dikhata hai ("Agar ye email registered hai, to OTP bhej diya gaya hai") — isse koi bhi ye pata nahi laga sakta ki koi specific email is app par account rakhta hai ya nahi (ye ek common security best-practice hai)
- Password reset hone ke baad, **saare devices/sessions se automatically logout** ho jaata hai (bilkul "Change Password" jaisa) — taaki agar koi aur bhi purane session me login tha, wo turant bahar ho jaaye
- Rate-limited hai — bahut zyada OTP request ya wrong-OTP attempts automatically block ho jaate hain (spam/brute-force se bachne ke liye)

## Admin Ke Liye Reference

Ye feature purely **self-service** hai — admin ko kuch nahi karna padta. Har successful password reset `audit_logs` me `password.reset_via_otp` action ke naam se record hota hai — Admin Panel ke "Admin Audit Logs" section me dikh jaayega (agar kabhi track karna ho ki kisne apna password kab reset kiya).

## In-App Email Setup Zaroori Hai

Ye feature tabhi kaam karega jab backend par email bhejne ka koi provider configure ho (Brevo/Resend/SMTP — dekhें `BREVO_EMAIL_API_SETUP.md` ya jo bhi email guide pehle se maujood hai). Agar koi email provider set nahi hai, to development mode me OTP sirf server logs me console print hota hai (production me kaam nahi karega jab tak real email provider set na ho).
