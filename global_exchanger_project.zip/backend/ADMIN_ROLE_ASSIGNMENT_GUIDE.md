# Admin Role Assignment

Admin APIs:

```text
GET /api/admin/admins
PATCH /api/admin/admins/:id/role
```

Update body:

```json
{
  "role": "finance_manager",
  "permissions": ["payments:read", "refunds:manage", "ledger:read", "exchange:manage", "audit:read"]
}
```

Default roles:

- super_admin
- kyc_manager
- finance_manager
- support_agent

Role updates are saved in audit logs.
