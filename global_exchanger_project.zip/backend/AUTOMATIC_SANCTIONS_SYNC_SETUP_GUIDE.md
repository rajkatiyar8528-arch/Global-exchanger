# Automatic Sanctions Sync — Setup Guide (v1.9.2+16)

This round makes the sanctions-list sync **fully automatic**, so you never
have to remember to click the admin panel "Sync Now" button again. Two
independent mechanisms work together:

1. **Automatic sync on server startup** — no setup needed, works
   immediately.
2. **Weekly GitHub Actions schedule** — requires a **one-time, 5-minute
   setup** (steps below) to fully activate, but the app works fine even if
   you skip this (mechanism #1 alone still gives you reasonably fresh data
   whenever the app restarts/wakes up).

## Why two mechanisms? (the honest technical reason)

Render's **free tier spins your app down after ~15 minutes of no traffic**.
A simple "check every day" timer running inside the app would silently
stop working the moment the app goes to sleep, and wouldn't run again
until someone happens to open the app and wake it up. That's not reliable
enough for "set and forget."

So instead:
- **Mechanism #1 (startup check)**: every time your app starts or wakes up
  (a new deploy, or Render waking it from sleep because someone opened the
  app), it checks: "is my sanctions list older than 7 days (or still the
  tiny starter sample)?" If yes, it automatically re-syncs in the
  background — you don't do anything, it just happens.
- **Mechanism #2 (GitHub Actions)**: runs on **GitHub's own servers**,
  completely independent of whether your Render app is awake or asleep,
  every Monday at 3 AM UTC (~8:30 AM IST). It sends one request to your
  live app which (a) wakes it up if asleep, then (b) triggers a sync. This
  guarantees a weekly refresh **even if nobody opens the app that whole
  week** — which mechanism #1 alone cannot guarantee, since it only runs
  when the app happens to start/wake.

Together: your sanctions list should never be more than ~7 days stale,
regardless of how often you or your users actually use the app.

## What's new (files added/changed this round)

- **`backend/src/sanctions_sync.js`**: added `isSanctionsListStale()` and
  `maybeAutoSyncIfStale()` — the startup self-check logic (Mechanism #1).
- **`backend/src/server.js` / `server_pg.js`**: call
  `maybeAutoSyncIfStale()` right after the server starts listening
  (fire-and-forget — does NOT delay the app becoming ready to serve
  requests, even though the sync itself takes a few seconds).
- **New endpoint**: `POST /api/cron/sanctions-sync` — a separate,
  cron-friendly trigger endpoint protected by its own single-purpose
  secret (`SANCTIONS_CRON_SECRET`), deliberately NOT using your real admin
  login, so a leaked GitHub secret can only ever be used to force a
  sanctions-list refresh — nothing else.
- **New file**: `.github/workflows/sanctions-sync.yml` — the GitHub
  Actions workflow definition (Mechanism #2). **This needs to be uploaded
  to your GitHub repo separately** (see setup steps below — GitHub
  Actions workflows must live at that exact path in the repo, they can't
  be inside the zip).

## One-time setup for the weekly GitHub Actions sync (Mechanism #2)

Skip this section entirely if you're fine relying on Mechanism #1 alone
(automatic sync on app startup/wake) — the app works correctly either way,
this section just makes the guarantee stronger ("definitely at least
weekly" vs. "whenever the app happens to restart").

### Step 1 — Set the secret on Render
1. Go to your Render dashboard → your Global Exchanger backend service →
   **Environment** tab.
2. Add a new environment variable:
   - Key: `SANCTIONS_CRON_SECRET`
   - Value: any long, random, hard-to-guess string. If you're not sure
     what to use, something like `gx-sanctions-cron-8f3a91d2e6b74c58` (mix
     it up — don't literally copy this example) is fine — length matters
     more than cleverness here.
3. Save — Render will redeploy automatically with the new variable.

### Step 2 — Set the same secret on GitHub
1. Go to your GitHub repository → **Settings** tab → **Secrets and
   variables** → **Actions** (in the left sidebar).
2. Click **"New repository secret"**.
3. Name: `SANCTIONS_CRON_SECRET`
4. Value: **the exact same value** you set on Render in Step 1.
5. Click **Add secret**.

### Step 3 — Upload the workflow file to your repo
1. In your GitHub repo, create this exact folder path if it doesn't exist:
   `.github/workflows/`
2. Upload the `sanctions-sync.yml` file (provided separately alongside
   this ZIP — look for `github_workflow_sanctions_sync.yml` in your
   downloads) into that folder, so the final path in your repo is:
   `.github/workflows/sanctions-sync.yml`
3. Commit it.

### Step 4 — Verify it works
1. Go to your GitHub repo → **Actions** tab.
2. You should see a workflow called "Weekly Sanctions List Auto-Sync" in
   the list.
3. Click on it, then click **"Run workflow"** (this manually triggers it
   right now, instead of waiting for Monday) → **Run workflow** button.
4. Wait ~10-30 seconds, refresh the page, click into the run that
   appeared, and check the logs — it should show "Sanctions list sync
   completed successfully" at the end.
5. If it shows a warning about `SANCTIONS_CRON_SECRET` not being set, or a
   403/404 error, double check Steps 1-2 — the value must match EXACTLY
   on both Render and GitHub (no extra spaces, matching case).

Once verified working, it will now run automatically every Monday without
you doing anything.

## How to tell it's working (ongoing, no setup needed)

Open the Admin Panel → "🚫 Sanctions/PEP Screening Flags" section — the
note at the top always shows the current entry count and last-updated
timestamp, e.g. "...20,158 entries, source: OFAC SDN List (US Treasury),
UN Security Council Consolidated List...". If that timestamp is more than
~7-10 days old, something's not syncing — check Render's logs for
`[sanctions-sync]` lines (both the startup check and the cron endpoint log
their activity there), or just click "🔄 Sync Full List Now" manually as a
fallback — that always works regardless of the automated mechanisms.

## Testing performed this round

- **Verified startup auto-sync**: started the server fresh with the small
  42-entry starter sample in place — confirmed the server became available
  immediately (health check responded `200` right away) while the sync ran
  in the background, and confirmed the file was correctly updated to
  20,158 real entries a few seconds later without the server ever being
  unresponsive during that time.
- **Verified staleness detection**: confirmed a small/sample dataset
  (under 1,000 entries) is always treated as stale regardless of its
  timestamp, so the very first deploy always triggers a real sync
  immediately rather than waiting up to 7 days.
- **Verified the cron endpoint's security model**: confirmed requests with
  the correct `X-Cron-Secret` header succeed (200), requests with a wrong
  secret are rejected (403), and — critically — confirmed that when
  `SANCTIONS_CRON_SECRET` is not configured at all, the endpoint returns
  404 (doesn't exist) rather than silently accepting unauthenticated
  requests.
- **Re-ran the 30-check regression suite** covering the full app (auth,
  KYC, payments, exchange, withdrawals, disputes, referrals, notifications,
  admin dashboard/analytics, AML flags, TDS records, sanctions flags,
  Travel Rule records, STR reports) against `server.js` after all these
  changes — **all 30/30 passed**, confirming no regressions.
- **Confirmed route parity**: both `server.js` and `server_pg.js` have
  exactly the same 78 API routes (up from 77 before this round, adding
  `/api/cron/sanctions-sync`).

## Version

Bumped to **v1.9.2+16**.
