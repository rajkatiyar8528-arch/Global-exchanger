# FIU-IND Registration Guide — Crypto/VDA Features (Step-by-Step)

**Applies to**: the BTC/ETH/XRP wallet, conversion, and exchange features in
Global Exchanger.

> ⚠️ **This is a structured, research-based guide, not legal advice.**
> FIU-IND's registration process involves in-person meetings, live
> compliance-system demonstrations, and judgment calls (e.g. what counts as
> "sufficient" AML/CFT infrastructure) that a real Chartered Accountant or
> compliance lawyer experienced with FIU-IND filings should guide you
> through. Treat this as your "know what to expect and prepare" checklist,
> not a DIY legal filing.

## 0. Is this actually mandatory for you?

**Yes — if your crypto features are live for real Indian users, this is not
optional.** Since March 2023, any entity carrying out "Virtual Digital
Asset Service Provider" (VDA SP) activities — which explicitly includes
**exchange of VDAs for fiat currency, exchange between VDAs, transfer,
safekeeping, and administration of VDAs** — is legally required to
register with FIU-IND as a "Reporting Entity" (RE) under the Prevention of
Money Laundering Act, 2002 (PMLA). Global Exchanger's BTC/ETH/XRP
conversion feature falls squarely within this definition.

**Consequences of not registering** (per Section 13 of PMLA and FIU-IND's
own public actions):
- Fines and/or access-blocking (FIU-IND has publicly blocked/restricted
  major exchanges like Binance, KuCoin, and issued notices to 25+ offshore
  platforms as of late 2025).
- The obligation applies **regardless of where your company is
  incorporated**, if you serve Indian users — FIU-IND has explicitly
  stated this is "activity-based," not physical-presence-based.
- This is separate from (and in addition to) the tax obligations (30% VDA
  gains tax + 1% TDS under Section 194S) already partially implemented in
  the app via `TECHNICAL_SAFEGUARDS_GUIDE.md`.

## 1. What you need to do BEFORE applying (prerequisite compliance)

FIU-IND will not even schedule your registration meeting until you can
demonstrate these are already in place:

- [ ] **Appoint a Principal Officer (PO)**: This person is personally
      accountable for AML/CFT compliance and must meet qualification
      criteria per FIU-IND's "Guidance for Principal Officer" circular
      (typically: relevant seniority, no criminal record, sufficient
      understanding of AML/CFT and the business). This should usually be
      someone senior (e.g. a director, compliance head), not a junior
      employee.
- [ ] **Appoint a Designated Director (DD)**: A board-level director
      formally designated as responsible for AML/CFT compliance oversight.
      Can be the same person as an existing director but must be formally
      designated via board resolution.
- [ ] **Write an AML/CFT Policy document** covering: Customer Due
      Diligence (CDD) procedures, Know-Your-Customer (KYC) standards,
      record-keeping (5-year retention — already reflected in
      `LEGAL_COMPLIANCE_CHECKLIST.md` and the Privacy Policy), Suspicious
      Transaction Report (STR) escalation process, employee training plan,
      and risk-based client categorization (high-risk vs low-risk).
- [ ] **Have working KYC/AML technical systems** — not just policy on
      paper. FIU-IND's September 2025 circular explicitly requires a
      **live demonstration** of: KYC verification, transaction monitoring,
      blockchain analysis tooling, Travel Rule implementation (originator/
      beneficiary info exchange for VDA transfers), and sanctions/PEP
      screening. The app currently has KYC document upload and basic
      transaction limits/AML flagging (see `TECHNICAL_SAFEGUARDS_GUIDE.md`)
      — you will likely need to add: sanctions-list screening, more
      granular transaction monitoring rules, and Travel Rule data capture
      for VDA transfers specifically, before this demo would pass.
- [ ] **Get a cybersecurity audit certificate** from an empanelled auditor
      (CERT-In empanelled auditors are commonly used for this).
- [ ] **Organize your corporate documents** (see Section 3 below) — GST/
      Income Tax returns for the last 3 financial years, MCA filings,
      financial statements, etc. If your company is newly incorporated
      and doesn't have 3 years of returns yet, expect FIU-IND to ask for
      whatever exists plus an explanation.

## 2. Registration process — 3 stages

### Stage 1: Self-enrolment on the FINGate 2.0 Portal
1. Go to the FIU-IND FINGate portal (`fingate.gov.in` — always verify the
   current official URL directly from a FIU-IND government notification,
   as portal names/URLs have changed over the registration circular
   revisions: FINnet → FINGate 2.0).
2. Register as a new Reporting Entity: enter entity name, category
   (Virtual Digital Asset Service Provider), and contact details.
3. On submission, FIU-IND issues a **system-generated FIU Reference ID
   (FIUREID)**. 
   ⚠️ **Important**: this reference ID is NOT your registration — it's
   just an acknowledgment that your application entered the queue. FIU-IND
   has explicitly clarified this to correct a common misconception.

### Stage 2: Document submission + in-person meeting
1. Submit the full document set (see Section 3) via the portal.
2. FIU-IND will schedule an **in-person meeting** — attendance by BOTH
   the Principal Officer and Designated Director is mandatory (not
   optional, not delegable to a lawyer alone).
3. At the meeting, be ready to give a **live walkthrough/demo** of your
   actual AML/CFT systems (not slides — the real running system): KYC
   flow, transaction monitoring dashboard, any blockchain analytics
   tooling, Travel Rule data handling, sanctions screening.
4. FIU-IND may request additional documents/clarifications after the
   meeting — respond promptly, as delays here are the most common cause of
   long registration timelines.

### Stage 3: Approval and RE-ID issuance
1. After satisfactory review, the **Director of FIU-IND** grants final
   approval.
2. You receive a formal **FIU Reporting Entity Identification Number
   (FIU RE-ID)** — this is your actual registration confirmation.
3. Typical timeline: **20–30 working days** for straightforward cases per
   some CA-firm estimates, but **4–12+ weeks** is commonly cited
   elsewhere, and can run longer if your AML/CFT systems aren't ready at
   the in-person meeting stage (you may need a second meeting). Budget
   generously — do not assume a fast turnaround.

## 3. Document checklist to prepare in advance

Gather these before you start the portal application, so you're not
scrambling mid-process:

**Corporate/legal:**
- [ ] Certificate of Incorporation
- [ ] Memorandum of Association (MOA) & Articles of Association (AOA)
- [ ] PAN of the entity
- [ ] GST registration (if applicable)
- [ ] MCA filings/returns for the last 3 financial years
- [ ] Corporate structure note + organogram (organizational chart)
- [ ] Significant Beneficial Owner (SBO) details

**Financial:**
- [ ] Audited Balance Sheets and Profit & Loss accounts, last 3 financial
      years (if the company is newer, provide what exists)
- [ ] GST returns, last 3 financial years
- [ ] Income Tax Returns, last 3 financial years
- [ ] TDS returns relevant to VDA transactions (Forms 26Q/26QF/26QE) —
      the crypto TDS logic added in `TECHNICAL_SAFEGUARDS_GUIDE.md`
      generates exactly the underlying data needed for this

**People:**
- [ ] Board resolution appointing the Principal Officer
- [ ] Board resolution formally designating the Designated Director
- [ ] KYC documents (ID proof, address proof) of both PO and DD
- [ ] Details of all directors/partners/promoters and Ultimate Beneficial
      Owners (UBOs)

**Compliance:**
- [ ] Written AML/CFT policy document
- [ ] A brief note explaining exactly how your activities fall under the
      Ministry of Finance's March 7, 2023 notification (S.O. 1072(E)) —
      i.e., explicitly describe the wallet/exchange/conversion features
- [ ] Self-declaration: no pending law-enforcement proceedings or criminal
      cases against the entity or its directors/partners
- [ ] Cybersecurity audit certificate
- [ ] Copies of agreements with any other VDA ecosystem participants
      (exchanges, brokers, custodians, intermediaries) you work with,
      domestic or international
- [ ] **PACT (Partner Accreditation for Compliance and Trust) certificates**
      from any FIU-registered VDA SPs you have existing/proposed business
      relationships with (only applicable if you integrate with other
      registered exchanges/liquidity providers)

## 4. Ongoing obligations AFTER registration (this is not a one-time task)

Registration is the start, not the end, of your compliance obligation:
- [ ] **File Suspicious Transaction Reports (STRs)** for any transaction
      that raises red flags — this should tie into the AML flagging system
      built in `TECHNICAL_SAFEGUARDS_GUIDE.md` (currently that system
      flags for admin review only; formal STR filing to FIU-IND is a
      separate, additional step your compliance team/PO must do manually
      or build tooling for).
- [ ] **File Counter Transaction Reports (CTRs)** and other periodic
      reports as prescribed.
- [ ] **Report transactions ≥ ₹10,00,000 by non-profit organizations**
      specifically, per current guidance.
- [ ] **Maintain records for 5 years** after the client relationship ends
      (already reflected in data retention policy).
- [ ] **Never "tip off" a client** that an STR has been filed about them —
      this is a strict legal prohibition, before/during/after filing.
- [ ] **Conduct periodic risk assessments**, categorize clients as
      high/low risk, with extra scrutiny for non-resident clients.
- [ ] **Implement Travel Rule compliance** for VDA transfers — exchange
      originator and beneficiary information with counterparty VDA SPs.
- [ ] **Review/update your AML/CFT policy at least annually**, or after
      any audit finding, new regulation, or major product change.
- [ ] Keep your PO/DD details current with FIU-IND if either role changes
      hands.

## 5. Realistic assessment for Global Exchanger specifically

Being direct about where the app currently stands vs. what's needed:

| Requirement | Current status in the app |
|---|---|
| KYC on users | ✅ Implemented (Aadhaar/PAN/selfie upload + admin approval) |
| Transaction record-keeping | ✅ Implemented (`transactions`, `ledger_entries`, 5-year retention documented) |
| Basic large-transaction flagging | ✅ Implemented (`TECHNICAL_SAFEGUARDS_GUIDE.md` AML flags) |
| Crypto TDS calculation | ✅ Implemented (Section 194S, 1%) |
| Sanctions/PEP screening | ❌ Not implemented — needed for the FIU demo |
| Travel Rule (originator/beneficiary data exchange) | ❌ Not implemented — needed since VDA transfers are treated like wire transfers under FIU guidance |
| Formal STR filing workflow/tooling | ❌ Not implemented — AML flags currently only reach your own admin panel, not FIU-IND |
| Written AML/CFT policy document | ❌ Needs to be authored (business/legal task, not code) |
| Principal Officer + Designated Director appointed | ❌ Business/organizational task — needs real named individuals |
| 3 years of financials/GST/IT returns | Depends on how long your entity has existed |
| Cybersecurity audit certificate | ❌ Needs a CERT-In empanelled auditor engagement |

**Bottom line**: the app has a reasonable technical foundation (KYC,
record-keeping, basic AML flagging, TDS), but real FIU-IND registration
also requires organizational/legal steps (appointing PO/DD, written
policy, cybersecurity audit) and additional technical work (sanctions
screening, Travel Rule, formal STR filing) that go beyond what code alone
can provide. **Recommend engaging a CA/compliance firm experienced
specifically with FIU-IND VDA SP registrations** (several are cited in
the research for this guide, e.g. firms offering "FIU-IND registration
support" — pick one via your own due diligence, this guide does not
endorse any specific vendor) to run the actual filing, while your dev team
builds the remaining technical gaps (sanctions screening + Travel Rule
being the biggest ones) in parallel.

## 6. Suggested near-term technical next steps (if you want to keep building)

To close the biggest gaps ahead of/in parallel with formal registration:
1. **Sanctions/PEP screening at KYC time** — check submitted names against
   published sanctions lists (e.g. UN, OFAC, India's own lists) during
   KYC review; flag matches for manual admin review rather than
   auto-approving.
2. **Travel Rule data capture** — for VDA exchange/transfer transactions,
   capture and store originator (sender) and beneficiary (receiver)
   identity information alongside the transaction record, ready to share
   with counterparty VDA SPs if/when your exchange feature integrates with
   external liquidity providers.
3. **Formal STR export/filing tool** — extend the existing AML flags
   admin view into a workflow where your Principal Officer can review a
   flagged transaction and mark it for formal STR filing, generating the
   data export needed for the actual FIU-IND filing (which today is
   likely a manual portal submission process on FIU-IND's side, not an
   API).

Ask if you'd like any of these three built next — they're the most
directly actionable technical gaps identified above.
