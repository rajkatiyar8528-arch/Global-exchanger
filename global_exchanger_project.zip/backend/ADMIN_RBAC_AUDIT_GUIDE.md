# Admin RBAC and Audit Logs

Added role-based permissions for admin APIs.

Default super admin permissions:

- users:read
- kyc:manage
- payments:read
- refunds:manage
- exchange:manage
- ledger:read
- audit:read
- admin:manage

Audit logs are created for:

- Admin login
- KYC approve/reject
- Payment refund
- Exchange complete/cancel

APIs:

```text
GET /api/admin/audit-logs
GET /api/admin/roles
```
