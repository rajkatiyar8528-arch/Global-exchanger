# Global Exchanger Backend API

Node.js + Express starter backend for Global Exchanger.

## Run

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

API base URL: `http://localhost:5000`

## Demo Admin

From `.env.example`:

- Email: `admin@globalexchanger.com`
- Password: `Admin@12345`
- Special Key: `GX-SUPER-KEY-2026`

Change these before production.

## Main APIs

### User

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/me`
- `POST /api/security/pin`
- `POST /api/kyc`
- `POST /api/bank-accounts`
- `GET /api/wallet`
- `GET /api/rates`
- `POST /api/transactions/send`
- `GET /api/transactions`
- `POST /api/exchange/orders`
- `POST /api/complaints`

### Admin

- `POST /api/admin/login`
- `GET /api/admin/dashboard`
- `GET /api/admin/users`
- `GET /api/admin/complaints`
- `PATCH /api/admin/kyc/:id`

## Production Important

This is a starter backend. Production app ke liye required:

- PostgreSQL database
- Real KYC provider integration
- Bank/UPI/payment gateway integration
- RBI/NPCI/FEMA/FIU compliance
- Rate limiting
- Audit logs
- Encrypted document storage
- 2FA/OTP
- Fraud monitoring
- Escrow ledger with double-entry accounting

## PostgreSQL Mode

1. Create PostgreSQL database:

```bash
createdb global_exchanger
```

2. Configure env:

```bash
cp .env.postgres.example .env
```

3. Install and migrate:

```bash
npm install
npm run migrate
npm run dev:pg
```

PostgreSQL server file: `src/server_pg.js`  
Schema file: `db/schema.sql`

## Double-Entry Ledger

Guide: `LEDGER_GUIDE.md`

Admin APIs added:

- `GET /api/admin/kyc-requests`
- `GET /api/admin/payment-orders`
- `GET /api/admin/ledger`
