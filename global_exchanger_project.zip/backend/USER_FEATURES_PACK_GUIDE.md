# User Features Pack: Price Alerts, Support Chat, Statement Export, Dark Mode, Watchlist (v1.10.0+19)

This round adds five user-facing features requested together in one go.
All five are implemented in **both** backends (`server.js` JSON demo and
`server_pg.js` PostgreSQL production) with matching behaviour, and in the
Flutter app + Admin Panel where relevant.

## 1. Price Alerts

**What it does:** a user can set an alert for a currency/crypto pair (e.g.
`USD_INR`, `BTC_USD`) with a target price and direction (`above`/`below`).
When the target is crossed, an in-app notification (+ email, if enabled) is
sent and the alert moves to `triggered` status.

**Files:**
- `backend/src/price_alerts.js` — shared, dependency-free helper functions
  (`SUPPORTED_PAIRS`, `isSupportedPair`, `flattenRates`,
  `findTriggeredAlerts`, `formatPairLabel`), used identically by both
  backends so the trigger logic can't drift.
- `price_alerts` table (Postgres) / `db.priceAlerts` array (JSON).
- Endpoints: `POST/GET/DELETE /api/price-alerts[/:id]`.
- Flutter: `PriceAlertsScreen` (Profile > Price Alerts, also a home-screen
  quick-access tile).

**Important limitation — read this before promising "real-time" alerts to
users:** Render's free tier has **no reliable always-on background
timer/cron** (the process can sleep after ~15 minutes of inactivity).
Rather than pretending to offer true real-time push, alerts are evaluated
**opportunistically every time `GET /api/rates` is called** — which happens
often anyway (home screen, convert screen, price-alerts screen's
"pull-to-refresh" all call it). This is documented in the app's Price
Alerts screen copy ("Alerts app khulne/rates refresh hone par check hote
hain — real-time push nahi") so user expectations are set correctly. If you
later want true real-time (checked every N minutes even with the app
closed), you would need either: (a) a paid Render background worker with
its own cron loop, or (b) the GitHub Actions weekly-cron pattern already
used for sanctions sync (`sanctions-sync.yml`) adapted to ping `/api/rates`
every few minutes — note GitHub Actions' minimum cron interval is 5
minutes and is not guaranteed to run exactly on schedule under load.

## 2. In-App Support Chat

**What it does:** upgrades the existing one-shot "Complaint" (subject +
message, submitted once, then only a status badge) into a real
back-and-forth chat thread between the user and support/admin staff.

**Files:**
- `complaint_messages` table (Postgres) / `db.complaintMessages` array
  (JSON) — one row per message, linked to the existing `complaints` table
  which now also tracks `last_user_read_at` / `last_admin_read_at` /
  `last_message_at` (for future unread-badge features).
- User endpoints: `POST/GET /api/complaints/:id/messages`.
- Admin endpoints: `POST/GET /api/admin/complaints/:id/messages`.
- Flutter: tapping any complaint card in Help > Complaints now opens
  `ComplaintChatScreen` — a real chat UI (message bubbles, auto-polls every
  8 seconds while open, pull-to-refresh, send box).
- Admin Panel: Complaints table has a "💬 Chat" button opening a modal chat
  view (`openChatModal`/`sendChatReply`/`refreshChatMessages` in
  `admin_panel/index.html`) with the same 8-second polling pattern.
- Sending an admin reply triggers a `support_reply` notification
  (in-app + email if enabled) to the user.

**Why polling instead of WebSockets:** keeps the Render free-tier
deployment simple (no extra infrastructure, no sticky-session concerns
behind Render's load balancer / Cloudflare). 8-second polling is a
reasonable trade-off for a support-chat use case (not a consumer
messaging app) — messages typically don't need sub-second latency here.

**Security:** a user can only post to / read messages on complaints they
own (`WHERE user_id = req.auth.id` on every user-side query) — verified via
automated test that a second, unrelated user gets `404 Not Found` (not
`403`, to avoid confirming the complaint ID exists at all) when attempting
to message someone else's complaint.

## 3. Transaction Statement Export (PDF-via-print + CSV)

**What it does:** a user can generate a full account statement (optionally
date-ranged) and either (a) open it as a printable HTML page in the phone's
browser, using the same "Print / Save as PDF" pattern as single-transaction
receipts, or (b) download it directly as a CSV file.

**Files:**
- `backend/src/statements.js` — `generateStatementToken()`,
  `renderStatementHtml()` (styled HTML with a summary of total
  credited/debited + a transaction table), `wrapStatementPage()` (same
  print-button wrapper as `receipts.js`), `renderStatementCsv()`.
- `statement_tokens` table (Postgres) / `db.statementTokens` array (JSON)
  — short-lived (15 min), single-purpose tokens, same security model as
  `receipt_tokens`.
- Endpoints: `POST /api/statements/token` (returns both a `url` for the
  HTML view and a `csvUrl` for the CSV download), `GET /api/statements/:token`,
  `GET /api/statements/:token/csv`.
- Flutter: `StatementExportScreen` (Profile > Download Statement) — date
  pickers for From/To (optional), "View / Print Statement (PDF)" and
  "Download as CSV" buttons, both opened via `url_launcher` in the phone's
  browser (same approach as receipts).

**IMPORTANT ROUTE-ORDERING BUG FOUND & FIXED DURING THIS ROUND:** the CSV
endpoint was originally implemented as `GET /api/statements/:token.csv`
(a dot-suffix on the same path segment as the HTML route
`/api/statements/:token`). Express registers routes in declaration order
and a `:token` param matches **any** character except `/` — so
`/api/statements/abc123.csv` was being captured by the earlier, broader
`/api/statements/:token` route (with `req.params.token` literally equal to
`"abc123.csv"`, which then failed the token lookup and returned 404) rather
than ever reaching the intended CSV handler. **Fixed** by changing the CSV
route to a distinct sub-path, `GET /api/statements/:token/csv` (declared
*before* the bare `/api/statements/:token` route, with a comment explaining
why the order matters), and updating `csvUrl` in the token-creation
response accordingly. Verified via automated test: CSV download now
returns `200` with proper CSV content in both backends (previously failed
with `404` on this exact scenario before the fix).

## 4. Dark Mode / App Settings

**What it does:** adds a Settings screen (Profile > App Settings) with:
theme choice (System Default / Light / Dark), and toggles for email
notifications and in-app/push notifications. Preferences are **synced to
the user's account** (not just stored locally on the phone), so they
follow the user if they reinstall the app or log in on another device.

**Files:**
- `users.theme_preference` / `email_notifications_enabled` /
  `push_notifications_enabled` columns (Postgres, via `ALTER TABLE ...ADD
  COLUMN IF NOT EXISTS`) / same fields on JSON `db.users[i]`.
- Endpoints: `GET/PATCH /api/settings`.
- `backend/src/notifications.js` / `notifications_json.js`'s
  `notifyUser`/`notifyUserJson` already supported a `sendEmail` flag — this
  round wires the user's `email_notifications_enabled` preference into
  the price-alert and support-reply notification call sites (a template
  for wiring it into other notification call sites too, if desired later).
- Flutter: `lib/theme/app_theme.dart` now has `AppTheme.dark()` (a full
  dark `ThemeData`) plus a `ThemeController` (a global `ValueNotifier
  <ThemeMode>`) that `MaterialApp` listens to via
  `ValueListenableBuilder` — switching the radio button in
  `AppSettingsScreen` applies Dark Mode **instantly app-wide**, no restart
  needed. On login (`MainNavigationScreen.initState`), the app fetches the
  saved preference from the backend and applies it, so a previously-set
  Dark Mode choice is respected on a fresh app launch/reinstall.
- Theme-aware helper functions (`isDark`, `cardColor`, `borderColor`,
  `mutedText`, `subtleText`, `faintText`, `warningBg` in `app_theme.dart`)
  were added and applied to the most commonly reused shared widgets
  (`InfoCard`, `FeatureTile`, `WarningBox`, `ErrorRetryView`,
  `EmptyStateView`, `ProfessionalCard`, and `AppPage`'s AppBar) so Dark
  Mode reads correctly across most of the app without a full per-screen
  rewrite. **Known limitation:** many older, one-off screens (built across
  earlier feature rounds) still have some hardcoded `Colors.white` /
  `Color(0xFFE5EDFF)` / `Colors.black54` literals in their own local
  `Container`/`Text` widgets rather than using the shared helpers — these
  will look correct in Light Mode but may have low-contrast or
  visually-odd elements in Dark Mode. This is a known, deliberately-scoped
  trade-off (full-app dark-mode conversion of every existing screen is a
  larger follow-up task, not blocking this round's ship) — flag to the
  user if a fully-polished all-screen dark mode is wanted in the next
  round.
- **No true OS-level background push** (e.g. via Firebase Cloud Messaging)
  is included — "Push / In-App Notifications" toggle currently only
  controls whether an item appears in the in-app notification bell/list
  (already existing feature), not a real push notification while the app
  is closed. This is called out explicitly in the Settings screen's
  warning box.

## 5. Favorites / Watchlist

**What it does:** a user can pin their favourite currency/crypto pairs;
pinned pairs show up in a "My Watchlist" card on the home screen with live
rates, and can be managed from a dedicated Watchlist screen.

**Files:**
- `watchlist_pairs` table (Postgres, `UNIQUE(user_id, pair)`) /
  `db.watchlistPairs` array (JSON, same uniqueness check done manually).
- Endpoints: `POST/GET/DELETE /api/watchlist[/:id]`.
- Flutter: `WatchlistScreen` (Profile > Favorites/Watchlist, also a
  home-screen tile) + `_WatchlistQuickView` widget on the home dashboard
  (auto-hides itself if the user has zero pins, so it doesn't clutter the
  home screen for users who haven't discovered the feature yet).

## Testing performed this round

A new automated test script covering all 34 new-feature checks (settings
get/patch + validation, watchlist add/duplicate-reject/invalid-reject/list/
delete, price-alerts create/invalid-reject/list/trigger-via-rates-call/
notification-created/cancel, support-chat send/empty-reject/read/admin-read/
admin-reply/user-sees-reply/notification-created/non-owner-blocked,
statement token-create/view-html/download-csv/bad-token-404) was run
against **both** backends (JSON on port 5099, PostgreSQL on port 5098) —
**34/34 passed on both** after fixing the statement CSV route-ordering bug
described above. Core pre-existing flows (register, login, `/api/me`,
wallet, security PIN, transactions, notifications, referrals, KYC submit)
were also re-verified to still return `200` after these changes (no
regression).

## Deferred / not done this round

- True real-time price alerts (needs a paid always-on worker or a
  frequent external cron ping — see limitation note under Price Alerts).
- Full-app Dark Mode visual polish for every legacy screen (see limitation
  note under Dark Mode / App Settings) — current coverage is the shared
  widgets + all five newly-added screens; most existing screens still use
  some hardcoded light-mode colors.
- Real OS push notifications (Firebase Cloud Messaging or similar) — the
  "Push Notifications" toggle only controls the existing in-app
  notification bell, not background push.
- Unread-message badges for Support Chat (the `last_user_read_at`/
  `last_admin_read_at`/`last_message_at` columns were added to support
  this in a future round, but no UI badge was built yet this round).
