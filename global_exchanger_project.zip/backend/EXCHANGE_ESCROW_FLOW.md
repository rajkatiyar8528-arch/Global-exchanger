# Exchange Escrow Complete Ledger Flow

User flow:

1. `POST /api/exchange/orders` creates exchange order and commission accrual.
2. `POST /api/exchange/orders/:id/lock-escrow` locks user's source currency.
3. Admin completes exchange: `POST /api/admin/exchange/orders/:id/complete`.
4. Converted currency is credited to user wallet.
5. Ledger entries are posted for escrow lock, source release, and converted credit.

Cancel flow:

```text
POST /api/admin/exchange/orders/:id/cancel
```

This releases locked funds back to user wallet and posts reversal ledger.
