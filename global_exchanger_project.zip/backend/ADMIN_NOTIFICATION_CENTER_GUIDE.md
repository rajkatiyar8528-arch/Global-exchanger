# Admin Notification Center / Alerts — Guide

Ye guide batati hai ki naya **Admin Notification Center** feature kaise kaam karta hai — pehle admin ko manually har section (KYC, Withdrawals, Disputes, Complaints, Sanctions Flags) check karna padta tha ye jaanne ke liye ki kya kuch pending hai.

## Kya Naya Hai

Admin Panel ke top-right corner me ab ek **🔔 Alerts** button dikhega:

- Agar koi bhi cheez pending/attention-needed hai, to button pe ek **laal number badge** dikhega (jaise "3")
- Button dabate hi ek **dropdown** khulega jisme category-wise breakdown dikhता hai:
  - 🪪 **Pending KYC Reviews** — jitni KYC requests review ke liye pending hain
  - 💸 **Pending Withdrawals** — jitni withdrawal requests process hone ka wait kar rahi hain
  - ⚖️ **Open Disputes** — jitne disputes resolve nahi hue hain
  - 💬 **Unread Support Messages** — jitni complaints/chats me user ka naya message hai jo admin ne nahi dekha
  - 🚫 **Unreviewed Sanctions Flags** — jitne KYC submissions sanctions list se match hue hain aur review pending hai
- Kisi bhi category par click karte hi seedha us section tak **scroll** ho jayega
- Ye har **30 second** me automatically refresh hota hai — admin ko manually refresh karne ki zaroorat nahi

## Permission-Aware Design (Zaroori Baat)

Agar aapke paas multiple admins hain alag-alag roles ke saath (jaise "Support Agent" sirf disputes/complaints dekh sakta hai, KYC nahi), to:

- Har admin ko **sirf wahi categories dikhengi jinki unke paas permission hai**
- Jaise agar kisi admin ke paas sirf "Manage Disputes" permission hai, to unhe sirf "Open Disputes" aur "Unread Support Messages" dikhega — KYC/Withdrawals/Sanctions ka koi count nahi dikhega (chahe wo pending ho bhi)
- Ye isliye zaroori hai taaki koi bhi admin sirf apne scope ki jaankari dekhe, aur accidentally sensitive information (jaise kitni withdrawals pending hain) na dekh sake agar unko wo access nahi diya gaya

## Technical Summary

- Naya endpoint: `GET /api/admin/alerts-summary` — ek hi call me sabhi categories ka count + total deta hai
- Permission checks bilkul wahi hain jo underlying list endpoints already use karte hain (`kyc:manage`, `refunds:manage`, `disputes:manage`) — koi naya permission system nahi banaya gaya
- **26 automated tests** (dono backends) — including ek khaas security test jisme ek "scoped" admin (sirf disputes:manage permission) banakar verify kiya gaya ki wo sirf disputes/complaints dekh sakta hai, KYC/withdrawals/sanctions nahi
- Koi naya database table nahi — sirf existing data (kyc_requests, withdrawals, disputes, complaints) se live count nikala jaata hai
- Route count 126 → 127 (1 naya endpoint), dono backends match

## Business Note

Ye feature admin response time improve karega — jaise hi koi naya KYC/withdrawal/dispute aaye, admin ko turant pata chal jayega bina manually check kiye, jisse customer satisfaction aur compliance turnaround dono behtar honge.
