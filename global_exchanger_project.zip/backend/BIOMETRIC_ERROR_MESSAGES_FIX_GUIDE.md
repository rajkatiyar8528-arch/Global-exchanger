# Biometric Login: Specific Error Messages Fix (v1.11.1+23)

Follow-up fix based on real-device feedback after v1.11.0+22: when a user
tried to enable Biometric Login, they only ever saw a generic
"Verification fail ho gayi" message with no indication of *why* it
failed — making it impossible to tell "your phone has no fingerprint
enrolled" apart from "wrong fingerprint" apart from "biometric hardware
missing" apart from any other failure.

## Root cause

`ApiService.authenticateWithBiometrics()` previously returned a plain
`bool`, and its `try/catch` swallowed **every** possible failure
(`PlatformException` with specific error codes from the OS, generic
exceptions, everything) into a single `false` — throwing away the actual
reason before it ever reached the UI.

**The single most common real-world cause** (and almost certainly what
happened in the reported case) is simply that the phone's screen lock is
a PIN/pattern/password only, with **no fingerprint or face ever enrolled**
in the phone's own Settings app. This app cannot enroll biometrics
itself — fingerprint/face enrollment is always an OS-level setting
(Settings > Security > Fingerprint/Face unlock on most Android phones),
the same as for any other app that uses device biometrics (banking apps,
etc.). If nothing is enrolled, `local_auth`'s `authenticate()` call
fails immediately with a `NotEnrolled` platform exception — which was
previously being silently collapsed into the same generic message as
every other failure.

## What changed

**`lib/services/api_service.dart`:**
- New `BiometricAuthResult` class carrying both a `success` flag and a
  specific `reasonMessage` string (plus a `noBiometricsEnrolled` flag).
- New `availableBiometrics()` — calls `local_auth`'s
  `getAvailableBiometrics()` to check what's actually enrolled on the
  device, separate from whether the hardware merely *exists*.
- `authenticateWithBiometrics()` now:
  1. Checks hardware availability first (`isBiometricAvailable()`) — if
     unavailable, returns a specific "hardware not available" message
     immediately without even attempting the OS prompt.
  2. Checks enrollment (`availableBiometrics().isEmpty`) — if nothing is
     enrolled, returns the specific "no fingerprint/face set on this
     phone, go to Settings > Security first" message, `noBiometricsEnrolled:
     true`.
  3. Only then calls the actual OS `authenticate()` prompt, and catches
     `PlatformException` specifically, mapping known `local_auth` error
     codes (`NotEnrolled`, `NotAvailable`, `LockedOut`/
     `PermanentlyLockedOut`, `PasscodeNotSet`) to distinct, actionable
     Hinglish messages instead of one generic string.

**`lib/main.dart`:**
- `BiometricGateScreen` (shown when unlocking a restored session) and
  `AppSettingsScreen`'s "Enable Biometric Login" toggle handler both
  updated to read `result.reasonMessage` and display it directly instead
  of a hardcoded generic string.
- `AppSettingsScreen` now proactively checks enrollment status
  (`availableBiometrics()`) when the screen loads, and — if the phone has
  biometric *hardware* but nothing *enrolled* — shows an inline warning
  card explaining exactly what to do ("go to Settings > Security, add a
  fingerprint/face, then come back") **instead of** showing the toggle at
  all. This prevents the user from even attempting to turn it on when it's
  guaranteed to fail, rather than letting them hit the error and figure it
  out themselves.

## Why this matters for the reported case

Based on the screenshot (Dark Mode showing correctly = app is definitely
running v1.10.1+ or later, confirming this is a real func-behavior report,
not a stale-build issue), the toggle attempt produced only the generic
message. With this fix, the exact same tap will now show one of:
- "Aapke phone mein koi fingerprint/face set nahi hai. Pehle phone ki
  Settings > Security mein jaakar fingerprint ya face unlock add karein..."
  (if nothing is enrolled — **most likely cause**)
- "Is phone mein biometric hardware available nahi hai..." (if the device
  genuinely lacks fingerprint/face hardware — less likely on a modern
  phone but possible on older/budget devices)
- "Fingerprint/face match nahi hua. Dobara try karein." (if enrolled but
  the actual scan didn't match / was cancelled)
- Lockout-specific or passcode-specific messages for those edge cases.

**Ask the user to try again after this update and report back which
specific message they now see** — that will confirm the root cause
definitively (almost certainly "no fingerprint/face enrolled on the
phone yet").

## Testing performed this round

- Python brace/bracket/paren balance check passed on `main.dart` and
  `api_service.dart` after every edit.
- Verified both call sites (`BiometricGateScreen._tryUnlock()` and
  `AppSettingsScreen._toggleBiometric()`) correctly updated to the new
  `BiometricAuthResult` return type (previously `bool`) — grepped for any
  leftover `if (ok)` / `final ok = ...` patterns from the old API shape;
  none found.
- Backend was NOT touched this round (this is a pure Flutter-side fix) —
  `node -c` re-verified on both `server.js`/`server_pg.js` as an
  unaffected-baseline sanity check.

**Not verified in this sandbox** (same limitation as v1.11.0+22's
Biometric Login section): no Flutter SDK/Android emulator with biometric
hardware available here to directly trigger and observe each
`PlatformException` code path. The specific error-code mappings
(`NotEnrolled`, `NotAvailable`, `LockedOut`, `PermanentlyLockedOut`,
`PasscodeNotSet`) are taken directly from `local_auth`'s own documented
Android/iOS exception codes. Ask the user to confirm the exact message
they see on their real device after this update.
