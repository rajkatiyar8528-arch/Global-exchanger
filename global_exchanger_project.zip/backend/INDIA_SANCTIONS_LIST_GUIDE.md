# India-Specific Sanctions List (MHA/UAPA) Guide (v1.9.3+17)

This round closes a specific gap flagged in `SANCTIONS_AUTO_UPDATE_GUIDE.md`:
the sanctions screening system previously only covered OFAC (US Treasury)
and UN Security Council lists — this round adds **India's own domestic
terrorism/unlawful-association lists** from the Ministry of Home Affairs
(MHA), which is specifically relevant to FIU-IND's compliance expectations
for a VDA Service Provider operating in India.

## What was added

Two new official India government sources are now fetched, parsed, and
merged into the same sanctions dataset alongside OFAC and UN, every time a
sync runs (whether triggered automatically on startup, via the weekly
GitHub Actions schedule, or manually via the admin panel button):

1. **MHA — Banned Organisations** (`mha.gov.in/en/banned-organisations`) —
   entities declared "unlawful associations" under **Section 3 of the
   Unlawful Activities (Prevention) Act, 1967 (UAPA)**. Currently 39
   organisations (e.g. Lashkar-e-Taiba, Jaish-e-Mohammed, various
   separatist/militant groups), fetched live from the official page — not
   hardcoded, so it stays current as MHA updates the page.

2. **MHA — Individual Terrorists** (Fourth Schedule of UAPA, Section 35) —
   individuals specifically designated as terrorists, including their
   known aliases. Currently 80 individuals (e.g. Maulana Masood Azhar,
   Hafiz Muhammad Saeed, Dawood Ibrahim, and others), also fetched live.

Both pages are simple, publicly-accessible, server-rendered HTML tables —
no login, no CAPTCHA, no JavaScript rendering required — so they're parsed
the same lightweight, dependency-free, regex-based way as the OFAC/UN
sources already in the codebase (see `backend/src/sanctions_sync.js`).

## How the data is structured

Same shape as the OFAC/UN entries, so the existing fuzzy-matching engine
(`backend/src/screening.js`) works on India MHA entries with zero code
changes needed there:

```json
{
  "id": "MHA-IND-1",
  "name": "Maulana Masood Azhar",
  "type": "individual",
  "programs": "India UAPA Designated Terrorist (Fourth Schedule, Section 35)",
  "aliases": ["Maulana Mohammad Masood AzharAlvi", "Vali Adam Issa"],
  "remarks": "Maulana Masood Azhar @ Maulana Mohammad Masood AzharAlvi @ Vali Adam Issa",
  "source": "India MHA — Individual Terrorists (UAPA Fourth Schedule)"
}
```

Organisation names that MHA lists with a "/" separator for alternate names
(e.g. `"Lashkar-E-Taiba/Pasban-E-Ahle Hadis"`) are automatically split into
a primary name + aliases, the same convention as OFAC's `a.k.a.` handling.

## Fail-safe behavior (consistent with the rest of the sync system)

If either MHA page is temporarily down, redesigned in a way that breaks
the parser, or returns unexpected content, that specific source is marked
`failed` in the sync summary and **skipped** — the sync continues normally
with whatever other sources succeeded (OFAC, UN, and/or the other MHA
page). The overall sync only reports total failure if **every single
source** fails, in which case the existing dataset file is left completely
untouched. This was explicitly tested this round: simulating a broken MHA
page structure resulted in those 2 sources correctly failing/skipping
while OFAC (19,210 entries) and UN (1,002 entries) still merged
successfully — 20,212 total entries even with India MHA sources down.

## Testing performed this round

- **Live-fetched both real MHA pages** from their actual government URLs
  and confirmed successful parsing: 39 banned organisations + 80
  individual terrorists = **119 India-specific entries**, correctly
  structured with names/aliases split out.
- **Combined total dataset**: OFAC (19,210) + UN (1,002) + India MHA (119)
  = **20,331 entries**, up from 20,158 before this round.
- **Verified genuine matches**: screened "Maulana Masood Azhar" (exact
  match, score 1.0), "Dawood Ibrahim" (matched across both OFAC's and
  MHA's entries for the same individual, demonstrating the multi-source
  overlap works correctly), and "Lashkar-e-Taiba" (matched MHA's entry
  plus related OFAC entries for the same organisation under different
  name spellings).
- **False-positive check**: 10 common Indian names (Raj Katiyar, Priya
  Sharma, Amit Kumar, etc.) — **zero false positives** even with the
  larger combined dataset.
- **Performance check**: screening speed remains ~10ms per call (no
  meaningful slowdown from the additional ~119 entries, which is a small
  fraction of the ~20,000+ total).
- **Fail-safe test**: simulated a broken/redesigned MHA page response and
  confirmed the sync correctly marks only those 2 sources as failed while
  still successfully merging OFAC + UN data — no crash, no data loss.
- **Full 33-check end-to-end regression suite** (including a live test
  that registers a user named "Dawood Ibrahim", submits KYC, and confirms
  the sanctions flag correctly appears in the admin panel data) — run
  against BOTH `server.js` and `server_pg.js` (real local PostgreSQL) —
  **all 33/33 passed on both backends**.
- **Route parity confirmed**: both backends still have exactly the same
  78 API routes (no new endpoints needed this round — this was purely an
  enhancement to the existing sync engine).

## What this means for you

No action needed — the next time a sync runs (automatically on server
startup/wake, via the weekly GitHub Actions schedule if you set that up
per `SANCTIONS_AUTO_UPDATE_GUIDE.md`, or manually via the admin panel "Sync
Full List Now" button), India's MHA lists will be included automatically
alongside OFAC and UN. The admin panel's "🚫 Sanctions/PEP Screening Flags"
section will show all 4 sources in its metadata note once synced.

## Remaining gaps (being transparent, as always)

- This covers UAPA-based lists (terrorism/unlawful associations) — India
  has other watch-list-adjacent frameworks (e.g. RBI's periodically
  circulated caution lists for certain financial contexts) that are more
  specialized/harder to access programmatically and are not included here.
- As with OFAC/UN, this remains a **from-scratch, dependency-free fuzzy-
  matching implementation** — appropriate as a real working system, but a
  dedicated commercial sanctions-screening vendor will still offer more
  sophisticated matching and broader list coverage if you scale to real
  production volume (see `SANCTIONS_SCREENING_GUIDE.md`'s original
  recommendation on this point, which still applies).

## Version

Bumped to **v1.9.3+17**.
