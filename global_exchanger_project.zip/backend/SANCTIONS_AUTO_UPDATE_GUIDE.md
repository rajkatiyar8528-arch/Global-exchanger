# Sanctions List Automatic Update Guide (v1.9.1+15)

This round replaces the 42-entry demo sample from `SANCTIONS_SCREENING_GUIDE.md`
with a real, working **automatic sync system** that fetches the complete,
current official sanctions datasets directly from their government sources
— no manual data entry, no third-party paid API needed.

## What was built

### 1. `backend/src/sanctions_sync.js`
Fetches and merges:
- **OFAC SDN List** (US Treasury) — the main sanctions list
  (`sdn.csv`, ~19,000+ entries) plus the separate aliases file
  (`alt.csv`, ~20,000+ "also known as" names merged onto the main entries).
- **UN Security Council Consolidated List** (`consolidated.xml`) —
  individuals and entities sanctioned by UN Security Council resolutions
  (~1,000+ entries).

Combined, this produces **over 20,000 real sanctions entries** — vastly
more complete than the 42-entry starter sample this replaces.

**Fail-safe design**: if a source is temporarily down or a fetch fails,
that source is skipped (logged as a warning) and the sync continues with
whatever sources succeeded. If ALL sources fail, the existing
`sanctions_list.json` is left completely untouched — a sync attempt can
never wipe out your working dataset with empty/partial data.

### 2. Three ways to trigger a sync

**a) Admin panel button (recommended for your phone-only workflow)**
A new "🔄 Sync Full List Now" button in the "🚫 Sanctions/PEP Screening
Flags" section. Click it, confirm the prompt (it downloads several MB from
government servers and can take up to ~30 seconds), and the list refreshes
immediately — no server shell/terminal access needed at all, which matters
since you operate entirely from your phone and Render's free tier has no
Shell access.

**b) API endpoint**: `POST /api/admin/sanctions-sync` (rate-limited to 6
calls/hour since each call is a genuine multi-MB network operation).

**c) Command line** (if you ever get server/local access):
```
cd backend
npm run sync:sanctions
```

### 3. What does NOT happen automatically
**This sync does NOT run on a timer/schedule by itself.** It only runs
when you explicitly trigger it (via the admin panel button, the API, or
the CLI). This is a deliberate choice — the app doesn't have persistent
background job infrastructure (no cron/queue system), and adding one just
for this would be a bigger architecture change than the value justifies
right now.

**Recommendation**: sync at least **weekly**, ideally after reading
this guide, bookmark a reminder to click the "Sync Full List Now" button
in the admin panel once a week. Sanctions lists change frequently (new
individuals/entities added, others removed) — the "🚫 Sanctions/PEP
Screening Flags" section always shows the current `lastUpdated` timestamp
and entry count so you can see at a glance how stale your local copy is.

If you want this fully automated later without any manual clicking, the
technical options (not built in this round, but noted for the future) are:
- **Render Cron Job** (a paid Render feature) that runs `npm run
  sync:sanctions` on a schedule.
- A simple `setInterval()` inside the server process that calls
  `syncSanctionsList()` every N hours — the risk with this approach is a
  slow/failed fetch could tie up the process; would need careful
  implementation to avoid impacting live traffic.

## Bugs found and fixed during this round (via full-dataset testing)

Building this against the SAMPLE 42-entry dataset earlier looked correct,
but testing against the REAL, full ~20,000-entry dataset surfaced two
real bugs that the small sample had hidden:

### Bug 1: OFAC alias file column misalignment
The `alt.csv` parser assumed the wrong column order, causing it to
compare the wrong two CSV fields — the net effect was that OFAC's
separate alias file's ~20,000 "also known as" names were being silently
dropped entirely (0 aliases merged instead of ~20,000). Fixed by
correcting the column mapping (verified against the live file:
`uid, altNum, type, aliasName, remarks`).

### Bug 2: OFAC main list column count assumption
The main `sdn.csv` parser assumed 11 columns per row; the real file has
12, which meant the `remarks` field (where a second style of alias,
`a.k.a. '...'`, is embedded) was being read from the wrong column,
silently losing those aliases too. Fixed by correcting the destructuring
to match the verified 12-column format.

### Bug 3: Fuzzy-matching false positives at scale
With only 42 sample entries, the matching algorithm looked accurate. With
the full ~43,000 candidate name/alias strings, a flaw emerged: a **short,
single-word alias fuzzy-matching a single word inside an unrelated name**
could produce a false "perfect" match score (e.g. the alias "VERSA" would
score 100% overlap against the unrelated name "Anita Verma" purely
because "Verma"~"Versa" are similar strings, even though nothing else
about the names is related). Fixed by discounting single-significant-token
matches unless that single token matched **exactly** (a genuine short
alias like "BNC" appearing verbatim is still treated as strong evidence;
a coincidental fuzzy single-word match is now heavily discounted).
Verified via testing: 20 real common Indian names now produce only 1 weak
false-positive candidate (a plausible near-match between "Ramesh" and
"Rajesh"), and 0 false positives on most others — while genuine matches
(including a known sanctioned individual with a common
spelling variant, "Khalid Sheikh/Shaikh Mohammed") still correctly flag.

### Bug 4: Performance — 700ms+ per KYC submission
Naively re-scoring the input name against all ~43,000 candidate strings on
every single KYC submission took **~700-800ms per call** — unacceptably
slow for a synchronous step in a user-facing request. Fixed with two
optimizations:
1. Pre-normalize every candidate name/alias once when the list loads
   (not on every screening call).
2. Build a lightweight inverted index (by 4-character token prefix) so
   only candidates sharing at least one token-prefix with the input name
   are actually scored — candidates with nothing in common are skipped
   entirely.

**Result: ~700ms → ~10ms per screening call** (70x+ speedup), verified via
timing tests, with no loss of matching correctness (re-verified all prior
test cases still pass after the optimization).

## Testing performed this round

- **Live-fetched the real OFAC SDN list, OFAC alias list, and UN
  Consolidated List** directly from their official government URLs and
  successfully parsed/merged them into a **20,158-entry** combined
  dataset.
- **Full 21-check end-to-end test suite** (sanctions screening with the
  FULL real dataset, Travel Rule capture, STR workflow, plus the core
  registration/KYC/payment/exchange flow) — run against BOTH `server.js`
  and `server_pg.js` (real local PostgreSQL) — **all 21/21 passed on
  both backends** after the bug fixes above.
- **Route parity check**: both backends have exactly the same 77 API
  routes (up from 75 before this round, adding `/api/admin/sanctions-sync`
  and `/api/admin/sanctions-list-metadata`).
- **False-positive spot-check**: 20 common Indian names tested against the
  full 20,000+ entry dataset — only 1 weak candidate match, 0 outright
  false flags.
- **Performance verified**: sync itself takes ~3-4 seconds end-to-end
  (network fetch + parse + merge + write), and screening a single name
  against the full dataset now takes ~10ms (down from ~700ms pre-fix).

## Files changed/added this round

- **New**: `backend/src/sanctions_sync.js` — the fetch/parse/merge engine.
- **New**: `backend/src/sync_sanctions_cli.js` — command-line entrypoint.
- **Modified**: `backend/src/screening.js` — performance optimization
  (prefix index) and false-positive fix (token-match confidence
  dampening).
- **Modified**: `backend/src/server.js` / `server_pg.js` — new
  `POST /api/admin/sanctions-sync` and
  `GET /api/admin/sanctions-list-metadata` endpoints.
- **Modified**: `admin_panel/index.html` — "Sync Full List Now" button.
- **Modified**: `backend/package.json` — new `npm run sync:sanctions`
  script.
- **Modified**: `backend/data/sanctions_list.json` — now populated with
  20,158 real entries from the initial sync run during this development
  session (will grow stale over time until you re-sync — see the
  "what does NOT happen automatically" section above).

## Remaining limitations (being transparent)

- Still missing: India-specific lists (e.g. UAPA-designated individuals/
  entities under India's Unlawful Activities (Prevention) Act) — OFAC and
  UN cover the most internationally-recognized sanctions regimes, but
  FIU-IND's own compliance expectations may specifically look for Indian
  domestic lists too. Adding a third source for this is a reasonable next
  step if you want to pursue it.
- The fuzzy-matching algorithm remains a dependency-free, from-scratch
  implementation — good enough for a real working system, but a dedicated
  commercial sanctions-screening vendor (ComplyAdvantage, Refinitiv
  World-Check, Dow Jones Risk & Compliance) will have more sophisticated
  matching (phonetic algorithms, cross-script transliteration handling)
  and properly licensed/maintained datasets if you scale to real
  production volume — this remains true even after this round's
  improvements, per the original `SANCTIONS_SCREENING_GUIDE.md`.
- No automatic scheduled re-sync yet (see the manual-trigger discussion
  above) — this is a "you need to remember to click the button
  periodically" system for now, not "fully automatic" despite the sync
  mechanism itself being automatic once triggered.

## Version

Bumped to **v1.9.1+15**.
