# Direct "Chat with Support" Button (v1.10.2+21)

Follow-up fix based on user feedback after v1.10.1+20: the in-app chat
worked, but it was only reachable **after** first submitting a full
complaint (Subject + Details form) and then tapping the resulting card —
there was no direct way to "just start chatting" the way one would expect
from a typical support-chat button. This round adds exactly that.

## What changed

**New backend endpoint (both `server.js` and `server_pg.js`):**
`POST /api/support/chat` — opens (or reuses) the user's single "General
Support Chat" thread instantly, with **no subject/details form required**.

- First call: creates a new `complaints` row with `subject: 'Support
  Chat'`, a placeholder `message`, and a new `is_general_chat` boolean
  column set to `TRUE` (added via `ALTER TABLE complaints ADD COLUMN IF
  NOT EXISTS is_general_chat BOOLEAN NOT NULL DEFAULT FALSE` — migration-
  safe, auto-applied via `autoMigrate()` on Postgres startup).
- Every subsequent call for the same user: finds and returns the existing
  general-chat thread (`WHERE user_id=$1 AND is_general_chat=TRUE`)
  instead of creating a new one — so repeatedly tapping "Chat with
  Support" always lands the user back in the same ongoing conversation,
  never spawning duplicate threads.
- Reuses all the existing chat message endpoints
  (`POST/GET /api/complaints/:id/messages`) unchanged — a general-chat
  thread is still just a `complaints` row underneath, so no new message
  storage/retrieval logic was needed.

**Flutter app (`SupportScreen`):** added a floating "💬 Chat with Support"
button (`FloatingActionButton.extended`) at the bottom-right of the Help
screen, visible on both the Complaints and Disputes tabs. Tapping it:
1. Calls `ApiService.openSupportChat()` → `POST /api/support/chat`.
2. Immediately navigates into the existing `ComplaintChatScreen` (the same
   chat UI built in v1.10.0+19) for that thread — one tap, no form.

The existing "Submit a Complaint" form (Subject + Details + Submit
button) is left completely unchanged/untouched — this is still the right
path for a user who wants to file a *specific, formal* complaint tied to
a named subject (e.g. for a transaction dispute paper trail). The new
direct-chat button is an *additional*, faster path alongside it for
"I just want to talk to someone right now" — both ultimately use the same
underlying chat mechanism.

**Distinguishing a direct chat from a normal complaint in the UI:**
- In the "My Complaints" list, a general-chat thread now shows a green
  "Direct Chat" status pill instead of the usual status
  (submitted/under_review/resolved/rejected) badge, since a general chat
  doesn't really have a "resolution status" the way a formal complaint
  does.
- In the Admin Panel's Complaints table, a general-chat row gets a green
  "DIRECT CHAT" pill next to the subject, so support staff can tell at a
  glance which threads are open-ended support chats vs. formal filed
  complaints.

## Testing performed this round

A new 11-check automated test script (`test_direct_chat.py`) verifies:
opening direct chat creates a thread with the `isGeneralChat`/
`is_general_chat` flag set; opening it again reuses the *same* thread ID
(no duplicates); exactly one general-chat thread exists per user even
after multiple opens; messages can be sent/read in it; the admin sees it
in their complaints list with the flag visible; the admin can reply; and
the user sees the admin's reply. **All 11 checks passed on both
backends** (`server.js` JSON and `server_pg.js` Postgres).

Route-count parity re-verified: **96 matching routes** on both backends
(up from 95 in v1.10.1+20, +1 for the new `POST /api/support/chat`
endpoint).

Full regression re-check of core pre-existing flows (register, login,
`/api/me`, normal complaint submission, complaints list, unread-count)
still return `200` on both backends — no regression introduced.

`node -c` syntax check passed on both `server.js` and `server_pg.js`.
Python brace/bracket/paren balance check passed on `main.dart` and
`api_service.dart`.

## Not changed / still applies from previous rounds

- Chat is still polling-based (8-second refresh while a chat screen is
  open, 20-second badge-count polling in the background) — no
  websockets/push, for the same Render free-tier simplicity reasons
  documented in `USER_FEATURES_PACK_GUIDE.md`.
- Real OS-level push notifications (Firebase) are still deferred pending
  the user setting up their own free Firebase project — see that same
  guide's "Deferred" section.
