# Real Email OTP Setup

Backend now supports real OTP emails using SMTP via Nodemailer.

## Required Render Environment Variables

```env
APP_NAME=Global Exchanger
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_16_digit_app_password
SMTP_FROM=Global Exchanger <your_email@gmail.com>
```

## Gmail Setup

1. Enable 2-Step Verification in Google Account.
2. Search `App passwords` in Google Account security.
3. Create app password for Mail.
4. Copy 16-character password.
5. Use it as `SMTP_PASS`.

Do not use your normal Gmail password.

## SendGrid SMTP Setup

```env
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=apikey
SMTP_PASS=your_sendgrid_api_key
SMTP_FROM=Global Exchanger <verified_sender_email>
```

## Brevo SMTP Setup

```env
SMTP_HOST=smtp-relay.brevo.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your_brevo_login_email
SMTP_PASS=your_brevo_smtp_key
SMTP_FROM=Global Exchanger <verified_sender_email>
```
