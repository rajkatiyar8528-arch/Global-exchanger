# Referral System

## How It Works (Fraud-Resistant Design)

Previously, the app only showed a static "Referral Reward ₹100" text — there
was no actual backend logic to validate referral codes, track referrals
properly, or ever pay out the reward. This is now fully implemented.

### The reward is paid when the referred user completes their FIRST real transaction — not at signup

This was a deliberate choice to prevent abuse: if the reward were paid at
signup, anyone could create throwaway/fake accounts using their own referral
code to farm free money, with zero real usage of the app.

**Qualifying "first transaction" events (any one of these triggers it):**
- Sending money to another user
- Topping up their wallet (successful payment)
- Completing a currency/crypto exchange order

Each referral can only be rewarded **once** — the `maybePayReferralReward`
function checks the referral's status and is a safe no-op if it's already
been paid.

## Signup Flow

1. New user enters a referral code (optional) during signup.
2. Backend validates the code actually belongs to an existing user **before**
   creating the account — an invalid/typo'd code is rejected immediately
   rather than silently creating an orphaned referral record.
3. Self-referral (someone using their own code) is silently ignored — the
   account is still created, just without a referral link.
4. A `referrals` row is created with status `pending_first_transaction`.

## Reward Payout

When the referred user's first qualifying transaction succeeds:
1. The referral row is found and locked (`FOR UPDATE`) to prevent double-payment race conditions.
2. ₹100 (configurable per-referral via the `reward`/`currency` columns) is credited to the **referrer's Reward Wallet** — the same wallet used for the 0.2% exchange commission reward, so users have one consistent place to see all their bonus earnings.
3. A ledger entry is posted for full auditability.
4. The referral status changes to `rewarded`, with a timestamp.
5. The referrer gets an in-app notification ("Referral Reward Credited!").

## New Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/referrals/mine` | User | My referral code, stats (total referred/rewarded/earned), and per-referral history |
| GET | `/api/admin/referrals` | Admin | All referrals across the platform, for oversight |

## Where It Shows Up

- **Signup screen**: optional "Referral Code" field.
- **Home screen**: "Refer & Earn ₹100" card → opens the new **Referral screen**, showing:
  - Your referral code (with a "Copy Code & Share" button)
  - Total referred / total rewarded / total earned
  - A history list of each referral with its status (Waiting for First Transaction / Reward Credited)
- **Admin panel**: new "Referral Program" table showing every referral, who referred whom, reward amount, and status.
- **Reward Wallet** (already built for the exchange commission feature): referral rewards now show up in the same balance, and can be redeemed into the main wallet the same way.

## Notes for Future Improvement

- Reward amount is currently fixed at ₹100 per referral (matches the
  original UI text). If you want tiered rewards or a cap on total referral
  earnings, the `referrals.reward` column already supports per-row custom
  amounts — you'd just need an admin UI to set them.
- Consider adding a referral leaderboard for gamification if user growth via
  referrals becomes a priority.
