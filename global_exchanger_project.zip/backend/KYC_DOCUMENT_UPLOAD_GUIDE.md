# KYC Document Upload

Real document upload (Aadhaar, PAN, Selfie) hai — sirf placeholder filenames
save nahi hote, actual image data backend mein store hota hai.

## Kaise Kaam Karta Hai

- App (Flutter) camera/gallery se photo leta hai, use base64 string mein
  convert karta hai, aur `POST /api/kyc` ko `documents` array ke saath bhejta hai:

```json
{
  "nationalId": "1234-5678-9012",
  "taxId": "ABCDE1234F",
  "country": "India",
  "documents": [
    { "label": "Aadhaar Card - Front", "mimeType": "image/jpeg", "dataBase64": "..." },
    { "label": "PAN Card", "mimeType": "image/jpeg", "dataBase64": "..." },
    { "label": "Live Selfie", "mimeType": "image/jpeg", "dataBase64": "..." }
  ]
}
```

- Backend documents ko **PostgreSQL `kyc_requests.documents` (JSONB)** column
  mein store karta hai — koi external storage account (S3/Cloudinary) ki
  zaroorat nahi.
- Validation: max **5 documents**, har document max **4MB**, sirf
  `image/jpeg`, `image/png`, `image/webp`, `application/pdf` allowed hain.

## Endpoints

| Method | Path | Kaun access kar sakta hai | Kaam |
|---|---|---|---|
| POST | `/api/kyc` | User | KYC submit karna (documents ke saath) |
| GET | `/api/kyc/me` | User | Apna latest KYC status + document names dekhna (raw files nahi) |
| GET | `/api/admin/kyc-requests` | Admin | Sab KYC requests ki list (documents ke bina, fast load) |
| GET | `/api/admin/kyc-requests/:id/documents` | Admin | Ek specific request ke actual documents dekhna |
| PATCH | `/api/admin/kyc/:id` | Admin | Approve/Reject karna |

## Admin Panel Mein Dekhna

Web Admin Panel (`admin_panel/index.html`) mein **KYC Approval** section ke
har row mein ab ek **"View Docs"** button hai — isse click karne par ek naya
tab khulta hai jisme uploaded Aadhaar/PAN/Selfie images dikhti hain, approve/
reject karne se pehle verify karne ke liye.

## Production Ke Liye Aage Ka Sujhaav

- Abhi documents Postgres mein hi store hote hain — chhote/medium scale ke
  liye theek hai, lekin bahut zyada users hone par dedicated object storage
  (S3, Cloudinary, Supabase Storage) pe move karna better rahega.
- Document access sirf `kyc:manage` permission wale admins ko milta hai,
  aur har baar document dekhne par ek **audit log entry** (`kyc.documents_viewed`)
  bhi banti hai.
