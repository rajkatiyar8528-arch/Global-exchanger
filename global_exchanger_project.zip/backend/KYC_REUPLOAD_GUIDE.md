# KYC Document Re-upload Flow — Guide

Ye guide batati hai ki naya KYC rejection/re-upload feature kaise kaam karta hai — pehle jab KYC reject hoti thi, user ko sirf ek generic message milta tha ("sahi documents ke saath dobara submit karein") aur koi specific reason ya seedha re-upload karne ka tareeka nahi tha.

## Admin Ke Liye — KYC Reject Karte Waqt

1. Admin Panel → **KYC Approval** section
2. Kisi bhi request ke liye **"Reject"** button dabayein
3. Ab ek **naya popup** khulega jisme:
   - **Rejection Reason** likhna **zaroori** hai (jaise "Aadhaar photo blurry hai, dobara clear photo bhejein")
   - Optionally, checkbox se **specific documents** select kar sakte hain jo dobara chahiye (jaise sirf "Aadhaar Card - Front")
4. "Reject & Notify User" dabayein — user ko turant specific reason ke saath notification/email jayega

⚠️ **Ab reason likhe bina reject nahi kar sakte** — na admin panel se, na hi seedhe API call se (backend bhi enforce karta hai).

## User Ke Liye — Jab KYC Reject Ho Jaaye

1. **Profile** screen par "KYC Status: Rejected" ka card dikhega (laal icon ke saath)
2. Tap karte hi KYC screen khulegi jisme:
   - Upar **exact reason** dikhega jo admin ne likha tha
   - Agar admin ne specific documents flag kiye the, to unhi documents ka card **laal border** ke saath highlight hoga aur "Dobara Upload Karein" badge dikhega
   - Baaki sab kuch bilkul normal KYC form jaisa hai — bas dobara photo lekar submit kar dein

## Technical Summary

- Naye database fields: `rejection_reason` (free-text), `rejected_document_labels` (specific documents ki list)
- `PATCH /api/admin/kyc/:id` ab reject karte waqt reason **required** karta hai — bina reason ke `400 Bad Request` aata hai
- User ka `GET /api/kyc/me` ab latest submission ka reason + flagged documents bhi return karta hai
- Har naya KYC submission ek **naya record** banata hai (purana wala history me rehta hai) — is se admin ko poora history dikhta hai ki kitni baar reject/resubmit hua
- **28 automated tests** (dono backends) — reject-without-reason block hona, reject-with-reason kaam karna, user ko sahi data milna, re-submission se naya record banna — sab verify kiya gaya
- Koi naya API endpoint nahi — existing endpoints hi enrich hue hain, route count same (124, dono backends match)

## Business Note

Ye feature KYC approval rate improve karega — jab users ko pata hoga exactly kya galat tha, wo jaldi aur sahi tarike se fix kar payenge, jisse support tickets bhi kam honge aur user experience behtar hoga.
