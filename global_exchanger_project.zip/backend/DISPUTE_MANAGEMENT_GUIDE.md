# Dispute Management System

Added user APIs:

```text
POST /api/disputes
GET /api/disputes
```

Create dispute body:

```json
{
  "transactionId": "optional_transaction_id",
  "reason": "Wrong payment",
  "message": "I sent money to wrong person",
  "evidence": []
}
```

Admin APIs:

```text
GET /api/admin/disputes
PATCH /api/admin/disputes/:id
```

Admin update body:

```json
{
  "status": "under_review",
  "adminNote": "Checking transaction",
  "resolution": "Pending receiver confirmation"
}
```

Statuses:

- submitted
- under_review
- waiting_user
- resolved
- rejected

Audit logs are created for admin dispute updates.
