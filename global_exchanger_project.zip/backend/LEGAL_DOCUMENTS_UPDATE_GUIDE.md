# Legal Documents Update Guide (v1.8.1+11)

This round of work rewrote the app's user-facing legal documents to be
significantly more thorough and India-law-aware, based on the actual
features implemented in the app (wallet, forex conversion, crypto
conversion, referral program, KYC/Aadhaar handling, Razorpay payments).

## What changed

All 4 documents live in `legal/` in the repo root (NOT inside `backend/`),
and need to be published on your website at the URLs referenced inside the
app (`TermsScreen` in `main.dart`) and inside the documents themselves:

| File | Published URL (as referenced in-app) | What it covers |
|---|---|---|
| `legal/terms-and-conditions.md` | `https://globalexchanger.com/terms` | Full rewrite — 20 sections covering services, eligibility, KYC, payments, wrong-payment handling, currency exchange/escrow, crypto risk disclosure, commission, referral program, prohibited use, account suspension, withdrawals, liability, grievance redressal, dispute resolution/arbitration, governing law |
| `legal/privacy-policy.md` | `https://globalexchanger.com/privacy-policy` | Full rewrite — DPDP Act 2023 structured: Data Fiduciary details, data collected, purposes, legal basis/consent, **Aadhaar-specific handling section**, storage/security, sharing, international transfers, **user rights (access/correction/erasure/nomination)**, retention periods, children's privacy |
| `legal/refund-and-cancellation-policy.md` | `https://globalexchanger.com/refund-policy` | **NEW document** — required for any app taking online payments in India. Covers wallet top-up failures, exchange order cancellation, send-money finality, crypto finality, withdrawal cancellation window, commission refund rules, chargeback handling |
| `legal/grievance-redressal-policy.md` | (referenced via grievance@ email in-app) | **NEW document** — legally required under IT Act 2000 + Consumer Protection E-Commerce Rules 2020 + DPDP Act 2023. Names a Grievance Officer, sets 48-hour acknowledgement / 30-day resolution SLA, lists escalation paths (RBI CMS, Consumer Helpline, Data Protection Board, Cyber Crime Portal) |

The in-app `TermsScreen` (Profile → Terms & Privacy) was updated to link
all 4 documents plus a direct grievance email, instead of just 2 generic
InfoCards.

## ⚠️ Action required from you before publishing these

Every document has bracketed placeholders like `[INSERT LEGAL ENTITY NAME]`,
`[INSERT NAME OF DESIGNATED PERSON]`, `[INSERT SLA]`, `[INSERT CITY]` etc.
**These are not filled in** because only you know:

1. Your actual registered business entity name/type (proprietorship,
   partnership, LLP, Pvt Ltd) and registration number, if any.
2. Who your actual Grievance Officer / Data Protection contact will be
   (a named real person is legally required, not just a generic email).
3. Your actual operational SLAs for withdrawal processing and refund
   turnaround times — the documents suggest placeholders like "1-3
   business days" but you should set these to match what you can actually
   deliver.
4. Which city/jurisdiction your arbitration and courts clause should name
   (usually wherever your business is registered).
5. Whether you use Firebase Crashlytics or any other analytics SDK in the
   actual Flutter build (the Privacy Policy has a placeholder to name any
   such tool actually integrated).

## ⚠️ These are drafts, not a substitute for a lawyer

As stated inside each document, these were drafted with AI assistance based
on your app's actual feature set and general knowledge of Indian law
(Consumer Protection Act 2019, DPDP Act 2023, IT Act 2000, PMLA/FIU-IND
framework, RBI's evolving 2026 FEMA/PPI regulations) as of July 2026. They
are a **strong structured starting point**, not a certified legal opinion.
Given this app handles real payments (Razorpay LIVE), foreign currency
conversion, and crypto — all separately regulated areas as detailed in the
earlier `LEGAL_COMPLIANCE_CHECKLIST.md` — you should have a qualified
Indian lawyer review and finalize these before treating them as binding
legal protection for your business.

## How to publish these

Since these are user-facing legal pages referenced by URL
(`globalexchanger.com/terms` etc.), you'll need to either:
- Host them as static pages on whatever website/domain you control for
  Global Exchanger (convert the Markdown to simple HTML pages), or
- At minimum, make sure the in-app `TermsScreen` text and any links you
  give users point to wherever you actually host the final, lawyer-reviewed
  versions.

The `admin_panel/index.html` GitHub Pages site could also host these as
simple linked HTML pages if you don't have a separate marketing website —
ask if you'd like help converting these Markdown files into simple styled
HTML pages for that purpose.

## Version bump

App version bumped to **v1.8.1+11** — a small/patch bump since this round
only touched the `TermsScreen` UI text (to add the 2 new document
references and grievance email) plus the standalone `legal/*.md` files;
no backend routes or database schema changed.
