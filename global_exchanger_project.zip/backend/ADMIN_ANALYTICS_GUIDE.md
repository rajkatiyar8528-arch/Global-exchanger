# Admin Dashboard Analytics

## What's New

Previously the admin dashboard only showed static lifetime counts (total
users, total transactions, total commission, etc.) with no way to see
trends, spot problems quickly, or understand what's actually driving the
numbers. This is now a real analytics dashboard.

### 1. "Today" Snapshot Cards
Five new cards on the dashboard give an at-a-glance pulse-check without
opening the full analytics section:
- Today's New Users
- Today's Transactions
- Today's Revenue (admin commission earned today)
- Today's Payment Volume (successful wallet top-ups today)
- Open Complaints/Disputes (combined count of anything not yet resolved/rejected)

### 2. Analytics Charts (7 / 30 / 90 day ranges)
All rendered with the native browser Canvas API — **no external chart
library or CDN is loaded**, so the panel keeps working offline/in restricted
preview environments and there's nothing third-party to keep patched.

| Chart | Shows |
|---|---|
| Revenue Trend | Daily admin commission earned, day by day |
| New User Signups | Daily registration count — growth trend |
| Transaction Volume | Daily transaction count |
| Payment Status Breakdown | Bar chart of paid/failed/created payment orders |
| Exchange Order Status | Bar chart of pending/completed/cancelled exchange orders |
| KYC Funnel | Bar chart of pending/under_review/approved/rejected KYC requests |

Plus a **Top Currency Pairs** table showing which conversions (e.g. INR→USD)
are most popular by order count and total volume — useful for deciding
where to focus on getting better live rates or liquidity.

## New Endpoint

```
GET /api/admin/analytics?days=30
```

`days` accepts 7, 30, or 90 (capped at 90 to keep the query fast). Returns:

```json
{
  "periodDays": 30,
  "revenueByDay": [{ "day": "2026-07-14", "revenue": 16, "user_rewards": 4 }],
  "usersByDay": [{ "day": "2026-07-14", "count": 2 }],
  "transactionsByDay": [...],
  "exchangeByCurrency": [{ "from_currency": "INR", "to_currency": "USD", "order_count": 2, "total_amount": 3000 }],
  "paymentStatusBreakdown": [...],
  "exchangeStatusBreakdown": [...],
  "kycBreakdown": [...]
}
```

The existing `GET /api/admin/dashboard` endpoint was also enriched with a
`today` object and `openComplaints`/`openDisputes` counts, while staying
fast/lightweight (it's called on every dashboard load, unlike analytics
which is only loaded when the admin views that section).

## A Bug Found & Fixed While Building This

While testing the new analytics against the JSON demo backend
(`server.js`), the `commissions` records turned out to be missing a
`createdAt` timestamp — meaning "today's revenue" would always show ₹0 even
right after a fresh commission was earned. This has been fixed; the
PostgreSQL backend (`server_pg.js`) was unaffected since its `commissions`
table already has a `created_at TIMESTAMPTZ DEFAULT NOW()` column.

## Where It Shows Up

Web Admin Panel only (`admin_panel/index.html`) — this is an operational
tool for whoever runs the platform, not something end users see. Login to
the panel and the new "Today" cards + "📊 Analytics" section (with a
7/30/90-day range selector) appear automatically above the existing
tables.
