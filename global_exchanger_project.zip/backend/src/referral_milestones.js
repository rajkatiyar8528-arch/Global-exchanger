/**
 * referral_milestones.js
 * -----------------------------------------------------------------------
 * Shared, dependency-free milestone-bonus configuration + pure helper
 * functions for the Referral/Rewards System Upgrade. Both server.js
 * (JSON) and server_pg.js (Postgres) import these constants/functions and
 * do their own DB reads/writes around them — keeps the milestone
 * thresholds/amounts in exactly one place so the two backends can't drift
 * (same pattern as limits.js for KYC tiers / scheduled_payments.js for
 * frequency logic).
 *
 * Design: on top of the EXISTING per-referral ₹100 reward (paid when a
 * referred friend completes their first transaction — unchanged), this
 * adds a SEPARATE one-time bonus each time a user's cumulative count of
 * REWARDED referrals crosses a milestone threshold (5, 10, 25, 50, 100).
 * Milestone bonuses are paid ONCE per threshold per user — re-crossing
 * (impossible, since counts only increase) or re-checking an
 * already-awarded milestone is a safe no-op, enforced by tracking which
 * milestones a user has already been paid for in a dedicated table/array
 * (not just inferred from the current count) so a bug in the counting
 * logic can never cause a double-payment on replay/retry.
 * -----------------------------------------------------------------------
 */

// Ordered ascending — checkMilestones() below relies on this order to award
// every newly-crossed milestone in one pass (e.g. a user whose count jumps
// from 4 to 10 in one go, due to several referrals rewarding in quick
// succession, should be awarded BOTH the 5 and 10 milestones, not just 10).
const MILESTONES = [
  { count: 5, bonus: 250, label: '5 Successful Referrals' },
  { count: 10, bonus: 600, label: '10 Successful Referrals' },
  { count: 25, bonus: 2000, label: '25 Successful Referrals' },
  { count: 50, bonus: 5000, label: '50 Successful Referrals' },
  { count: 100, bonus: 15000, label: '100 Successful Referrals — Top Referrer!' },
];

// Given a user's CURRENT count of rewarded referrals and the set of
// milestone thresholds they've ALREADY been paid for, returns the list of
// newly-crossed milestones (in ascending order) that should be paid now.
// Pure function — no DB access — so it's trivially unit-testable and used
// identically by both backends.
function findNewlyCrossedMilestones(currentRewardedCount, alreadyPaidThresholds) {
  const paidSet = new Set(alreadyPaidThresholds || []);
  return MILESTONES.filter(m => currentRewardedCount >= m.count && !paidSet.has(m.count));
}

// Returns { nextMilestone, remaining, currentCount } for the "X more
// referrals to your next bonus" progress UI — nextMilestone is null once
// the user has passed the highest defined milestone (they keep earning the
// flat ₹100 per-referral for referrals beyond that; only the bonus
// milestones stop, keeping the tier list finite and simple to reason
// about rather than needing an open-ended formula).
function nextMilestoneInfo(currentRewardedCount) {
  const next = MILESTONES.find(m => m.count > currentRewardedCount);
  if (!next) return { nextMilestone: null, remaining: 0, currentCount: currentRewardedCount };
  return { nextMilestone: next, remaining: next.count - currentRewardedCount, currentCount: currentRewardedCount };
}

module.exports = { MILESTONES, findNewlyCrossedMilestones, nextMilestoneInfo };
