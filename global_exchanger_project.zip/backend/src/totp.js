/**
 * totp.js
 * -----------------------------------------------------------------------
 * Dependency-free TOTP (Time-based One-Time Password, RFC 6238) + HOTP
 * (RFC 4226) implementation for Two-Factor Authentication, compatible with
 * Google Authenticator / Authy / Microsoft Authenticator / any standard
 * authenticator app. Deliberately built on Node's built-in `crypto` module
 * (HMAC-SHA1) rather than pulling in a package like `speakeasy` or `otplib`,
 * matching this codebase's established dependency-light pattern (see
 * push.js for the same rationale re: firebase-admin).
 *
 * Core algorithm implementation is verified against the official RFC 6238
 * Appendix B test vectors (see the bottom of this file for the values used
 * in this session's manual verification — SHA1, 8-digit, 30s step, using
 * the RFC's fixed 20-byte ASCII test secret "12345678901234567890").
 * -----------------------------------------------------------------------
 */
const crypto = require('crypto');

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

// ---------------------------------------------------------------------------
// RFC 4648 Base32 encode/decode — used because TOTP secrets are
// conventionally shared with users/authenticator apps as Base32 (shorter,
// case-insensitive, no ambiguous characters like Base64's +/=).
// ---------------------------------------------------------------------------
function base32Encode(buffer) {
  let bits = 0;
  let value = 0;
  let output = '';
  for (let i = 0; i < buffer.length; i++) {
    value = (value << 8) | buffer[i];
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return output;
}

function base32Decode(input) {
  const clean = String(input).toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const bytes = [];
  for (let i = 0; i < clean.length; i++) {
    const idx = BASE32_ALPHABET.indexOf(clean[i]);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

// ---------------------------------------------------------------------------
// HOTP (RFC 4226) — the counter-based one-time password that TOTP builds on.
// ---------------------------------------------------------------------------
function hotp(keyBuffer, counter, digits = 6) {
  const counterBuffer = Buffer.alloc(8);
  // Counter is a 64-bit big-endian integer. JS numbers are safe up to
  // 2^53, and a 30-second time-step counter won't overflow that for
  // billions of years, so writing the low 32 bits (after zeroing the high
  // 4 bytes) is sufficient here.
  counterBuffer.writeUInt32BE(Math.floor(counter / 0x100000000), 0);
  counterBuffer.writeUInt32BE(counter >>> 0, 4);

  const hmac = crypto.createHmac('sha1', keyBuffer).update(counterBuffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binCode =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  const otp = binCode % 10 ** digits;
  return String(otp).padStart(digits, '0');
}

// ---------------------------------------------------------------------------
// TOTP (RFC 6238) — HOTP where the counter is derived from the current time.
// ---------------------------------------------------------------------------
function totpForTime(keyBuffer, { time = Date.now(), step = 30, digits = 6 } = {}) {
  const counter = Math.floor(Math.floor(time / 1000) / step);
  return hotp(keyBuffer, counter, digits);
}

function generateSecretBase32(byteLength = 20) {
  return base32Encode(crypto.randomBytes(byteLength));
}

// Verifies a user-entered code against a Base32 secret, tolerating clock
// drift by checking a small window of adjacent time steps (default ±1 step
// = ±30s either side, i.e. a 90-second acceptance window total) — standard
// practice since phone clocks and server clocks are rarely perfectly
// synced, and users take a few seconds to type the code in.
function verifyTotp(secretBase32, token, { window = 1, step = 30, digits = 6 } = {}) {
  if (!token || !/^\d+$/.test(String(token).trim())) return false;
  const normalizedToken = String(token).trim().padStart(digits, '0');
  const keyBuffer = base32Decode(secretBase32);
  const now = Date.now();
  for (let errorSteps = -window; errorSteps <= window; errorSteps++) {
    const candidate = totpForTime(keyBuffer, { time: now + errorSteps * step * 1000, step, digits });
    if (crypto.timingSafeEqual(Buffer.from(candidate), Buffer.from(normalizedToken))) return true;
  }
  return false;
}

// Builds the otpauth:// URI that authenticator apps scan via QR code (or
// accept as a manual "Setup Key" entry) to start generating matching codes.
function otpauthUrl({ secretBase32, accountName, issuer = 'Global Exchanger', digits = 6, period = 30 }) {
  const label = `${encodeURIComponent(issuer)}:${encodeURIComponent(accountName)}`;
  const params = new URLSearchParams({
    secret: secretBase32,
    issuer,
    algorithm: 'SHA1',
    digits: String(digits),
    period: String(period),
  });
  return `otpauth://totp/${label}?${params.toString()}`;
}

// ---------------------------------------------------------------------------
// Backup/recovery codes — generated once when 2FA is enabled, shown to the
// user exactly one time (they must save them somewhere safe), and each one
// can be used exactly once as a substitute for a TOTP code if the user
// loses access to their authenticator app/device. Stored server-side as
// bcrypt hashes (via the caller, see server.js/server_pg.js) — never in
// plaintext — with a `used` flag per code.
function generateBackupCodes(count = 8) {
  const codes = [];
  for (let i = 0; i < count; i++) {
    // 8 hex chars split as XXXX-XXXX for readability — not meant to be
    // cryptographically as strong as the TOTP secret itself (that stays
    // server-side), just unguessable enough as a one-time fallback that's
    // also bcrypt-hashed at rest.
    const raw = crypto.randomBytes(4).toString('hex').toUpperCase();
    codes.push(`${raw.slice(0, 4)}-${raw.slice(4, 8)}`);
  }
  return codes;
}

// ---------------------------------------------------------------------------
// At-rest encryption for the TOTP secret. Unlike a password (which is only
// ever compared, never needed back in plaintext, so bcrypt-hashing it is
// correct), the TOTP secret must be readable again by the SERVER every time
// it verifies a code — so it cannot be a one-way hash. Storing it in plain
// text in the database would mean anyone with DB access (a leaked backup,
// an SQL injection elsewhere, a compromised Render dashboard) could
// silently clone every user's 2FA and defeat the entire point of the
// feature. AES-256-GCM (authenticated encryption) with a server-side key
// (never stored in the DB, only as an env var) closes that gap: a DB-only
// leak is not enough to recover any secret.
//
// Uses process.env.TOTP_ENCRYPTION_KEY (any string, hashed down to a fixed
// 32-byte AES-256 key via SHA-256, so the operator doesn't need to generate
// a hex key by hand) if set; otherwise falls back to deriving a key from
// JWT_SECRET (still server-only, never in the DB) so 2FA works out of the
// box without requiring an extra Render env var on day one, while still
// documenting the option to set a dedicated key for defense-in-depth (see
// TWO_FACTOR_AUTH_GUIDE.md).
function getEncryptionKey() {
  const material = process.env.TOTP_ENCRYPTION_KEY || process.env.JWT_SECRET;
  if (!material) throw new Error('Cannot encrypt/decrypt TOTP secret: neither TOTP_ENCRYPTION_KEY nor JWT_SECRET is set.');
  return crypto.createHash('sha256').update(material).digest(); // 32 bytes, exactly what AES-256 needs
}

function encryptSecret(plaintextSecret) {
  const key = getEncryptionKey();
  const iv = crypto.randomBytes(12); // 96-bit IV, standard for GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(String(plaintextSecret), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // Pack iv + authTag + ciphertext into one base64 string for easy storage
  // in a single TEXT column.
  return Buffer.concat([iv, authTag, encrypted]).toString('base64');
}

function decryptSecret(packedBase64) {
  const key = getEncryptionKey();
  const packed = Buffer.from(packedBase64, 'base64');
  const iv = packed.subarray(0, 12);
  const authTag = packed.subarray(12, 28);
  const encrypted = packed.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString('utf8');
}

module.exports = {
  base32Encode,
  base32Decode,
  hotp,
  totpForTime,
  generateSecretBase32,
  verifyTotp,
  otpauthUrl,
  generateBackupCodes,
  encryptSecret,
  decryptSecret,
};
