/**
 * travel_rule.js
 * -----------------------------------------------------------------------
 * "Travel Rule" data capture for Virtual Digital Asset (VDA/crypto)
 * transfers — required under FIU-IND's AML/CFT guidance, which explicitly
 * treats VDA transfers like wire transfers: originator (sender) and
 * beneficiary (receiver) identity information must be captured, retained,
 * and made available to counterparty VDA Service Providers / authorities
 * on request. See FIU_IND_REGISTRATION_GUIDE.md and
 * SANCTIONS_SCREENING_GUIDE.md / TRAVEL_RULE_GUIDE.md for full rationale.
 *
 * Scope note: Global Exchanger currently only moves VDA value BETWEEN
 * ACCOUNTS WITHIN THE SAME PLATFORM (internal wallet-to-wallet sends, and
 * exchange orders that convert a user's own balance from one currency to
 * another) — there is no external blockchain withdrawal/deposit feature
 * yet. This module captures the originator/beneficiary data now, in the
 * platform-internal shape needed today, so that:
 *   (a) You already have the required identity data on file the moment
 *       any real Travel-Rule-triggering transfer happens, and
 *   (b) If/when an external wallet withdrawal/deposit feature is added
 *       (sending VDA to an address outside the platform), this same
 *       capture mechanism extends naturally to also record the external
 *       counterparty's VASP/wallet details for exchange with them per the
 *       Travel Rule, without needing to redesign the data model.
 * -----------------------------------------------------------------------
 */

// FIU-IND / global Travel Rule practice commonly cites a de-minimis
// threshold below which detailed data capture is less critical (many
// jurisdictions use USD/EUR 1000 as the FATF Travel Rule threshold) — but
// to be conservative (and because this is cheap to always capture), we
// capture Travel Rule data for EVERY VDA transfer regardless of amount by
// default. The threshold constant is exported for transparency/tuning if
// you want to restrict capture to larger transfers only.
const VDA_TRANSFER_THRESHOLD_INR_FOR_TRAVEL_RULE = Number(process.env.TRAVEL_RULE_THRESHOLD_INR || 0);

/**
 * Builds a Travel Rule data record for an internal (platform-to-platform)
 * VDA transfer. Both originator and beneficiary are Global Exchanger users
 * in this internal-transfer case, so we capture what FIU-IND guidance
 * calls "required and accurate originator information and required
 * beneficiary information" using data already collected during KYC.
 *
 * @param {object} params
 * @param {object} params.originatorUser - the sending user's DB row (needs id, name, and KYC-linked national ID if available)
 * @param {object} params.beneficiaryUser - the receiving user's DB row
 * @param {string} params.currency - the VDA currency being transferred (BTC/ETH/XRP)
 * @param {number} params.amount - the amount transferred
 * @param {string} params.referenceType - 'transaction' | 'exchange_order'
 * @param {string} params.referenceId - id of the underlying transaction/order
 * @param {string|null} params.originatorNationalId - originator's KYC national ID if available (redacted/hashed recommended for storage — see guide)
 */
function buildTravelRuleRecord({ originatorUser, beneficiaryUser, currency, amount, referenceType, referenceId, originatorNationalId = null, beneficiaryNationalId = null }) {
  return {
    currency,
    amount,
    referenceType,
    referenceId,
    originator: {
      userId: originatorUser?.id || null,
      name: originatorUser?.name || null,
      // Only the LAST 4 characters of the national ID are stored here to
      // balance Travel Rule "sufficient identity data" requirements against
      // data-minimization principles (DPDP Act) — the full KYC document is
      // already separately retained in kyc_requests for full identity
      // verification if ever needed by an investigation.
      nationalIdLast4: originatorNationalId ? String(originatorNationalId).slice(-4) : null,
      isInternalPlatformUser: true,
    },
    beneficiary: {
      userId: beneficiaryUser?.id || null,
      name: beneficiaryUser?.name || null,
      nationalIdLast4: beneficiaryNationalId ? String(beneficiaryNationalId).slice(-4) : null,
      isInternalPlatformUser: true,
    },
    capturedAt: new Date().toISOString(),
  };
}

/**
 * JSON-backend helper: appends a Travel Rule record to db.travelRuleRecords
 * (creating the array if it doesn't exist yet) and returns the record with
 * a generated id. Caller is responsible for calling writeDb(db) afterwards.
 */
function captureTravelRuleData(db, uuidFn, params) {
  db.travelRuleRecords = db.travelRuleRecords || [];
  const record = { id: uuidFn(), ...buildTravelRuleRecord(params) };
  db.travelRuleRecords.push(record);
  return record;
}

module.exports = {
  buildTravelRuleRecord,
  captureTravelRuleData,
  VDA_TRANSFER_THRESHOLD_INR_FOR_TRAVEL_RULE,
};
