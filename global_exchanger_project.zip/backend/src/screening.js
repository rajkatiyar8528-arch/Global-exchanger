/**
 * screening.js
 * -----------------------------------------------------------------------
 * Sanctions/PEP name screening for KYC — a required piece of FIU-IND's
 * VDA Service Provider AML/CFT compliance demo (see
 * FIU_IND_REGISTRATION_GUIDE.md section 1, and
 * SANCTIONS_SCREENING_GUIDE.md for full rationale/setup instructions).
 *
 * Design goals:
 *   - Dependency-free (no npm package for fuzzy matching) so it can't break
 *     the Codemagic/Render build.
 *   - Works against a local JSON dataset (`data/sanctions_list.json`) so it
 *     has zero runtime dependency on any third-party API being up/paid.
 *   - Fuzzy enough to catch near-matches (misspellings, missing middle
 *     names) without being so loose that it floods admins with false
 *     positives on every common name — tuned via a configurable threshold.
 *   - NEVER auto-rejects a user. A match only creates a review flag for
 *     an admin to manually confirm/dismiss — sanctions screening false
 *     positives are common (e.g. "Mohammed Ali" is an extremely common
 *     name that also appears on watchlists) and auto-blocking on name
 *     match alone would be both bad UX and a false sense of security.
 * -----------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');

const SANCTIONS_PATH = path.join(__dirname, '../data/sanctions_list.json');

let _cache = null;
let _cacheLoadedAt = 0;
const CACHE_TTL_MS = 5 * 60_000; // reload from disk at most every 5 minutes

// Performance note (found via full-dataset load testing, ~20,000+ real
// entries / ~43,000 candidate name+alias strings): naively running full
// Levenshtein-distance comparisons against EVERY candidate on every single
// screenName() call took ~700-800ms per KYC submission — far too slow for
// a synchronous step in the user-facing KYC submission request. Two
// optimizations bring this down to a few milliseconds in the common case:
//   1. Pre-normalize every candidate name/alias ONCE when the list is
//      (re)loaded (not on every screening call).
//   2. Build a lightweight inverted index keyed by a 4-character prefix of
//      each significant word/token across all candidate names. At query
//      time, only candidates that share at least one token-prefix with the
//      input name are run through the expensive fuzzy-match scoring —
//      candidates with nothing in common are skipped entirely. This still
//      catches misspellings/transliteration variants (e.g. "Sheikh" vs
//      "Shaikh" share the "SHEI"/"SHAI"... actually differ in prefix, but
//      typically OTHER tokens in the same name — e.g. "Khalid", "Mohammed"
//      — match exactly, so the candidate is still found via those). The
//      trade-off: a name where EVERY token is simultaneously misspelled
//      enough to change its 4-char prefix could be missed — an accepted
//      limitation of this dependency-free starter implementation (see
//      SANCTIONS_SCREENING_GUIDE.md's recommendation to use a dedicated
//      screening vendor for production-grade fuzzy matching at scale).
function buildPrefixIndex(entries) {
  const index = new Map(); // prefixKey -> Set<entry index in `entries` array>
  entries.forEach((entry, i) => {
    for (const candidate of entry._normalizedCandidates) {
      for (const token of candidate.split(' ')) {
        if (token.length < 3) continue;
        const key = token.slice(0, 4);
        if (!index.has(key)) index.set(key, new Set());
        index.get(key).add(i);
      }
    }
  });
  return index;
}

function loadSanctionsList() {
  const now = Date.now();
  if (_cache && now - _cacheLoadedAt < CACHE_TTL_MS) return _cache;
  try {
    const raw = fs.readFileSync(SANCTIONS_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    // Pre-compute normalized candidate name/alias list once per entry.
    for (const entry of parsed.entries || []) {
      entry._normalizedCandidates = [entry.name, ...(entry.aliases || [])]
        .map(normalizeName)
        .filter(Boolean);
    }
    parsed._prefixIndex = buildPrefixIndex(parsed.entries || []);
    _cache = parsed;
  } catch (e) {
    console.error('[screening] Failed to load sanctions_list.json:', e.message);
    _cache = { metadata: {}, entries: [], _prefixIndex: new Map() };
  }
  _cacheLoadedAt = now;
  return _cache;
}

// ---------------------------------------------------------------------------
// Name normalization + fuzzy matching (dependency-free Levenshtein distance
// based similarity, plus a substring/token-overlap heuristic). This is a
// reasonable, transparent approach for a starter implementation — a real
// production deployment at scale should eventually use a dedicated
// sanctions-screening vendor/API (e.g. ComplyAdvantage, Refinitiv World-
// Check, Dow Jones Risk & Compliance) for better fuzzy-matching quality,
// phonetic matching, and a properly maintained, complete, auto-updating
// dataset. See SANCTIONS_SCREENING_GUIDE.md.
// ---------------------------------------------------------------------------

function normalizeName(name) {
  return String(name || '')
    .toUpperCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // strip diacritics
    .replace(/[^A-Z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function levenshtein(a, b) {
  if (a === b) return 0;
  const al = a.length, bl = b.length;
  if (al === 0) return bl;
  if (bl === 0) return al;
  let prev = Array.from({ length: bl + 1 }, (_, i) => i);
  for (let i = 1; i <= al; i++) {
    const curr = [i];
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    prev = curr;
  }
  return prev[bl];
}

// Similarity score 0..1 (1 = identical) using normalized Levenshtein distance
// over the longer of the two strings' length.
function similarity(a, b) {
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  return 1 - levenshtein(a, b) / maxLen;
}

// Token-overlap score: fraction of the smaller name's word tokens that have
// a close match (exact OR fuzzy, to catch transliteration variants like
// "Sheikh" vs "Shaikh") in the larger name. Helps catch cases like "Ahmed
// Ali" matching within "Ahmed Mohammed Hamed Ali", and name-order/spelling
// variants common in transliterated Arabic/other non-Latin names.
//
// IMPORTANT (bug found via full-dataset testing, ~20k sanctions entries):
// naively scoring "all of the smaller name's tokens matched" as high
// confidence breaks down badly when the smaller name has only ONE
// significant token — e.g. a single-word alias like "VERSA" would score a
// PERFECT 1.0 overlap against completely unrelated names like "Anita
// Verma" just because "Verma"~"Versa" fuzzy-matches, even though the rest
// of the name shares nothing. Single-token comparisons are inherently weak
// evidence and must NOT be allowed to produce a high-confidence score on
// their own — they're now capped low and require the full-string
// Levenshtein similarity (which naturally penalizes length mismatch) to
// also be reasonably high before a match is reported.
const TOKEN_FUZZY_MATCH_THRESHOLD = 0.8; // per-token similarity to count as "matching"
const MIN_SIGNIFICANT_TOKENS_FOR_FULL_CONFIDENCE = 2;

function tokenOverlap(a, b) {
  const at = a.split(' ').filter(t => t.length > 2);
  const bt = b.split(' ').filter(t => t.length > 2);
  if (at.length === 0 || bt.length === 0) return 0;
  const smaller = at.length <= bt.length ? at : bt;
  const larger = at.length <= bt.length ? bt : at;
  let hits = 0;
  let hasOnlyExactHits = true;
  for (const tok of smaller) {
    const isExactHit = larger.includes(tok);
    const bestTokenMatch = isExactHit ? 1 : Math.max(0, ...larger.map(t => similarity(tok, t)));
    if (bestTokenMatch >= TOKEN_FUZZY_MATCH_THRESHOLD) {
      hits++;
      if (!isExactHit) hasOnlyExactHits = false;
    }
  }
  const rawOverlap = hits / smaller.length;
  // Confidence dampening: a coincidental match built from only ONE
  // significant token is weak evidence — UNLESS that single token matched
  // EXACTLY (e.g. a distinctive short alias like "BNC" appearing verbatim
  // in the input), in which case an exact rare-token hit is fairly strong
  // evidence even on its own. It's specifically the FUZZY single-token
  // case (e.g. "VERSA" fuzzy-matching unrelated "VERMA") that produces
  // false positives and needs heavy discounting — see the bug writeup
  // above this function for how this was found via full-dataset testing.
  if (smaller.length < MIN_SIGNIFICANT_TOKENS_FOR_FULL_CONFIDENCE && !hasOnlyExactHits) {
    return rawOverlap * 0.5;
  }
  return rawOverlap;
}


// Combined match score (0..1). Configurable review threshold via env var.
const SCREENING_MATCH_THRESHOLD = Number(process.env.SANCTIONS_MATCH_THRESHOLD || 0.82);

function matchScore(inputName, candidateName) {
  const sim = similarity(inputName, candidateName);
  const overlap = tokenOverlap(inputName, candidateName);
  // Weighted blend: token overlap catches reordered/partial names,
  // Levenshtein similarity catches misspellings/transliteration variants.
  return Math.max(sim, overlap * 0.95);
}

/**
 * Screens a single name (and optional list of known aliases to also check,
 * e.g. from a KYC form) against the local sanctions dataset.
 * Returns an array of { entry, matchedAgainst, score } for anything at or
 * above the configured threshold, sorted by score descending. Empty array
 * means no concerning matches found.
 */
function screenName(name) {
  const list = loadSanctionsList();
  const entries = list.entries || [];
  const prefixIndex = list._prefixIndex;
  const normalizedInput = normalizeName(name);
  if (!normalizedInput) return [];

  // Use the prefix index to shortlist candidate entry indices sharing at
  // least one token-prefix with the input name, instead of scoring against
  // every single entry in the dataset. Falls back to scanning everything
  // if the index isn't available for some reason (e.g. very short input
  // with no tokens >= 3 chars, or an empty/failed-to-build index).
  let candidateIndices = null;
  if (prefixIndex && prefixIndex.size > 0) {
    candidateIndices = new Set();
    for (const token of normalizedInput.split(' ')) {
      if (token.length < 3) continue;
      const matchesForToken = prefixIndex.get(token.slice(0, 4));
      if (matchesForToken) for (const i of matchesForToken) candidateIndices.add(i);
    }
  }
  const entriesToCheck = candidateIndices ? [...candidateIndices].map(i => entries[i]) : entries;

  const results = [];
  for (const entry of entriesToCheck) {
    const candidates = entry._normalizedCandidates || [entry.name, ...(entry.aliases || [])].map(normalizeName).filter(Boolean);
    let best = 0;
    let bestAgainst = null;
    for (const cand of candidates) {
      const score = matchScore(normalizedInput, cand);
      if (score > best) { best = score; bestAgainst = cand; }
    }
    if (best >= SCREENING_MATCH_THRESHOLD) {
      // Strip the internal cache field before returning to callers/API responses.
      const { _normalizedCandidates, ...cleanEntry } = entry;
      results.push({ entry: cleanEntry, matchedAgainst: bestAgainst, score: Math.round(best * 1000) / 1000 });
    }
  }
  return results.sort((a, b) => b.score - a.score);
}

/**
 * Screens a full KYC submission (name plus any other name-like fields you
 * want to check, e.g. an "also known as" field if you add one later).
 * Returns { flagged: boolean, matches: [...] }.
 */
function screenKycSubmission({ fullName, aliasNames = [] }) {
  const allMatches = [];
  for (const n of [fullName, ...aliasNames].filter(Boolean)) {
    allMatches.push(...screenName(n));
  }
  // De-duplicate by entry id, keeping the highest score per entry.
  const byId = new Map();
  for (const m of allMatches) {
    const existing = byId.get(m.entry.id);
    if (!existing || m.score > existing.score) byId.set(m.entry.id, m);
  }
  const matches = [...byId.values()].sort((a, b) => b.score - a.score);
  return { flagged: matches.length > 0, matches };
}

function getSanctionsListMetadata() {
  const list = loadSanctionsList();
  return list.metadata || {};
}

module.exports = {
  screenName,
  screenKycSubmission,
  getSanctionsListMetadata,
  SCREENING_MATCH_THRESHOLD,
  // exported for unit testing
  normalizeName,
  similarity,
  tokenOverlap,
  matchScore,
};
