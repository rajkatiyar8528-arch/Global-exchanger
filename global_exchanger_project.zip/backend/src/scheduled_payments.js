/**
 * scheduled_payments.js
 * -----------------------------------------------------------------------
 * Dependency-free, pure helper functions for Scheduled/Recurring Payments
 * ("Autopay"-style mandates). Shared by both server.js (JSON) and
 * server_pg.js (Postgres) so the actual due/next-run-date logic can't
 * drift between the two backends.
 *
 * IMPORTANT (Render free-tier constraint, same story as price_alerts.js):
 * there is no reliable always-on background timer/cron on Render's free
 * web-service tier. Due mandates are executed OPPORTUNISTICALLY:
 *   1. Every time a signed-in user's app calls `GET /api/me` (happens on
 *      every screen that shows wallet balance — home, wallet, profile —
 *      so very frequently in practice) — that user's own due mandates run.
 *   2. Via the same `/api/cron/*`-style pattern already used for
 *      sanctions sync: `POST /api/cron/run-scheduled-payments` protected
 *      by a shared secret, meant to be pinged by an external scheduler
 *      (e.g. a GitHub Actions cron, same as sanctions-sync.yml) so due
 *      mandates run even for users who haven't opened the app recently.
 * This is documented to the user in SCHEDULED_PAYMENTS_GUIDE.md and in
 * the app's own screen copy so expectations are set correctly.
 * -----------------------------------------------------------------------
 */

const FREQUENCIES = ['daily', 'weekly', 'monthly'];

function isValidFrequency(freq) {
  return FREQUENCIES.includes(String(freq || ''));
}

// Given a frequency and a "from" Date, returns the next run Date.
// Monthly correctly rolls over month-end edge cases (e.g. 31st -> Feb)
// by relying on JS Date's own day-overflow rollover behavior.
function computeNextRunAt(frequency, from = new Date()) {
  const d = new Date(from.getTime());
  if (frequency === 'daily') {
    d.setDate(d.getDate() + 1);
  } else if (frequency === 'weekly') {
    d.setDate(d.getDate() + 7);
  } else if (frequency === 'monthly') {
    d.setMonth(d.getMonth() + 1);
  } else {
    throw new Error(`Unknown frequency: ${frequency}`);
  }
  return d;
}

// Max consecutive failures (e.g. insufficient balance) before a mandate is
// auto-paused so it doesn't keep silently failing forever without the user
// noticing — configurable via env var.
const MAX_CONSECUTIVE_FAILURES = Number(process.env.SCHEDULED_PAYMENT_MAX_FAILURES || 3);

module.exports = { FREQUENCIES, isValidFrequency, computeNextRunAt, MAX_CONSECUTIVE_FAILURES };
