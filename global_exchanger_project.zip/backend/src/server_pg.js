require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const { getPaymentProvider } = require('./payments/provider');
const { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail } = require('./otp');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb', verify: (req, res, buf) => { req.rawBody = buf; } }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function sign(payload) { return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' }); }
function auth(role = 'user') {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (role !== 'any' && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.auth = decoded;
      next();
    } catch (_) { res.status(401).json({ error: 'Invalid token' }); }
  };
}
function safeUser(row) {
  if (!row) return null;
  const { password_hash, security_pin_hash, ...u } = row;
  return {
    ...u,
    houseNumber: row.house_number,
    kycStatus: row.kyc_status,
    referralCode: row.referral_code,
    referredBy: row.referred_by,
    createdAt: row.created_at
  };
}


async function auditLog(clientOrPool, { adminId = null, userId = null, action, entityType, entityId, metadata = {}, req = null }) {
  await clientOrPool.query(
    'INSERT INTO audit_logs(admin_id,user_id,action,entity_type,entity_id,metadata,ip,user_agent) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',
    [adminId, userId, action, entityType, String(entityId || ''), metadata, req?.ip || null, req?.headers?.['user-agent'] || null]
  );
}

function requirePermission(permission) {
  return async (req, res, next) => {
    const r = await pool.query('SELECT * FROM admins WHERE id=$1', [req.auth.id]);
    const admin = r.rows[0];
    if (!admin) return res.status(403).json({ error: 'Admin not found' });
    const permissions = admin.permissions || [];
    if (admin.role !== 'super_admin' && !permissions.includes(permission)) return res.status(403).json({ error: `Missing permission: ${permission}` });
    req.admin = admin;
    next();
  };
}

async function getLedgerAccount(client, ownerType, ownerId, currency) {
  const existing = await client.query('SELECT * FROM ledger_accounts WHERE owner_type=$1 AND owner_id=$2 AND currency=$3', [ownerType, String(ownerId), currency]);
  if (existing.rows[0]) return existing.rows[0];
  const created = await client.query('INSERT INTO ledger_accounts(owner_type,owner_id,currency) VALUES($1,$2,$3) RETURNING *', [ownerType, String(ownerId), currency]);
  return created.rows[0];
}

async function postLedger(client, { debit, credit, amount, currency, referenceType, referenceId, description }) {
  if (!amount || Number(amount) <= 0) throw new Error('Ledger amount must be positive');
  const debitAccount = await getLedgerAccount(client, debit.ownerType, debit.ownerId, currency);
  const creditAccount = await getLedgerAccount(client, credit.ownerType, credit.ownerId, currency);
  await client.query('UPDATE ledger_accounts SET balance=balance+$1 WHERE id=$2', [amount, debitAccount.id]);
  await client.query('UPDATE ledger_accounts SET balance=balance-$1 WHERE id=$2', [amount, creditAccount.id]);
  const group = await client.query('SELECT uuid_generate_v4() AS id');
  const groupId = group.rows[0].id;
  await client.query('INSERT INTO ledger_entries(group_id,account_id,direction,amount,currency,reference_type,reference_id,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [groupId, debitAccount.id, 'debit', amount, currency, referenceType, String(referenceId), description]);
  await client.query('INSERT INTO ledger_entries(group_id,account_id,direction,amount,currency,reference_type,reference_id,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [groupId, creditAccount.id, 'credit', amount, currency, referenceType, String(referenceId), description]);
  return { groupId, debitAccount, creditAccount };
}

async function ensureAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@globalexchanger.com';
  const exists = await pool.query('SELECT id FROM admins WHERE email=$1', [email]);
  if (exists.rowCount === 0) {
    await pool.query(
      'INSERT INTO admins(email,password_hash,special_key_hash) VALUES($1,$2,$3)',
      [email, await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@12345', 10), await bcrypt.hash(process.env.ADMIN_SPECIAL_KEY || 'GX-SUPER-KEY-2026', 10)]
    );
  }
}

app.get('/', (_, res) => res.json({ app: 'Global Exchanger PostgreSQL API', status: 'running' }));

app.post('/api/auth/register', async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, email, phone, country, address, houseNumber, password, referralCode } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
    await client.query('BEGIN');
    const ref = `GX${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const userResult = await client.query(
      `INSERT INTO users(name,email,phone,country,address,house_number,password_hash,referral_code,referred_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name, email, phone, country, address, houseNumber, await bcrypt.hash(password, 10), ref, referralCode || null]
    );
    const user = userResult.rows[0];
    await client.query('INSERT INTO wallets(user_id) VALUES($1)', [user.id]);
    if (referralCode) await client.query('INSERT INTO referrals(referrer_code,referred_user_id) VALUES($1,$2)', [referralCode, user.id]);
    await client.query('COMMIT');
    res.json({ token: sign({ id: user.id, role: 'user' }), user: safeUser(user) });
  } catch (e) {
    await client.query('ROLLBACK');
    if (String(e.message).includes('duplicate')) return res.status(409).json({ error: 'Email or referral already exists' });
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const r = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = r.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Invalid login' });
  res.json({ token: sign({ id: user.id, role: 'user' }), user: safeUser(user) });
});

app.post('/api/admin/login', async (req, res) => {
  const { email, password, specialKey } = req.body;
  const r = await pool.query('SELECT * FROM admins WHERE email=$1', [email]);
  const admin = r.rows[0];
  const ok = admin && await bcrypt.compare(password, admin.password_hash) && await bcrypt.compare(specialKey, admin.special_key_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid admin login' });
  await auditLog(pool, { adminId: admin.id, action: 'admin.login', entityType: 'admin', entityId: admin.id, req });
  res.json({ token: sign({ id: admin.id, role: 'admin' }), admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

app.get('/api/me', auth('user'), async (req, res) => {
  const u = await pool.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
  const w = await pool.query('SELECT user_id AS "userId", balances, locked FROM wallets WHERE user_id=$1', [req.auth.id]);
  res.json({ user: safeUser(u.rows[0]), wallet: w.rows[0] });
});

app.post('/api/security/pin', auth('user'), async (req, res) => {
  const { pin } = req.body;
  if (!pin || String(pin).length < 4) return res.status(400).json({ error: 'PIN minimum 4 digits' });
  await pool.query('UPDATE users SET security_pin_hash=$1 WHERE id=$2', [await bcrypt.hash(String(pin), 10), req.auth.id]);
  res.json({ message: 'Security PIN created' });
});

app.post('/api/kyc', auth('user'), async (req, res) => {
  const { nationalId, taxId, country, documentNames = [] } = req.body;
  const r = await pool.query(
    'INSERT INTO kyc_requests(user_id,national_id,tax_id,country,document_names) VALUES($1,$2,$3,$4,$5) RETURNING *',
    [req.auth.id, nationalId, taxId, country, JSON.stringify(documentNames)]
  );
  await pool.query('UPDATE users SET kyc_status=$1 WHERE id=$2', ['under_review', req.auth.id]);
  await auditLog(pool, { userId: req.auth.id, action: 'kyc.submitted', entityType: 'kyc_request', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ kyc: r.rows[0] });
});

app.post('/api/bank-accounts', auth('user'), async (req, res) => {
  const { holderName, bankName, accountNumber, ifscSwiftIban, country } = req.body;
  const masked = String(accountNumber || '').slice(-4).padStart(8, '*');
  const r = await pool.query(
    `INSERT INTO bank_accounts(user_id,holder_name,bank_name,account_number_masked,ifsc_swift_iban,country)
     VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.auth.id, holderName, bankName, masked, ifscSwiftIban, country]
  );
  res.json({ account: r.rows[0] });
});

app.get('/api/wallet', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT user_id AS "userId", balances, locked FROM wallets WHERE user_id=$1', [req.auth.id]);
  res.json(r.rows[0]);
});

app.get('/api/rates', (_, res) => res.json({
  source: 'demo_rates_replace_with_live_api', updatedAt: new Date().toISOString(),
  forex: { USD_INR: 83.5, EUR_INR: 90.2, GBP_INR: 106.1, AED_INR: 22.7 },
  crypto: { BTC_USD: 65000, ETH_USD: 3400, XRP_USD: 0.52, BTC_INR: 5427500 }
}));

app.post('/api/transactions/send', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { toUserId, receiver, toEmail, amount, currency = 'INR', pin, note = '' } = req.body;
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) throw new Error('positive amount required');
    await client.query('BEGIN');
    const ur = await client.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
    const sender = ur.rows[0];
    if (!sender.security_pin_hash || !(await bcrypt.compare(String(pin), sender.security_pin_hash))) throw new Error('Invalid security PIN');
    const receiverKey = String(toUserId || receiver || toEmail || '').trim();
    if (!receiverKey) throw new Error('receiver email or userId required');
    const rr = await client.query('SELECT * FROM users WHERE id::text=$1 OR lower(email)=lower($1) OR phone=$1 LIMIT 1', [receiverKey]);
    const receiverUser = rr.rows[0];
    if (!receiverUser) throw new Error('Receiver not found');
    if (receiverUser.id === req.auth.id) throw new Error('Cannot send money to yourself');
    const from = (await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id])).rows[0];
    const to = (await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [receiverUser.id])).rows[0];
    if (!to) throw new Error('Receiver wallet not found');
    const bal = Number(from.balances[currency] || 0);
    if (bal < numericAmount) throw new Error('Insufficient balance');
    from.balances[currency] = bal - numericAmount;
    to.balances[currency] = Number(to.balances[currency] || 0) + numericAmount;
    await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [from.balances, req.auth.id]);
    await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [to.balances, receiverUser.id]);
    const txn = await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status,metadata) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', ['send', req.auth.id, receiverUser.id, numericAmount, currency, 'completed', { note }]);
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: receiverUser.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: numericAmount, currency, referenceType: 'transaction', referenceId: txn.rows[0].id, description: 'User to user wallet send/receive' });
    await client.query('COMMIT');
    res.json({ transaction: txn.rows[0], receiver: safeUser(receiverUser) });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.get('/api/transactions', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM transactions WHERE from_user_id=$1 OR to_user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});

app.post('/api/exchange/orders', auth('user'), async (req, res) => {
  const { fromCurrency, toCurrency, amount, mode = 'convert' } = req.body;
  const commission = Number(amount) * 0.01, adminCommission = Number(amount) * 0.008, sellerCommission = Number(amount) * 0.002;
  const r = await pool.query(
    `INSERT INTO exchange_orders(user_id,mode,from_currency,to_currency,amount,commission,admin_commission,seller_commission)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [req.auth.id, mode, fromCurrency, toCurrency, amount, commission, adminCommission, sellerCommission]
  );
  await pool.query('INSERT INTO commissions(order_id,admin_commission,seller_commission) VALUES($1,$2,$3)', [r.rows[0].id, adminCommission, sellerCommission]);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await postLedger(client, { debit: { ownerType: 'platform_commission_receivable', ownerId: 'exchange' }, credit: { ownerType: 'exchange_user_payable', ownerId: req.auth.id }, amount: commission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '1% exchange commission accrued' });
    await postLedger(client, { debit: { ownerType: 'admin_commission_earning', ownerId: 'admin' }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: adminCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.8% admin commission split' });
    await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.2% seller/user commission split' });
    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  res.json({ order: r.rows[0] });
});


app.post('/api/disputes', auth('user'), async (req, res) => {
  const { transactionId, reason, message, evidence = [] } = req.body;
  if (!reason || !message) return res.status(400).json({ error: 'reason and message required' });
  const r = await pool.query('INSERT INTO disputes(user_id,transaction_id,reason,message,evidence) VALUES($1,$2,$3,$4,$5) RETURNING *', [req.auth.id, transactionId || null, reason, message, JSON.stringify(evidence)]);
  res.json({ dispute: r.rows[0] });
});

app.get('/api/disputes', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM disputes WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});

app.get('/api/admin/disputes', auth('admin'), requirePermission('disputes:manage'), async (_, res) => {
  const r = await pool.query(`SELECT d.*, row_to_json(u.*) AS user FROM disputes d LEFT JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.patch('/api/admin/disputes/:id', auth('admin'), requirePermission('disputes:manage'), async (req, res) => {
  const { status, adminNote, resolution } = req.body;
  const r = await pool.query('UPDATE disputes SET status=COALESCE($1,status), admin_note=COALESCE($2,admin_note), resolution=COALESCE($3,resolution), updated_at=NOW() WHERE id=$4 RETURNING *', [status || null, adminNote || null, resolution || null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Dispute not found' });
  await auditLog(pool, { adminId: req.auth.id, action: `dispute.${r.rows[0].status}`, entityType: 'dispute', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ dispute: r.rows[0] });
});

app.post('/api/complaints', auth('user'), async (req, res) => {
  const { subject, message, transactionId } = req.body;
  const r = await pool.query('INSERT INTO complaints(user_id,subject,message,transaction_id) VALUES($1,$2,$3,$4) RETURNING *', [req.auth.id, subject, message, transactionId || null]);
  res.json({ complaint: r.rows[0] });
});


// OTP and Email Verification APIs
app.post('/api/auth/request-otp', async (req, res) => {
  const { email, purpose = 'email_verification' } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  const otp = generateOtp();
  await pool.query('INSERT INTO otp_codes(email,purpose,otp_hash,expires_at) VALUES($1,$2,$3,$4)', [email, purpose, await hashOtp(otp), otpExpiry(10)]);
  await sendOtpEmail({ email, otp, purpose });
  res.json({ message: 'OTP sent', purpose, devOtp: process.env.NODE_ENV === 'production' ? undefined : otp });
});

app.post('/api/auth/verify-email-otp', async (req, res) => {
  const { email, otp } = req.body;
  const r = await pool.query('SELECT * FROM otp_codes WHERE email=$1 AND purpose=$2 AND used=false ORDER BY created_at DESC LIMIT 1', [email, 'email_verification']);
  const item = r.rows[0];
  if (!item || isExpired(item.expires_at) || !(await compareOtp(otp, item.otp_hash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  await pool.query('UPDATE otp_codes SET used=true WHERE id=$1', [item.id]);
  await pool.query('UPDATE users SET email_verified=true WHERE email=$1', [email]);
  res.json({ message: 'Email verified' });
});

app.post('/api/auth/login-otp', async (req, res) => {
  const { email, otp } = req.body;
  const r = await pool.query('SELECT * FROM otp_codes WHERE email=$1 AND purpose=$2 AND used=false ORDER BY created_at DESC LIMIT 1', [email, 'login']);
  const item = r.rows[0];
  if (!item || isExpired(item.expires_at) || !(await compareOtp(otp, item.otp_hash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  const u = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = u.rows[0];
  if (!user) return res.status(404).json({ error: 'User not found' });
  await pool.query('UPDATE otp_codes SET used=true WHERE id=$1', [item.id]);
  res.json({ token: sign({ id: user.id, role: 'user' }), user: safeUser(user) });
});

// Payment Gateway Structure APIs
app.post('/api/payments/orders', auth('user'), async (req, res) => {
  const { amount, currency = 'INR', purpose = 'wallet_topup' } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'positive amount required' });
  const provider = getPaymentProvider();
  const gatewayOrder = await provider.createOrder({ amount: Number(amount), currency, receipt: `GX_${Date.now()}`, notes: { userId: req.auth.id, purpose } });
  const r = await pool.query(
    `INSERT INTO payment_orders(user_id,provider,gateway_order_id,amount,currency,purpose,gateway_response)
     VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [req.auth.id, gatewayOrder.provider, gatewayOrder.gatewayOrderId, amount, currency, purpose, gatewayOrder]
  );
  res.json({ order: r.rows[0], gatewayOrder });
});

app.post('/api/payments/verify', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { orderId, gatewayOrderId, gatewayPaymentId, gatewaySignature } = req.body;
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM payment_orders WHERE id=$1 AND user_id=$2 FOR UPDATE', [orderId, req.auth.id]);
    const order = r.rows[0];
    if (!order) throw new Error('Payment order not found');
    const provider = getPaymentProvider(order.provider);
    const verification = await provider.verifyPayment({ gatewayOrderId: gatewayOrderId || order.gateway_order_id, gatewayPaymentId, gatewaySignature });
    const status = verification.verified ? 'paid' : 'verification_failed';
    await client.query('UPDATE payment_orders SET status=$1, verification=$2 WHERE id=$3', [status, verification, order.id]);
    if (verification.verified && order.purpose === 'wallet_topup') {
      const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
      const balances = w.rows[0].balances;
      balances[order.currency] = Number(balances[order.currency] || 0) + Number(order.amount);
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [balances, req.auth.id]);
      await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['wallet_topup', null, req.auth.id, order.amount, order.currency, 'completed']);
      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, amount: order.amount, currency: order.currency, referenceType: 'payment_order', referenceId: order.id, description: 'Wallet top-up via payment gateway' });
    }
    await client.query('COMMIT');
    res.json({ order: { ...order, status }, verification });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message });
  } finally { client.release(); }
});

app.post('/api/payments/webhook', async (req, res) => {
  const provider = getPaymentProvider(process.env.PAYMENT_PROVIDER || 'mock');
  const signature = req.headers['x-razorpay-signature'];
  const raw = req.rawBody ? req.rawBody.toString() : JSON.stringify(req.body);
  const verified = provider.verifyWebhookSignature(raw, signature, process.env.RAZORPAY_WEBHOOK_SECRET);
  if ((process.env.PAYMENT_PROVIDER === 'razorpay') && !verified) return res.status(400).json({ error: 'Invalid webhook signature' });
  res.json({ received: true, verified });
});

app.post('/api/payments/refund', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { orderId, gatewayPaymentId, amount, reason = 'admin_refund' } = req.body;
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM payment_orders WHERE id=$1 FOR UPDATE', [orderId]);
    const order = r.rows[0];
    if (!order) throw new Error('Payment order not found');
    if (order.status !== 'paid') throw new Error('Only paid orders can be refunded');
    const provider = getPaymentProvider(order.provider);
    const refund = await provider.refundPayment({ gatewayPaymentId: gatewayPaymentId || order.verification?.gatewayPaymentId, amount: amount || order.amount, notes: { reason, orderId } });
    const refundAmount = Number(amount || order.amount);
    const rr = await client.query('INSERT INTO refunds(order_id,provider,amount,currency,reason,status,gateway_refund) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', [orderId, order.provider, refundAmount, order.currency, reason, refund.status || 'processed', refund]);
    await client.query('UPDATE payment_orders SET status=$1 WHERE id=$2', ['refunded', orderId]);
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    if (w.rows[0]) {
      const balances = w.rows[0].balances;
      balances[order.currency] = Number(balances[order.currency] || 0) - refundAmount;
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [balances, order.user_id]);
    }
    await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['refund', order.user_id, null, refundAmount, order.currency, 'completed']);
    await postLedger(client, { debit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, credit: { ownerType: 'user_wallet', ownerId: order.user_id }, amount: refundAmount, currency: order.currency, referenceType: 'refund', referenceId: rr.rows[0].id, description: 'Payment refund from wallet' });
    await auditLog(client, { adminId: req.auth.id, action: 'payment.refund', entityType: 'payment_order', entityId: orderId, metadata: { refundId: rr.rows[0].id, amount: refundAmount, currency: order.currency }, req });
    await client.query('COMMIT');
    res.json({ refund: rr.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});


app.post('/api/exchange/orders/:id/lock-escrow', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 AND user_id=$2 FOR UPDATE', [req.params.id, req.auth.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status === 'locked') throw new Error('Escrow already locked');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {};
    if (Number(balances[order.from_currency] || 0) < Number(order.amount)) throw new Error('Insufficient balance for escrow');
    balances[order.from_currency] = Number(balances[order.from_currency] || 0) - Number(order.amount);
    locked[order.from_currency] = Number(locked[order.from_currency] || 0) + Number(order.amount);
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, req.auth.id]);
    const updated = await client.query("UPDATE exchange_orders SET status='escrow_locked', escrow_status='locked' WHERE id=$1 RETURNING *", [order.id]);
    await postLedger(client, { debit: { ownerType: 'exchange_escrow', ownerId: order.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Exchange amount locked in escrow' });
    await client.query('COMMIT');
    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.post('/api/admin/exchange/orders/:id/complete', auth('admin'), requirePermission('exchange:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { rate, receiveAmount } = req.body;
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status !== 'locked') throw new Error('Escrow must be locked before completion');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    const wallet = w.rows[0], balances = wallet.balances, locked = wallet.locked || {};
    const finalReceive = Number(receiveAmount || (Number(order.amount) * Number(rate || 1)));
    locked[order.from_currency] = Math.max(0, Number(locked[order.from_currency] || 0) - Number(order.amount));
    balances[order.to_currency] = Number(balances[order.to_currency] || 0) + finalReceive;
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, order.user_id]);
    const updated = await client.query("UPDATE exchange_orders SET status='completed', escrow_status='released' WHERE id=$1 RETURNING *", [order.id]);
    await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['exchange_complete', order.user_id, order.user_id, finalReceive, order.to_currency, 'completed']);
    await postLedger(client, { debit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow source currency released to exchange pool' });
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: order.user_id }, credit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, amount: finalReceive, currency: order.to_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Converted currency credited to user wallet' });
    await auditLog(client, { adminId: req.auth.id, action: 'exchange.complete', entityType: 'exchange_order', entityId: order.id, metadata: { rate, receiveAmount: finalReceive }, req });
    await client.query('COMMIT');
    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.post('/api/admin/exchange/orders/:id/cancel', auth('admin'), requirePermission('exchange:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status === 'locked') {
      const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
      const balances = w.rows[0].balances, locked = w.rows[0].locked || {};
      locked[order.from_currency] = Math.max(0, Number(locked[order.from_currency] || 0) - Number(order.amount));
      balances[order.from_currency] = Number(balances[order.from_currency] || 0) + Number(order.amount);
      await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, order.user_id]);
      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: order.user_id }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow returned to user after cancellation' });
    }
    const updated = await client.query("UPDATE exchange_orders SET status='cancelled', escrow_status='cancelled' WHERE id=$1 RETURNING *", [order.id]);
    await auditLog(client, { adminId: req.auth.id, action: 'exchange.cancel', entityType: 'exchange_order', entityId: order.id, req });
    await client.query('COMMIT');
    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.get('/api/admin/exchange/orders', auth('admin'), requirePermission('exchange:manage'), async (_, res) => {
  const r = await pool.query(`SELECT e.*, row_to_json(u.*) AS user FROM exchange_orders e LEFT JOIN users u ON u.id=e.user_id ORDER BY e.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});


app.get('/api/admin/admins', auth('admin'), requirePermission('admin:manage'), async (_, res) => {
  const r = await pool.query('SELECT id,email,role,permissions,created_at FROM admins ORDER BY created_at DESC');
  res.json(r.rows);
});

app.patch('/api/admin/admins/:id/role', auth('admin'), requirePermission('admin:manage'), async (req, res) => {
  const { role, permissions } = req.body;
  const r = await pool.query('UPDATE admins SET role=COALESCE($1,role), permissions=COALESCE($2,permissions) WHERE id=$3 RETURNING id,email,role,permissions,created_at', [role || null, permissions ? JSON.stringify(permissions) : null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Admin not found' });
  await auditLog(pool, { adminId: req.auth.id, action: 'admin.role_update', entityType: 'admin', entityId: req.params.id, metadata: { role: r.rows[0].role, permissions: r.rows[0].permissions }, req });
  res.json({ admin: r.rows[0] });
});

app.get('/api/admin/audit-logs', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500');
  res.json(r.rows);
});

app.get('/api/admin/roles', auth('admin'), requirePermission('admin:manage','disputes:manage'), async (_, res) => {
  res.json({ roles: [
    { role: 'super_admin', permissions: ['*'] },
    { role: 'kyc_manager', permissions: ['users:read','kyc:manage','audit:read'] },
    { role: 'finance_manager', permissions: ['payments:read','refunds:manage','ledger:read','exchange:manage','audit:read'] },
    { role: 'support_agent', permissions: ['users:read','payments:read','disputes:manage','audit:read'] }
  ]});
});

app.get('/api/admin/dashboard', auth('admin'), async (_, res) => {
  const q = async sql => Number((await pool.query(sql)).rows[0].count || 0);
  const commission = await pool.query('SELECT COALESCE(SUM(admin_commission),0) AS total FROM commissions');
  res.json({ users: await q('SELECT COUNT(*) FROM users'), kycPending: await q("SELECT COUNT(*) FROM kyc_requests WHERE status <> 'approved'"), transactions: await q('SELECT COUNT(*) FROM transactions'), complaints: await q('SELECT COUNT(*) FROM complaints'), exchangeOrders: await q('SELECT COUNT(*) FROM exchange_orders'), adminCommission: Number(commission.rows[0].total) });
});

app.get('/api/admin/kyc-requests', auth('admin'), requirePermission('kyc:manage'), async (_, res) => {
  const r = await pool.query(`SELECT k.*, row_to_json(u.*) AS user FROM kyc_requests k LEFT JOIN users u ON u.id=k.user_id ORDER BY k.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.get('/api/admin/refunds', auth('admin'), async (_, res) => {
  const r = await pool.query('SELECT * FROM refunds ORDER BY created_at DESC');
  res.json(r.rows);
});

app.get('/api/admin/payment-orders', auth('admin'), requirePermission('payments:read'), async (_, res) => {
  const r = await pool.query(`SELECT p.*, row_to_json(u.*) AS user FROM payment_orders p LEFT JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.get('/api/admin/ledger', auth('admin'), requirePermission('ledger:read'), async (_, res) => {
  const accounts = await pool.query('SELECT * FROM ledger_accounts ORDER BY created_at DESC');
  const entries = await pool.query('SELECT * FROM ledger_entries ORDER BY created_at DESC LIMIT 500');
  res.json({ accounts: accounts.rows, entries: entries.rows });
});

app.get('/api/admin/users', auth('admin'), async (_, res) => { const r = await pool.query('SELECT * FROM users ORDER BY created_at DESC'); res.json(r.rows.map(safeUser)); });

app.patch('/api/admin/complaints/:id', auth('admin'), async (req, res) => {
  const { status } = req.body;
  const r = await pool.query('UPDATE complaints SET status=COALESCE($1,status) WHERE id=$2 RETURNING *', [status || null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  await auditLog(pool, { adminId: req.auth.id, action: `complaint.${r.rows[0].status}`, entityType: 'complaint', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ complaint: r.rows[0] });
});

app.get('/api/admin/complaints', auth('admin'), async (_, res) => { const r = await pool.query('SELECT * FROM complaints ORDER BY created_at DESC'); res.json(r.rows); });
app.patch('/api/admin/kyc/:id', auth('admin'), requirePermission('kyc:manage'), async (req, res) => {
  const { status } = req.body;
  const r = await pool.query('UPDATE kyc_requests SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'KYC not found' });
  await pool.query('UPDATE users SET kyc_status=$1 WHERE id=$2', [status, r.rows[0].user_id]);
  res.json({ kyc: r.rows[0] });
});

ensureAdmin().then(() => app.listen(PORT, () => console.log(`Global Exchanger PostgreSQL API running on http://localhost:${PORT}`))).catch(e => { console.error(e); process.exit(1); });
