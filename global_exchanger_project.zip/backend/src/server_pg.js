require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const { getPaymentProvider } = require('./payments/provider');
const { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail } = require('./otp');
const { notifyUser } = require('./notifications');
const { rateLimit, ipAndFieldKey, securityHeaders, isStrongPassword, buildCorsOptions } = require('./security');
const { generateReceiptToken, renderTransactionReceipt, renderExchangeReceipt, wrapReceiptPage } = require('./receipts');
const { signAccessToken, issueNewRefreshTokenFamily, rotateRefreshToken, revokeRefreshToken, revokeAllForOwner } = require('./auth_tokens');

const app = express();
app.set('trust proxy', true); // Render sits behind Cloudflare + its own internal proxy (multiple hops); trust all of them so req.ip reflects the real client IP for rate limiting.
app.use(securityHeaders);
app.use(cors(buildCorsOptions()));
app.use(express.json({ limit: '20mb', verify: (req, res, buf) => { req.rawBody = buf; } }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is not set. Refusing to start with an insecure default.');
  process.exit(1);
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Rate limiters for sensitive/abuse-prone endpoints.
const loginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many login attempts. Please try again in 15 minutes.' });
const adminLoginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many admin login attempts. Please try again in 15 minutes.' });
const otpRequestLimiter = rateLimit({ windowMs: 10 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many OTP requests. Please wait before requesting again.' });
const otpVerifyLimiter = rateLimit({ windowMs: 10 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many OTP verification attempts. Please try again later.' });
const registerLimiter = rateLimit({ windowMs: 60 * 60_000, max: 10, keyFn: (req) => req.ip, message: 'Too many signup attempts from this network. Please try again later.' });
const generalApiLimiter = rateLimit({ windowMs: 60_000, max: 120, keyFn: (req) => req.ip, message: 'Too many requests. Please slow down.' });

app.use('/api', generalApiLimiter);


function sign(payload) { return signAccessToken(JWT_SECRET, payload); }

// Issues a fresh access token (15 min) + refresh token (30 days, rotating,
// revocable) pair for a login/register/refresh event, and shapes it into
// the response fields the app expects.
async function issueAuthSession({ ownerType, ownerId, payload, req }) {
  const accessToken = sign(payload);
  const { refreshToken, expiresAt } = await issueNewRefreshTokenFamily(pool, { ownerType, ownerId, req });
  return { token: accessToken, refreshToken, refreshTokenExpiresAt: expiresAt };
}

function auth(role = 'user') {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (role !== 'any' && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.auth = decoded;
      next();
    } catch (e) {
      // Distinguish "expired" from "invalid" so the app knows an expired
      // access token just needs a silent refresh (normal, expected every 15
      // minutes) rather than forcing the user all the way back to login.
      if (e.name === 'TokenExpiredError') return res.status(401).json({ error: 'Access token expired', code: 'TOKEN_EXPIRED' });
      res.status(401).json({ error: 'Invalid token' });
    }
  };
}
function safeUser(row) {
  if (!row) return null;
  const { password_hash, security_pin_hash, ...u } = row;
  return {
    ...u,
    houseNumber: row.house_number,
    kycStatus: row.kyc_status,
    referralCode: row.referral_code,
    referredBy: row.referred_by,
    createdAt: row.created_at
  };
}


async function auditLog(clientOrPool, { adminId = null, userId = null, action, entityType, entityId, metadata = {}, req = null }) {
  await clientOrPool.query(
    'INSERT INTO audit_logs(admin_id,user_id,action,entity_type,entity_id,metadata,ip,user_agent) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',
    [adminId, userId, action, entityType, String(entityId || ''), metadata, req?.ip || null, req?.headers?.['user-agent'] || null]
  );
}

function requirePermission(permission) {
  return async (req, res, next) => {
    const r = await pool.query('SELECT * FROM admins WHERE id=$1', [req.auth.id]);
    const admin = r.rows[0];
    if (!admin) return res.status(403).json({ error: 'Admin not found' });
    const permissions = admin.permissions || [];
    if (admin.role !== 'super_admin' && !permissions.includes(permission)) return res.status(403).json({ error: `Missing permission: ${permission}` });
    req.admin = admin;
    next();
  };
}

async function getLedgerAccount(client, ownerType, ownerId, currency) {
  const existing = await client.query('SELECT * FROM ledger_accounts WHERE owner_type=$1 AND owner_id=$2 AND currency=$3', [ownerType, String(ownerId), currency]);
  if (existing.rows[0]) return existing.rows[0];
  const created = await client.query('INSERT INTO ledger_accounts(owner_type,owner_id,currency) VALUES($1,$2,$3) RETURNING *', [ownerType, String(ownerId), currency]);
  return created.rows[0];
}

async function postLedger(client, { debit, credit, amount, currency, referenceType, referenceId, description }) {
  if (!amount || Number(amount) <= 0) throw new Error('Ledger amount must be positive');
  const debitAccount = await getLedgerAccount(client, debit.ownerType, debit.ownerId, currency);
  const creditAccount = await getLedgerAccount(client, credit.ownerType, credit.ownerId, currency);
  await client.query('UPDATE ledger_accounts SET balance=balance+$1 WHERE id=$2', [amount, debitAccount.id]);
  await client.query('UPDATE ledger_accounts SET balance=balance-$1 WHERE id=$2', [amount, creditAccount.id]);
  const group = await client.query('SELECT uuid_generate_v4() AS id');
  const groupId = group.rows[0].id;
  await client.query('INSERT INTO ledger_entries(group_id,account_id,direction,amount,currency,reference_type,reference_id,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [groupId, debitAccount.id, 'debit', amount, currency, referenceType, String(referenceId), description]);
  await client.query('INSERT INTO ledger_entries(group_id,account_id,direction,amount,currency,reference_type,reference_id,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [groupId, creditAccount.id, 'credit', amount, currency, referenceType, String(referenceId), description]);
  return { groupId, debitAccount, creditAccount };
}

// ---------------------------------------------------------------------------
// Referral reward: pays out the referrer's ₹100 the first time (and only the
// first time) their referred user completes ANY real transaction — sending
// money, topping up their wallet, or completing a currency exchange. This is
// intentionally NOT paid at signup, to avoid fake-account abuse where someone
// creates throwaway accounts just to farm referral rewards without any real
// usage. Safe to call on every transaction; it's a no-op once already paid.
// ---------------------------------------------------------------------------
async function maybePayReferralReward(client, referredUserId) {
  const r = await client.query(
    "SELECT * FROM referrals WHERE referred_user_id=$1 AND status='pending_first_transaction' FOR UPDATE",
    [referredUserId]
  );
  const referral = r.rows[0];
  if (!referral) return;

  const rewardAmount = Number(referral.reward || 100);
  const currency = referral.currency || 'INR';

  const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [referral.referrer_user_id]);
  const wallet = w.rows[0];
  if (!wallet) return; // referrer account no longer exists — leave referral as-is for manual review

  const rewardBalances = wallet.reward_balances || {};
  rewardBalances[currency] = Number(rewardBalances[currency] || 0) + rewardAmount;
  await client.query('UPDATE wallets SET reward_balances=$1 WHERE user_id=$2', [rewardBalances, referral.referrer_user_id]);

  await client.query("UPDATE referrals SET status='rewarded', rewarded_at=NOW() WHERE id=$1", [referral.id]);

  await postLedger(client, {
    debit: { ownerType: 'user_reward_wallet', ownerId: referral.referrer_user_id },
    credit: { ownerType: 'referral_reward_pool', ownerId: 'referrals' },
    amount: rewardAmount,
    currency,
    referenceType: 'referral',
    referenceId: referral.id,
    description: `Referral reward for inviting a user who completed their first transaction`,
  });

  const refUser = await client.query('SELECT email FROM users WHERE id=$1', [referral.referrer_user_id]);
  await notifyUser(pool, {
    userId: referral.referrer_user_id,
    userEmail: refUser.rows[0]?.email,
    type: 'referral_reward_credited',
    title: 'Referral Reward Credited!',
    message: `Aapke refer kiye hue user ne apna pehla transaction complete kar liya. ${currency} ${rewardAmount} aapke Reward Wallet mein credit ho gaya hai!`,
    metadata: { referralId: referral.id, amount: rewardAmount, currency },
    sendEmail: false,
  });
}

// Auto-run schema.sql on every server startup so Render free-tier (no Shell access)
// deployments always have the latest tables/columns without needing manual migration.
async function autoMigrate() {
  try {
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const sql = fs.readFileSync(schemaPath, 'utf8');
    await pool.query(sql);
    console.log('Auto-migration completed (schema.sql applied)');
  } catch (e) {
    console.error('Auto-migration failed:', e.message);
  }
}

async function ensureAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@globalexchanger.com';
  const exists = await pool.query('SELECT id FROM admins WHERE email=$1', [email]);
  if (exists.rowCount === 0) {
    await pool.query(
      'INSERT INTO admins(email,password_hash,special_key_hash) VALUES($1,$2,$3)',
      [email, await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@12345', 10), await bcrypt.hash(process.env.ADMIN_SPECIAL_KEY || 'GX-SUPER-KEY-2026', 10)]
    );
  }
}

app.get('/', (_, res) => res.json({ app: 'Global Exchanger PostgreSQL API', status: 'running' }));

app.post('/api/auth/register', registerLimiter, async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, email, phone, country, address, houseNumber, password, referralCode } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
    if (!isStrongPassword(password)) return res.status(400).json({ error: 'Password must be at least 8 characters and include both letters and numbers.' });

    // Validate the referral code (if provided) BEFORE creating the account,
    // so a typo/fake code doesn't silently create an orphaned referral row.
    let referrer = null;
    if (referralCode) {
      const refCheck = await client.query('SELECT id, email FROM users WHERE referral_code=$1', [String(referralCode).trim().toUpperCase()]);
      referrer = refCheck.rows[0] || null;
      if (!referrer) return res.status(400).json({ error: 'Invalid referral code' });
    }

    await client.query('BEGIN');
    const ref = `GX${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const userResult = await client.query(
      `INSERT INTO users(name,email,phone,country,address,house_number,password_hash,referral_code,referred_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name, email, phone, country, address, houseNumber, await bcrypt.hash(password, 10), ref, referralCode || null]
    );
    const user = userResult.rows[0];
    await client.query('INSERT INTO wallets(user_id) VALUES($1)', [user.id]);

    // Prevent self-referral (someone using their own code) — silently ignored
    // rather than erroring, so registration still succeeds.
    if (referrer && referrer.id !== user.id) {
      await client.query(
        'INSERT INTO referrals(referrer_code,referrer_user_id,referred_user_id,status) VALUES($1,$2,$3,$4)',
        [referralCode, referrer.id, user.id, 'pending_first_transaction']
      );
    }

    await client.query('COMMIT');
    const session = await issueAuthSession({ ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
    res.json({ ...session, user: safeUser(user) });
  } catch (e) {
    await client.query('ROLLBACK');
    if (String(e.message).includes('duplicate')) return res.status(409).json({ error: 'Email or referral already exists' });
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Invalid login' });
  const r = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = r.rows[0];
  // Always run bcrypt.compare (even with a dummy hash) so response timing doesn't
  // reveal whether the email exists — mitigates user-enumeration via timing attacks.
  const passwordHash = user?.password_hash || '$2a$10$CwTycUXWue0Thq9StjUM0uJ8gI0mZzn0EXAMPLEHASHVALUEXXXXX';
  const passwordOk = await bcrypt.compare(password, passwordHash);
  if (!user || !passwordOk) return res.status(401).json({ error: 'Invalid email or password' });
  const session = await issueAuthSession({ ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  res.json({ ...session, user: safeUser(user) });
});

app.post('/api/admin/login', adminLoginLimiter, async (req, res) => {
  const { email, password, specialKey } = req.body;
  if (!email || !password || !specialKey) return res.status(400).json({ error: 'Invalid admin login' });
  const r = await pool.query('SELECT * FROM admins WHERE email=$1', [email]);
  const admin = r.rows[0];
  const ok = admin && await bcrypt.compare(password, admin.password_hash) && await bcrypt.compare(specialKey, admin.special_key_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid admin login' });
  await auditLog(pool, { adminId: admin.id, action: 'admin.login', entityType: 'admin', entityId: admin.id, req });
  const session = await issueAuthSession({ ownerType: 'admin', ownerId: admin.id, payload: { id: admin.id, role: 'admin' }, req });
  res.json({ ...session, admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

// Exchanges a valid, unrevoked refresh token for a brand new access token +
// rotated refresh token. Called automatically by the app in the background
// shortly before the current 15-minute access token expires, so the user
// never has to manually re-login during the 30-day refresh token window.
app.post('/api/auth/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });

  const result = await rotateRefreshToken(pool, refreshToken, req);
  if (!result.ok) {
    const messages = {
      invalid: 'Invalid refresh token. Please log in again.',
      reused: 'This session was used from another device or has expired. For your security, please log in again.',
      expired: 'Your session has expired. Please log in again.',
    };
    return res.status(401).json({ error: messages[result.reason] || 'Please log in again.' });
  }

  const accessToken = signAccessToken(JWT_SECRET, { id: result.ownerId, role: result.ownerType });
  res.json({ token: accessToken, refreshToken: result.refreshToken, refreshTokenExpiresAt: result.expiresAt });
});

// Revokes the current refresh token — real server-side logout, unlike just
// deleting the token from the app (which left the token valid until its
// natural 7-day expiry under the old design).
app.post('/api/auth/logout', async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) await revokeRefreshToken(pool, refreshToken);
  res.json({ success: true });
});

// "Logout everywhere" — revokes ALL of the current user's refresh tokens
// (every device/session), e.g. if they suspect their account/device is
// compromised. Requires a valid (short-lived) access token to call.
app.post('/api/auth/logout-all', auth('any'), async (req, res) => {
  await revokeAllForOwner(pool, req.auth.role, req.auth.id);
  res.json({ success: true });
});

app.get('/api/me', auth('user'), async (req, res) => {
  const u = await pool.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
  const w = await pool.query('SELECT user_id AS "userId", balances, locked, reward_balances AS "rewardBalances" FROM wallets WHERE user_id=$1', [req.auth.id]);
  res.json({ user: safeUser(u.rows[0]), wallet: w.rows[0] });
});

// Referral summary: my code, how many people I've referred, how many have
// been rewarded yet, and a per-referral breakdown (without exposing the
// referred user's private info beyond name/email).
app.get('/api/referrals/mine', auth('user'), async (req, res) => {
  const me = await pool.query('SELECT referral_code FROM users WHERE id=$1', [req.auth.id]);
  const referralCode = me.rows[0]?.referral_code;

  const rows = await pool.query(
    `SELECT r.*, row_to_json(u.*) AS referred_user
     FROM referrals r LEFT JOIN users u ON u.id = r.referred_user_id
     WHERE r.referrer_user_id=$1 ORDER BY r.created_at DESC`,
    [req.auth.id]
  );

  const referrals = rows.rows.map(r => ({
    id: r.id,
    status: r.status,
    reward: r.reward,
    currency: r.currency,
    rewardedAt: r.rewarded_at,
    createdAt: r.created_at,
    referredUser: r.referred_user ? { name: r.referred_user.name, email: r.referred_user.email } : null,
  }));

  const totalReferred = referrals.length;
  const totalRewarded = referrals.filter(r => r.status === 'rewarded').length;
  const totalEarned = referrals.filter(r => r.status === 'rewarded').reduce((sum, r) => sum + Number(r.reward || 0), 0);

  res.json({ referralCode, totalReferred, totalRewarded, totalEarned, referrals });
});

app.post('/api/security/pin', auth('user'), async (req, res) => {
  const { pin } = req.body;
  const pinStr = String(pin || '');
  if (!/^\d{4,6}$/.test(pinStr)) return res.status(400).json({ error: 'PIN must be 4-6 digits' });
  // Reject only the most obviously guessable PINs: all-same-digit (0000, 1111...)
  // or a fully ascending/descending run (1234, 4321, 123456, 654321...).
  // Anything else (e.g. 1357, 2468, 9182) is accepted — the previous check was
  // too aggressive and rejected common, perfectly reasonable PINs like 1234/5678.
  const isAllSameDigit = /^(\d)\1+$/.test(pinStr);
  const digits = pinStr.split('').map(Number);
  const isAscendingRun = digits.every((d, i) => i === 0 || d === digits[i - 1] + 1);
  const isDescendingRun = digits.every((d, i) => i === 0 || d === digits[i - 1] - 1);
  if (isAllSameDigit || isAscendingRun || isDescendingRun) {
    return res.status(400).json({ error: 'This PIN is too easy to guess (all same digit or a straight sequence). Please choose a different one.' });
  }
  await pool.query('UPDATE users SET security_pin_hash=$1 WHERE id=$2', [await bcrypt.hash(pinStr, 10), req.auth.id]);
  res.json({ message: 'Security PIN created' });
});

// KYC documents are accepted as base64 data URLs from the app (no external
// storage account needed) and stored directly in Postgres as JSONB. We cap
// the number of documents and the size of each one so a bad/huge upload
// can't blow up the database or the request payload.
const MAX_KYC_DOCUMENTS = 5;
const MAX_KYC_DOCUMENT_BYTES = 4 * 1024 * 1024; // ~4MB per document (post base64-decode)
const ALLOWED_KYC_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

function sanitizeKycDocuments(documents) {
  if (!Array.isArray(documents)) return [];
  if (documents.length > MAX_KYC_DOCUMENTS) throw new Error(`Maximum ${MAX_KYC_DOCUMENTS} documents allowed`);
  return documents.map((doc, i) => {
    const label = String(doc?.label || `Document ${i + 1}`).slice(0, 100);
    const mimeType = String(doc?.mimeType || '');
    const dataBase64 = String(doc?.dataBase64 || '');
    if (!ALLOWED_KYC_MIME_TYPES.includes(mimeType)) throw new Error(`Unsupported document type: ${mimeType || 'unknown'}`);
    if (!dataBase64) throw new Error(`${label}: document data is empty`);
    const approxBytes = Math.floor((dataBase64.length * 3) / 4);
    if (approxBytes > MAX_KYC_DOCUMENT_BYTES) throw new Error(`${label} is too large (max 4MB per document)`);
    return { label, mimeType, dataBase64, uploadedAt: new Date().toISOString() };
  });
}

app.post('/api/kyc', auth('user'), async (req, res) => {
  try {
    const { nationalId, taxId, country, documents = [] } = req.body;
    const sanitizedDocs = sanitizeKycDocuments(documents);
    const documentNames = sanitizedDocs.map(d => d.label);
    const r = await pool.query(
      'INSERT INTO kyc_requests(user_id,national_id,tax_id,country,document_names,documents) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,user_id,national_id,tax_id,country,document_names,status,created_at',
      [req.auth.id, nationalId, taxId, country, JSON.stringify(documentNames), JSON.stringify(sanitizedDocs)]
    );
    await pool.query('UPDATE users SET kyc_status=$1 WHERE id=$2', ['under_review', req.auth.id]);
    await auditLog(pool, { userId: req.auth.id, action: 'kyc.submitted', entityType: 'kyc_request', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status, documentCount: sanitizedDocs.length }, req });
    res.json({ kyc: r.rows[0] });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Lets the logged-in user check their own KYC status + which documents they've submitted
// (without ever sending the raw document bytes back down, to keep responses small/fast).
app.get('/api/kyc/me', auth('user'), async (req, res) => {
  const r = await pool.query(
    'SELECT id, national_id, tax_id, country, document_names, status, created_at FROM kyc_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1',
    [req.auth.id]
  );
  res.json({ kyc: r.rows[0] || null });
});

app.post('/api/bank-accounts', auth('user'), async (req, res) => {
  const { holderName, bankName, accountNumber, ifscSwiftIban, country } = req.body;
  const masked = String(accountNumber || '').slice(-4).padStart(8, '*');
  const r = await pool.query(
    `INSERT INTO bank_accounts(user_id,holder_name,bank_name,account_number_masked,ifsc_swift_iban,country)
     VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.auth.id, holderName, bankName, masked, ifscSwiftIban, country]
  );
  res.json({ account: r.rows[0] });
});

app.get('/api/wallet', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT user_id AS "userId", balances, locked, reward_balances AS "rewardBalances" FROM wallets WHERE user_id=$1', [req.auth.id]);
  res.json(r.rows[0]);
});

// Move reward wallet balance into the main spendable wallet balance for one currency.
app.post('/api/wallet/redeem-rewards', auth('user'), async (req, res) => {
  const { currency = 'INR' } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, rewardBalances = wallet.reward_balances || {};
    const amount = Number(rewardBalances[currency] || 0);
    if (amount <= 0) throw new Error('No reward balance available to redeem for this currency');
    rewardBalances[currency] = 0;
    balances[currency] = Number(balances[currency] || 0) + amount;
    await client.query('UPDATE wallets SET balances=$1, reward_balances=$2 WHERE user_id=$3', [balances, rewardBalances, req.auth.id]);
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, amount, currency, referenceType: 'reward_redeem', referenceId: req.auth.id, description: 'Reward wallet redeemed into main wallet balance' });
    await client.query('COMMIT');
    res.json({ redeemed: amount, currency, wallet: { balances, rewardBalances } });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

// ---------------------------------------------------------------------------
// Live exchange rates (forex + crypto), fetched from free public APIs and
// cached in-memory for 60 seconds so we don't hammer the upstream providers
// or slow down every /api/rates request. If both providers fail (network
// issue, rate limit, etc.), we fall back to the last known good rates so the
// app never breaks; if we have never fetched successfully we fall back to
// the original static demo numbers, clearly marked as "demo_fallback".
// ---------------------------------------------------------------------------
let _ratesCache = null;
let _ratesCacheExpiry = 0;
const RATES_CACHE_MS = 60_000;
const STATIC_FALLBACK_RATES = {
  forex: { USD_INR: 83.5, EUR_INR: 90.2, GBP_INR: 106.1, AED_INR: 22.7 },
  crypto: { BTC_USD: 65000, ETH_USD: 3400, XRP_USD: 0.52, BTC_INR: 5427500 }
};

async function fetchLiveRates() {
  const [forexRes, cryptoRes] = await Promise.allSettled([
    fetch('https://open.er-api.com/v6/latest/USD').then(r => r.json()),
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,ripple&vs_currencies=usd,inr').then(r => r.json())
  ]);

  let forex = null;
  if (forexRes.status === 'fulfilled' && forexRes.value?.result === 'success') {
    const r = forexRes.value.rates;
    // API base is USD, convert to *_INR pairs the app expects.
    forex = {
      USD_INR: r.INR,
      EUR_INR: r.INR / r.EUR,
      GBP_INR: r.INR / r.GBP,
      AED_INR: r.INR / r.AED
    };
  }

  let crypto = null;
  if (cryptoRes.status === 'fulfilled' && cryptoRes.value?.bitcoin) {
    const c = cryptoRes.value;
    crypto = {
      BTC_USD: c.bitcoin?.usd,
      ETH_USD: c.ethereum?.usd,
      XRP_USD: c.ripple?.usd,
      BTC_INR: c.bitcoin?.inr
    };
  }

  if (!forex && !crypto) throw new Error('Both forex and crypto providers failed');
  return { forex, crypto };
}

async function getRates() {
  const now = Date.now();
  if (_ratesCache && now < _ratesCacheExpiry) return _ratesCache;

  try {
    const live = await fetchLiveRates();
    _ratesCache = {
      source: 'live',
      updatedAt: new Date().toISOString(),
      forex: live.forex || _ratesCache?.forex || STATIC_FALLBACK_RATES.forex,
      crypto: live.crypto || _ratesCache?.crypto || STATIC_FALLBACK_RATES.crypto
    };
  } catch (e) {
    console.error('Live rate fetch failed, using fallback:', e.message);
    _ratesCache = _ratesCache || {
      source: 'demo_fallback',
      updatedAt: new Date().toISOString(),
      forex: STATIC_FALLBACK_RATES.forex,
      crypto: STATIC_FALLBACK_RATES.crypto
    };
  }

  _ratesCacheExpiry = now + RATES_CACHE_MS;
  return _ratesCache;
}

app.get('/api/rates', async (_, res) => {
  const rates = await getRates();
  res.json(rates);
});

// ---------------------------------------------------------------------------
// In-app notifications
// ---------------------------------------------------------------------------
app.get('/api/notifications', auth('user'), async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 30, 100);
  const offset = parseInt(req.query.offset) || 0;
  const r = await pool.query(
    'SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3',
    [req.auth.id, limit, offset]
  );
  const unread = await pool.query('SELECT COUNT(*) FROM notifications WHERE user_id=$1 AND is_read=false', [req.auth.id]);
  res.json({ notifications: r.rows, unreadCount: Number(unread.rows[0].count) });
});

app.post('/api/notifications/:id/read', auth('user'), async (req, res) => {
  const r = await pool.query('UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2 RETURNING *', [req.params.id, req.auth.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Notification not found' });
  res.json({ notification: r.rows[0] });
});

app.post('/api/notifications/read-all', auth('user'), async (req, res) => {
  await pool.query('UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false', [req.auth.id]);
  res.json({ success: true });
});

const sendMoneyPinLimiter = rateLimit({ windowMs: 15 * 60_000, max: 8, keyFn: (req) => `pin:${req.auth?.id || req.ip}`, message: 'Too many incorrect PIN attempts. Please try again in 15 minutes.' });

app.post('/api/transactions/send', auth('user'), sendMoneyPinLimiter, async (req, res) => {
  const client = await pool.connect();
  try {
    const { toUserId, receiver, toEmail, amount, currency = 'INR', pin, note = '' } = req.body;
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) throw new Error('positive amount required');
    await client.query('BEGIN');
    const ur = await client.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
    const sender = ur.rows[0];
    if (!sender.security_pin_hash || !(await bcrypt.compare(String(pin), sender.security_pin_hash))) throw new Error('Invalid security PIN');
    const receiverKey = String(toUserId || receiver || toEmail || '').trim();
    if (!receiverKey) throw new Error('receiver email or userId required');
    const rr = await client.query('SELECT * FROM users WHERE id::text=$1 OR lower(email)=lower($1) OR phone=$1 LIMIT 1', [receiverKey]);
    const receiverUser = rr.rows[0];
    if (!receiverUser) throw new Error('Receiver not found');
    if (receiverUser.id === req.auth.id) throw new Error('Cannot send money to yourself');
    const from = (await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id])).rows[0];
    const to = (await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [receiverUser.id])).rows[0];
    if (!to) throw new Error('Receiver wallet not found');
    const bal = Number(from.balances[currency] || 0);
    if (bal < numericAmount) throw new Error('Insufficient balance');
    from.balances[currency] = bal - numericAmount;
    to.balances[currency] = Number(to.balances[currency] || 0) + numericAmount;
    await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [from.balances, req.auth.id]);
    await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [to.balances, receiverUser.id]);
    const txn = await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status,metadata) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', ['send', req.auth.id, receiverUser.id, numericAmount, currency, 'completed', { note }]);
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: receiverUser.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: numericAmount, currency, referenceType: 'transaction', referenceId: txn.rows[0].id, description: 'User to user wallet send/receive' });
    await maybePayReferralReward(client, req.auth.id);
    await client.query('COMMIT');
    res.json({ transaction: txn.rows[0], receiver: safeUser(receiverUser) });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.get('/api/transactions', auth('user'), async (req, res) => {
  const { type, status, from, to, search, limit = 50, offset = 0 } = req.query;
  const conditions = ['(from_user_id=$1 OR to_user_id=$1)'];
  const params = [req.auth.id];

  if (type) { params.push(type); conditions.push(`type=$${params.length}`); }
  if (status) { params.push(status); conditions.push(`status=$${params.length}`); }
  if (from) { params.push(from); conditions.push(`created_at >= $${params.length}`); }
  if (to) { params.push(to); conditions.push(`created_at <= $${params.length}`); }
  if (search) { params.push(`%${search}%`); conditions.push(`(id::text ILIKE $${params.length} OR currency ILIKE $${params.length})`); }

  const limitNum = Math.min(parseInt(limit) || 50, 200);
  const offsetNum = parseInt(offset) || 0;
  params.push(limitNum, offsetNum);

  const sql = `SELECT * FROM transactions WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;
  const r = await pool.query(sql, params);
  res.json(r.rows);
});

// User's own exchange orders (with commission breakdown) — previously only
// admins could list exchange orders; users had no way to see their own
// convert/exchange history beyond the generic `transactions` table.
app.get('/api/exchange/orders/mine', auth('user'), async (req, res) => {
  const { status, limit = 50, offset = 0 } = req.query;
  const conditions = ['user_id=$1'];
  const params = [req.auth.id];
  if (status) { params.push(status); conditions.push(`status=$${params.length}`); }
  const limitNum = Math.min(parseInt(limit) || 50, 200);
  const offsetNum = parseInt(offset) || 0;
  params.push(limitNum, offsetNum);
  const sql = `SELECT * FROM exchange_orders WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;
  const r = await pool.query(sql, params);
  res.json(r.rows);
});

// ---------------------------------------------------------------------------
// Receipts: request a short-lived token for a specific transaction/exchange
// order, then open it in a browser to view/print/save-as-PDF. The token is
// scoped to exactly one record, expires in 15 minutes, and is single-use
// only in the sense that it always re-checks ownership — it does not carry
// the user's real JWT, so it's safe to put in a URL/QR/share link.
// ---------------------------------------------------------------------------
const receiptTokenLimiter = rateLimit({ windowMs: 60_000, max: 20, keyFn: (req) => `receipt:${req.auth?.id || req.ip}` });

app.post('/api/receipts/token', auth('user'), receiptTokenLimiter, async (req, res) => {
  const { transactionId, exchangeOrderId } = req.body;
  if (!transactionId && !exchangeOrderId) return res.status(400).json({ error: 'transactionId or exchangeOrderId required' });

  if (transactionId) {
    const t = await pool.query('SELECT id FROM transactions WHERE id=$1 AND (from_user_id=$2 OR to_user_id=$2)', [transactionId, req.auth.id]);
    if (!t.rows[0]) return res.status(404).json({ error: 'Transaction not found' });
  }
  if (exchangeOrderId) {
    const o = await pool.query('SELECT id FROM exchange_orders WHERE id=$1 AND user_id=$2', [exchangeOrderId, req.auth.id]);
    if (!o.rows[0]) return res.status(404).json({ error: 'Exchange order not found' });
  }

  const token = generateReceiptToken();
  const expiresAt = new Date(Date.now() + 15 * 60_000).toISOString();
  await pool.query(
    'INSERT INTO receipt_tokens(token, user_id, transaction_id, exchange_order_id, expires_at) VALUES($1,$2,$3,$4,$5)',
    [token, req.auth.id, transactionId || null, exchangeOrderId || null, expiresAt]
  );
  res.json({ token, url: `/api/receipts/${token}`, expiresAt });
});

app.get('/api/receipts/:token', async (req, res) => {
  const r = await pool.query('SELECT * FROM receipt_tokens WHERE token=$1', [req.params.token]);
  const record = r.rows[0];
  if (!record) return res.status(404).send('<h2>Receipt link not found or already expired.</h2>');
  if (new Date(record.expires_at).getTime() < Date.now()) return res.status(410).send('<h2>This receipt link has expired. Please generate a new one from the app.</h2>');

  const u = await pool.query('SELECT name, email FROM users WHERE id=$1', [record.user_id]);
  const user = u.rows[0] || {};

  if (record.transaction_id) {
    const t = await pool.query('SELECT * FROM transactions WHERE id=$1', [record.transaction_id]);
    if (!t.rows[0]) return res.status(404).send('<h2>Transaction not found.</h2>');
    return res.send(wrapReceiptPage(renderTransactionReceipt({ transaction: t.rows[0], user: { ...user, id: record.user_id } })));
  }

  if (record.exchange_order_id) {
    const o = await pool.query('SELECT * FROM exchange_orders WHERE id=$1', [record.exchange_order_id]);
    if (!o.rows[0]) return res.status(404).send('<h2>Exchange order not found.</h2>');
    return res.send(wrapReceiptPage(renderExchangeReceipt({ order: o.rows[0], user })));
  }

  res.status(404).send('<h2>Receipt not found.</h2>');
});

app.post('/api/exchange/orders', auth('user'), async (req, res) => {
  const { fromCurrency, toCurrency, amount, mode = 'convert' } = req.body;
  const commission = Number(amount) * 0.01, adminCommission = Number(amount) * 0.008, sellerCommission = Number(amount) * 0.002;
  const r = await pool.query(
    `INSERT INTO exchange_orders(user_id,mode,from_currency,to_currency,amount,commission,admin_commission,seller_commission)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [req.auth.id, mode, fromCurrency, toCurrency, amount, commission, adminCommission, sellerCommission]
  );
  await pool.query('INSERT INTO commissions(order_id,admin_commission,seller_commission) VALUES($1,$2,$3)', [r.rows[0].id, adminCommission, sellerCommission]);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await postLedger(client, { debit: { ownerType: 'platform_commission_receivable', ownerId: 'exchange' }, credit: { ownerType: 'exchange_user_payable', ownerId: req.auth.id }, amount: commission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '1% exchange commission accrued' });
    await postLedger(client, { debit: { ownerType: 'admin_commission_earning', ownerId: 'admin' }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: adminCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.8% admin commission split' });
    await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.2% seller/user commission split' });

    // Reward wallet credit: actually move 0.2% (sellerCommission) into the user's
    // reward_balances so it is visible/usable, not just recorded in the ledger.
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const rewardBalances = wallet.reward_balances || {};
    rewardBalances[fromCurrency] = Number(rewardBalances[fromCurrency] || 0) + sellerCommission;
    await client.query('UPDATE wallets SET reward_balances=$1 WHERE user_id=$2', [rewardBalances, req.auth.id]);
    await postLedger(client, { debit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, credit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.2% reward credited to user reward wallet' });

    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }

  const u = await pool.query('SELECT email FROM users WHERE id=$1', [req.auth.id]);
  await notifyUser(pool, {
    userId: req.auth.id,
    userEmail: u.rows[0]?.email,
    type: 'reward_credited',
    title: 'Reward Credited',
    message: `Aapko ${fromCurrency} ${sellerCommission.toFixed(4)} ka reward mila hai is exchange order par. Wallet screen ke "Reward Wallet" section mein dekhein.`,
    metadata: { orderId: r.rows[0].id, amount: sellerCommission, currency: fromCurrency },
    sendEmail: false, // keep this one in-app only to avoid an extra email per exchange
  });

  res.json({ order: r.rows[0] });
});


app.post('/api/disputes', auth('user'), async (req, res) => {
  const { transactionId, reason, message, evidence = [] } = req.body;
  if (!reason || !message) return res.status(400).json({ error: 'reason and message required' });
  const r = await pool.query('INSERT INTO disputes(user_id,transaction_id,reason,message,evidence) VALUES($1,$2,$3,$4,$5) RETURNING *', [req.auth.id, transactionId || null, reason, message, JSON.stringify(evidence)]);
  res.json({ dispute: r.rows[0] });
});

app.get('/api/disputes', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM disputes WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});

app.get('/api/admin/disputes', auth('admin'), requirePermission('disputes:manage'), async (_, res) => {
  const r = await pool.query(`SELECT d.*, row_to_json(u.*) AS user FROM disputes d LEFT JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.patch('/api/admin/disputes/:id', auth('admin'), requirePermission('disputes:manage'), async (req, res) => {
  const { status, adminNote, resolution } = req.body;
  const r = await pool.query('UPDATE disputes SET status=COALESCE($1,status), admin_note=COALESCE($2,admin_note), resolution=COALESCE($3,resolution), updated_at=NOW() WHERE id=$4 RETURNING *', [status || null, adminNote || null, resolution || null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Dispute not found' });
  await auditLog(pool, { adminId: req.auth.id, action: `dispute.${r.rows[0].status}`, entityType: 'dispute', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ dispute: r.rows[0] });
});

app.post('/api/complaints', auth('user'), async (req, res) => {
  const { subject, message, transactionId } = req.body;
  const r = await pool.query('INSERT INTO complaints(user_id,subject,message,transaction_id) VALUES($1,$2,$3,$4) RETURNING *', [req.auth.id, subject, message, transactionId || null]);
  res.json({ complaint: r.rows[0] });
});

// User's own complaints — previously only admins could list complaints;
// a user could submit one but never see its status afterwards.
app.get('/api/complaints', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM complaints WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});


// OTP and Email Verification APIs
//
// SECURITY: the OTP is only ever echoed back in the API response when the
// operator has explicitly opted in via ALLOW_DEV_OTP_IN_RESPONSE=true. Do
// NOT rely on NODE_ENV here — many hosts (including Render, unless you set
// it yourself) never set NODE_ENV=production, which previously caused real
// OTPs to leak in the API response even in the live production deployment.
const DEV_OTP_IN_RESPONSE = String(process.env.ALLOW_DEV_OTP_IN_RESPONSE || '').toLowerCase() === 'true';

app.post('/api/auth/request-otp', otpRequestLimiter, async (req, res) => {
  const { email, purpose = 'email_verification' } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  const otp = generateOtp();
  await pool.query('INSERT INTO otp_codes(email,purpose,otp_hash,expires_at) VALUES($1,$2,$3,$4)', [email, purpose, await hashOtp(otp), otpExpiry(10)]);
  await sendOtpEmail({ email, otp, purpose });
  res.json({ message: 'OTP sent', purpose, devOtp: DEV_OTP_IN_RESPONSE ? otp : undefined });
});

app.post('/api/auth/verify-email-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const r = await pool.query('SELECT * FROM otp_codes WHERE email=$1 AND purpose=$2 AND used=false ORDER BY created_at DESC LIMIT 1', [email, 'email_verification']);
  const item = r.rows[0];
  if (!item || isExpired(item.expires_at) || !(await compareOtp(otp, item.otp_hash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  await pool.query('UPDATE otp_codes SET used=true WHERE id=$1', [item.id]);
  await pool.query('UPDATE users SET email_verified=true WHERE email=$1', [email]);
  res.json({ message: 'Email verified' });
});

app.post('/api/auth/login-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const r = await pool.query('SELECT * FROM otp_codes WHERE email=$1 AND purpose=$2 AND used=false ORDER BY created_at DESC LIMIT 1', [email, 'login']);
  const item = r.rows[0];
  if (!item || isExpired(item.expires_at) || !(await compareOtp(otp, item.otp_hash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  const u = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = u.rows[0];
  if (!user) return res.status(404).json({ error: 'User not found' });
  await pool.query('UPDATE otp_codes SET used=true WHERE id=$1', [item.id]);
  const session = await issueAuthSession({ ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  res.json({ ...session, user: safeUser(user) });
});

// Payment Gateway Structure APIs
app.post('/api/payments/orders', auth('user'), async (req, res) => {
  const { amount, currency = 'INR', purpose = 'wallet_topup' } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'positive amount required' });
  const provider = getPaymentProvider();
  const gatewayOrder = await provider.createOrder({ amount: Number(amount), currency, receipt: `GX_${Date.now()}`, notes: { userId: req.auth.id, purpose } });
  const r = await pool.query(
    `INSERT INTO payment_orders(user_id,provider,gateway_order_id,amount,currency,purpose,gateway_response)
     VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [req.auth.id, gatewayOrder.provider, gatewayOrder.gatewayOrderId, amount, currency, purpose, gatewayOrder]
  );
  res.json({ order: r.rows[0], gatewayOrder });
});

app.post('/api/payments/verify', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { orderId, gatewayOrderId, gatewayPaymentId, gatewaySignature } = req.body;
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM payment_orders WHERE id=$1 AND user_id=$2 FOR UPDATE', [orderId, req.auth.id]);
    const order = r.rows[0];
    if (!order) throw new Error('Payment order not found');
    const provider = getPaymentProvider(order.provider);
    const verification = await provider.verifyPayment({ gatewayOrderId: gatewayOrderId || order.gateway_order_id, gatewayPaymentId, gatewaySignature });
    const status = verification.verified ? 'paid' : 'verification_failed';
    await client.query('UPDATE payment_orders SET status=$1, verification=$2 WHERE id=$3', [status, verification, order.id]);
    if (verification.verified && order.purpose === 'wallet_topup') {
      const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
      const balances = w.rows[0].balances;
      balances[order.currency] = Number(balances[order.currency] || 0) + Number(order.amount);
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [balances, req.auth.id]);
      await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['wallet_topup', null, req.auth.id, order.amount, order.currency, 'completed']);
      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, amount: order.amount, currency: order.currency, referenceType: 'payment_order', referenceId: order.id, description: 'Wallet top-up via payment gateway' });
      await maybePayReferralReward(client, req.auth.id);
    }
    await client.query('COMMIT');

    const u = await pool.query('SELECT email FROM users WHERE id=$1', [req.auth.id]);
    if (verification.verified) {
      await notifyUser(pool, {
        userId: req.auth.id,
        userEmail: u.rows[0]?.email,
        type: 'payment_success',
        title: 'Payment Successful',
        message: `Aapka payment of ${order.currency} ${order.amount} successful ho gaya hai aur wallet mein credit ho gaya hai.`,
        metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
      });
    } else {
      await notifyUser(pool, {
        userId: req.auth.id,
        userEmail: u.rows[0]?.email,
        type: 'payment_failed',
        title: 'Payment Failed',
        message: `Aapka payment of ${order.currency} ${order.amount} verify nahi ho paya. Kripya dobara try karein ya support se contact karein.`,
        metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
      });
    }

    res.json({ order: { ...order, status }, verification });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message });
  } finally { client.release(); }
});

app.post('/api/payments/webhook', async (req, res) => {
  const provider = getPaymentProvider(process.env.PAYMENT_PROVIDER || 'mock');
  const signature = req.headers['x-razorpay-signature'];
  const raw = req.rawBody ? req.rawBody.toString() : JSON.stringify(req.body);

  if (process.env.PAYMENT_PROVIDER === 'razorpay') {
    // In LIVE Razorpay mode, a missing webhook secret must never silently
    // pass — that would let anyone forge a "payment successful" webhook.
    if (!process.env.RAZORPAY_WEBHOOK_SECRET) {
      console.error('SECURITY: RAZORPAY_WEBHOOK_SECRET is not set while PAYMENT_PROVIDER=razorpay. Rejecting webhook.');
      return res.status(500).json({ error: 'Webhook not configured correctly' });
    }
    const verified = provider.verifyWebhookSignature(raw, signature, process.env.RAZORPAY_WEBHOOK_SECRET);
    if (!verified) return res.status(400).json({ error: 'Invalid webhook signature' });
    return res.json({ received: true, verified: true });
  }

  // mock/cashfree structure providers — accepted as-is (no real money involved).
  res.json({ received: true, verified: true });
});

app.post('/api/payments/refund', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { orderId, gatewayPaymentId, amount, reason = 'admin_refund' } = req.body;
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM payment_orders WHERE id=$1 FOR UPDATE', [orderId]);
    const order = r.rows[0];
    if (!order) throw new Error('Payment order not found');
    if (order.status !== 'paid') throw new Error('Only paid orders can be refunded');
    const provider = getPaymentProvider(order.provider);
    const refund = await provider.refundPayment({ gatewayPaymentId: gatewayPaymentId || order.verification?.gatewayPaymentId, amount: amount || order.amount, notes: { reason, orderId } });
    const refundAmount = Number(amount || order.amount);
    const rr = await client.query('INSERT INTO refunds(order_id,provider,amount,currency,reason,status,gateway_refund) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', [orderId, order.provider, refundAmount, order.currency, reason, refund.status || 'processed', refund]);
    await client.query('UPDATE payment_orders SET status=$1 WHERE id=$2', ['refunded', orderId]);
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    if (w.rows[0]) {
      const balances = w.rows[0].balances;
      balances[order.currency] = Number(balances[order.currency] || 0) - refundAmount;
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [balances, order.user_id]);
    }
    await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['refund', order.user_id, null, refundAmount, order.currency, 'completed']);
    await postLedger(client, { debit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, credit: { ownerType: 'user_wallet', ownerId: order.user_id }, amount: refundAmount, currency: order.currency, referenceType: 'refund', referenceId: rr.rows[0].id, description: 'Payment refund from wallet' });
    await auditLog(client, { adminId: req.auth.id, action: 'payment.refund', entityType: 'payment_order', entityId: orderId, metadata: { refundId: rr.rows[0].id, amount: refundAmount, currency: order.currency }, req });
    await client.query('COMMIT');
    res.json({ refund: rr.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});


app.post('/api/exchange/orders/:id/lock-escrow', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 AND user_id=$2 FOR UPDATE', [req.params.id, req.auth.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status === 'locked') throw new Error('Escrow already locked');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {};
    if (Number(balances[order.from_currency] || 0) < Number(order.amount)) throw new Error('Insufficient balance for escrow');
    balances[order.from_currency] = Number(balances[order.from_currency] || 0) - Number(order.amount);
    locked[order.from_currency] = Number(locked[order.from_currency] || 0) + Number(order.amount);
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, req.auth.id]);
    const updated = await client.query("UPDATE exchange_orders SET status='escrow_locked', escrow_status='locked' WHERE id=$1 RETURNING *", [order.id]);
    await postLedger(client, { debit: { ownerType: 'exchange_escrow', ownerId: order.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Exchange amount locked in escrow' });
    await client.query('COMMIT');
    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.post('/api/admin/exchange/orders/:id/complete', auth('admin'), requirePermission('exchange:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { rate, receiveAmount } = req.body;
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status !== 'locked') throw new Error('Escrow must be locked before completion');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    const wallet = w.rows[0], balances = wallet.balances, locked = wallet.locked || {};
    const finalReceive = Number(receiveAmount || (Number(order.amount) * Number(rate || 1)));
    locked[order.from_currency] = Math.max(0, Number(locked[order.from_currency] || 0) - Number(order.amount));
    balances[order.to_currency] = Number(balances[order.to_currency] || 0) + finalReceive;
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, order.user_id]);
    const updated = await client.query("UPDATE exchange_orders SET status='completed', escrow_status='released' WHERE id=$1 RETURNING *", [order.id]);
    await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['exchange_complete', order.user_id, order.user_id, finalReceive, order.to_currency, 'completed']);
    await postLedger(client, { debit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow source currency released to exchange pool' });
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: order.user_id }, credit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, amount: finalReceive, currency: order.to_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Converted currency credited to user wallet' });
    await auditLog(client, { adminId: req.auth.id, action: 'exchange.complete', entityType: 'exchange_order', entityId: order.id, metadata: { rate, receiveAmount: finalReceive }, req });
    await maybePayReferralReward(client, order.user_id);
    await client.query('COMMIT');

    const u = await pool.query('SELECT email FROM users WHERE id=$1', [order.user_id]);
    await notifyUser(pool, {
      userId: order.user_id,
      userEmail: u.rows[0]?.email,
      type: 'exchange_completed',
      title: 'Exchange Order Completed',
      message: `Aapka ${order.from_currency} to ${order.to_currency} exchange complete ho gaya hai. Aapko ${order.to_currency} ${finalReceive} mila hai.`,
      metadata: { orderId: order.id, receiveAmount: finalReceive, toCurrency: order.to_currency },
    });

    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.post('/api/admin/exchange/orders/:id/cancel', auth('admin'), requirePermission('exchange:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.status === 'cancelled') throw new Error('Order already cancelled');
    if (order.status === 'completed') throw new Error('Cannot cancel a completed order');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {}, rewardBalances = wallet.reward_balances || {};

    if (order.escrow_status === 'locked') {
      locked[order.from_currency] = Math.max(0, Number(locked[order.from_currency] || 0) - Number(order.amount));
      balances[order.from_currency] = Number(balances[order.from_currency] || 0) + Number(order.amount);
      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: order.user_id }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow returned to user after cancellation' });
    }

    // Reverse the 0.2% reward that was credited when the order was created,
    // so cancelled orders never leave a stray reward with the user.
    // Priority 1: take it back from the reward wallet (normal case).
    // Priority 2: if the user already redeemed it into the main wallet, claw back
    //             whatever is left there too (never push balance below zero).
    // Anything that still can't be recovered is logged for manual admin review.
    const sellerCommission = Number(order.seller_commission || 0);
    if (sellerCommission > 0) {
      let remaining = sellerCommission;

      const currentReward = Number(rewardBalances[order.from_currency] || 0);
      const fromReward = Math.min(currentReward, remaining);
      if (fromReward > 0) {
        rewardBalances[order.from_currency] = currentReward - fromReward;
        remaining -= fromReward;
        await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: order.user_id }, credit: { ownerType: 'user_reward_wallet', ownerId: order.user_id }, amount: fromReward, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% reward reversed due to order cancellation' });
      }

      if (remaining > 0) {
        const currentMainBalance = Number(balances[order.from_currency] || 0);
        const fromMainWallet = Math.min(currentMainBalance, remaining);
        if (fromMainWallet > 0) {
          balances[order.from_currency] = currentMainBalance - fromMainWallet;
          remaining -= fromMainWallet;
          await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: order.user_id }, credit: { ownerType: 'user_wallet', ownerId: order.user_id }, amount: fromMainWallet, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% already-redeemed reward clawed back from main wallet due to order cancellation' });
        }
      }

      if (remaining > 0) {
        await auditLog(client, { adminId: req.auth.id, action: 'exchange.cancel.reward_reversal_incomplete', entityType: 'exchange_order', entityId: order.id, metadata: { currency: order.from_currency, unrecovered: remaining }, req });
      }
    }

    await client.query('UPDATE wallets SET balances=$1, locked=$2, reward_balances=$3 WHERE user_id=$4', [balances, locked, rewardBalances, order.user_id]);

    const updated = await client.query("UPDATE exchange_orders SET status='cancelled', escrow_status='cancelled' WHERE id=$1 RETURNING *", [order.id]);
    await auditLog(client, { adminId: req.auth.id, action: 'exchange.cancel', entityType: 'exchange_order', entityId: order.id, req });
    await client.query('COMMIT');

    const u = await pool.query('SELECT email FROM users WHERE id=$1', [order.user_id]);
    await notifyUser(pool, {
      userId: order.user_id,
      userEmail: u.rows[0]?.email,
      type: 'exchange_cancelled',
      title: 'Exchange Order Cancelled',
      message: `Aapka ${order.from_currency} to ${order.to_currency} exchange order cancel kar diya gaya hai. Locked amount aapke wallet mein wapas kar diya gaya hai.`,
      metadata: { orderId: order.id },
    });

    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.get('/api/admin/exchange/orders', auth('admin'), requirePermission('exchange:manage'), async (_, res) => {
  const r = await pool.query(`SELECT e.*, row_to_json(u.*) AS user FROM exchange_orders e LEFT JOIN users u ON u.id=e.user_id ORDER BY e.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});


app.get('/api/admin/admins', auth('admin'), requirePermission('admin:manage'), async (_, res) => {
  const r = await pool.query('SELECT id,email,role,permissions,created_at FROM admins ORDER BY created_at DESC');
  res.json(r.rows);
});

app.patch('/api/admin/admins/:id/role', auth('admin'), requirePermission('admin:manage'), async (req, res) => {
  const { role, permissions } = req.body;
  const r = await pool.query('UPDATE admins SET role=COALESCE($1,role), permissions=COALESCE($2,permissions) WHERE id=$3 RETURNING id,email,role,permissions,created_at', [role || null, permissions ? JSON.stringify(permissions) : null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Admin not found' });
  await auditLog(pool, { adminId: req.auth.id, action: 'admin.role_update', entityType: 'admin', entityId: req.params.id, metadata: { role: r.rows[0].role, permissions: r.rows[0].permissions }, req });
  res.json({ admin: r.rows[0] });
});

app.get('/api/admin/audit-logs', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500');
  res.json(r.rows);
});

app.get('/api/admin/roles', auth('admin'), requirePermission('admin:manage','disputes:manage'), async (_, res) => {
  res.json({ roles: [
    { role: 'super_admin', permissions: ['*'] },
    { role: 'kyc_manager', permissions: ['users:read','kyc:manage','audit:read'] },
    { role: 'finance_manager', permissions: ['payments:read','refunds:manage','ledger:read','exchange:manage','audit:read'] },
    { role: 'support_agent', permissions: ['users:read','payments:read','disputes:manage','audit:read'] }
  ]});
});

app.get('/api/admin/dashboard', auth('admin'), async (_, res) => {
  const q = async sql => Number((await pool.query(sql)).rows[0].count || 0);
  const commission = await pool.query('SELECT COALESCE(SUM(admin_commission),0) AS total FROM commissions');

  // "Today" figures give the admin a quick pulse-check without needing to
  // open the full analytics page.
  const todayCommission = await pool.query("SELECT COALESCE(SUM(admin_commission),0) AS total FROM commissions WHERE created_at::date = CURRENT_DATE");
  const todayUsers = await q("SELECT COUNT(*) FROM users WHERE created_at::date = CURRENT_DATE");
  const todayTransactions = await q("SELECT COUNT(*) FROM transactions WHERE created_at::date = CURRENT_DATE");
  const todayPaymentVolume = await pool.query("SELECT COALESCE(SUM(amount),0) AS total FROM payment_orders WHERE status='paid' AND created_at::date = CURRENT_DATE");
  const pendingKyc = await q("SELECT COUNT(*) FROM kyc_requests WHERE status <> 'approved'");
  const openComplaints = await q("SELECT COUNT(*) FROM complaints WHERE status NOT IN ('resolved','rejected')");
  const openDisputes = await q("SELECT COUNT(*) FROM disputes WHERE status NOT IN ('resolved','rejected')");

  res.json({
    users: await q('SELECT COUNT(*) FROM users'),
    kycPending: pendingKyc,
    transactions: await q('SELECT COUNT(*) FROM transactions'),
    complaints: await q('SELECT COUNT(*) FROM complaints'),
    exchangeOrders: await q('SELECT COUNT(*) FROM exchange_orders'),
    adminCommission: Number(commission.rows[0].total),
    today: {
      newUsers: todayUsers,
      transactions: todayTransactions,
      revenue: Number(todayCommission.rows[0].total),
      paymentVolume: Number(todayPaymentVolume.rows[0].total),
    },
    openComplaints,
    openDisputes,
  });
});

// ---------------------------------------------------------------------------
// Analytics: time-series and breakdown data for the admin dashboard charts.
// Kept as a separate endpoint from /api/admin/dashboard (which stays fast/
// lightweight for the top summary cards) since this does more aggregation
// work and isn't needed on every dashboard page load.
// ---------------------------------------------------------------------------
app.get('/api/admin/analytics', auth('admin'), async (req, res) => {
  const days = Math.min(parseInt(req.query.days) || 30, 90);

  // Daily revenue (admin commission) for the last N days — the core "is the
  // business growing" chart.
  const revenueByDay = await pool.query(
    `SELECT date_trunc('day', created_at)::date AS day, COALESCE(SUM(admin_commission),0) AS revenue, COALESCE(SUM(seller_commission),0) AS user_rewards
     FROM commissions
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY day ORDER BY day ASC`,
    [days]
  );

  // Daily new user signups — growth chart.
  const usersByDay = await pool.query(
    `SELECT created_at::date AS day, COUNT(*) AS count
     FROM users
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY day ORDER BY day ASC`,
    [days]
  );

  // Daily transaction volume (count + total amount by currency is too
  // granular for a simple chart, so this is count-only; currency breakdown
  // is provided separately below).
  const transactionsByDay = await pool.query(
    `SELECT created_at::date AS day, COUNT(*) AS count
     FROM transactions
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY day ORDER BY day ASC`,
    [days]
  );

  // Exchange volume by currency pair — which conversions are most popular.
  const exchangeByCurrency = await pool.query(
    `SELECT from_currency, to_currency, COUNT(*) AS order_count, COALESCE(SUM(amount),0) AS total_amount
     FROM exchange_orders
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY from_currency, to_currency
     ORDER BY order_count DESC LIMIT 10`,
    [days]
  );

  // Payment success/failure breakdown — helps spot a broken payment
  // integration quickly instead of just seeing "revenue is low".
  const paymentStatusBreakdown = await pool.query(
    `SELECT status, COUNT(*) AS count, COALESCE(SUM(amount),0) AS total_amount
     FROM payment_orders
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY status`,
    [days]
  );

  // Exchange order status breakdown (pending/completed/cancelled).
  const exchangeStatusBreakdown = await pool.query(
    `SELECT status, COUNT(*) AS count
     FROM exchange_orders
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY status`,
    [days]
  );

  // KYC funnel — how many are pending/approved/rejected right now (not time-
  // windowed, since KYC status is a current-state snapshot, not an event log).
  const kycBreakdown = await pool.query(`SELECT status, COUNT(*) AS count FROM kyc_requests GROUP BY status`);

  res.json({
    periodDays: days,
    revenueByDay: revenueByDay.rows,
    usersByDay: usersByDay.rows,
    transactionsByDay: transactionsByDay.rows,
    exchangeByCurrency: exchangeByCurrency.rows,
    paymentStatusBreakdown: paymentStatusBreakdown.rows,
    exchangeStatusBreakdown: exchangeStatusBreakdown.rows,
    kycBreakdown: kycBreakdown.rows,
  });
});

app.get('/api/admin/kyc-requests', auth('admin'), requirePermission('kyc:manage'), async (_, res) => {
  // Exclude the heavy `documents` column from the list view (it can contain multiple
  // base64-encoded files) — admin fetches those individually via the endpoint below.
  const r = await pool.query(`
    SELECT k.id, k.user_id, k.national_id, k.tax_id, k.country, k.document_names, k.status, k.created_at,
           row_to_json(u.*) AS user
    FROM kyc_requests k LEFT JOIN users u ON u.id=k.user_id
    ORDER BY k.created_at DESC
  `);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

// Admin-only: fetch the actual uploaded documents (base64) for one KYC request,
// so they can be viewed/downloaded for verification.
app.get('/api/admin/kyc-requests/:id/documents', auth('admin'), requirePermission('kyc:manage'), async (req, res) => {
  const r = await pool.query('SELECT documents FROM kyc_requests WHERE id=$1', [req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'KYC request not found' });
  await auditLog(pool, { adminId: req.auth.id, action: 'kyc.documents_viewed', entityType: 'kyc_request', entityId: req.params.id, req });
  res.json({ documents: r.rows[0].documents || [] });
});

app.get('/api/admin/refunds', auth('admin'), async (_, res) => {
  const r = await pool.query('SELECT * FROM refunds ORDER BY created_at DESC');
  res.json(r.rows);
});

app.get('/api/admin/payment-orders', auth('admin'), requirePermission('payments:read'), async (_, res) => {
  const r = await pool.query(`SELECT p.*, row_to_json(u.*) AS user FROM payment_orders p LEFT JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.get('/api/admin/ledger', auth('admin'), requirePermission('ledger:read'), async (_, res) => {
  const accounts = await pool.query('SELECT * FROM ledger_accounts ORDER BY created_at DESC');
  const entries = await pool.query('SELECT * FROM ledger_entries ORDER BY created_at DESC LIMIT 500');
  res.json({ accounts: accounts.rows, entries: entries.rows });
});

app.get('/api/admin/users', auth('admin'), async (_, res) => { const r = await pool.query('SELECT * FROM users ORDER BY created_at DESC'); res.json(r.rows.map(safeUser)); });

app.patch('/api/admin/complaints/:id', auth('admin'), async (req, res) => {
  const { status } = req.body;
  const r = await pool.query('UPDATE complaints SET status=COALESCE($1,status) WHERE id=$2 RETURNING *', [status || null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  await auditLog(pool, { adminId: req.auth.id, action: `complaint.${r.rows[0].status}`, entityType: 'complaint', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ complaint: r.rows[0] });
});

app.get('/api/admin/complaints', auth('admin'), async (_, res) => { const r = await pool.query('SELECT * FROM complaints ORDER BY created_at DESC'); res.json(r.rows); });

app.get('/api/admin/referrals', auth('admin'), async (_, res) => {
  const r = await pool.query(`
    SELECT rf.*, row_to_json(ru.*) AS referrer, row_to_json(du.*) AS referred
    FROM referrals rf
    LEFT JOIN users ru ON ru.id = rf.referrer_user_id
    LEFT JOIN users du ON du.id = rf.referred_user_id
    ORDER BY rf.created_at DESC
  `);
  res.json(r.rows.map(row => ({ ...row, referrer: safeUser(row.referrer), referred: safeUser(row.referred) })));
});
app.patch('/api/admin/kyc/:id', auth('admin'), requirePermission('kyc:manage'), async (req, res) => {
  const { status } = req.body;
  const r = await pool.query('UPDATE kyc_requests SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'KYC not found' });
  await pool.query('UPDATE users SET kyc_status=$1 WHERE id=$2', [status, r.rows[0].user_id]);

  const u = await pool.query('SELECT email FROM users WHERE id=$1', [r.rows[0].user_id]);
  const isApproved = status === 'approved';
  await notifyUser(pool, {
    userId: r.rows[0].user_id,
    userEmail: u.rows[0]?.email,
    type: isApproved ? 'kyc_approved' : 'kyc_rejected',
    title: isApproved ? 'KYC Verified Successfully' : 'KYC Verification Update',
    message: isApproved
      ? 'Aapka KYC verify ho gaya hai. Ab aap bina limit ke transactions kar sakte hain.'
      : 'Aapka KYC document verify nahi ho paya. Kripya sahi/clear documents ke saath dobara submit karein.',
    metadata: { kycRequestId: r.rows[0].id, status },
  });

  res.json({ kyc: r.rows[0] });
});

autoMigrate()
  .then(() => ensureAdmin())
  .then(() => app.listen(PORT, () => console.log(`Global Exchanger PostgreSQL API running on http://localhost:${PORT}`)))
  .catch(e => { console.error(e); process.exit(1); });
