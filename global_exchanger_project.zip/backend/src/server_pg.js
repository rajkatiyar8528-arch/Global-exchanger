require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const { getPaymentProvider } = require('./payments/provider');
const { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail } = require('./otp');
const { notifyUser } = require('./notifications');
const { rateLimit, ipAndFieldKey, securityHeaders, isStrongPassword, buildCorsOptions } = require('./security');
const { generateReceiptToken, renderTransactionReceipt, renderExchangeReceipt, wrapReceiptPage } = require('./receipts');
const { signAccessToken, issueNewRefreshTokenFamily, rotateRefreshToken, revokeRefreshToken, revokeAllForOwner } = require('./auth_tokens');
const { VDA_CURRENCIES, tierFor, AML_SINGLE_TXN_THRESHOLD_INR, AML_DAILY_AGGREGATE_THRESHOLD_INR, toApproxInr, currentFinancialYear, computeCryptoTds } = require('./limits');
const { screenKycSubmission, getSanctionsListMetadata } = require('./screening');
const { buildTravelRuleRecord } = require('./travel_rule');
const { syncSanctionsList, maybeAutoSyncIfStale } = require('./sanctions_sync');
const { SUPPORTED_PAIRS, isSupportedPair, flattenRates, findTriggeredAlerts, formatPairLabel } = require('./price_alerts');
const { generateStatementToken, renderStatementHtml, wrapStatementPage, renderStatementCsv } = require('./statements');
const { FREQUENCIES, isValidFrequency, computeNextRunAt, MAX_CONSECUTIVE_FAILURES } = require('./scheduled_payments');
const { monthlyTrend, categoryBreakdown, topCounterparties, overallSummary } = require('./analytics');

const app = express();
app.set('trust proxy', true); // Render sits behind Cloudflare + its own internal proxy (multiple hops); trust all of them so req.ip reflects the real client IP for rate limiting.

// ---------------------------------------------------------------------------
// CRASH-SAFETY WRAPPER — critical production fix.
// -----------------------------------------------------------------------
// Almost every route handler in this file is `async (req, res) => {...}`
// WITHOUT its own try/catch. In Express 4 (used here), if an async handler
// throws/rejects, Express does NOT catch it automatically — the rejection
// becomes an uncaught exception that CRASHES THE ENTIRE NODE PROCESS,
// taking the whole API down for every user until Render restarts it (with a
// cold-start delay). This was discovered/verified during technical-
// safeguards testing: a single malformed ID (e.g. hitting a PATCH endpoint
// with a non-UUID id in the URL) reliably crashed the whole server.
//
// The fix: monkey-patch Express's route-registration methods so every
// handler function registered from this point onward is automatically
// wrapped to catch both sync throws and async rejections and forward them
// to Express's error-handling middleware (defined near the bottom of this
// file) instead of crashing the process. This requires NO changes to the
// hundreds of existing route definitions below.
// ---------------------------------------------------------------------------
function wrapAsyncHandler(fn) {
  if (typeof fn !== 'function') return fn; // pass through non-function args (e.g. middleware arrays)
  // Express identifies error-handling middleware purely by counting its
  // declared parameters (must be exactly 4: err, req, res, next). If we
  // wrapped it with a 3-param function, Express would treat our own error
  // handler as regular middleware and it would never be invoked — silently
  // falling back to Express's default HTML error page, which leaks stack
  // traces to the client. So error handlers (arity 4) must be passed
  // through with their arity preserved by wrapping with a matching
  // 4-parameter function; everything else uses the normal 3-param wrapper.
  if (fn.length >= 4) {
    return function wrappedErrorHandler(err, req, res, next) {
      try {
        const result = fn(err, req, res, next);
        if (result && typeof result.catch === 'function') {
          result.catch((e) => next(e));
        }
      } catch (e) {
        next(e);
      }
    };
  }
  return function wrapped(req, res, next) {
    try {
      const result = fn(req, res, next);
      if (result && typeof result.catch === 'function') {
        result.catch((err) => next(err));
      }
    } catch (err) {
      next(err);
    }
  };
}
for (const method of ['get', 'post', 'patch', 'put', 'delete', 'use']) {
  const original = app[method].bind(app);
  app[method] = (...args) => original(...args.map((a) => (typeof a === 'function' ? wrapAsyncHandler(a) : a)));
}

app.use(securityHeaders);
app.use(cors(buildCorsOptions()));
app.use(express.json({ limit: '20mb', verify: (req, res, buf) => { req.rawBody = buf; } }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is not set. Refusing to start with an insecure default.');
  process.exit(1);
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Rate limiters for sensitive/abuse-prone endpoints.
const loginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many login attempts. Please try again in 15 minutes.' });
const adminLoginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many admin login attempts. Please try again in 15 minutes.' });
const otpRequestLimiter = rateLimit({ windowMs: 10 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many OTP requests. Please wait before requesting again.' });
const otpVerifyLimiter = rateLimit({ windowMs: 10 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many OTP verification attempts. Please try again later.' });
const registerLimiter = rateLimit({ windowMs: 60 * 60_000, max: 10, keyFn: (req) => req.ip, message: 'Too many signup attempts from this network. Please try again later.' });
const generalApiLimiter = rateLimit({ windowMs: 60_000, max: 120, keyFn: (req) => req.ip, message: 'Too many requests. Please slow down.' });

app.use('/api', generalApiLimiter);


function sign(payload) { return signAccessToken(JWT_SECRET, payload); }

// Issues a fresh access token (15 min) + refresh token (30 days, rotating,
// revocable) pair for a login/register/refresh event, and shapes it into
// the response fields the app expects.
async function issueAuthSession({ ownerType, ownerId, payload, req }) {
  const accessToken = sign(payload);
  const { refreshToken, expiresAt } = await issueNewRefreshTokenFamily(pool, { ownerType, ownerId, req });
  return { token: accessToken, refreshToken, refreshTokenExpiresAt: expiresAt };
}

function auth(role = 'user') {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (role !== 'any' && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.auth = decoded;
      next();
    } catch (e) {
      // Distinguish "expired" from "invalid" so the app knows an expired
      // access token just needs a silent refresh (normal, expected every 15
      // minutes) rather than forcing the user all the way back to login.
      if (e.name === 'TokenExpiredError') return res.status(401).json({ error: 'Access token expired', code: 'TOKEN_EXPIRED' });
      res.status(401).json({ error: 'Invalid token' });
    }
  };
}
function safeUser(row) {
  if (!row) return null;
  const { password_hash, security_pin_hash, ...u } = row;
  return {
    ...u,
    houseNumber: row.house_number,
    kycStatus: row.kyc_status,
    referralCode: row.referral_code,
    referredBy: row.referred_by,
    createdAt: row.created_at
  };
}


async function auditLog(clientOrPool, { adminId = null, userId = null, action, entityType, entityId, metadata = {}, req = null }) {
  await clientOrPool.query(
    'INSERT INTO audit_logs(admin_id,user_id,action,entity_type,entity_id,metadata,ip,user_agent) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',
    [adminId, userId, action, entityType, String(entityId || ''), metadata, req?.ip || null, req?.headers?.['user-agent'] || null]
  );
}

function requirePermission(permission) {
  return async (req, res, next) => {
    const r = await pool.query('SELECT * FROM admins WHERE id=$1', [req.auth.id]);
    const admin = r.rows[0];
    if (!admin) return res.status(403).json({ error: 'Admin not found' });
    const permissions = admin.permissions || [];
    if (admin.role !== 'super_admin' && !permissions.includes(permission)) return res.status(403).json({ error: `Missing permission: ${permission}` });
    req.admin = admin;
    next();
  };
}

async function getLedgerAccount(client, ownerType, ownerId, currency) {
  const existing = await client.query('SELECT * FROM ledger_accounts WHERE owner_type=$1 AND owner_id=$2 AND currency=$3', [ownerType, String(ownerId), currency]);
  if (existing.rows[0]) return existing.rows[0];
  const created = await client.query('INSERT INTO ledger_accounts(owner_type,owner_id,currency) VALUES($1,$2,$3) RETURNING *', [ownerType, String(ownerId), currency]);
  return created.rows[0];
}

async function postLedger(client, { debit, credit, amount, currency, referenceType, referenceId, description }) {
  if (!amount || Number(amount) <= 0) throw new Error('Ledger amount must be positive');
  const debitAccount = await getLedgerAccount(client, debit.ownerType, debit.ownerId, currency);
  const creditAccount = await getLedgerAccount(client, credit.ownerType, credit.ownerId, currency);
  await client.query('UPDATE ledger_accounts SET balance=balance+$1 WHERE id=$2', [amount, debitAccount.id]);
  await client.query('UPDATE ledger_accounts SET balance=balance-$1 WHERE id=$2', [amount, creditAccount.id]);
  const group = await client.query('SELECT uuid_generate_v4() AS id');
  const groupId = group.rows[0].id;
  await client.query('INSERT INTO ledger_entries(group_id,account_id,direction,amount,currency,reference_type,reference_id,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [groupId, debitAccount.id, 'debit', amount, currency, referenceType, String(referenceId), description]);
  await client.query('INSERT INTO ledger_entries(group_id,account_id,direction,amount,currency,reference_type,reference_id,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [groupId, creditAccount.id, 'credit', amount, currency, referenceType, String(referenceId), description]);
  return { groupId, debitAccount, creditAccount };
}

// ---------------------------------------------------------------------------
// Referral reward: pays out the referrer's ₹100 the first time (and only the
// first time) their referred user completes ANY real transaction — sending
// money, topping up their wallet, or completing a currency exchange. This is
// intentionally NOT paid at signup, to avoid fake-account abuse where someone
// creates throwaway accounts just to farm referral rewards without any real
// usage. Safe to call on every transaction; it's a no-op once already paid.
// ---------------------------------------------------------------------------
async function maybePayReferralReward(client, referredUserId) {
  const r = await client.query(
    "SELECT * FROM referrals WHERE referred_user_id=$1 AND status='pending_first_transaction' FOR UPDATE",
    [referredUserId]
  );
  const referral = r.rows[0];
  if (!referral) return;

  const rewardAmount = Number(referral.reward || 100);
  const currency = referral.currency || 'INR';

  const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [referral.referrer_user_id]);
  const wallet = w.rows[0];
  if (!wallet) return; // referrer account no longer exists — leave referral as-is for manual review

  const rewardBalances = wallet.reward_balances || {};
  rewardBalances[currency] = Number(rewardBalances[currency] || 0) + rewardAmount;
  await client.query('UPDATE wallets SET reward_balances=$1 WHERE user_id=$2', [rewardBalances, referral.referrer_user_id]);

  await client.query("UPDATE referrals SET status='rewarded', rewarded_at=NOW() WHERE id=$1", [referral.id]);

  await postLedger(client, {
    debit: { ownerType: 'user_reward_wallet', ownerId: referral.referrer_user_id },
    credit: { ownerType: 'referral_reward_pool', ownerId: 'referrals' },
    amount: rewardAmount,
    currency,
    referenceType: 'referral',
    referenceId: referral.id,
    description: `Referral reward for inviting a user who completed their first transaction`,
  });

  const refUser = await client.query('SELECT email FROM users WHERE id=$1', [referral.referrer_user_id]);
  await notifyUser(pool, {
    userId: referral.referrer_user_id,
    userEmail: refUser.rows[0]?.email,
    type: 'referral_reward_credited',
    title: 'Referral Reward Credited!',
    message: `Aapke refer kiye hue user ne apna pehla transaction complete kar liya. ${currency} ${rewardAmount} aapke Reward Wallet mein credit ho gaya hai!`,
    metadata: { referralId: referral.id, amount: rewardAmount, currency },
    sendEmail: false,
  });
}

// ---------------------------------------------------------------------------
// Technical Safeguards: KYC-tier transaction limits, AML flagging, and
// crypto TDS. See TECHNICAL_SAFEGUARDS_GUIDE.md for full rationale. Mirrors
// the JSON-backend implementation in server.js exactly, using SQL queries
// against the same source-of-truth thresholds/logic in limits.js.
// ---------------------------------------------------------------------------

async function sumUserTransactionsTodayInr(client, userId) {
  const r = await client.query(
    `SELECT currency, COALESCE(SUM(amount),0) AS total FROM transactions
     WHERE from_user_id=$1 AND status='completed' AND created_at >= date_trunc('day', NOW())
     GROUP BY currency`,
    [userId]
  );
  return r.rows.reduce((sum, row) => sum + toApproxInr(row.total, row.currency), 0);
}

async function sumUserMonthlySendInr(client, userId) {
  const r = await client.query(
    `SELECT currency, COALESCE(SUM(amount),0) AS total FROM transactions
     WHERE from_user_id=$1 AND type='send' AND status='completed' AND created_at >= date_trunc('month', NOW())
     GROUP BY currency`,
    [userId]
  );
  return r.rows.reduce((sum, row) => sum + toApproxInr(row.total, row.currency), 0);
}

async function sumUserMonthlyTopupInr(client, userId) {
  const r = await client.query(
    `SELECT currency, COALESCE(SUM(amount),0) AS total FROM transactions
     WHERE to_user_id=$1 AND type='wallet_topup' AND status='completed' AND created_at >= date_trunc('month', NOW())
     GROUP BY currency`,
    [userId]
  );
  return r.rows.reduce((sum, row) => sum + toApproxInr(row.total, row.currency), 0);
}

// Throws a plain Error with a user-facing message if a proposed action
// would breach the user's KYC-tier limits. Called before mutating balances.
async function enforceTierLimits(client, user, { action, amount, currency }) {
  const kycStatus = user.kycStatus || user.kyc_status;
  const tier = tierFor(kycStatus);
  const amountInr = toApproxInr(amount, currency);

  if (action === 'topup') {
    if (tier.monthlyLoadLimit != null) {
      const usedThisMonth = await sumUserMonthlyTopupInr(client, user.id);
      if (usedThisMonth + amountInr > tier.monthlyLoadLimit) {
        throw new Error(`Monthly wallet top-up limit of ₹${tier.monthlyLoadLimit} reached for un-verified accounts. Please complete KYC to increase your limit.`);
      }
    }
  }

  if (action === 'send') {
    if (!tier.allowP2PSend) throw new Error('KYC verification is required before you can send money to other users.');
    if (tier.perTransactionLimit != null && amountInr > tier.perTransactionLimit) {
      throw new Error(`This amount exceeds the maximum per-transaction limit of ₹${tier.perTransactionLimit}.`);
    }
    if (tier.monthlyP2PLimit != null) {
      const usedThisMonth = await sumUserMonthlySendInr(client, user.id);
      if (usedThisMonth + amountInr > tier.monthlyP2PLimit) {
        throw new Error(`Monthly send-money limit of ₹${tier.monthlyP2PLimit} reached. This limit resets next calendar month.`);
      }
    }
  }

  if (action === 'exchange') {
    if (!tier.allowExchange) throw new Error('KYC verification is required before you can use currency/crypto exchange features.');
    if (tier.perTransactionLimit != null && amountInr > tier.perTransactionLimit) {
      throw new Error(`This amount exceeds the maximum per-transaction limit of ₹${tier.perTransactionLimit}.`);
    }
  }

  if (action === 'withdrawal') {
    if (!tier.allowWithdrawal) throw new Error('KYC verification is required before you can withdraw funds.');
  }

  if (tier.dailyTransactionLimit != null && ['send', 'exchange', 'withdrawal'].includes(action)) {
    const usedToday = await sumUserTransactionsTodayInr(client, user.id);
    if (usedToday + amountInr > tier.dailyTransactionLimit) {
      throw new Error(`Daily transaction limit of ₹${tier.dailyTransactionLimit} reached. Please try again tomorrow, or contact support for a limit increase.`);
    }
  }

  return { tier, amountInr };
}

// Wallet-balance cap check (Full-KYC max ₹2,00,000-equivalent, min-KYC max
// ₹10,000-equivalent, loosely modeled on RBI PPI framework), applied after a
// credit would land. Not applied to crypto holdings (fluctuate in value;
// capped via per-transaction/exchange limits instead).
function enforceWalletBalanceCap(kycStatus, balances) {
  const tier = tierFor(kycStatus);
  const newBalanceInr = Object.entries(balances || {}).reduce((sum, [cur, amt]) => {
    return VDA_CURRENCIES.includes(cur) ? sum : sum + toApproxInr(amt, cur);
  }, 0);
  if (tier.maxWalletBalance != null && newBalanceInr > tier.maxWalletBalance) {
    throw new Error(`This would take your wallet balance above the ₹${tier.maxWalletBalance} limit for your verification level. Please withdraw/spend down your balance, or complete KYC to raise this limit.`);
  }
}

// Flags (but does not block) large single transactions / daily aggregates
// for admin AML review by writing to audit_logs with a distinguishing action.
async function checkAmlAndBalanceCap(client, userId, { amountInr, referenceType, referenceId, note }) {
  const flagged = [];
  if (amountInr >= AML_SINGLE_TXN_THRESHOLD_INR) {
    flagged.push(`single transaction of ~₹${Math.round(amountInr)} exceeds AML review threshold of ₹${AML_SINGLE_TXN_THRESHOLD_INR}`);
  }
  const dailyTotal = await sumUserTransactionsTodayInr(client, userId);
  if (dailyTotal >= AML_DAILY_AGGREGATE_THRESHOLD_INR) {
    flagged.push(`daily aggregate of ~₹${Math.round(dailyTotal)} exceeds AML review threshold of ₹${AML_DAILY_AGGREGATE_THRESHOLD_INR}`);
  }
  if (flagged.length) {
    await auditLog(client, { adminId: null, userId, action: 'aml.flag.large_transaction', entityType: referenceType, entityId: referenceId, metadata: { reasons: flagged, note } });
  }
}

// Crypto (VDA) TDS — Section 194S. Call whenever a user disposes of a VDA
// currency. Tracks cumulative gross VDA-transfer value per user per Indian
// financial year in the `tds_records` table, and returns { tdsAmountInr,
// netCreditAmount } so the caller can deduct TDS from what's credited.
async function applyCryptoTds(client, userId, { grossAmount, grossCurrency, creditCurrency, creditAmount, referenceType, referenceId }) {
  const fy = currentFinancialYear();
  const grossAmountInr = toApproxInr(grossAmount, grossCurrency);

  let rec = await client.query('SELECT * FROM tds_records WHERE user_id=$1 AND financial_year=$2 FOR UPDATE', [userId, fy]);
  if (!rec.rows[0]) {
    rec = await client.query(
      'INSERT INTO tds_records(user_id, financial_year, cumulative_gross_inr, cumulative_tds_inr, entries) VALUES($1,$2,0,0,$3::jsonb) RETURNING *',
      [userId, fy, JSON.stringify([])]
    );
  }
  const record = rec.rows[0];
  const cumulativeBefore = Number(record.cumulative_gross_inr || 0);
  const tdsAmountInr = computeCryptoTds(cumulativeBefore, grossAmountInr);
  const newCumulativeGross = cumulativeBefore + grossAmountInr;

  if (tdsAmountInr <= 0) {
    await client.query('UPDATE tds_records SET cumulative_gross_inr=$1, updated_at=NOW() WHERE id=$2', [newCumulativeGross, record.id]);
    return { tdsAmountInr: 0, netCreditAmount: creditAmount };
  }

  const tdsInCreditCurrency = grossAmountInr > 0 ? (tdsAmountInr / grossAmountInr) * Number(creditAmount) : 0;
  const netCreditAmount = Math.max(0, Number(creditAmount) - tdsInCreditCurrency);

  const entries = record.entries || [];
  entries.push({
    id: require('crypto').randomUUID(), referenceType, referenceId, grossAmount, grossCurrency, grossAmountInr,
    tdsAmountInr, creditCurrency, createdAt: new Date().toISOString(),
  });
  await client.query(
    'UPDATE tds_records SET cumulative_gross_inr=$1, cumulative_tds_inr=cumulative_tds_inr+$2, entries=$3::jsonb, updated_at=NOW() WHERE id=$4',
    [newCumulativeGross, tdsAmountInr, JSON.stringify(entries), record.id]
  );

  await postLedger(client, {
    debit: { ownerType: 'user_wallet', ownerId: userId },
    credit: { ownerType: 'tds_payable_194s', ownerId: 'government' },
    amount: tdsInCreditCurrency,
    currency: creditCurrency,
    referenceType,
    referenceId,
    description: `1% TDS under Section 194S withheld on VDA transfer (FY ${fy})`,
  });

  await auditLog(client, {
    adminId: null, userId, action: 'tds.crypto.deducted', entityType: referenceType, entityId: referenceId,
    metadata: { financialYear: fy, grossAmountInr, tdsAmountInr, tdsInCreditCurrency, creditCurrency },
  });

  return { tdsAmountInr, netCreditAmount };
}

// ---------------------------------------------------------------------------
// Scheduled / Recurring Payments — executes any of a user's DUE mandates
// (next_run_at <= now) by re-running the same money-movement logic as a
// normal send-money transaction (balance check, tier limits, AML checks,
// ledger postings, notifications), but WITHOUT re-prompting for the
// security PIN (already verified once at mandate-creation time — same UX
// as real UPI Autopay mandates). See scheduled_payments.js for why this
// runs opportunistically (called from GET /api/me) rather than a real
// background cron.
// ---------------------------------------------------------------------------
async function runDueScheduledPaymentsPg(userId) {
  const due = await pool.query("SELECT * FROM scheduled_payments WHERE user_id=$1 AND status='active' AND next_run_at <= NOW()", [userId]);
  if (due.rowCount === 0) return;

  for (const mandate of due.rows) {
    const client = await pool.connect();
    let runStatus = 'failed';
    let errorMessage = null;
    let txnId = null;
    try {
      await client.query('BEGIN');
      const s = await client.query('SELECT * FROM users WHERE id=$1', [mandate.user_id]);
      const sender = s.rows[0];
      const r = await client.query('SELECT * FROM users WHERE id=$1', [mandate.receiver_user_id]);
      const receiverUser = r.rows[0];
      if (!sender) throw new Error('Sender account not found');
      if (!receiverUser) throw new Error('Receiver account no longer exists');

      const fw = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [sender.id]);
      const fromWallet = fw.rows[0];
      const tw = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [receiverUser.id]);
      const toWallet = tw.rows[0];
      if (!fromWallet || !toWallet) throw new Error('Wallet not found');

      const amount = Number(mandate.amount);
      const currency = mandate.currency;
      const fromBalances = fromWallet.balances;
      if ((fromBalances[currency] || 0) < amount) throw new Error('Insufficient balance');

      const limitCheck = await enforceTierLimits(client, sender, { action: 'send', amount, currency });

      fromBalances[currency] -= amount;
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [fromBalances, sender.id]);
      const toBalances = toWallet.balances;
      toBalances[currency] = Number(toBalances[currency] || 0) + amount;
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [toBalances, receiverUser.id]);

      const txn = await client.query(
        "INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status,metadata) VALUES('send',$1,$2,$3,$4,'completed',$5) RETURNING *",
        [sender.id, receiverUser.id, amount, currency, { note: `Scheduled payment: ${mandate.note || mandate.frequency}`, scheduledPaymentId: mandate.id }]
      );
      txnId = txn.rows[0].id;

      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: receiverUser.id }, credit: { ownerType: 'user_wallet', ownerId: sender.id }, amount, currency, referenceType: 'scheduled_payment', referenceId: mandate.id, description: 'Scheduled/recurring payment execution' });
      await checkAmlAndBalanceCap(client, sender.id, { amountInr: limitCheck.amountInr, referenceType: 'scheduled_payment', referenceId: mandate.id, note: 'scheduled payment' });
      await maybePayReferralReward(client, sender.id);

      await client.query('COMMIT');
      runStatus = 'completed';

      await client.query("UPDATE scheduled_payments SET consecutive_failures=0 WHERE id=$1", [mandate.id]);

      await notifyUser(pool, {
        userId: sender.id, userEmail: sender.email, sendEmail: sender.email_notifications_enabled !== false,
        type: 'scheduled_payment_success', title: 'Scheduled Payment Sent',
        message: `Aapka scheduled payment of ${currency} ${amount} safaltapoorvak bhej diya gaya hai.`,
        metadata: { scheduledPaymentId: mandate.id, transactionId: txn.rows[0].id },
      });
    } catch (e) {
      await client.query('ROLLBACK');
      runStatus = 'failed';
      errorMessage = e.message;
      const u = await pool.query('SELECT email, email_notifications_enabled FROM users WHERE id=$1', [mandate.user_id]);
      const senderForNotif = u.rows[0];
      const failCountResult = await pool.query('UPDATE scheduled_payments SET consecutive_failures=consecutive_failures+1 WHERE id=$1 RETURNING consecutive_failures, frequency', [mandate.id]);
      const newFailureCount = failCountResult.rows[0]?.consecutive_failures || 1;

      await notifyUser(pool, {
        userId: mandate.user_id, userEmail: senderForNotif?.email, sendEmail: senderForNotif?.email_notifications_enabled !== false,
        type: 'scheduled_payment_failed', title: 'Scheduled Payment Failed',
        message: `Aapka scheduled payment of ${mandate.currency} ${mandate.amount} fail ho gaya: ${e.message}.`,
        metadata: { scheduledPaymentId: mandate.id, error: e.message },
      });

      if (newFailureCount >= MAX_CONSECUTIVE_FAILURES) {
        await pool.query("UPDATE scheduled_payments SET status='paused' WHERE id=$1", [mandate.id]);
        await notifyUser(pool, {
          userId: mandate.user_id, userEmail: senderForNotif?.email, sendEmail: senderForNotif?.email_notifications_enabled !== false,
          type: 'scheduled_payment_paused', title: 'Scheduled Payment Auto-Paused',
          message: `Aapka scheduled payment ${MAX_CONSECUTIVE_FAILURES} baar lagataar fail hone ke baad automatically pause kar diya gaya hai. Wallet balance check karke ise dobara activate karein.`,
          metadata: { scheduledPaymentId: mandate.id },
        });
      }
    } finally {
      client.release();
    }

    const current = await pool.query('SELECT status, frequency FROM scheduled_payments WHERE id=$1', [mandate.id]);
    const nextRunAt = current.rows[0]?.status === 'active' ? computeNextRunAt(mandate.frequency, new Date()) : null;
    if (nextRunAt) {
      await pool.query('UPDATE scheduled_payments SET last_run_at=NOW(), last_run_status=$1, next_run_at=$2 WHERE id=$3', [runStatus, nextRunAt, mandate.id]);
    } else {
      await pool.query('UPDATE scheduled_payments SET last_run_at=NOW(), last_run_status=$1 WHERE id=$2', [runStatus, mandate.id]);
    }
    await pool.query(
      'INSERT INTO scheduled_payment_runs(scheduled_payment_id, status, transaction_id, error_message) VALUES($1,$2,$3,$4)',
      [mandate.id, runStatus, txnId, errorMessage]
    );
  }
}

// Auto-run schema.sql on every server startup so Render free-tier (no Shell access)
// deployments always have the latest tables/columns without needing manual migration.
async function autoMigrate() {
  try {
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const sql = fs.readFileSync(schemaPath, 'utf8');
    await pool.query(sql);
    console.log('Auto-migration completed (schema.sql applied)');
  } catch (e) {
    console.error('Auto-migration failed:', e.message);
  }
}

async function ensureAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@globalexchanger.com';
  const exists = await pool.query('SELECT id FROM admins WHERE email=$1', [email]);
  if (exists.rowCount === 0) {
    await pool.query(
      'INSERT INTO admins(email,password_hash,special_key_hash) VALUES($1,$2,$3)',
      [email, await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@12345', 10), await bcrypt.hash(process.env.ADMIN_SPECIAL_KEY || 'GX-SUPER-KEY-2026', 10)]
    );
  }
}

app.get('/', (_, res) => res.json({ app: 'Global Exchanger PostgreSQL API', status: 'running' }));

app.post('/api/auth/register', registerLimiter, async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, email, phone, country, address, houseNumber, password, referralCode } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
    if (!isStrongPassword(password)) return res.status(400).json({ error: 'Password must be at least 8 characters and include both letters and numbers.' });

    // Validate the referral code (if provided) BEFORE creating the account,
    // so a typo/fake code doesn't silently create an orphaned referral row.
    let referrer = null;
    if (referralCode) {
      const refCheck = await client.query('SELECT id, email FROM users WHERE referral_code=$1', [String(referralCode).trim().toUpperCase()]);
      referrer = refCheck.rows[0] || null;
      if (!referrer) return res.status(400).json({ error: 'Invalid referral code' });
    }

    await client.query('BEGIN');
    const ref = `GX${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const userResult = await client.query(
      `INSERT INTO users(name,email,phone,country,address,house_number,password_hash,referral_code,referred_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name, email, phone, country, address, houseNumber, await bcrypt.hash(password, 10), ref, referralCode || null]
    );
    const user = userResult.rows[0];
    await client.query('INSERT INTO wallets(user_id) VALUES($1)', [user.id]);

    // Prevent self-referral (someone using their own code) — silently ignored
    // rather than erroring, so registration still succeeds.
    if (referrer && referrer.id !== user.id) {
      await client.query(
        'INSERT INTO referrals(referrer_code,referrer_user_id,referred_user_id,status) VALUES($1,$2,$3,$4)',
        [referralCode, referrer.id, user.id, 'pending_first_transaction']
      );
    }

    await client.query('COMMIT');
    const session = await issueAuthSession({ ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
    res.json({ ...session, user: safeUser(user) });
  } catch (e) {
    await client.query('ROLLBACK');
    if (String(e.message).includes('duplicate')) return res.status(409).json({ error: 'Email or referral already exists' });
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Invalid login' });
  const r = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = r.rows[0];
  // Always run bcrypt.compare (even with a dummy hash) so response timing doesn't
  // reveal whether the email exists — mitigates user-enumeration via timing attacks.
  const passwordHash = user?.password_hash || '$2a$10$CwTycUXWue0Thq9StjUM0uJ8gI0mZzn0EXAMPLEHASHVALUEXXXXX';
  const passwordOk = await bcrypt.compare(password, passwordHash);
  if (!user || !passwordOk) return res.status(401).json({ error: 'Invalid email or password' });
  const session = await issueAuthSession({ ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  res.json({ ...session, user: safeUser(user) });
});

app.post('/api/admin/login', adminLoginLimiter, async (req, res) => {
  const { email, password, specialKey } = req.body;
  if (!email || !password || !specialKey) return res.status(400).json({ error: 'Invalid admin login' });
  const r = await pool.query('SELECT * FROM admins WHERE email=$1', [email]);
  const admin = r.rows[0];
  const ok = admin && await bcrypt.compare(password, admin.password_hash) && await bcrypt.compare(specialKey, admin.special_key_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid admin login' });
  await auditLog(pool, { adminId: admin.id, action: 'admin.login', entityType: 'admin', entityId: admin.id, req });
  const session = await issueAuthSession({ ownerType: 'admin', ownerId: admin.id, payload: { id: admin.id, role: 'admin' }, req });
  res.json({ ...session, admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

// Exchanges a valid, unrevoked refresh token for a brand new access token +
// rotated refresh token. Called automatically by the app in the background
// shortly before the current 15-minute access token expires, so the user
// never has to manually re-login during the 30-day refresh token window.
app.post('/api/auth/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });

  const result = await rotateRefreshToken(pool, refreshToken, req);
  if (!result.ok) {
    const messages = {
      invalid: 'Invalid refresh token. Please log in again.',
      reused: 'This session was used from another device or has expired. For your security, please log in again.',
      expired: 'Your session has expired. Please log in again.',
    };
    return res.status(401).json({ error: messages[result.reason] || 'Please log in again.' });
  }

  const accessToken = signAccessToken(JWT_SECRET, { id: result.ownerId, role: result.ownerType });
  res.json({ token: accessToken, refreshToken: result.refreshToken, refreshTokenExpiresAt: result.expiresAt });
});

// Revokes the current refresh token — real server-side logout, unlike just
// deleting the token from the app (which left the token valid until its
// natural 7-day expiry under the old design).
app.post('/api/auth/logout', async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) await revokeRefreshToken(pool, refreshToken);
  res.json({ success: true });
});

// "Logout everywhere" — revokes ALL of the current user's refresh tokens
// (every device/session), e.g. if they suspect their account/device is
// compromised. Requires a valid (short-lived) access token to call.
app.post('/api/auth/logout-all', auth('any'), async (req, res) => {
  await revokeAllForOwner(pool, req.auth.role, req.auth.id);
  res.json({ success: true });
});

app.get('/api/me', auth('user'), async (req, res) => {
  try {
    await runDueScheduledPaymentsPg(req.auth.id);
  } catch (e) {
    console.error('Scheduled payment execution failed:', e.message);
  }
  const u = await pool.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
  const w = await pool.query('SELECT user_id AS "userId", balances, locked, reward_balances AS "rewardBalances" FROM wallets WHERE user_id=$1', [req.auth.id]);
  res.json({ user: safeUser(u.rows[0]), wallet: w.rows[0] });
});

// Referral summary: my code, how many people I've referred, how many have
// been rewarded yet, and a per-referral breakdown (without exposing the
// referred user's private info beyond name/email).
app.get('/api/referrals/mine', auth('user'), async (req, res) => {
  const me = await pool.query('SELECT referral_code FROM users WHERE id=$1', [req.auth.id]);
  const referralCode = me.rows[0]?.referral_code;

  const rows = await pool.query(
    `SELECT r.*, row_to_json(u.*) AS referred_user
     FROM referrals r LEFT JOIN users u ON u.id = r.referred_user_id
     WHERE r.referrer_user_id=$1 ORDER BY r.created_at DESC`,
    [req.auth.id]
  );

  const referrals = rows.rows.map(r => ({
    id: r.id,
    status: r.status,
    reward: r.reward,
    currency: r.currency,
    rewardedAt: r.rewarded_at,
    createdAt: r.created_at,
    referredUser: r.referred_user ? { name: r.referred_user.name, email: r.referred_user.email } : null,
  }));

  const totalReferred = referrals.length;
  const totalRewarded = referrals.filter(r => r.status === 'rewarded').length;
  const totalEarned = referrals.filter(r => r.status === 'rewarded').reduce((sum, r) => sum + Number(r.reward || 0), 0);

  res.json({ referralCode, totalReferred, totalRewarded, totalEarned, referrals });
});

// Masks a name for the public leaderboard, e.g. "Rajesh Kumar" -> "Rajesh K."
// — shows enough to feel personal/competitive without exposing a full name
// to every other user of the app.
function maskNameForLeaderboard(name, email) {
  const source = (name && name.trim()) || (email ? email.split('@')[0] : 'User');
  const parts = source.trim().split(/\s+/);
  if (parts.length >= 2) return `${parts[0]} ${parts[1][0]}.`;
  return parts[0].length > 2 ? `${parts[0].slice(0, 2)}***` : `${parts[0]}***`;
}

// Referral Leaderboard — top referrers ranked by number of REWARDED
// referrals. Gamification feature: shows the top N publicly (masked
// names) plus the current user's own rank even if outside the visible
// top N.
app.get('/api/referrals/leaderboard', auth('user'), async (req, res) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit) || 10, 1), 50);
  const r = await pool.query(`
    SELECT rf.referrer_user_id AS user_id, COUNT(*) AS cnt, u.name, u.email
    FROM referrals rf
    JOIN users u ON u.id = rf.referrer_user_id
    WHERE rf.status = 'rewarded'
    GROUP BY rf.referrer_user_id, u.name, u.email
    ORDER BY cnt DESC
  `);
  const ranked = r.rows.map(row => ({ userId: row.user_id, count: Number(row.cnt), name: maskNameForLeaderboard(row.name, row.email) }));
  const top = ranked.slice(0, limit).map((row, i) => ({ rank: i + 1, name: row.name, referralCount: row.count, isMe: row.userId === req.auth.id }));
  const myIndex = ranked.findIndex(row => row.userId === req.auth.id);
  const myRank = myIndex === -1 ? null : { rank: myIndex + 1, referralCount: ranked[myIndex].count };
  res.json({ leaderboard: top, myRank, totalRankedUsers: ranked.length });
});

app.post('/api/security/pin', auth('user'), async (req, res) => {
  const { pin } = req.body;
  const pinStr = String(pin || '');
  if (!/^\d{4,6}$/.test(pinStr)) return res.status(400).json({ error: 'PIN must be 4-6 digits' });
  // Reject only the most obviously guessable PINs: all-same-digit (0000, 1111...)
  // or a fully ascending/descending run (1234, 4321, 123456, 654321...).
  // Anything else (e.g. 1357, 2468, 9182) is accepted — the previous check was
  // too aggressive and rejected common, perfectly reasonable PINs like 1234/5678.
  const isAllSameDigit = /^(\d)\1+$/.test(pinStr);
  const digits = pinStr.split('').map(Number);
  const isAscendingRun = digits.every((d, i) => i === 0 || d === digits[i - 1] + 1);
  const isDescendingRun = digits.every((d, i) => i === 0 || d === digits[i - 1] - 1);
  if (isAllSameDigit || isAscendingRun || isDescendingRun) {
    return res.status(400).json({ error: 'This PIN is too easy to guess (all same digit or a straight sequence). Please choose a different one.' });
  }
  await pool.query('UPDATE users SET security_pin_hash=$1 WHERE id=$2', [await bcrypt.hash(pinStr, 10), req.auth.id]);
  res.json({ message: 'Security PIN created' });
});

// KYC documents are accepted as base64 data URLs from the app (no external
// storage account needed) and stored directly in Postgres as JSONB. We cap
// the number of documents and the size of each one so a bad/huge upload
// can't blow up the database or the request payload.
const MAX_KYC_DOCUMENTS = 5;
const MAX_KYC_DOCUMENT_BYTES = 4 * 1024 * 1024; // ~4MB per document (post base64-decode)
const ALLOWED_KYC_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

function sanitizeKycDocuments(documents) {
  if (!Array.isArray(documents)) return [];
  if (documents.length > MAX_KYC_DOCUMENTS) throw new Error(`Maximum ${MAX_KYC_DOCUMENTS} documents allowed`);
  return documents.map((doc, i) => {
    const label = String(doc?.label || `Document ${i + 1}`).slice(0, 100);
    const mimeType = String(doc?.mimeType || '');
    const dataBase64 = String(doc?.dataBase64 || '');
    if (!ALLOWED_KYC_MIME_TYPES.includes(mimeType)) throw new Error(`Unsupported document type: ${mimeType || 'unknown'}`);
    if (!dataBase64) throw new Error(`${label}: document data is empty`);
    const approxBytes = Math.floor((dataBase64.length * 3) / 4);
    if (approxBytes > MAX_KYC_DOCUMENT_BYTES) throw new Error(`${label} is too large (max 4MB per document)`);
    return { label, mimeType, dataBase64, uploadedAt: new Date().toISOString() };
  });
}

app.post('/api/kyc', auth('user'), async (req, res) => {
  try {
    const { nationalId, taxId, country, documents = [], aliasNames = [] } = req.body;
    const sanitizedDocs = sanitizeKycDocuments(documents);
    const documentNames = sanitizedDocs.map(d => d.label);

    // Sanctions/PEP screening — see server.js's equivalent handler and
    // screening.js for full rationale. Never auto-rejects; only flags for
    // mandatory admin review.
    const ur = await pool.query('SELECT name FROM users WHERE id=$1', [req.auth.id]);
    const screeningResult = screenKycSubmission({ fullName: ur.rows[0]?.name, aliasNames: Array.isArray(aliasNames) ? aliasNames : [] });
    const sanctionsScreening = { flagged: screeningResult.flagged, matches: screeningResult.matches, screenedAt: new Date().toISOString() };

    const r = await pool.query(
      'INSERT INTO kyc_requests(user_id,national_id,tax_id,country,document_names,documents,sanctions_screening) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,user_id,national_id,tax_id,country,document_names,status,created_at',
      [req.auth.id, nationalId, taxId, country, JSON.stringify(documentNames), JSON.stringify(sanitizedDocs), JSON.stringify(sanctionsScreening)]
    );
    await pool.query('UPDATE users SET kyc_status=$1 WHERE id=$2', ['under_review', req.auth.id]);
    await auditLog(pool, { userId: req.auth.id, action: 'kyc.submitted', entityType: 'kyc_request', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status, documentCount: sanitizedDocs.length, sanctionsFlagged: screeningResult.flagged }, req });
    if (screeningResult.flagged) {
      await auditLog(pool, { userId: req.auth.id, action: 'sanctions.screening.flagged', entityType: 'kyc_request', entityId: r.rows[0].id, metadata: { matchCount: screeningResult.matches.length, topMatch: screeningResult.matches[0]?.entry?.name, topScore: screeningResult.matches[0]?.score }, req });
    }
    res.json({ kyc: r.rows[0] });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Lets the logged-in user check their own KYC status + which documents they've submitted
// (without ever sending the raw document bytes back down, to keep responses small/fast).
app.get('/api/kyc/me', auth('user'), async (req, res) => {
  const r = await pool.query(
    'SELECT id, national_id, tax_id, country, document_names, status, created_at FROM kyc_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1',
    [req.auth.id]
  );
  res.json({ kyc: r.rows[0] || null });
});

app.post('/api/bank-accounts', auth('user'), async (req, res) => {
  const { holderName, bankName, accountNumber, ifscSwiftIban, country } = req.body;
  if (!holderName || !bankName || !accountNumber || !ifscSwiftIban) {
    return res.status(400).json({ error: 'holderName, bankName, accountNumber and ifscSwiftIban are required' });
  }
  const masked = String(accountNumber || '').slice(-4).padStart(8, '*');
  const r = await pool.query(
    `INSERT INTO bank_accounts(user_id,holder_name,bank_name,account_number_masked,ifsc_swift_iban,country)
     VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.auth.id, holderName, bankName, masked, ifscSwiftIban, country]
  );
  res.json({ account: r.rows[0] });
});

// User's own bank accounts (excludes soft-deleted ones).
app.get('/api/bank-accounts', auth('user'), async (req, res) => {
  const r = await pool.query(
    'SELECT * FROM bank_accounts WHERE user_id=$1 AND is_deleted=false ORDER BY created_at DESC',
    [req.auth.id]
  );
  res.json(r.rows);
});

// Soft-delete a bank account. Blocked if it has any non-final withdrawal
// (pending/approved/processing) pointing at it, so an in-flight withdrawal
// never ends up referencing a removed account.
app.delete('/api/bank-accounts/:id', auth('user'), async (req, res) => {
  const active = await pool.query(
    "SELECT id FROM withdrawals WHERE bank_account_id=$1 AND status IN ('pending','approved','processing') LIMIT 1",
    [req.params.id]
  );
  if (active.rows[0]) return res.status(400).json({ error: 'Cannot remove a bank account with an active withdrawal in progress.' });
  const r = await pool.query(
    'UPDATE bank_accounts SET is_deleted=true WHERE id=$1 AND user_id=$2 RETURNING *',
    [req.params.id, req.auth.id]
  );
  if (!r.rows[0]) return res.status(404).json({ error: 'Bank account not found' });
  res.json({ success: true });
});

app.get('/api/wallet', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT user_id AS "userId", balances, locked, reward_balances AS "rewardBalances" FROM wallets WHERE user_id=$1', [req.auth.id]);
  res.json(r.rows[0]);
});

// Move reward wallet balance into the main spendable wallet balance for one currency.
app.post('/api/wallet/redeem-rewards', auth('user'), async (req, res) => {
  const { currency = 'INR' } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, rewardBalances = wallet.reward_balances || {};
    const amount = Number(rewardBalances[currency] || 0);
    if (amount <= 0) throw new Error('No reward balance available to redeem for this currency');
    rewardBalances[currency] = 0;
    balances[currency] = Number(balances[currency] || 0) + amount;
    await client.query('UPDATE wallets SET balances=$1, reward_balances=$2 WHERE user_id=$3', [balances, rewardBalances, req.auth.id]);
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, amount, currency, referenceType: 'reward_redeem', referenceId: req.auth.id, description: 'Reward wallet redeemed into main wallet balance' });
    await client.query('COMMIT');
    res.json({ redeemed: amount, currency, wallet: { balances, rewardBalances } });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

// ---------------------------------------------------------------------------
// Withdrawals: user requests money be sent from their wallet to a verified
// bank account. Amount is locked immediately (same pattern as exchange
// escrow) so it can't be double-spent while the admin processes it.
// ---------------------------------------------------------------------------
const MIN_WITHDRAWAL_AMOUNT = { INR: 100, USD: 5, EUR: 5 };
const withdrawalLimiter = rateLimit({ windowMs: 60 * 60_000, max: 10, keyFn: (req) => `withdraw:${req.auth?.id || req.ip}`, message: 'Too many withdrawal requests. Please try again later.' });

app.post('/api/withdrawals', auth('user'), withdrawalLimiter, async (req, res) => {
  const client = await pool.connect();
  try {
    const { bankAccountId, amount, currency = 'INR' } = req.body;
    const numericAmount = Number(amount);
    if (!bankAccountId) throw new Error('bankAccountId is required');
    if (!numericAmount || numericAmount <= 0) throw new Error('A positive amount is required');
    const minAmount = MIN_WITHDRAWAL_AMOUNT[currency] || 0;
    if (numericAmount < minAmount) throw new Error(`Minimum withdrawal amount for ${currency} is ${minAmount}`);

    await client.query('BEGIN');

    // KYC is required before allowing money to leave the platform — this is
    // a compliance necessity for a forex/crypto exchange app, not just a UX
    // choice (see LEGAL_COMPLIANCE_CHECKLIST.md).
    const u = await client.query('SELECT kyc_status FROM users WHERE id=$1', [req.auth.id]);
    if (u.rows[0]?.kyc_status !== 'approved') throw new Error('KYC approval is required before you can withdraw funds. Please complete KYC verification first.');
    const limitCheck = await enforceTierLimits(client, { id: req.auth.id, kycStatus: u.rows[0]?.kyc_status }, { action: 'withdrawal', amount: numericAmount, currency });

    const bank = await client.query('SELECT * FROM bank_accounts WHERE id=$1 AND user_id=$2 AND is_deleted=false', [bankAccountId, req.auth.id]);
    if (!bank.rows[0]) throw new Error('Bank account not found');
    if (!bank.rows[0].verified_at) throw new Error('This bank account is not yet verified by our team. Please wait for verification or add a different account.');

    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {};
    const available = Number(balances[currency] || 0);
    if (available < numericAmount) throw new Error('Insufficient balance for this withdrawal');

    // No withdrawal fee by default (fee column exists for future flexibility,
    // e.g. a flat fee or percentage cut per currency/payout method).
    const fee = 0;
    const netAmount = numericAmount - fee;

    balances[currency] = available - numericAmount;
    locked[currency] = Number(locked[currency] || 0) + numericAmount;
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, req.auth.id]);

    const wr = await client.query(
      `INSERT INTO withdrawals(user_id,bank_account_id,amount,currency,fee,net_amount,status)
       VALUES($1,$2,$3,$4,$5,$6,'pending') RETURNING *`,
      [req.auth.id, bankAccountId, numericAmount, currency, fee, netAmount]
    );

    await postLedger(client, {
      debit: { ownerType: 'withdrawal_escrow', ownerId: wr.rows[0].id },
      credit: { ownerType: 'user_wallet', ownerId: req.auth.id },
      amount: numericAmount, currency, referenceType: 'withdrawal', referenceId: wr.rows[0].id,
      description: 'Withdrawal amount locked pending admin processing',
    });
    await checkAmlAndBalanceCap(client, req.auth.id, { amountInr: limitCheck.amountInr, referenceType: 'withdrawal', referenceId: wr.rows[0].id, note: 'withdrawal request' });

    await client.query('COMMIT');
    res.json({ withdrawal: wr.rows[0] });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message });
  } finally { client.release(); }
});

app.get('/api/withdrawals', auth('user'), async (req, res) => {
  const r = await pool.query(
    `SELECT w.*, row_to_json(b.*) AS bank_account FROM withdrawals w
     LEFT JOIN bank_accounts b ON b.id = w.bank_account_id
     WHERE w.user_id=$1 ORDER BY w.created_at DESC`,
    [req.auth.id]
  );
  res.json(r.rows);
});

// User can cancel their own withdrawal only while it's still pending
// (not yet approved/processing) — returns the locked amount to the
// spendable balance.
app.post('/api/withdrawals/:id/cancel', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const w = await client.query('SELECT * FROM withdrawals WHERE id=$1 AND user_id=$2 FOR UPDATE', [req.params.id, req.auth.id]);
    const withdrawal = w.rows[0];
    if (!withdrawal) throw new Error('Withdrawal not found');
    if (withdrawal.status !== 'pending') throw new Error('Only pending withdrawals can be cancelled');

    const wal = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = wal.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {};
    locked[withdrawal.currency] = Math.max(0, Number(locked[withdrawal.currency] || 0) - Number(withdrawal.amount));
    balances[withdrawal.currency] = Number(balances[withdrawal.currency] || 0) + Number(withdrawal.amount);
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, req.auth.id]);

    const updated = await client.query("UPDATE withdrawals SET status='cancelled', processed_at=NOW() WHERE id=$1 RETURNING *", [withdrawal.id]);
    await postLedger(client, {
      debit: { ownerType: 'user_wallet', ownerId: req.auth.id },
      credit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
      amount: withdrawal.amount, currency: withdrawal.currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
      description: 'Withdrawal cancelled by user, funds returned to wallet',
    });

    await client.query('COMMIT');
    res.json({ withdrawal: updated.rows[0] });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message });
  } finally { client.release(); }
});

// ---------------------------------------------------------------------------
// Admin: bank account verification + withdrawal processing.
// ---------------------------------------------------------------------------
app.get('/api/admin/bank-accounts', auth('admin'), requirePermission('payments:read'), async (req, res) => {
  const r = await pool.query(`
    SELECT b.*, row_to_json(u.*) AS user FROM bank_accounts b
    LEFT JOIN users u ON u.id = b.user_id
    WHERE b.is_deleted=false ORDER BY b.created_at DESC
  `);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.patch('/api/admin/bank-accounts/:id/verify', auth('admin'), requirePermission('payments:read'), async (req, res) => {
  const { verified, note } = req.body;
  const r = await pool.query(
    'UPDATE bank_accounts SET verified_at=$1, verification_note=$2 WHERE id=$3 RETURNING *',
    [verified ? new Date().toISOString() : null, note || null, req.params.id]
  );
  if (!r.rows[0]) return res.status(404).json({ error: 'Bank account not found' });
  await auditLog(pool, { adminId: req.auth.id, action: verified ? 'bank_account.verified' : 'bank_account.unverified', entityType: 'bank_account', entityId: r.rows[0].id, req });
  res.json({ account: r.rows[0] });
});

app.get('/api/admin/withdrawals', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const r = await pool.query(`
    SELECT w.*, row_to_json(u.*) AS user, row_to_json(b.*) AS bank_account FROM withdrawals w
    LEFT JOIN users u ON u.id = w.user_id
    LEFT JOIN bank_accounts b ON b.id = w.bank_account_id
    ORDER BY w.created_at DESC
  `);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

// Admin moves a withdrawal through approved -> processing -> completed, or
// rejects/cancels it at any non-final stage (returning the locked funds).
app.patch('/api/admin/withdrawals/:id', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { status, adminNote } = req.body;
    const allowed = ['approved', 'processing', 'completed', 'rejected'];
    if (!allowed.includes(status)) throw new Error(`status must be one of: ${allowed.join(', ')}`);

    await client.query('BEGIN');
    const w = await client.query('SELECT * FROM withdrawals WHERE id=$1 FOR UPDATE', [req.params.id]);
    const withdrawal = w.rows[0];
    if (!withdrawal) throw new Error('Withdrawal not found');
    if (['completed', 'rejected', 'cancelled'].includes(withdrawal.status)) throw new Error('This withdrawal has already reached a final state');

    if (status === 'rejected') {
      const wal = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [withdrawal.user_id]);
      const wallet = wal.rows[0];
      const balances = wallet.balances, locked = wallet.locked || {};
      locked[withdrawal.currency] = Math.max(0, Number(locked[withdrawal.currency] || 0) - Number(withdrawal.amount));
      balances[withdrawal.currency] = Number(balances[withdrawal.currency] || 0) + Number(withdrawal.amount);
      await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, withdrawal.user_id]);
      await postLedger(client, {
        debit: { ownerType: 'user_wallet', ownerId: withdrawal.user_id },
        credit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
        amount: withdrawal.amount, currency: withdrawal.currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
        description: 'Withdrawal rejected by admin, funds returned to wallet',
      });
    } else if (status === 'completed') {
      // Money has now actually left the platform (sent to the user's bank
      // account) — clear it from `locked` too, not just the ledger, so the
      // wallet's locked-funds view doesn't keep showing a stale amount.
      const wal = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [withdrawal.user_id]);
      const wallet = wal.rows[0];
      const locked = wallet.locked || {};
      locked[withdrawal.currency] = Math.max(0, Number(locked[withdrawal.currency] || 0) - Number(withdrawal.amount));
      await client.query('UPDATE wallets SET locked=$1 WHERE user_id=$2', [locked, withdrawal.user_id]);
      await postLedger(client, {
        debit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
        credit: { ownerType: 'platform_cash', ownerId: 'bank_payout' },
        amount: withdrawal.amount, currency: withdrawal.currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
        description: 'Withdrawal completed — funds sent to user bank account',
      });
    }

    const updated = await client.query(
      'UPDATE withdrawals SET status=$1, admin_note=COALESCE($2,admin_note), processed_by=$3, processed_at=NOW() WHERE id=$4 RETURNING *',
      [status, adminNote || null, req.auth.id, withdrawal.id]
    );
    await auditLog(client, { adminId: req.auth.id, action: `withdrawal.${status}`, entityType: 'withdrawal', entityId: withdrawal.id, metadata: { userId: withdrawal.user_id, amount: withdrawal.amount, currency: withdrawal.currency }, req });

    const u = await pool.query('SELECT email FROM users WHERE id=$1', [withdrawal.user_id]);
    const statusMessages = {
      approved: 'Aapki withdrawal request approve ho gayi hai aur process ho rahi hai.',
      processing: 'Aapki withdrawal process ho rahi hai, jaldi hi aapke bank account mein credit hogi.',
      completed: `Aapki withdrawal of ${withdrawal.currency} ${withdrawal.net_amount} successfully aapke bank account mein bhej di gayi hai.`,
      rejected: `Aapki withdrawal reject ho gayi hai. Amount aapke wallet mein wapas kar diya gaya hai.${adminNote ? ' Reason: ' + adminNote : ''}`,
    };
    await notifyUser(pool, {
      userId: withdrawal.user_id,
      userEmail: u.rows[0]?.email,
      type: `withdrawal_${status}`,
      title: `Withdrawal ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      message: statusMessages[status] || `Withdrawal status updated to ${status}`,
      metadata: { withdrawalId: withdrawal.id, amount: withdrawal.amount, currency: withdrawal.currency, status },
    });

    await client.query('COMMIT');
    res.json({ withdrawal: updated.rows[0] });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message });
  } finally { client.release(); }
});

// ---------------------------------------------------------------------------
// Live exchange rates (forex + crypto), fetched from free public APIs and
// cached in-memory for 60 seconds so we don't hammer the upstream providers
// or slow down every /api/rates request. If both providers fail (network
// issue, rate limit, etc.), we fall back to the last known good rates so the
// app never breaks; if we have never fetched successfully we fall back to
// the original static demo numbers, clearly marked as "demo_fallback".
// ---------------------------------------------------------------------------
let _ratesCache = null;
let _ratesCacheExpiry = 0;
const RATES_CACHE_MS = 60_000;
const STATIC_FALLBACK_RATES = {
  forex: { USD_INR: 83.5, EUR_INR: 90.2, GBP_INR: 106.1, AED_INR: 22.7 },
  crypto: { BTC_USD: 65000, ETH_USD: 3400, XRP_USD: 0.52, BTC_INR: 5427500 }
};

async function fetchLiveRates() {
  const [forexRes, cryptoRes] = await Promise.allSettled([
    fetch('https://open.er-api.com/v6/latest/USD').then(r => r.json()),
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,ripple&vs_currencies=usd,inr').then(r => r.json())
  ]);

  let forex = null;
  if (forexRes.status === 'fulfilled' && forexRes.value?.result === 'success') {
    const r = forexRes.value.rates;
    // API base is USD, convert to *_INR pairs the app expects.
    forex = {
      USD_INR: r.INR,
      EUR_INR: r.INR / r.EUR,
      GBP_INR: r.INR / r.GBP,
      AED_INR: r.INR / r.AED
    };
  }

  let crypto = null;
  if (cryptoRes.status === 'fulfilled' && cryptoRes.value?.bitcoin) {
    const c = cryptoRes.value;
    crypto = {
      BTC_USD: c.bitcoin?.usd,
      ETH_USD: c.ethereum?.usd,
      XRP_USD: c.ripple?.usd,
      BTC_INR: c.bitcoin?.inr
    };
  }

  if (!forex && !crypto) throw new Error('Both forex and crypto providers failed');
  return { forex, crypto };
}

async function getRates() {
  const now = Date.now();
  if (_ratesCache && now < _ratesCacheExpiry) return _ratesCache;

  try {
    const live = await fetchLiveRates();
    _ratesCache = {
      source: 'live',
      updatedAt: new Date().toISOString(),
      forex: live.forex || _ratesCache?.forex || STATIC_FALLBACK_RATES.forex,
      crypto: live.crypto || _ratesCache?.crypto || STATIC_FALLBACK_RATES.crypto
    };
  } catch (e) {
    console.error('Live rate fetch failed, using fallback:', e.message);
    _ratesCache = _ratesCache || {
      source: 'demo_fallback',
      updatedAt: new Date().toISOString(),
      forex: STATIC_FALLBACK_RATES.forex,
      crypto: STATIC_FALLBACK_RATES.crypto
    };
  }

  _ratesCacheExpiry = now + RATES_CACHE_MS;
  return _ratesCache;
}

// Checks every currently-active price alert against a freshly-fetched
// rates snapshot and fires notifications for any that have crossed their
// target. See price_alerts.js for why this is opportunistic (called from
// GET /api/rates) rather than a real background cron — Render's free tier
// has no reliable always-on timer.
async function checkPriceAlerts(rates) {
  const active = await pool.query("SELECT * FROM price_alerts WHERE status='active'");
  if (active.rowCount === 0) return;
  const flat = flattenRates(rates);
  const triggered = findTriggeredAlerts(active.rows.map(r => ({ id: r.id, userId: r.user_id, pair: r.pair, direction: r.direction, targetPrice: r.target_price })), flat);
  if (triggered.length === 0) return;

  for (const t of triggered) {
    await pool.query("UPDATE price_alerts SET status='triggered', triggered_at=NOW(), triggered_price=$1 WHERE id=$2", [t.currentPrice, t.id]);
    const u = await pool.query('SELECT email, email_notifications_enabled FROM users WHERE id=$1', [t.userId]);
    const user = u.rows[0];
    await notifyUser(pool, {
      userId: t.userId,
      userEmail: user?.email,
      sendEmail: user?.email_notifications_enabled !== false,
      type: 'price_alert_triggered',
      title: `Price Alert: ${formatPairLabel(t.pair)}`,
      message: `${formatPairLabel(t.pair)} is now ${t.currentPrice} — your target was ${t.direction} ${t.targetPrice}.`,
      metadata: { pair: t.pair, targetPrice: t.targetPrice, currentPrice: t.currentPrice, direction: t.direction },
    });
  }
}

app.get('/api/rates', async (_, res) => {
  const rates = await getRates();
  try {
    await checkPriceAlerts(rates);
  } catch (e) {
    console.error('Price alert check failed:', e.message);
  }
  res.json(rates);
});

// ---------------------------------------------------------------------------
// Price Alerts
// ---------------------------------------------------------------------------
app.post('/api/price-alerts', auth('user'), async (req, res) => {
  const { pair, direction, targetPrice } = req.body;
  if (!isSupportedPair(pair)) return res.status(400).json({ error: `Unsupported pair. Supported: ${SUPPORTED_PAIRS.join(', ')}` });
  if (!['above', 'below'].includes(direction)) return res.status(400).json({ error: "direction must be 'above' or 'below'" });
  const price = Number(targetPrice);
  if (!price || price <= 0) return res.status(400).json({ error: 'positive targetPrice required' });
  const r = await pool.query(
    "INSERT INTO price_alerts(user_id, pair, direction, target_price, status) VALUES($1,$2,$3,$4,'active') RETURNING *",
    [req.auth.id, String(pair).toUpperCase(), direction, price]
  );
  res.json({ alert: r.rows[0] });
});

app.get('/api/price-alerts', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM price_alerts WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});

app.delete('/api/price-alerts/:id', auth('user'), async (req, res) => {
  const r = await pool.query("UPDATE price_alerts SET status='cancelled' WHERE id=$1 AND user_id=$2 RETURNING *", [req.params.id, req.auth.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Alert not found' });
  res.json({ alert: r.rows[0] });
});

// ---------------------------------------------------------------------------
// Favorites / Watchlist
// ---------------------------------------------------------------------------
app.post('/api/watchlist', auth('user'), async (req, res) => {
  const { pair } = req.body;
  if (!isSupportedPair(pair)) return res.status(400).json({ error: `Unsupported pair. Supported: ${SUPPORTED_PAIRS.join(', ')}` });
  try {
    const r = await pool.query('INSERT INTO watchlist_pairs(user_id, pair) VALUES($1,$2) RETURNING *', [req.auth.id, String(pair).toUpperCase()]);
    res.json({ item: r.rows[0] });
  } catch (e) {
    if (String(e.code) === '23505') return res.status(409).json({ error: 'Pair already in watchlist' });
    throw e;
  }
});

app.get('/api/watchlist', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM watchlist_pairs WHERE user_id=$1 ORDER BY created_at ASC', [req.auth.id]);
  res.json(r.rows);
});

app.delete('/api/watchlist/:id', auth('user'), async (req, res) => {
  const r = await pool.query('DELETE FROM watchlist_pairs WHERE id=$1 AND user_id=$2 RETURNING id', [req.params.id, req.auth.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Watchlist item not found' });
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// App Settings — theme preference + notification toggles, synced to the
// account (not just stored locally) so they follow the user across devices.
// ---------------------------------------------------------------------------
app.get('/api/settings', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT theme_preference, language_preference, email_notifications_enabled, push_notifications_enabled FROM users WHERE id=$1', [req.auth.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'User not found' });
  res.json({
    themePreference: r.rows[0].theme_preference || 'system',
    languagePreference: r.rows[0].language_preference || 'en',
    emailNotificationsEnabled: r.rows[0].email_notifications_enabled !== false,
    pushNotificationsEnabled: r.rows[0].push_notifications_enabled !== false,
  });
});

app.patch('/api/settings', auth('user'), async (req, res) => {
  const { themePreference, languagePreference, emailNotificationsEnabled, pushNotificationsEnabled } = req.body;
  if (themePreference !== undefined && !['light', 'dark', 'system'].includes(themePreference)) {
    return res.status(400).json({ error: "themePreference must be 'light', 'dark' or 'system'" });
  }
  if (languagePreference !== undefined && !['en', 'hi'].includes(languagePreference)) {
    return res.status(400).json({ error: "languagePreference must be 'en' or 'hi'" });
  }
  const r = await pool.query(
    `UPDATE users SET
       theme_preference = COALESCE($1, theme_preference),
       language_preference = COALESCE($2, language_preference),
       email_notifications_enabled = COALESCE($3, email_notifications_enabled),
       push_notifications_enabled = COALESCE($4, push_notifications_enabled)
     WHERE id=$5
     RETURNING theme_preference, language_preference, email_notifications_enabled, push_notifications_enabled`,
    [themePreference || null, languagePreference || null, emailNotificationsEnabled === undefined ? null : Boolean(emailNotificationsEnabled), pushNotificationsEnabled === undefined ? null : Boolean(pushNotificationsEnabled), req.auth.id]
  );
  if (!r.rows[0]) return res.status(404).json({ error: 'User not found' });
  res.json({
    themePreference: r.rows[0].theme_preference || 'system',
    languagePreference: r.rows[0].language_preference || 'en',
    emailNotificationsEnabled: r.rows[0].email_notifications_enabled !== false,
    pushNotificationsEnabled: r.rows[0].push_notifications_enabled !== false,
  });
});

// ---------------------------------------------------------------------------
// Transaction Statement Export (PDF-via-print + CSV)
// ---------------------------------------------------------------------------
const statementTokenLimiter = rateLimit({ windowMs: 5 * 60_000, max: 15, keyFn: (req) => `stmt:${req.auth?.id || req.ip}`, message: 'Too many statement requests. Please try again shortly.' });

function normalizeTxnForStatement(txn, userId) {
  const direction = (txn.type === 'wallet_topup' || txn.type === 'refund' || txn.type === 'exchange_complete' || txn.to_user_id === userId) ? 'credit' : 'debit';
  return { id: txn.id, type: txn.type, currency: txn.currency, amount: txn.amount, status: txn.status, direction, createdAt: txn.created_at };
}

app.post('/api/statements/token', auth('user'), statementTokenLimiter, async (req, res) => {
  const { fromDate, toDate } = req.body;
  const token = generateStatementToken();
  const r = await pool.query(
    "INSERT INTO statement_tokens(token, user_id, from_date, to_date, expires_at) VALUES($1,$2,$3,$4, NOW() + INTERVAL '15 minutes') RETURNING expires_at",
    [token, req.auth.id, fromDate || null, toDate || null]
  );
  res.json({ token, url: `/api/statements/${token}`, csvUrl: `/api/statements/${token}/csv`, expiresAt: r.rows[0].expires_at });
});

async function loadStatementData(token) {
  const t = await pool.query('SELECT * FROM statement_tokens WHERE token=$1', [token]);
  const record = t.rows[0];
  if (!record) return { record: null };
  if (new Date(record.expires_at).getTime() < Date.now()) return { record, expired: true };
  const u = await pool.query('SELECT * FROM users WHERE id=$1', [record.user_id]);
  const user = safeUser(u.rows[0]);
  const params = [record.user_id];
  let sql = 'SELECT * FROM transactions WHERE (from_user_id=$1 OR to_user_id=$1)';
  if (record.from_date) { params.push(record.from_date); sql += ` AND created_at >= $${params.length}`; }
  if (record.to_date) { params.push(record.to_date); sql += ` AND created_at < ($${params.length}::date + INTERVAL '1 day')`; }
  sql += ' ORDER BY created_at DESC';
  const txns = await pool.query(sql, params);
  const rows = txns.rows.map(t => normalizeTxnForStatement(t, record.user_id));
  return { record, user, rows };
}

// IMPORTANT: the /csv route must be registered BEFORE the bare /:token
// route below — Express path params (`:token`) match any character except
// `/`, so `/api/statements/abc123/csv` would otherwise never be reached if
// a broader pattern were declared first. Using a `/csv` sub-path (rather
// than a `.csv` suffix on the same segment) avoids the ambiguity entirely.
app.get('/api/statements/:token/csv', async (req, res) => {
  const { record, expired, rows } = await loadStatementData(req.params.token);
  if (!record) return res.status(404).json({ error: 'Statement link not found' });
  if (expired) return res.status(410).json({ error: 'Statement link expired' });
  const csv = renderStatementCsv(rows);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="global-exchanger-statement.csv"');
  res.send(csv);
});

app.get('/api/statements/:token', async (req, res) => {
  const { record, expired, user, rows } = await loadStatementData(req.params.token);
  if (!record) return res.status(404).send('<h2>Statement link not found.</h2>');
  if (expired) return res.status(410).send('<h2>This statement link has expired. Please generate a new one from the app.</h2>');
  const html = renderStatementHtml({ user, fromDate: record.from_date, toDate: record.to_date, rows });
  res.send(wrapStatementPage(html));
});

// ---------------------------------------------------------------------------
// In-app notifications
// ---------------------------------------------------------------------------
app.get('/api/notifications', auth('user'), async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 30, 100);
  const offset = parseInt(req.query.offset) || 0;
  const r = await pool.query(
    'SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3',
    [req.auth.id, limit, offset]
  );
  const unread = await pool.query('SELECT COUNT(*) FROM notifications WHERE user_id=$1 AND is_read=false', [req.auth.id]);
  res.json({ notifications: r.rows, unreadCount: Number(unread.rows[0].count) });
});

app.post('/api/notifications/:id/read', auth('user'), async (req, res) => {
  const r = await pool.query('UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2 RETURNING *', [req.params.id, req.auth.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Notification not found' });
  res.json({ notification: r.rows[0] });
});

app.post('/api/notifications/read-all', auth('user'), async (req, res) => {
  await pool.query('UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false', [req.auth.id]);
  res.json({ success: true });
});

const sendMoneyPinLimiter = rateLimit({ windowMs: 15 * 60_000, max: 8, keyFn: (req) => `pin:${req.auth?.id || req.ip}`, message: 'Too many incorrect PIN attempts. Please try again in 15 minutes.' });

app.post('/api/transactions/send', auth('user'), sendMoneyPinLimiter, async (req, res) => {
  const client = await pool.connect();
  let limitError = null;
  let pinError = false;
  try {
    const { toUserId, receiver, toEmail, amount, currency = 'INR', pin, note = '' } = req.body;
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) throw new Error('positive amount required');
    await client.query('BEGIN');
    const ur = await client.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
    const sender = ur.rows[0];
    if (!sender.security_pin_hash || !(await bcrypt.compare(String(pin), sender.security_pin_hash))) { pinError = true; throw new Error('Invalid security PIN'); }
    const receiverKey = String(toUserId || receiver || toEmail || '').trim();
    if (!receiverKey) throw new Error('receiver email or userId required');
    const rr = await client.query('SELECT * FROM users WHERE id::text=$1 OR lower(email)=lower($1) OR phone=$1 LIMIT 1', [receiverKey]);
    const receiverUser = rr.rows[0];
    if (!receiverUser) throw new Error('Receiver not found');
    if (receiverUser.id === req.auth.id) throw new Error('Cannot send money to yourself');
    const from = (await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id])).rows[0];
    const to = (await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [receiverUser.id])).rows[0];
    if (!to) throw new Error('Receiver wallet not found');
    const bal = Number(from.balances[currency] || 0);
    if (bal < numericAmount) throw new Error('Insufficient balance');
    // Tier-limit rejections are permission-based (KYC/limit gated), not
    // malformed-request errors, so they're surfaced as 403 rather than the
    // generic 400 used for everything else in this handler — tracked via
    // limitError (set here, checked in the catch block below) since a plain
    // throw would otherwise be indistinguishable from a validation error.
    let limitCheck;
    try {
      limitCheck = await enforceTierLimits(client, sender, { action: 'send', amount: numericAmount, currency });
    } catch (e) {
      limitError = e;
      throw e;
    }
    from.balances[currency] = bal - numericAmount;
    to.balances[currency] = Number(to.balances[currency] || 0) + numericAmount;
    await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [from.balances, req.auth.id]);
    await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [to.balances, receiverUser.id]);
    const txn = await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status,metadata) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', ['send', req.auth.id, receiverUser.id, numericAmount, currency, 'completed', { note }]);
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: receiverUser.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: numericAmount, currency, referenceType: 'transaction', referenceId: txn.rows[0].id, description: 'User to user wallet send/receive' });
    await checkAmlAndBalanceCap(client, req.auth.id, { amountInr: limitCheck.amountInr, referenceType: 'transaction', referenceId: txn.rows[0].id, note: 'send money' });

    // Travel Rule data capture — see travel_rule.js and server.js's
    // equivalent handler for full rationale.
    if (VDA_CURRENCIES.includes(currency)) {
      const senderKyc = await client.query('SELECT national_id FROM kyc_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1', [req.auth.id]);
      const receiverKyc = await client.query('SELECT national_id FROM kyc_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1', [receiverUser.id]);
      const tr = buildTravelRuleRecord({
        originatorUser: sender, beneficiaryUser: receiverUser, currency, amount: numericAmount,
        referenceType: 'transaction', referenceId: txn.rows[0].id,
        originatorNationalId: senderKyc.rows[0]?.national_id, beneficiaryNationalId: receiverKyc.rows[0]?.national_id,
      });
      await client.query(
        'INSERT INTO travel_rule_records(currency,amount,reference_type,reference_id,originator,beneficiary,captured_at) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [tr.currency, tr.amount, tr.referenceType, tr.referenceId, JSON.stringify(tr.originator), JSON.stringify(tr.beneficiary), tr.capturedAt]
      );
    }

    await maybePayReferralReward(client, req.auth.id);
    await client.query('COMMIT');
    res.json({ transaction: txn.rows[0], receiver: safeUser(receiverUser) });
  } catch (e) { await client.query('ROLLBACK'); res.status((limitError || pinError) ? 403 : 400).json({ error: e.message }); }
  finally { client.release(); }
});

// ---------------------------------------------------------------------------
// Scheduled / Recurring Payments ("Autopay"-style mandates). Security PIN
// is verified once here at creation time; automatic executions later
// (runDueScheduledPaymentsPg, above) do NOT re-prompt for it — same UX as
// real UPI Autopay mandates. See SCHEDULED_PAYMENTS_GUIDE.md.
// ---------------------------------------------------------------------------
app.post('/api/scheduled-payments', auth('user'), sendMoneyPinLimiter, async (req, res) => {
  const { receiver, amount, currency = 'INR', frequency, note = '', pin } = req.body;
  const numericAmount = Number(amount);
  if (!numericAmount || numericAmount <= 0) return res.status(400).json({ error: 'positive amount required' });
  if (!isValidFrequency(frequency)) return res.status(400).json({ error: `frequency must be one of: ${FREQUENCIES.join(', ')}` });
  const ur = await pool.query('SELECT * FROM users WHERE id=$1', [req.auth.id]);
  const sender = ur.rows[0];
  if (!sender.security_pin_hash || !(await bcrypt.compare(String(pin), sender.security_pin_hash))) return res.status(403).json({ error: 'Invalid security PIN' });
  const receiverKey = String(receiver || '').trim();
  if (!receiverKey) return res.status(400).json({ error: 'receiver email or userId required' });
  const rr = await pool.query('SELECT * FROM users WHERE id::text=$1 OR lower(email)=lower($1) OR phone=$1 LIMIT 1', [receiverKey]);
  const receiverUser = rr.rows[0];
  if (!receiverUser) return res.status(404).json({ error: 'Receiver not found' });
  if (receiverUser.id === req.auth.id) return res.status(400).json({ error: 'Cannot schedule a payment to yourself' });

  const nextRunAt = computeNextRunAt(frequency, new Date());
  const r = await pool.query(
    "INSERT INTO scheduled_payments(user_id, receiver_key, receiver_user_id, amount, currency, frequency, note, status, next_run_at) VALUES($1,$2,$3,$4,$5,$6,$7,'active',$8) RETURNING *",
    [req.auth.id, receiverKey, receiverUser.id, numericAmount, currency, frequency, note, nextRunAt]
  );
  res.json({ scheduledPayment: r.rows[0] });
});

app.get('/api/scheduled-payments', auth('user'), async (req, res) => {
  try {
    await runDueScheduledPaymentsPg(req.auth.id);
  } catch (e) {
    console.error('Scheduled payment execution failed:', e.message);
  }
  const r = await pool.query('SELECT * FROM scheduled_payments WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});

app.get('/api/scheduled-payments/:id/runs', auth('user'), async (req, res) => {
  const m = await pool.query('SELECT id FROM scheduled_payments WHERE id=$1 AND user_id=$2', [req.params.id, req.auth.id]);
  if (!m.rows[0]) return res.status(404).json({ error: 'Scheduled payment not found' });
  const r = await pool.query('SELECT * FROM scheduled_payment_runs WHERE scheduled_payment_id=$1 ORDER BY run_at DESC', [req.params.id]);
  res.json(r.rows);
});

app.patch('/api/scheduled-payments/:id', auth('user'), async (req, res) => {
  const { status } = req.body;
  if (!['active', 'paused', 'cancelled'].includes(status)) return res.status(400).json({ error: "status must be 'active', 'paused' or 'cancelled'" });
  const existing = await pool.query('SELECT * FROM scheduled_payments WHERE id=$1 AND user_id=$2', [req.params.id, req.auth.id]);
  if (!existing.rows[0]) return res.status(404).json({ error: 'Scheduled payment not found' });
  if (existing.rows[0].status === 'cancelled') return res.status(400).json({ error: 'Cannot modify a cancelled scheduled payment' });

  let r;
  if (status === 'active') {
    const nextRunAt = computeNextRunAt(existing.rows[0].frequency, new Date());
    r = await pool.query("UPDATE scheduled_payments SET status=$1, consecutive_failures=0, next_run_at=$2 WHERE id=$3 RETURNING *", [status, nextRunAt, req.params.id]);
  } else {
    r = await pool.query('UPDATE scheduled_payments SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]);
  }
  res.json({ scheduledPayment: r.rows[0] });
});

app.get('/api/transactions', auth('user'), async (req, res) => {
  const { type, status, from, to, search, limit = 50, offset = 0 } = req.query;
  const conditions = ['(from_user_id=$1 OR to_user_id=$1)'];
  const params = [req.auth.id];

  if (type) { params.push(type); conditions.push(`type=$${params.length}`); }
  if (status) { params.push(status); conditions.push(`status=$${params.length}`); }
  if (from) { params.push(from); conditions.push(`created_at >= $${params.length}`); }
  if (to) { params.push(to); conditions.push(`created_at <= $${params.length}`); }
  if (search) { params.push(`%${search}%`); conditions.push(`(id::text ILIKE $${params.length} OR currency ILIKE $${params.length})`); }

  const limitNum = Math.min(parseInt(limit) || 50, 200);
  const offsetNum = parseInt(offset) || 0;
  params.push(limitNum, offsetNum);

  const sql = `SELECT * FROM transactions WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;
  const r = await pool.query(sql, params);
  res.json(r.rows);
});

// ---------------------------------------------------------------------------
// Spending Analytics — monthly in/out trend, category breakdown, top
// counterparties, computed purely from the user's own transaction history.
// See analytics.js for the shared aggregation logic.
// ---------------------------------------------------------------------------
app.get('/api/analytics/spending', auth('user'), async (req, res) => {
  const monthsBack = Math.min(Math.max(parseInt(req.query.months) || 6, 1), 12);
  const myId = req.auth.id;
  const t = await pool.query('SELECT * FROM transactions WHERE from_user_id=$1 OR to_user_id=$1', [myId]);

  const counterpartyIds = [...new Set(t.rows.filter(row => row.type === 'send').map(row => row.from_user_id === myId ? row.to_user_id : row.from_user_id).filter(Boolean))];
  let counterpartyMap = {};
  if (counterpartyIds.length > 0) {
    const u = await pool.query('SELECT id, name, email FROM users WHERE id = ANY($1)', [counterpartyIds]);
    counterpartyMap = Object.fromEntries(u.rows.map(row => [row.id, row.name || row.email || 'Unknown']));
  }

  const normalized = t.rows.map(row => {
    const direction = (row.type === 'wallet_topup' || row.type === 'refund' || row.type === 'exchange_complete' || row.to_user_id === myId) ? 'credit' : 'debit';
    let counterpartyId = null, counterpartyLabel = null;
    if (row.type === 'send') {
      counterpartyId = direction === 'debit' ? row.to_user_id : row.from_user_id;
      counterpartyLabel = counterpartyMap[counterpartyId] || 'Unknown';
    }
    return { id: row.id, type: row.type, currency: row.currency, amount: row.amount, status: row.status, direction, createdAt: row.created_at, counterpartyId, counterpartyLabel };
  });

  res.json({
    summary: overallSummary(normalized, toApproxInr),
    monthlyTrend: monthlyTrend(normalized, toApproxInr, monthsBack),
    categoryBreakdown: categoryBreakdown(normalized, toApproxInr),
    topCounterparties: topCounterparties(normalized, toApproxInr),
  });
});

// User's own exchange orders (with commission breakdown) — previously only
// admins could list exchange orders; users had no way to see their own
// convert/exchange history beyond the generic `transactions` table.
app.get('/api/exchange/orders/mine', auth('user'), async (req, res) => {
  const { status, limit = 50, offset = 0 } = req.query;
  const conditions = ['user_id=$1'];
  const params = [req.auth.id];
  if (status) { params.push(status); conditions.push(`status=$${params.length}`); }
  const limitNum = Math.min(parseInt(limit) || 50, 200);
  const offsetNum = parseInt(offset) || 0;
  params.push(limitNum, offsetNum);
  const sql = `SELECT * FROM exchange_orders WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;
  const r = await pool.query(sql, params);
  res.json(r.rows);
});

// ---------------------------------------------------------------------------
// Receipts: request a short-lived token for a specific transaction/exchange
// order, then open it in a browser to view/print/save-as-PDF. The token is
// scoped to exactly one record, expires in 15 minutes, and is single-use
// only in the sense that it always re-checks ownership — it does not carry
// the user's real JWT, so it's safe to put in a URL/QR/share link.
// ---------------------------------------------------------------------------
const receiptTokenLimiter = rateLimit({ windowMs: 60_000, max: 20, keyFn: (req) => `receipt:${req.auth?.id || req.ip}` });

app.post('/api/receipts/token', auth('user'), receiptTokenLimiter, async (req, res) => {
  const { transactionId, exchangeOrderId } = req.body;
  if (!transactionId && !exchangeOrderId) return res.status(400).json({ error: 'transactionId or exchangeOrderId required' });

  if (transactionId) {
    const t = await pool.query('SELECT id FROM transactions WHERE id=$1 AND (from_user_id=$2 OR to_user_id=$2)', [transactionId, req.auth.id]);
    if (!t.rows[0]) return res.status(404).json({ error: 'Transaction not found' });
  }
  if (exchangeOrderId) {
    const o = await pool.query('SELECT id FROM exchange_orders WHERE id=$1 AND user_id=$2', [exchangeOrderId, req.auth.id]);
    if (!o.rows[0]) return res.status(404).json({ error: 'Exchange order not found' });
  }

  const token = generateReceiptToken();
  const expiresAt = new Date(Date.now() + 15 * 60_000).toISOString();
  await pool.query(
    'INSERT INTO receipt_tokens(token, user_id, transaction_id, exchange_order_id, expires_at) VALUES($1,$2,$3,$4,$5)',
    [token, req.auth.id, transactionId || null, exchangeOrderId || null, expiresAt]
  );
  res.json({ token, url: `/api/receipts/${token}`, expiresAt });
});

app.get('/api/receipts/:token', async (req, res) => {
  const r = await pool.query('SELECT * FROM receipt_tokens WHERE token=$1', [req.params.token]);
  const record = r.rows[0];
  if (!record) return res.status(404).send('<h2>Receipt link not found or already expired.</h2>');
  if (new Date(record.expires_at).getTime() < Date.now()) return res.status(410).send('<h2>This receipt link has expired. Please generate a new one from the app.</h2>');

  const u = await pool.query('SELECT name, email FROM users WHERE id=$1', [record.user_id]);
  const user = u.rows[0] || {};

  if (record.transaction_id) {
    const t = await pool.query('SELECT * FROM transactions WHERE id=$1', [record.transaction_id]);
    if (!t.rows[0]) return res.status(404).send('<h2>Transaction not found.</h2>');
    return res.send(wrapReceiptPage(renderTransactionReceipt({ transaction: t.rows[0], user: { ...user, id: record.user_id } })));
  }

  if (record.exchange_order_id) {
    const o = await pool.query('SELECT * FROM exchange_orders WHERE id=$1', [record.exchange_order_id]);
    if (!o.rows[0]) return res.status(404).send('<h2>Exchange order not found.</h2>');
    return res.send(wrapReceiptPage(renderExchangeReceipt({ order: o.rows[0], user })));
  }

  res.status(404).send('<h2>Receipt not found.</h2>');
});

app.post('/api/exchange/orders', auth('user'), async (req, res) => {
  const { fromCurrency, toCurrency, amount, mode = 'convert' } = req.body;
  const commission = Number(amount) * 0.01, adminCommission = Number(amount) * 0.008, sellerCommission = Number(amount) * 0.002;
  try {
    const ur = await pool.query('SELECT kyc_status FROM users WHERE id=$1', [req.auth.id]);
    await enforceTierLimits(pool, { id: req.auth.id, kycStatus: ur.rows[0]?.kyc_status }, { action: 'exchange', amount: Number(amount), currency: fromCurrency });
  } catch (e) {
    return res.status(403).json({ error: e.message });
  }
  const r = await pool.query(
    `INSERT INTO exchange_orders(user_id,mode,from_currency,to_currency,amount,commission,admin_commission,seller_commission)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [req.auth.id, mode, fromCurrency, toCurrency, amount, commission, adminCommission, sellerCommission]
  );
  await pool.query('INSERT INTO commissions(order_id,admin_commission,seller_commission) VALUES($1,$2,$3)', [r.rows[0].id, adminCommission, sellerCommission]);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await postLedger(client, { debit: { ownerType: 'platform_commission_receivable', ownerId: 'exchange' }, credit: { ownerType: 'exchange_user_payable', ownerId: req.auth.id }, amount: commission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '1% exchange commission accrued' });
    await postLedger(client, { debit: { ownerType: 'admin_commission_earning', ownerId: 'admin' }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: adminCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.8% admin commission split' });
    await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.2% seller/user commission split' });

    // Reward wallet credit: actually move 0.2% (sellerCommission) into the user's
    // reward_balances so it is visible/usable, not just recorded in the ledger.
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const rewardBalances = wallet.reward_balances || {};
    rewardBalances[fromCurrency] = Number(rewardBalances[fromCurrency] || 0) + sellerCommission;
    await client.query('UPDATE wallets SET reward_balances=$1 WHERE user_id=$2', [rewardBalances, req.auth.id]);
    await postLedger(client, { debit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, credit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: r.rows[0].id, description: '0.2% reward credited to user reward wallet' });
    await checkAmlAndBalanceCap(client, req.auth.id, { amountInr: toApproxInr(amount, fromCurrency), referenceType: 'exchange_order', referenceId: r.rows[0].id, note: 'currency/crypto exchange order created' });

    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }

  const u = await pool.query('SELECT email FROM users WHERE id=$1', [req.auth.id]);
  await notifyUser(pool, {
    userId: req.auth.id,
    userEmail: u.rows[0]?.email,
    type: 'reward_credited',
    title: 'Reward Credited',
    message: `Aapko ${fromCurrency} ${sellerCommission.toFixed(4)} ka reward mila hai is exchange order par. Wallet screen ke "Reward Wallet" section mein dekhein.`,
    metadata: { orderId: r.rows[0].id, amount: sellerCommission, currency: fromCurrency },
    sendEmail: false, // keep this one in-app only to avoid an extra email per exchange
  });

  res.json({ order: r.rows[0] });
});


app.post('/api/disputes', auth('user'), async (req, res) => {
  const { transactionId, reason, message, evidence = [] } = req.body;
  if (!reason || !message) return res.status(400).json({ error: 'reason and message required' });
  const r = await pool.query('INSERT INTO disputes(user_id,transaction_id,reason,message,evidence) VALUES($1,$2,$3,$4,$5) RETURNING *', [req.auth.id, transactionId || null, reason, message, JSON.stringify(evidence)]);
  res.json({ dispute: r.rows[0] });
});

app.get('/api/disputes', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM disputes WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows);
});

app.get('/api/admin/disputes', auth('admin'), requirePermission('disputes:manage'), async (_, res) => {
  const r = await pool.query(`SELECT d.*, row_to_json(u.*) AS user FROM disputes d LEFT JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.patch('/api/admin/disputes/:id', auth('admin'), requirePermission('disputes:manage'), async (req, res) => {
  const { status, adminNote, resolution } = req.body;
  const r = await pool.query('UPDATE disputes SET status=COALESCE($1,status), admin_note=COALESCE($2,admin_note), resolution=COALESCE($3,resolution), updated_at=NOW() WHERE id=$4 RETURNING *', [status || null, adminNote || null, resolution || null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Dispute not found' });
  await auditLog(pool, { adminId: req.auth.id, action: `dispute.${r.rows[0].status}`, entityType: 'dispute', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ dispute: r.rows[0] });
});

app.post('/api/complaints', auth('user'), async (req, res) => {
  const { subject, message, transactionId } = req.body;
  const r = await pool.query('INSERT INTO complaints(user_id,subject,message,transaction_id) VALUES($1,$2,$3,$4) RETURNING *', [req.auth.id, subject, message, transactionId || null]);
  res.json({ complaint: r.rows[0] });
});

// Whether a complaint has a chat reply the given side ("user" or "admin")
// hasn't seen yet. Works because every SEND endpoint also stamps the
// sender's own "last read" pointer to the same moment (see the message
// endpoints below) — so this simple timestamp comparison only ever shows
// "unread" to the side that did NOT send the most recent message.
function complaintHasUnread(row, side) {
  if (!row.last_message_at) return false;
  const lastRead = side === 'user' ? row.last_user_read_at : row.last_admin_read_at;
  return !lastRead || new Date(row.last_message_at) > new Date(lastRead);
}

// User's own complaints — previously only admins could list complaints;
// a user could submit one but never see its status afterwards.
app.get('/api/complaints', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM complaints WHERE user_id=$1 ORDER BY created_at DESC', [req.auth.id]);
  res.json(r.rows.map(row => ({ ...row, hasUnread: complaintHasUnread(row, 'user') })));
});

// Lightweight summary endpoint for a badge (e.g. on the Help bottom-nav tab)
// — avoids the app needing to fetch and diff the full complaints list just
// to know whether to show a red dot.
app.get('/api/complaints/unread-count', auth('user'), async (req, res) => {
  const r = await pool.query('SELECT * FROM complaints WHERE user_id=$1', [req.auth.id]);
  const count = r.rows.filter(row => complaintHasUnread(row, 'user')).length;
  res.json({ unreadCount: count });
});

app.get('/api/admin/complaints/unread-count', auth('admin'), async (_, res) => {
  const r = await pool.query('SELECT * FROM complaints');
  const count = r.rows.filter(row => complaintHasUnread(row, 'admin')).length;
  res.json({ unreadCount: count });
});

// ---------------------------------------------------------------------------
// In-App Support Chat — real back-and-forth messages within a complaint
// ("case"), on top of the original one-shot complaint submission above.
// Polling-based (no websockets) to keep the Render free-tier deployment
// simple; the app polls GET .../messages while the chat screen is open.
// ---------------------------------------------------------------------------

// Direct "Chat with Support" — lets a user open a chat thread instantly
// (no subject/details form) via a single tap. Reuses the user's existing
// general-chat thread if one already exists (so repeated taps don't spawn
// a new thread every time), otherwise creates one on first use.
app.post('/api/support/chat', auth('user'), async (req, res) => {
  const existing = await pool.query('SELECT * FROM complaints WHERE user_id=$1 AND is_general_chat=TRUE LIMIT 1', [req.auth.id]);
  if (existing.rows[0]) return res.json({ complaint: existing.rows[0] });
  const r = await pool.query(
    "INSERT INTO complaints(user_id,subject,message,transaction_id,status,is_general_chat) VALUES($1,$2,$3,$4,$5,TRUE) RETURNING *",
    [req.auth.id, 'Support Chat', 'General support chat opened from the Help tab.', null, 'submitted']
  );
  res.json({ complaint: r.rows[0] });
});

app.post('/api/complaints/:id/messages', auth('user'), async (req, res) => {
  const { message } = req.body;
  if (!message || !String(message).trim()) return res.status(400).json({ error: 'message required' });
  const c = await pool.query('SELECT * FROM complaints WHERE id=$1 AND user_id=$2', [req.params.id, req.auth.id]);
  if (!c.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  const u = await pool.query('SELECT name FROM users WHERE id=$1', [req.auth.id]);
  const r = await pool.query(
    "INSERT INTO complaint_messages(complaint_id, sender_type, sender_id, sender_name, message) VALUES($1,'user',$2,$3,$4) RETURNING *",
    [req.params.id, req.auth.id, u.rows[0]?.name || 'User', String(message).trim()]
  );
  await pool.query('UPDATE complaints SET last_message_at=NOW(), last_user_read_at=NOW() WHERE id=$1', [req.params.id]);
  res.json({ message: r.rows[0] });
});

app.get('/api/complaints/:id/messages', auth('user'), async (req, res) => {
  const c = await pool.query('SELECT * FROM complaints WHERE id=$1 AND user_id=$2', [req.params.id, req.auth.id]);
  if (!c.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  const r = await pool.query('SELECT * FROM complaint_messages WHERE complaint_id=$1 ORDER BY created_at ASC', [req.params.id]);
  await pool.query('UPDATE complaints SET last_user_read_at=NOW() WHERE id=$1', [req.params.id]);
  res.json({ messages: r.rows, complaint: c.rows[0] });
});

app.get('/api/admin/complaints/:id/messages', auth('admin'), async (req, res) => {
  const c = await pool.query('SELECT * FROM complaints WHERE id=$1', [req.params.id]);
  if (!c.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  const r = await pool.query('SELECT * FROM complaint_messages WHERE complaint_id=$1 ORDER BY created_at ASC', [req.params.id]);
  await pool.query('UPDATE complaints SET last_admin_read_at=NOW() WHERE id=$1', [req.params.id]);
  res.json({ messages: r.rows, complaint: c.rows[0] });
});

app.post('/api/admin/complaints/:id/messages', auth('admin'), async (req, res) => {
  const { message } = req.body;
  if (!message || !String(message).trim()) return res.status(400).json({ error: 'message required' });
  const c = await pool.query('SELECT * FROM complaints WHERE id=$1', [req.params.id]);
  if (!c.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  const a = await pool.query('SELECT email FROM admins WHERE id=$1', [req.auth.id]);
  const r = await pool.query(
    "INSERT INTO complaint_messages(complaint_id, sender_type, sender_id, sender_name, message) VALUES($1,'admin',$2,$3,$4) RETURNING *",
    [req.params.id, req.auth.id, a.rows[0]?.email || 'Support Team', String(message).trim()]
  );
  await pool.query('UPDATE complaints SET last_message_at=NOW(), last_admin_read_at=NOW() WHERE id=$1', [req.params.id]);

  const u = await pool.query('SELECT email, email_notifications_enabled FROM users WHERE id=$1', [c.rows[0].user_id]);
  await notifyUser(pool, {
    userId: c.rows[0].user_id,
    userEmail: u.rows[0]?.email,
    sendEmail: u.rows[0]?.email_notifications_enabled !== false,
    type: 'support_reply',
    title: 'New reply on your support ticket',
    message: `Support team ne aapki complaint "${c.rows[0].subject || ''}" par reply kiya hai.`,
    metadata: { complaintId: req.params.id },
  });

  res.json({ message: r.rows[0] });
});


// OTP and Email Verification APIs
//
// SECURITY: the OTP is only ever echoed back in the API response when the
// operator has explicitly opted in via ALLOW_DEV_OTP_IN_RESPONSE=true. Do
// NOT rely on NODE_ENV here — many hosts (including Render, unless you set
// it yourself) never set NODE_ENV=production, which previously caused real
// OTPs to leak in the API response even in the live production deployment.
const DEV_OTP_IN_RESPONSE = String(process.env.ALLOW_DEV_OTP_IN_RESPONSE || '').toLowerCase() === 'true';

app.post('/api/auth/request-otp', otpRequestLimiter, async (req, res) => {
  const { email, purpose = 'email_verification' } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  const otp = generateOtp();
  await pool.query('INSERT INTO otp_codes(email,purpose,otp_hash,expires_at) VALUES($1,$2,$3,$4)', [email, purpose, await hashOtp(otp), otpExpiry(10)]);
  await sendOtpEmail({ email, otp, purpose });
  res.json({ message: 'OTP sent', purpose, devOtp: DEV_OTP_IN_RESPONSE ? otp : undefined });
});

app.post('/api/auth/verify-email-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const r = await pool.query('SELECT * FROM otp_codes WHERE email=$1 AND purpose=$2 AND used=false ORDER BY created_at DESC LIMIT 1', [email, 'email_verification']);
  const item = r.rows[0];
  if (!item || isExpired(item.expires_at) || !(await compareOtp(otp, item.otp_hash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  await pool.query('UPDATE otp_codes SET used=true WHERE id=$1', [item.id]);
  await pool.query('UPDATE users SET email_verified=true WHERE email=$1', [email]);
  res.json({ message: 'Email verified' });
});

app.post('/api/auth/login-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const r = await pool.query('SELECT * FROM otp_codes WHERE email=$1 AND purpose=$2 AND used=false ORDER BY created_at DESC LIMIT 1', [email, 'login']);
  const item = r.rows[0];
  if (!item || isExpired(item.expires_at) || !(await compareOtp(otp, item.otp_hash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  const u = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = u.rows[0];
  if (!user) return res.status(404).json({ error: 'User not found' });
  await pool.query('UPDATE otp_codes SET used=true WHERE id=$1', [item.id]);
  const session = await issueAuthSession({ ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  res.json({ ...session, user: safeUser(user) });
});

// Payment Gateway Structure APIs
app.post('/api/payments/orders', auth('user'), async (req, res) => {
  const { amount, currency = 'INR', purpose = 'wallet_topup' } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'positive amount required' });
  if (purpose === 'wallet_topup') {
    try {
      const ur = await pool.query('SELECT id, kyc_status FROM users WHERE id=$1', [req.auth.id]);
      await enforceTierLimits(pool, { id: req.auth.id, kycStatus: ur.rows[0]?.kyc_status }, { action: 'topup', amount: Number(amount), currency });
    } catch (e) {
      return res.status(403).json({ error: e.message });
    }
  }
  const provider = getPaymentProvider();
  const gatewayOrder = await provider.createOrder({ amount: Number(amount), currency, receipt: `GX_${Date.now()}`, notes: { userId: req.auth.id, purpose } });
  const r = await pool.query(
    `INSERT INTO payment_orders(user_id,provider,gateway_order_id,amount,currency,purpose,gateway_response)
     VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [req.auth.id, gatewayOrder.provider, gatewayOrder.gatewayOrderId, amount, currency, purpose, gatewayOrder]
  );
  res.json({ order: r.rows[0], gatewayOrder });
});

app.post('/api/payments/verify', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { orderId, gatewayOrderId, gatewayPaymentId, gatewaySignature } = req.body;
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM payment_orders WHERE id=$1 AND user_id=$2 FOR UPDATE', [orderId, req.auth.id]);
    const order = r.rows[0];
    if (!order) throw new Error('Payment order not found');
    const provider = getPaymentProvider(order.provider);
    const verification = await provider.verifyPayment({ gatewayOrderId: gatewayOrderId || order.gateway_order_id, gatewayPaymentId, gatewaySignature });
    const status = verification.verified ? 'paid' : 'verification_failed';
    await client.query('UPDATE payment_orders SET status=$1, verification=$2 WHERE id=$3', [status, verification, order.id]);
    if (verification.verified && order.purpose === 'wallet_topup') {
      const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
      const balances = w.rows[0].balances;
      balances[order.currency] = Number(balances[order.currency] || 0) + Number(order.amount);
      const ur = await client.query('SELECT kyc_status FROM users WHERE id=$1', [req.auth.id]);
      try {
        enforceWalletBalanceCap(ur.rows[0]?.kyc_status, balances);
      } catch (e) {
        // Payment gateway already captured the money — flag for admin manual
        // handling/refund rather than silently discarding it (see server.js
        // JSON-backend equivalent + TECHNICAL_SAFEGUARDS_GUIDE.md).
        await auditLog(client, { adminId: null, userId: req.auth.id, action: 'topup.blocked.wallet_cap_exceeded', entityType: 'payment_order', entityId: order.id, metadata: { amount: order.amount, currency: order.currency, reason: e.message } });
        await client.query('COMMIT');
        return res.status(403).json({ error: e.message + ' Your payment was captured but could not be credited — please contact support for a refund or to complete KYC.' });
      }
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [balances, req.auth.id]);
      const txn = await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6) RETURNING id', ['wallet_topup', null, req.auth.id, order.amount, order.currency, 'completed']);
      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, amount: order.amount, currency: order.currency, referenceType: 'payment_order', referenceId: order.id, description: 'Wallet top-up via payment gateway' });
      await checkAmlAndBalanceCap(client, req.auth.id, { amountInr: toApproxInr(order.amount, order.currency), referenceType: 'payment_order', referenceId: order.id, note: 'wallet top-up' });
      await maybePayReferralReward(client, req.auth.id);
    }
    await client.query('COMMIT');


    const u = await pool.query('SELECT email FROM users WHERE id=$1', [req.auth.id]);
    if (verification.verified) {
      await notifyUser(pool, {
        userId: req.auth.id,
        userEmail: u.rows[0]?.email,
        type: 'payment_success',
        title: 'Payment Successful',
        message: `Aapka payment of ${order.currency} ${order.amount} successful ho gaya hai aur wallet mein credit ho gaya hai.`,
        metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
      });
    } else {
      await notifyUser(pool, {
        userId: req.auth.id,
        userEmail: u.rows[0]?.email,
        type: 'payment_failed',
        title: 'Payment Failed',
        message: `Aapka payment of ${order.currency} ${order.amount} verify nahi ho paya. Kripya dobara try karein ya support se contact karein.`,
        metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
      });
    }

    res.json({ order: { ...order, status }, verification });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message });
  } finally { client.release(); }
});

app.post('/api/payments/webhook', async (req, res) => {
  const provider = getPaymentProvider(process.env.PAYMENT_PROVIDER || 'mock');
  const signature = req.headers['x-razorpay-signature'];
  const raw = req.rawBody ? req.rawBody.toString() : JSON.stringify(req.body);

  if (process.env.PAYMENT_PROVIDER === 'razorpay') {
    // In LIVE Razorpay mode, a missing webhook secret must never silently
    // pass — that would let anyone forge a "payment successful" webhook.
    if (!process.env.RAZORPAY_WEBHOOK_SECRET) {
      console.error('SECURITY: RAZORPAY_WEBHOOK_SECRET is not set while PAYMENT_PROVIDER=razorpay. Rejecting webhook.');
      return res.status(500).json({ error: 'Webhook not configured correctly' });
    }
    const verified = provider.verifyWebhookSignature(raw, signature, process.env.RAZORPAY_WEBHOOK_SECRET);
    if (!verified) return res.status(400).json({ error: 'Invalid webhook signature' });
    return res.json({ received: true, verified: true });
  }

  // mock/cashfree structure providers — accepted as-is (no real money involved).
  res.json({ received: true, verified: true });
});

app.post('/api/payments/refund', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { orderId, gatewayPaymentId, amount, reason = 'admin_refund' } = req.body;
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM payment_orders WHERE id=$1 FOR UPDATE', [orderId]);
    const order = r.rows[0];
    if (!order) throw new Error('Payment order not found');
    if (order.status !== 'paid') throw new Error('Only paid orders can be refunded');
    const provider = getPaymentProvider(order.provider);
    const refund = await provider.refundPayment({ gatewayPaymentId: gatewayPaymentId || order.verification?.gatewayPaymentId, amount: amount || order.amount, notes: { reason, orderId } });
    const refundAmount = Number(amount || order.amount);
    const rr = await client.query('INSERT INTO refunds(order_id,provider,amount,currency,reason,status,gateway_refund) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', [orderId, order.provider, refundAmount, order.currency, reason, refund.status || 'processed', refund]);
    await client.query('UPDATE payment_orders SET status=$1 WHERE id=$2', ['refunded', orderId]);
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    if (w.rows[0]) {
      const balances = w.rows[0].balances;
      balances[order.currency] = Number(balances[order.currency] || 0) - refundAmount;
      await client.query('UPDATE wallets SET balances=$1 WHERE user_id=$2', [balances, order.user_id]);
    }
    await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['refund', order.user_id, null, refundAmount, order.currency, 'completed']);
    await postLedger(client, { debit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, credit: { ownerType: 'user_wallet', ownerId: order.user_id }, amount: refundAmount, currency: order.currency, referenceType: 'refund', referenceId: rr.rows[0].id, description: 'Payment refund from wallet' });
    await auditLog(client, { adminId: req.auth.id, action: 'payment.refund', entityType: 'payment_order', entityId: orderId, metadata: { refundId: rr.rows[0].id, amount: refundAmount, currency: order.currency }, req });
    await client.query('COMMIT');
    res.json({ refund: rr.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});


app.post('/api/exchange/orders/:id/lock-escrow', auth('user'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 AND user_id=$2 FOR UPDATE', [req.params.id, req.auth.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status === 'locked') throw new Error('Escrow already locked');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [req.auth.id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {};
    if (Number(balances[order.from_currency] || 0) < Number(order.amount)) throw new Error('Insufficient balance for escrow');
    balances[order.from_currency] = Number(balances[order.from_currency] || 0) - Number(order.amount);
    locked[order.from_currency] = Number(locked[order.from_currency] || 0) + Number(order.amount);
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, req.auth.id]);
    const updated = await client.query("UPDATE exchange_orders SET status='escrow_locked', escrow_status='locked' WHERE id=$1 RETURNING *", [order.id]);
    await postLedger(client, { debit: { ownerType: 'exchange_escrow', ownerId: order.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Exchange amount locked in escrow' });
    await client.query('COMMIT');
    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.post('/api/admin/exchange/orders/:id/complete', auth('admin'), requirePermission('exchange:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    const { rate, receiveAmount } = req.body;
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.escrow_status !== 'locked') throw new Error('Escrow must be locked before completion');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    const wallet = w.rows[0], balances = wallet.balances, locked = wallet.locked || {};
    let finalReceive = Number(receiveAmount || (Number(order.amount) * Number(rate || 1)));
    locked[order.from_currency] = Math.max(0, Number(locked[order.from_currency] || 0) - Number(order.amount));

    // Crypto (VDA) TDS under Section 194S: applies when the user is
    // disposing of a VDA (selling/converting AWAY FROM crypto). See
    // limits.js and TECHNICAL_SAFEGUARDS_GUIDE.md.
    let tdsAmountInr = 0;
    if (VDA_CURRENCIES.includes(order.from_currency)) {
      const tdsInfo = await applyCryptoTds(client, order.user_id, {
        grossAmount: order.amount, grossCurrency: order.from_currency,
        creditCurrency: order.to_currency, creditAmount: finalReceive,
        referenceType: 'exchange_order', referenceId: order.id,
      });
      tdsAmountInr = tdsInfo.tdsAmountInr;
      finalReceive = tdsInfo.netCreditAmount;
    }

    balances[order.to_currency] = Number(balances[order.to_currency] || 0) + finalReceive;
    await client.query('UPDATE wallets SET balances=$1, locked=$2 WHERE user_id=$3', [balances, locked, order.user_id]);
    const updated = await client.query("UPDATE exchange_orders SET status='completed', escrow_status='released' WHERE id=$1 RETURNING *", [order.id]);
    await client.query('INSERT INTO transactions(type,from_user_id,to_user_id,amount,currency,status) VALUES($1,$2,$3,$4,$5,$6)', ['exchange_complete', order.user_id, order.user_id, finalReceive, order.to_currency, 'completed']);
    await postLedger(client, { debit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow source currency released to exchange pool' });
    await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: order.user_id }, credit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, amount: finalReceive, currency: order.to_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Converted currency credited to user wallet (net of TDS if applicable)' });
    await auditLog(client, { adminId: req.auth.id, action: 'exchange.complete', entityType: 'exchange_order', entityId: order.id, metadata: { rate, receiveAmount: finalReceive, tdsDeductedInr: tdsAmountInr }, req });
    await checkAmlAndBalanceCap(client, order.user_id, { amountInr: toApproxInr(order.amount, order.from_currency), referenceType: 'exchange_order', referenceId: order.id, note: 'currency/crypto exchange completed' });

    // Travel Rule data capture — self-conversion within the platform, still
    // recorded for a complete VDA transfer audit trail. See travel_rule.js.
    if (VDA_CURRENCIES.includes(order.from_currency) || VDA_CURRENCIES.includes(order.to_currency)) {
      const orderUserRow = await client.query('SELECT id, name FROM users WHERE id=$1', [order.user_id]);
      const orderUserKyc = await client.query('SELECT national_id FROM kyc_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1', [order.user_id]);
      const trCurrency = VDA_CURRENCIES.includes(order.from_currency) ? order.from_currency : order.to_currency;
      const trAmount = VDA_CURRENCIES.includes(order.from_currency) ? order.amount : finalReceive;
      const tr = buildTravelRuleRecord({
        originatorUser: orderUserRow.rows[0], beneficiaryUser: orderUserRow.rows[0],
        currency: trCurrency, amount: trAmount,
        referenceType: 'exchange_order', referenceId: order.id,
        originatorNationalId: orderUserKyc.rows[0]?.national_id, beneficiaryNationalId: orderUserKyc.rows[0]?.national_id,
      });
      await client.query(
        'INSERT INTO travel_rule_records(currency,amount,reference_type,reference_id,originator,beneficiary,captured_at) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [tr.currency, tr.amount, tr.referenceType, tr.referenceId, JSON.stringify(tr.originator), JSON.stringify(tr.beneficiary), tr.capturedAt]
      );
    }

    await maybePayReferralReward(client, order.user_id);
    await client.query('COMMIT');

    const u = await pool.query('SELECT email FROM users WHERE id=$1', [order.user_id]);
    await notifyUser(pool, {
      userId: order.user_id,
      userEmail: u.rows[0]?.email,
      type: 'exchange_completed',
      title: 'Exchange Order Completed',
      message: `Aapka ${order.from_currency} to ${order.to_currency} exchange complete ho gaya hai. Aapko ${order.to_currency} ${finalReceive} mila hai.`,
      metadata: { orderId: order.id, receiveAmount: finalReceive, toCurrency: order.to_currency },
    });

    res.json({ order: { ...updated.rows[0], tdsDeductedInr: tdsAmountInr } });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});


app.post('/api/admin/exchange/orders/:id/cancel', auth('admin'), requirePermission('exchange:manage'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query('SELECT * FROM exchange_orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = o.rows[0];
    if (!order) throw new Error('Exchange order not found');
    if (order.status === 'cancelled') throw new Error('Order already cancelled');
    if (order.status === 'completed') throw new Error('Cannot cancel a completed order');
    const w = await client.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [order.user_id]);
    const wallet = w.rows[0];
    const balances = wallet.balances, locked = wallet.locked || {}, rewardBalances = wallet.reward_balances || {};

    if (order.escrow_status === 'locked') {
      locked[order.from_currency] = Math.max(0, Number(locked[order.from_currency] || 0) - Number(order.amount));
      balances[order.from_currency] = Number(balances[order.from_currency] || 0) + Number(order.amount);
      await postLedger(client, { debit: { ownerType: 'user_wallet', ownerId: order.user_id }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow returned to user after cancellation' });
    }

    // Reverse the 0.2% reward that was credited when the order was created,
    // so cancelled orders never leave a stray reward with the user.
    // Priority 1: take it back from the reward wallet (normal case).
    // Priority 2: if the user already redeemed it into the main wallet, claw back
    //             whatever is left there too (never push balance below zero).
    // Anything that still can't be recovered is logged for manual admin review.
    const sellerCommission = Number(order.seller_commission || 0);
    if (sellerCommission > 0) {
      let remaining = sellerCommission;

      const currentReward = Number(rewardBalances[order.from_currency] || 0);
      const fromReward = Math.min(currentReward, remaining);
      if (fromReward > 0) {
        rewardBalances[order.from_currency] = currentReward - fromReward;
        remaining -= fromReward;
        await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: order.user_id }, credit: { ownerType: 'user_reward_wallet', ownerId: order.user_id }, amount: fromReward, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% reward reversed due to order cancellation' });
      }

      if (remaining > 0) {
        const currentMainBalance = Number(balances[order.from_currency] || 0);
        const fromMainWallet = Math.min(currentMainBalance, remaining);
        if (fromMainWallet > 0) {
          balances[order.from_currency] = currentMainBalance - fromMainWallet;
          remaining -= fromMainWallet;
          await postLedger(client, { debit: { ownerType: 'seller_commission_earning', ownerId: order.user_id }, credit: { ownerType: 'user_wallet', ownerId: order.user_id }, amount: fromMainWallet, currency: order.from_currency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% already-redeemed reward clawed back from main wallet due to order cancellation' });
        }
      }

      if (remaining > 0) {
        await auditLog(client, { adminId: req.auth.id, action: 'exchange.cancel.reward_reversal_incomplete', entityType: 'exchange_order', entityId: order.id, metadata: { currency: order.from_currency, unrecovered: remaining }, req });
      }
    }

    await client.query('UPDATE wallets SET balances=$1, locked=$2, reward_balances=$3 WHERE user_id=$4', [balances, locked, rewardBalances, order.user_id]);

    const updated = await client.query("UPDATE exchange_orders SET status='cancelled', escrow_status='cancelled' WHERE id=$1 RETURNING *", [order.id]);
    await auditLog(client, { adminId: req.auth.id, action: 'exchange.cancel', entityType: 'exchange_order', entityId: order.id, req });
    await client.query('COMMIT');

    const u = await pool.query('SELECT email FROM users WHERE id=$1', [order.user_id]);
    await notifyUser(pool, {
      userId: order.user_id,
      userEmail: u.rows[0]?.email,
      type: 'exchange_cancelled',
      title: 'Exchange Order Cancelled',
      message: `Aapka ${order.from_currency} to ${order.to_currency} exchange order cancel kar diya gaya hai. Locked amount aapke wallet mein wapas kar diya gaya hai.`,
      metadata: { orderId: order.id },
    });

    res.json({ order: updated.rows[0] });
  } catch (e) { await client.query('ROLLBACK'); res.status(400).json({ error: e.message }); }
  finally { client.release(); }
});

app.get('/api/admin/exchange/orders', auth('admin'), requirePermission('exchange:manage'), async (_, res) => {
  const r = await pool.query(`SELECT e.*, row_to_json(u.*) AS user FROM exchange_orders e LEFT JOIN users u ON u.id=e.user_id ORDER BY e.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});


app.get('/api/admin/admins', auth('admin'), requirePermission('admin:manage'), async (_, res) => {
  const r = await pool.query('SELECT id,email,role,permissions,created_at FROM admins ORDER BY created_at DESC');
  res.json(r.rows);
});

app.patch('/api/admin/admins/:id/role', auth('admin'), requirePermission('admin:manage'), async (req, res) => {
  const { role, permissions } = req.body;
  const r = await pool.query('UPDATE admins SET role=COALESCE($1,role), permissions=COALESCE($2,permissions) WHERE id=$3 RETURNING id,email,role,permissions,created_at', [role || null, permissions ? JSON.stringify(permissions) : null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Admin not found' });
  await auditLog(pool, { adminId: req.auth.id, action: 'admin.role_update', entityType: 'admin', entityId: req.params.id, metadata: { role: r.rows[0].role, permissions: r.rows[0].permissions }, req });
  res.json({ admin: r.rows[0] });
});

app.get('/api/admin/audit-logs', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500');
  res.json(r.rows);
});

// AML flags: a filtered view of audit logs specifically for large/unusual
// transactions that crossed the AML review thresholds in limits.js. See
// TECHNICAL_SAFEGUARDS_GUIDE.md for the rationale and how to tune
// thresholds via environment variables.
app.get('/api/admin/aml-flags', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query(
    `SELECT a.*, u.id AS u_id, u.name AS u_name, u.email AS u_email
     FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
     WHERE a.action = 'aml.flag.large_transaction'
     ORDER BY a.created_at DESC LIMIT 500`
  );
  res.json(r.rows.map(row => ({
    id: row.id, adminId: row.admin_id, userId: row.user_id, action: row.action,
    entityType: row.entity_type, entityId: row.entity_id, metadata: row.metadata, createdAt: row.created_at,
    user: row.u_id ? { id: row.u_id, name: row.u_name, email: row.u_email } : null,
  })));
});

// Crypto TDS (Section 194S) records: per-user, per-financial-year cumulative
// gross VDA-transfer value and TDS withheld, plus the individual deduction
// entries — this is what your CA needs to prepare Form 26QE filings.
app.get('/api/admin/tds-records', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query(
    `SELECT t.*, u.name AS u_name, u.email AS u_email
     FROM tds_records t LEFT JOIN users u ON u.id = t.user_id
     ORDER BY t.updated_at DESC`
  );
  res.json(r.rows.map(row => ({
    id: row.id, userId: row.user_id, financialYear: row.financial_year,
    cumulativeGrossInr: row.cumulative_gross_inr, cumulativeTdsInr: row.cumulative_tds_inr,
    entries: row.entries, createdAt: row.created_at, updatedAt: row.updated_at,
    user: { id: row.user_id, name: row.u_name, email: row.u_email },
  })));
});

// Sanctions/PEP screening flags — see server.js's equivalent handler and
// screening.js for full rationale. Never auto-rejected; requires manual
// admin review.
app.get('/api/admin/sanctions-flags', auth('admin'), requirePermission('kyc:manage'), async (_, res) => {
  const r = await pool.query(
    `SELECT k.id AS kyc_request_id, k.user_id, k.status AS kyc_status, k.sanctions_screening,
            u.name AS u_name, u.email AS u_email
     FROM kyc_requests k LEFT JOIN users u ON u.id = k.user_id
     WHERE k.sanctions_screening->>'flagged' = 'true'
     ORDER BY (k.sanctions_screening->>'screenedAt') DESC`
  );
  const flags = r.rows.map(row => ({
    kycRequestId: row.kyc_request_id,
    userId: row.user_id,
    user: { id: row.user_id, name: row.u_name, email: row.u_email },
    kycStatus: row.kyc_status,
    matches: row.sanctions_screening.matches,
    screenedAt: row.sanctions_screening.screenedAt,
    reviewStatus: row.sanctions_screening.reviewStatus || 'pending_review',
    reviewNote: row.sanctions_screening.reviewNote || null,
  }));
  res.json({ metadata: getSanctionsListMetadata(), flags });
});

app.patch('/api/admin/sanctions-flags/:kycRequestId', auth('admin'), requirePermission('kyc:manage'), async (req, res) => {
  const { reviewStatus, reviewNote } = req.body;
  if (!['confirmed_match', 'false_positive'].includes(reviewStatus)) return res.status(400).json({ error: "reviewStatus must be 'confirmed_match' or 'false_positive'" });
  const existing = await pool.query('SELECT sanctions_screening, user_id FROM kyc_requests WHERE id=$1', [req.params.kycRequestId]);
  if (!existing.rows[0]?.sanctions_screening) return res.status(404).json({ error: 'Sanctions-flagged KYC request not found' });
  const updated = {
    ...existing.rows[0].sanctions_screening,
    reviewStatus, reviewNote: reviewNote || null, reviewedBy: req.auth.id, reviewedAt: new Date().toISOString(),
  };
  await pool.query('UPDATE kyc_requests SET sanctions_screening=$1 WHERE id=$2', [JSON.stringify(updated), req.params.kycRequestId]);
  await auditLog(pool, { adminId: req.auth.id, action: 'sanctions.screening.reviewed', entityType: 'kyc_request', entityId: req.params.kycRequestId, metadata: { reviewStatus, userId: existing.rows[0].user_id }, req });
  res.json({ kyc: { id: req.params.kycRequestId, sanctionsScreening: updated } });
});

// Manually triggers a full re-sync of the sanctions dataset from the
// official OFAC + UN sources — see server.js's equivalent handler and
// sanctions_sync.js for full rationale. Exists so an admin without server
// shell access (Render free tier / phone-only operation) can refresh the
// list from the admin panel.
const sanctionsSyncLimiter = rateLimit({ windowMs: 60 * 60_000, max: 6, keyFn: (req) => `sanctions-sync:${req.auth?.id || req.ip}`, message: 'Sanctions list sync can only be run a few times per hour. Please wait before trying again.' });
app.post('/api/admin/sanctions-sync', auth('admin'), requirePermission('kyc:manage'), sanctionsSyncLimiter, async (req, res) => {
  try {
    const summary = await syncSanctionsList({ writeToFile: true });
    await auditLog(pool, { adminId: req.auth.id, action: 'sanctions.list.synced', entityType: 'sanctions_list', entityId: 'global', metadata: { entryCount: summary.entryCount, sources: summary.sources, errors: summary.errors }, req });
    if (summary.entryCount === 0) {
      return res.status(502).json({ error: 'Sync failed for all sources — the sanctions list was NOT changed. Try again later.', summary });
    }
    res.json({ message: `Sanctions list synced: ${summary.entryCount} entries from ${summary.sources.filter(s => s.status !== 'failed').length} source(s).`, summary });
  } catch (e) {
    res.status(500).json({ error: 'Sync failed unexpectedly: ' + e.message });
  }
});

app.get('/api/admin/sanctions-list-metadata', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  res.json(getSanctionsListMetadata());
});

// Cron-friendly sanctions sync trigger — see server.js's equivalent
// handler for full rationale (separate single-purpose secret so an
// external scheduler doesn't need real admin credentials).
app.post('/api/cron/sanctions-sync', sanctionsSyncLimiter, async (req, res) => {
  const configuredSecret = process.env.SANCTIONS_CRON_SECRET;
  if (!configuredSecret) return res.status(404).json({ error: 'Not found' });
  const providedSecret = req.headers['x-cron-secret'] || req.body?.secret;
  if (!providedSecret || providedSecret !== configuredSecret) return res.status(403).json({ error: 'Invalid or missing cron secret' });
  try {
    const summary = await syncSanctionsList({ writeToFile: true });
    await auditLog(pool, { adminId: null, action: 'sanctions.list.synced', entityType: 'sanctions_list', entityId: 'global', metadata: { entryCount: summary.entryCount, sources: summary.sources, errors: summary.errors, trigger: 'cron' } });
    if (summary.entryCount === 0) {
      return res.status(502).json({ error: 'Sync failed for all sources.', summary });
    }
    res.json({ message: `Sanctions list synced via cron: ${summary.entryCount} entries.`, summary });
  } catch (e) {
    res.status(500).json({ error: 'Sync failed unexpectedly: ' + e.message });
  }
});

// ---------------------------------------------------------------------------
// Cron-friendly Scheduled-Payments executor — same rationale as the
// sanctions-sync cron endpoint above: lets an external scheduler run ALL
// users' due mandates even if those users haven't opened the app recently
// (the opportunistic per-user execution in GET /api/me only covers users
// who are actively using the app). Protected by CRON_SECRET.
// ---------------------------------------------------------------------------
app.post('/api/cron/run-scheduled-payments', async (req, res) => {
  const configuredSecret = process.env.CRON_SECRET;
  if (!configuredSecret) return res.status(404).json({ error: 'Not found' });
  const providedSecret = req.headers['x-cron-secret'] || req.body?.secret;
  if (!providedSecret || providedSecret !== configuredSecret) return res.status(403).json({ error: 'Invalid or missing cron secret' });
  try {
    const due = await pool.query("SELECT DISTINCT user_id FROM scheduled_payments WHERE status='active' AND next_run_at <= NOW()");
    for (const row of due.rows) await runDueScheduledPaymentsPg(row.user_id);
    res.json({ message: `Processed due scheduled payments for ${due.rowCount} user(s).`, userCount: due.rowCount });
  } catch (e) {
    res.status(500).json({ error: 'Scheduled payment run failed unexpectedly: ' + e.message });
  }
});

// Travel Rule records — see travel_rule.js for full rationale.
app.get('/api/admin/travel-rule-records', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query('SELECT * FROM travel_rule_records ORDER BY captured_at DESC LIMIT 500');
  res.json(r.rows.map(row => ({
    id: row.id, currency: row.currency, amount: row.amount,
    referenceType: row.reference_type, referenceId: row.reference_id,
    originator: row.originator, beneficiary: row.beneficiary, capturedAt: row.captured_at,
  })));
});

// Admin visibility into all users' scheduled-payment mandates — mainly
// useful for spotting mandates stuck auto-paused after repeated failures
// (a support/fraud signal worth a human look).
app.get('/api/admin/scheduled-payments', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query(`
    SELECT sp.*, u.email AS user_email, ru.email AS receiver_email
    FROM scheduled_payments sp
    LEFT JOIN users u ON u.id = sp.user_id
    LEFT JOIN users ru ON ru.id = sp.receiver_user_id
    ORDER BY sp.created_at DESC
  `);
  res.json(r.rows);
});

// ---------------------------------------------------------------------------
// Suspicious Transaction Report (STR) workflow — see server.js's equivalent
// handlers for full rationale. Filing with FIU-IND itself remains a manual,
// out-of-band process; this just tracks the case lifecycle.
// ---------------------------------------------------------------------------
app.post('/api/admin/str-reports', auth('admin'), requirePermission('audit:read'), async (req, res) => {
  const { userId, reason, sourceType, sourceId, notes = '' } = req.body;
  if (!userId || !reason) return res.status(400).json({ error: 'userId and reason are required' });
  const userRow = await pool.query('SELECT id, name, email, kyc_status FROM users WHERE id=$1', [userId]);
  if (!userRow.rows[0]) return res.status(404).json({ error: 'User not found' });
  const r = await pool.query(
    `INSERT INTO str_reports(user_id, user_snapshot, reason, source_type, source_id, notes, status, created_by)
     VALUES($1,$2,$3,$4,$5,$6,'draft',$7) RETURNING *`,
    [userId, JSON.stringify(userRow.rows[0]), reason, sourceType || null, sourceId || null, notes, req.auth.id]
  );
  await auditLog(pool, { adminId: req.auth.id, action: 'str.created', entityType: 'str_report', entityId: r.rows[0].id, metadata: { userId, reason, sourceType, sourceId }, req });
  res.json({ str: r.rows[0] });
});

app.get('/api/admin/str-reports', auth('admin'), requirePermission('audit:read'), async (_, res) => {
  const r = await pool.query('SELECT * FROM str_reports ORDER BY created_at DESC');
  res.json(r.rows);
});

app.patch('/api/admin/str-reports/:id', auth('admin'), requirePermission('audit:read'), async (req, res) => {
  const { status, notes } = req.body;
  if (!['draft', 'filed', 'acknowledged', 'closed'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const existing = await pool.query('SELECT * FROM str_reports WHERE id=$1', [req.params.id]);
  if (!existing.rows[0]) return res.status(404).json({ error: 'STR report not found' });
  const filedAt = status === 'filed' && !existing.rows[0].filed_at ? new Date().toISOString() : existing.rows[0].filed_at;
  const r = await pool.query(
    'UPDATE str_reports SET status=$1, notes=COALESCE($2,notes), filed_at=$3, updated_at=NOW() WHERE id=$4 RETURNING *',
    [status, notes, filedAt, req.params.id]
  );
  await auditLog(pool, { adminId: req.auth.id, action: 'str.status_updated', entityType: 'str_report', entityId: req.params.id, metadata: { status }, req });
  res.json({ str: r.rows[0] });
});

app.get('/api/admin/roles', auth('admin'), requirePermission('admin:manage','disputes:manage'), async (_, res) => {
  res.json({ roles: [
    { role: 'super_admin', permissions: ['*'] },
    { role: 'kyc_manager', permissions: ['users:read','kyc:manage','audit:read'] },
    { role: 'finance_manager', permissions: ['payments:read','refunds:manage','ledger:read','exchange:manage','audit:read'] },
    { role: 'support_agent', permissions: ['users:read','payments:read','disputes:manage','audit:read'] }
  ]});
});

app.get('/api/admin/dashboard', auth('admin'), async (_, res) => {
  const q = async sql => Number((await pool.query(sql)).rows[0].count || 0);
  const commission = await pool.query('SELECT COALESCE(SUM(admin_commission),0) AS total FROM commissions');

  // "Today" figures give the admin a quick pulse-check without needing to
  // open the full analytics page.
  const todayCommission = await pool.query("SELECT COALESCE(SUM(admin_commission),0) AS total FROM commissions WHERE created_at::date = CURRENT_DATE");
  const todayUsers = await q("SELECT COUNT(*) FROM users WHERE created_at::date = CURRENT_DATE");
  const todayTransactions = await q("SELECT COUNT(*) FROM transactions WHERE created_at::date = CURRENT_DATE");
  const todayPaymentVolume = await pool.query("SELECT COALESCE(SUM(amount),0) AS total FROM payment_orders WHERE status='paid' AND created_at::date = CURRENT_DATE");
  const pendingKyc = await q("SELECT COUNT(*) FROM kyc_requests WHERE status <> 'approved'");
  const openComplaints = await q("SELECT COUNT(*) FROM complaints WHERE status NOT IN ('resolved','rejected')");
  const openDisputes = await q("SELECT COUNT(*) FROM disputes WHERE status NOT IN ('resolved','rejected')");

  res.json({
    users: await q('SELECT COUNT(*) FROM users'),
    kycPending: pendingKyc,
    transactions: await q('SELECT COUNT(*) FROM transactions'),
    complaints: await q('SELECT COUNT(*) FROM complaints'),
    exchangeOrders: await q('SELECT COUNT(*) FROM exchange_orders'),
    adminCommission: Number(commission.rows[0].total),
    today: {
      newUsers: todayUsers,
      transactions: todayTransactions,
      revenue: Number(todayCommission.rows[0].total),
      paymentVolume: Number(todayPaymentVolume.rows[0].total),
    },
    openComplaints,
    openDisputes,
  });
});

// ---------------------------------------------------------------------------
// Analytics: time-series and breakdown data for the admin dashboard charts.
// Kept as a separate endpoint from /api/admin/dashboard (which stays fast/
// lightweight for the top summary cards) since this does more aggregation
// work and isn't needed on every dashboard page load.
// ---------------------------------------------------------------------------
app.get('/api/admin/analytics', auth('admin'), async (req, res) => {
  const days = Math.min(parseInt(req.query.days) || 30, 90);

  // Daily revenue (admin commission) for the last N days — the core "is the
  // business growing" chart.
  const revenueByDay = await pool.query(
    `SELECT date_trunc('day', created_at)::date AS day, COALESCE(SUM(admin_commission),0) AS revenue, COALESCE(SUM(seller_commission),0) AS user_rewards
     FROM commissions
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY day ORDER BY day ASC`,
    [days]
  );

  // Daily new user signups — growth chart.
  const usersByDay = await pool.query(
    `SELECT created_at::date AS day, COUNT(*) AS count
     FROM users
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY day ORDER BY day ASC`,
    [days]
  );

  // Daily transaction volume (count + total amount by currency is too
  // granular for a simple chart, so this is count-only; currency breakdown
  // is provided separately below).
  const transactionsByDay = await pool.query(
    `SELECT created_at::date AS day, COUNT(*) AS count
     FROM transactions
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY day ORDER BY day ASC`,
    [days]
  );

  // Exchange volume by currency pair — which conversions are most popular.
  const exchangeByCurrency = await pool.query(
    `SELECT from_currency, to_currency, COUNT(*) AS order_count, COALESCE(SUM(amount),0) AS total_amount
     FROM exchange_orders
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY from_currency, to_currency
     ORDER BY order_count DESC LIMIT 10`,
    [days]
  );

  // Payment success/failure breakdown — helps spot a broken payment
  // integration quickly instead of just seeing "revenue is low".
  const paymentStatusBreakdown = await pool.query(
    `SELECT status, COUNT(*) AS count, COALESCE(SUM(amount),0) AS total_amount
     FROM payment_orders
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY status`,
    [days]
  );

  // Exchange order status breakdown (pending/completed/cancelled).
  const exchangeStatusBreakdown = await pool.query(
    `SELECT status, COUNT(*) AS count
     FROM exchange_orders
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY status`,
    [days]
  );

  // KYC funnel — how many are pending/approved/rejected right now (not time-
  // windowed, since KYC status is a current-state snapshot, not an event log).
  const kycBreakdown = await pool.query(`SELECT status, COUNT(*) AS count FROM kyc_requests GROUP BY status`);

  res.json({
    periodDays: days,
    revenueByDay: revenueByDay.rows,
    usersByDay: usersByDay.rows,
    transactionsByDay: transactionsByDay.rows,
    exchangeByCurrency: exchangeByCurrency.rows,
    paymentStatusBreakdown: paymentStatusBreakdown.rows,
    exchangeStatusBreakdown: exchangeStatusBreakdown.rows,
    kycBreakdown: kycBreakdown.rows,
  });
});

app.get('/api/admin/kyc-requests', auth('admin'), requirePermission('kyc:manage'), async (_, res) => {
  // Exclude the heavy `documents` column from the list view (it can contain multiple
  // base64-encoded files) — admin fetches those individually via the endpoint below.
  const r = await pool.query(`
    SELECT k.id, k.user_id, k.national_id, k.tax_id, k.country, k.document_names, k.status, k.created_at,
           row_to_json(u.*) AS user
    FROM kyc_requests k LEFT JOIN users u ON u.id=k.user_id
    ORDER BY k.created_at DESC
  `);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

// Admin-only: fetch the actual uploaded documents (base64) for one KYC request,
// so they can be viewed/downloaded for verification.
app.get('/api/admin/kyc-requests/:id/documents', auth('admin'), requirePermission('kyc:manage'), async (req, res) => {
  const r = await pool.query('SELECT documents FROM kyc_requests WHERE id=$1', [req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'KYC request not found' });
  await auditLog(pool, { adminId: req.auth.id, action: 'kyc.documents_viewed', entityType: 'kyc_request', entityId: req.params.id, req });
  res.json({ documents: r.rows[0].documents || [] });
});

app.get('/api/admin/refunds', auth('admin'), async (_, res) => {
  const r = await pool.query('SELECT * FROM refunds ORDER BY created_at DESC');
  res.json(r.rows);
});

app.get('/api/admin/payment-orders', auth('admin'), requirePermission('payments:read'), async (_, res) => {
  const r = await pool.query(`SELECT p.*, row_to_json(u.*) AS user FROM payment_orders p LEFT JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC`);
  res.json(r.rows.map(row => ({ ...row, user: safeUser(row.user) })));
});

app.get('/api/admin/ledger', auth('admin'), requirePermission('ledger:read'), async (_, res) => {
  const accounts = await pool.query('SELECT * FROM ledger_accounts ORDER BY created_at DESC');
  const entries = await pool.query('SELECT * FROM ledger_entries ORDER BY created_at DESC LIMIT 500');
  res.json({ accounts: accounts.rows, entries: entries.rows });
});

app.get('/api/admin/users', auth('admin'), async (_, res) => { const r = await pool.query('SELECT * FROM users ORDER BY created_at DESC'); res.json(r.rows.map(safeUser)); });

app.patch('/api/admin/complaints/:id', auth('admin'), async (req, res) => {
  const { status } = req.body;
  const r = await pool.query('UPDATE complaints SET status=COALESCE($1,status) WHERE id=$2 RETURNING *', [status || null, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Complaint not found' });
  await auditLog(pool, { adminId: req.auth.id, action: `complaint.${r.rows[0].status}`, entityType: 'complaint', entityId: r.rows[0].id, metadata: { userId: r.rows[0].user_id, status: r.rows[0].status }, req });
  res.json({ complaint: r.rows[0] });
});

app.get('/api/admin/complaints', auth('admin'), async (_, res) => { const r = await pool.query('SELECT * FROM complaints ORDER BY created_at DESC'); res.json(r.rows.map(row => ({ ...row, hasUnread: complaintHasUnread(row, 'admin') }))); });

app.get('/api/admin/referrals', auth('admin'), async (_, res) => {
  const r = await pool.query(`
    SELECT rf.*, row_to_json(ru.*) AS referrer, row_to_json(du.*) AS referred
    FROM referrals rf
    LEFT JOIN users ru ON ru.id = rf.referrer_user_id
    LEFT JOIN users du ON du.id = rf.referred_user_id
    ORDER BY rf.created_at DESC
  `);
  res.json(r.rows.map(row => ({ ...row, referrer: safeUser(row.referrer), referred: safeUser(row.referred) })));
});
app.patch('/api/admin/kyc/:id', auth('admin'), requirePermission('kyc:manage'), async (req, res) => {
  const { status } = req.body;
  const r = await pool.query('UPDATE kyc_requests SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'KYC not found' });
  await pool.query('UPDATE users SET kyc_status=$1 WHERE id=$2', [status, r.rows[0].user_id]);

  const u = await pool.query('SELECT email FROM users WHERE id=$1', [r.rows[0].user_id]);
  const isApproved = status === 'approved';
  await notifyUser(pool, {
    userId: r.rows[0].user_id,
    userEmail: u.rows[0]?.email,
    type: isApproved ? 'kyc_approved' : 'kyc_rejected',
    title: isApproved ? 'KYC Verified Successfully' : 'KYC Verification Update',
    message: isApproved
      ? 'Aapka KYC verify ho gaya hai. Ab aap bina limit ke transactions kar sakte hain.'
      : 'Aapka KYC document verify nahi ho paya. Kripya sahi/clear documents ke saath dobara submit karein.',
    metadata: { kycRequestId: r.rows[0].id, status },
  });

  res.json({ kyc: r.rows[0] });
});

// ---------------------------------------------------------------------------
// Global error-handling middleware. Must be registered LAST (after all
// routes) — Express recognizes it as an error handler purely because it
// takes 4 arguments (err, req, res, next). Every error forwarded by the
// wrapAsyncHandler() wrapper above (or thrown synchronously in any
// middleware) lands here instead of crashing the process. Malformed input
// (e.g. bad UUID, bad JSON shape) is treated as a 400; anything else is
// logged server-side and returned as a generic 500 (never leaking internal
// error details/stack traces to the client, which would be a security risk).
// ---------------------------------------------------------------------------
app.use((err, req, res, next) => {
  console.error('[unhandled route error]', req.method, req.path, err);
  if (res.headersSent) return next(err);
  // Postgres "invalid input syntax" (code 22P02, e.g. malformed UUID in a
  // route param) and similar client-caused data errors are surfaced as 400
  // rather than 500, since they're the client's fault, not a server bug.
  const isClientDataError = err && (err.code === '22P02' || err.code === '23505' || err.code === '23503');
  res.status(isClientDataError ? 400 : 500).json({
    error: isClientDataError ? 'Invalid request data.' : 'Something went wrong on our end. Please try again.',
  });
});

// Belt-and-braces: even with every route wrapped above, catch any remaining
// uncaught exception/unhandled rejection (e.g. from a background timer, a
// library callback outside the request lifecycle, etc.) and log it loudly
// instead of silently letting the process die, so Render's crash-loop
// detection and logs make the root cause visible rather than a mysterious
// restart.
process.on('uncaughtException', (err) => {
  console.error('[FATAL] Uncaught exception (process will continue running):', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[FATAL] Unhandled promise rejection (process will continue running):', reason);
});

autoMigrate()
  .then(() => ensureAdmin())
  .then(() => app.listen(PORT, () => {
    console.log(`Global Exchanger PostgreSQL API running on http://localhost:${PORT}`);
    // Fire-and-forget: does not block startup. See sanctions_sync.js's
    // maybeAutoSyncIfStale() doc comment for why this matters on Render's
    // free tier (no reliable long-running background timers between sleeps).
    maybeAutoSyncIfStale();
  }))
  .catch(e => { console.error(e); process.exit(1); });
