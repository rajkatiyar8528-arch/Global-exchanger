require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const fs = require('fs');
const path = require('path');
const { getPaymentProvider } = require('./payments/provider');
const { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail } = require('./otp');
const { notifyUserJson } = require('./notifications_json');
const { generateReceiptToken, renderTransactionReceiptJson, renderExchangeReceiptJson, wrapReceiptPage } = require('./receipts_json');
const { rateLimit, ipAndFieldKey, securityHeaders, isStrongPassword, buildCorsOptions } = require('./security');
const { signAccessToken, issueNewRefreshTokenFamilyJson, rotateRefreshTokenJson, revokeRefreshTokenJson, revokeAllForOwnerJson } = require('./auth_tokens_json');
const { VDA_CURRENCIES, tierFor, AML_SINGLE_TXN_THRESHOLD_INR, AML_DAILY_AGGREGATE_THRESHOLD_INR, toApproxInr, currentFinancialYear, computeCryptoTds } = require('./limits');
const { screenKycSubmission, getSanctionsListMetadata } = require('./screening');
const { captureTravelRuleData, VDA_TRANSFER_THRESHOLD_INR_FOR_TRAVEL_RULE } = require('./travel_rule');
const { syncSanctionsList, maybeAutoSyncIfStale } = require('./sanctions_sync');
const { SUPPORTED_PAIRS, isSupportedPair, flattenRates, findTriggeredAlerts, formatPairLabel } = require('./price_alerts');
const { generateStatementToken, renderStatementHtml, wrapStatementPage, renderStatementCsv } = require('./statements');


const app = express();
app.set('trust proxy', true); // Render sits behind Cloudflare + its own internal proxy (multiple hops); trust all of them so req.ip reflects the real client IP for rate limiting.

// ---------------------------------------------------------------------------
// CRASH-SAFETY WRAPPER — critical production fix (mirrors server_pg.js).
// -----------------------------------------------------------------------
// Several route handlers here are `async (req, res) => {...}` without their
// own try/catch. In Express 4, an unhandled async rejection from a route
// handler crashes the entire Node process (taking the whole API down for
// every user). Monkey-patching the route-registration methods here ensures
// every handler is automatically wrapped to forward errors to Express's
// error-handling middleware instead of crashing — no changes needed to the
// existing route definitions below. See server_pg.js for the same fix and
// fuller rationale (this bug was found via direct testing there).
// ---------------------------------------------------------------------------
function wrapAsyncHandler(fn) {
  if (typeof fn !== 'function') return fn;
  // Preserve 4-argument arity for error-handling middleware — Express
  // identifies error handlers purely by their declared parameter count
  // (must be exactly 4). See server_pg.js for the fuller explanation of
  // why this matters (a 3-param wrapper would silently disable our custom
  // error handler and fall back to Express's stack-trace-leaking default).
  if (fn.length >= 4) {
    return function wrappedErrorHandler(err, req, res, next) {
      try {
        const result = fn(err, req, res, next);
        if (result && typeof result.catch === 'function') {
          result.catch((e) => next(e));
        }
      } catch (e) {
        next(e);
      }
    };
  }
  return function wrapped(req, res, next) {
    try {
      const result = fn(req, res, next);
      if (result && typeof result.catch === 'function') {
        result.catch((err) => next(err));
      }
    } catch (err) {
      next(err);
    }
  };
}
for (const method of ['get', 'post', 'patch', 'put', 'delete', 'use']) {
  const original = app[method].bind(app);
  app[method] = (...args) => original(...args.map((a) => (typeof a === 'function' ? wrapAsyncHandler(a) : a)));
}

app.use(securityHeaders);
app.use(cors(buildCorsOptions()));
app.use(express.json({ limit: '20mb', verify: (req, res, buf) => { req.rawBody = buf; } }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is not set. Refusing to start with an insecure default.');
  process.exit(1);
}
const DB_PATH = path.join(__dirname, '../data/db.json');

const loginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many login attempts. Please try again in 15 minutes.' });
const adminLoginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many admin login attempts. Please try again in 15 minutes.' });
const otpRequestLimiter = rateLimit({ windowMs: 10 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many OTP requests. Please wait before requesting again.' });
const otpVerifyLimiter = rateLimit({ windowMs: 10 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many OTP verification attempts. Please try again later.' });
const registerLimiter = rateLimit({ windowMs: 60 * 60_000, max: 10, keyFn: (req) => req.ip, message: 'Too many signup attempts from this network. Please try again later.' });
const generalApiLimiter = rateLimit({ windowMs: 60_000, max: 120, keyFn: (req) => req.ip, message: 'Too many requests. Please slow down.' });
app.use('/api', generalApiLimiter);
const DEV_OTP_IN_RESPONSE = String(process.env.ALLOW_DEV_OTP_IN_RESPONSE || '').toLowerCase() === 'true';

function readDb() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function writeDb(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}
function sign(payload) {
  return signAccessToken(JWT_SECRET, payload);
}

// Issues a fresh access token (15 min) + refresh token (30 days, rotating,
// revocable) pair — mirrors issueAuthSession() in server_pg.js.
function issueAuthSession(db, { ownerType, ownerId, payload, req }) {
  const accessToken = sign(payload);
  const { refreshToken, expiresAt } = issueNewRefreshTokenFamilyJson(db, { ownerType, ownerId, req });
  return { token: accessToken, refreshToken, refreshTokenExpiresAt: expiresAt };
}

function auth(role = 'user') {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (role !== 'any' && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.auth = decoded;
      next();
    } catch (e) {
      if (e.name === 'TokenExpiredError') return res.status(401).json({ error: 'Access token expired', code: 'TOKEN_EXPIRED' });
      return res.status(401).json({ error: 'Invalid token' });
    }
  };
}
function publicUser(user) {
  const { passwordHash, securityPinHash, ...safe } = user;
  return safe;
}


function auditLog(db, { adminId = null, userId = null, action, entityType, entityId, metadata = {}, req = null }) {
  db.auditLogs = db.auditLogs || [];
  const log = {
    id: uuid(), adminId, userId, action, entityType, entityId,
    metadata,
    ip: req?.ip || null,
    userAgent: req?.headers?.['user-agent'] || null,
    createdAt: new Date().toISOString()
  };
  db.auditLogs.push(log);
  return log;
}

function requirePermission(permission) {
  return (req, res, next) => {
    const db = readDb();
    const admin = db.admins.find(a => a.id === req.auth.id);
    if (!admin) return res.status(403).json({ error: 'Admin not found' });
    const permissions = admin.permissions || [];
    if (!permissions.includes(permission) && admin.role !== 'super_admin') return res.status(403).json({ error: `Missing permission: ${permission}` });
    req.admin = admin;
    next();
  };
}

function getLedgerAccount(db, ownerType, ownerId, currency) {
  db.ledgerAccounts = db.ledgerAccounts || [];
  let account = db.ledgerAccounts.find(a => a.ownerType === ownerType && a.ownerId === ownerId && a.currency === currency);
  if (!account) {
    account = { id: uuid(), ownerType, ownerId, currency, balance: 0, createdAt: new Date().toISOString() };
    db.ledgerAccounts.push(account);
  }
  return account;
}

function postLedger(db, { debit, credit, amount, currency, referenceType, referenceId, description }) {
  db.ledgerEntries = db.ledgerEntries || [];
  if (!amount || Number(amount) <= 0) throw new Error('Ledger amount must be positive');
  const debitAccount = getLedgerAccount(db, debit.ownerType, debit.ownerId, currency);
  const creditAccount = getLedgerAccount(db, credit.ownerType, credit.ownerId, currency);
  debitAccount.balance = Number(debitAccount.balance || 0) + Number(amount);
  creditAccount.balance = Number(creditAccount.balance || 0) - Number(amount);
  const groupId = uuid();
  const createdAt = new Date().toISOString();
  db.ledgerEntries.push({ id: uuid(), groupId, accountId: debitAccount.id, direction: 'debit', amount: Number(amount), currency, referenceType, referenceId, description, createdAt });
  db.ledgerEntries.push({ id: uuid(), groupId, accountId: creditAccount.id, direction: 'credit', amount: Number(amount), currency, referenceType, referenceId, description, createdAt });
  return { groupId, debitAccount, creditAccount };
}

// Referral reward: pays the referrer's ₹100 the first (and only the first)
// time their referred user completes any real transaction. See the Postgres
// version's comment (server_pg.js -> maybePayReferralReward) for the full
// rationale (fraud-resistance vs. paying at signup).
function maybePayReferralRewardJson(db, referredUserId) {
  db.referrals = db.referrals || [];
  const referral = db.referrals.find(r => r.referredUserId === referredUserId && r.status === 'pending_first_transaction');
  if (!referral) return;

  const wallet = db.wallets.find(w => w.userId === referral.referrerUserId);
  if (!wallet) return;

  const rewardAmount = Number(referral.reward || 100);
  const currency = referral.currency || 'INR';
  wallet.rewardBalances = wallet.rewardBalances || {};
  wallet.rewardBalances[currency] = Number(wallet.rewardBalances[currency] || 0) + rewardAmount;

  referral.status = 'rewarded';
  referral.rewardedAt = new Date().toISOString();

  postLedger(db, {
    debit: { ownerType: 'user_reward_wallet', ownerId: referral.referrerUserId },
    credit: { ownerType: 'referral_reward_pool', ownerId: 'referrals' },
    amount: rewardAmount,
    currency,
    referenceType: 'referral',
    referenceId: referral.id,
    description: 'Referral reward for inviting a user who completed their first transaction',
  });

  const refUser = db.users.find(u => u.id === referral.referrerUserId);
  notifyUserJson(db, {
    userId: referral.referrerUserId,
    userEmail: refUser?.email,
    type: 'referral_reward_credited',
    title: 'Referral Reward Credited!',
    message: `Aapke refer kiye hue user ne apna pehla transaction complete kar liya. ${currency} ${rewardAmount} aapke Reward Wallet mein credit ho gaya hai!`,
    metadata: { referralId: referral.id, amount: rewardAmount, currency },
    sendEmail: false,
  });
}

// ---------------------------------------------------------------------------
// Technical Safeguards: KYC-tier transaction limits, AML flagging, and
// crypto TDS. See TECHNICAL_SAFEGUARDS_GUIDE.md for full rationale.
// These are conservative, engineering-level risk controls implemented
// while formal RBI/FIU-IND licensing is pursued (see
// LEGAL_COMPLIANCE_CHECKLIST.md) — they reduce exposure but do NOT by
// themselves make the underlying activities licensed.
// ---------------------------------------------------------------------------

// Sums the INR-equivalent value of a user's own completed transactions
// (as fromUserId, i.e. money leaving them) within the current UTC day, used
// for daily aggregate limit + AML checks. amountField lets callers restrict
// to a specific set of transaction types if needed; by default all types.
function sumUserTransactionsTodayInr(db, userId, { types = null } = {}) {
  const startOfDay = new Date(); startOfDay.setUTCHours(0, 0, 0, 0);
  return (db.transactions || [])
    .filter(t => t.fromUserId === userId && t.status === 'completed' && new Date(t.createdAt) >= startOfDay && (!types || types.includes(t.type)))
    .reduce((sum, t) => sum + toApproxInr(t.amount, t.currency), 0);
}

// Sums a user's monthly P2P "send" transaction volume (calendar month, UTC)
// for the Full-KYC-tier monthly P2P cap.
function sumUserMonthlySendInr(db, userId) {
  const now = new Date();
  const startOfMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  return (db.transactions || [])
    .filter(t => t.fromUserId === userId && t.type === 'send' && t.status === 'completed' && new Date(t.createdAt) >= startOfMonth)
    .reduce((sum, t) => sum + toApproxInr(t.amount, t.currency), 0);
}

// Sums a user's monthly wallet-load (top-up) volume for the min-KYC tier's
// monthly load cap (loosely modeled on RBI's Small PPI limit).
function sumUserMonthlyTopupInr(db, userId) {
  const now = new Date();
  const startOfMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  return (db.transactions || [])
    .filter(t => t.toUserId === userId && t.type === 'wallet_topup' && t.status === 'completed' && new Date(t.createdAt) >= startOfMonth)
    .reduce((sum, t) => sum + toApproxInr(t.amount, t.currency), 0);
}

// Throws a plain Error with a user-facing message if a proposed action
// would breach the user's KYC-tier limits. Called before mutating balances.
function enforceTierLimits(db, user, { action, amount, currency }) {
  const tier = tierFor(user.kycStatus);
  const amountInr = toApproxInr(amount, currency);

  if (action === 'topup') {
    if (tier.monthlyLoadLimit != null) {
      const usedThisMonth = sumUserMonthlyTopupInr(db, user.id);
      if (usedThisMonth + amountInr > tier.monthlyLoadLimit) {
        throw new Error(`Monthly wallet top-up limit of ₹${tier.monthlyLoadLimit} reached for un-verified accounts. Please complete KYC to increase your limit.`);
      }
    }
  }

  if (action === 'send') {
    if (!tier.allowP2PSend) throw new Error('KYC verification is required before you can send money to other users.');
    if (tier.perTransactionLimit != null && amountInr > tier.perTransactionLimit) {
      throw new Error(`This amount exceeds the maximum per-transaction limit of ₹${tier.perTransactionLimit}.`);
    }
    if (tier.monthlyP2PLimit != null) {
      const usedThisMonth = sumUserMonthlySendInr(db, user.id);
      if (usedThisMonth + amountInr > tier.monthlyP2PLimit) {
        throw new Error(`Monthly send-money limit of ₹${tier.monthlyP2PLimit} reached. This limit resets next calendar month.`);
      }
    }
  }

  if (action === 'exchange') {
    if (!tier.allowExchange) throw new Error('KYC verification is required before you can use currency/crypto exchange features.');
    if (tier.perTransactionLimit != null && amountInr > tier.perTransactionLimit) {
      throw new Error(`This amount exceeds the maximum per-transaction limit of ₹${tier.perTransactionLimit}.`);
    }
  }

  if (action === 'withdrawal') {
    if (!tier.allowWithdrawal) throw new Error('KYC verification is required before you can withdraw funds.');
  }

  if (tier.dailyTransactionLimit != null && ['send', 'exchange', 'withdrawal'].includes(action)) {
    const usedToday = sumUserTransactionsTodayInr(db, user.id);
    if (usedToday + amountInr > tier.dailyTransactionLimit) {
      throw new Error(`Daily transaction limit of ₹${tier.dailyTransactionLimit} reached. Please try again tomorrow, or contact support for a limit increase.`);
    }
  }

  return { tier, amountInr };
}

// Checks a wallet-balance cap after a hypothetical credit, and flags
// (but does not block) large single transactions / daily aggregates for
// admin AML review. Call after a successful balance mutation.
function checkAmlAndBalanceCap(db, user, { amountInr, referenceType, referenceId, note }) {
  db.auditLogs = db.auditLogs || [];
  const flagged = [];

  if (amountInr >= AML_SINGLE_TXN_THRESHOLD_INR) {
    flagged.push(`single transaction of ~₹${Math.round(amountInr)} exceeds AML review threshold of ₹${AML_SINGLE_TXN_THRESHOLD_INR}`);
  }
  const dailyTotal = sumUserTransactionsTodayInr(db, user.id);
  if (dailyTotal >= AML_DAILY_AGGREGATE_THRESHOLD_INR) {
    flagged.push(`daily aggregate of ~₹${Math.round(dailyTotal)} exceeds AML review threshold of ₹${AML_DAILY_AGGREGATE_THRESHOLD_INR}`);
  }

  if (flagged.length) {
    db.auditLogs.push({
      id: uuid(),
      adminId: null,
      userId: user.id,
      action: 'aml.flag.large_transaction',
      entityType: referenceType,
      entityId: referenceId,
      metadata: { reasons: flagged, note },
      createdAt: new Date().toISOString(),
    });
  }
}

// Wallet balance cap check (Full-KYC max ₹2,00,000-equivalent, min-KYC max
// ₹10,000-equivalent, loosely modeled on RBI PPI framework) applied after a
// credit would land. Only enforced for INR-denominated cash-like balances
// (not applied to crypto holdings, which fluctuate in value and are capped
// separately via per-transaction/exchange limits instead).
function enforceWalletBalanceCap(user, wallet, currency) {
  if (VDA_CURRENCIES.includes(currency)) return;
  const tier = tierFor(user.kycStatus);
  const newBalanceInr = Object.entries(wallet.balances || {}).reduce((sum, [cur, amt]) => sum + toApproxInr(amt, cur), 0);
  if (tier.maxWalletBalance != null && newBalanceInr > tier.maxWalletBalance) {
    throw new Error(`This would take your wallet balance above the ₹${tier.maxWalletBalance} limit for your verification level. Please withdraw/spend down your balance${tier === tierFor('pending') ? ', or complete KYC to raise this limit' : ''}.`);
  }
}

// ---------------------------------------------------------------------------
// Crypto (VDA) TDS — Section 194S. Call whenever a user disposes of a VDA
// currency (i.e. sells/converts crypto INTO INR/USD/EUR or another asset).
// Tracks cumulative gross VDA-transfer value per user per Indian financial
// year in `db.tdsRecords`, and returns { tdsAmountInr, netCreditCurrency,
// netCreditAmount } so the caller can deduct TDS from what's credited to
// the user and record it as a platform TDS liability (to be deposited with
// the government via Form 26QE — see TECHNICAL_SAFEGUARDS_GUIDE.md).
// ---------------------------------------------------------------------------
function applyCryptoTds(db, user, { grossAmount, grossCurrency, creditCurrency, creditAmount, referenceType, referenceId }) {
  db.tdsRecords = db.tdsRecords || [];
  const fy = currentFinancialYear();
  const grossAmountInr = toApproxInr(grossAmount, grossCurrency);

  let record = db.tdsRecords.find(r => r.userId === user.id && r.financialYear === fy);
  if (!record) {
    record = { id: uuid(), userId: user.id, financialYear: fy, cumulativeGrossInr: 0, cumulativeTdsInr: 0, entries: [] };
    db.tdsRecords.push(record);
  }

  const tdsAmountInr = computeCryptoTds(record.cumulativeGrossInr, grossAmountInr);
  record.cumulativeGrossInr += grossAmountInr;

  if (tdsAmountInr <= 0) {
    return { tdsAmountInr: 0, netCreditAmount: creditAmount };
  }

  record.cumulativeTdsInr += tdsAmountInr;
  record.entries.push({
    id: uuid(), referenceType, referenceId, grossAmount, grossCurrency, grossAmountInr,
    tdsAmountInr, creditCurrency, createdAt: new Date().toISOString(),
  });

  // Deduct the TDS (converted into the credit currency at the same implied
  // rate as the transaction) from what the user actually receives.
  const effectiveRate = grossAmountInr > 0 ? Number(creditAmount) / (grossAmountInr / toApproxInr(1, grossCurrency)) : 0;
  const tdsInCreditCurrency = grossAmountInr > 0 ? (tdsAmountInr / grossAmountInr) * Number(creditAmount) : 0;
  const netCreditAmount = Math.max(0, Number(creditAmount) - tdsInCreditCurrency);

  postLedger(db, {
    debit: { ownerType: 'user_wallet', ownerId: user.id },
    credit: { ownerType: 'tds_payable_194s', ownerId: 'government' },
    amount: tdsInCreditCurrency,
    currency: creditCurrency,
    referenceType,
    referenceId,
    description: `1% TDS under Section 194S withheld on VDA transfer (FY ${fy})`,
  });

  db.auditLogs = db.auditLogs || [];
  db.auditLogs.push({
    id: uuid(), adminId: null, userId: user.id, action: 'tds.crypto.deducted', entityType: referenceType, entityId: referenceId,
    metadata: { financialYear: fy, grossAmountInr, tdsAmountInr, tdsInCreditCurrency, creditCurrency },
    createdAt: new Date().toISOString(),
  });

  return { tdsAmountInr, netCreditAmount };
}

function ensureAdmin() {
  const db = readDb();
  const email = process.env.ADMIN_EMAIL || 'admin@globalexchanger.com';
  if (!db.admins.find(a => a.email === email)) {
    db.admins.push({
      id: uuid(),
      email,
      passwordHash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Admin@12345', 10),
      specialKeyHash: bcrypt.hashSync(process.env.ADMIN_SPECIAL_KEY || 'GX-SUPER-KEY-2026', 10),
      role: 'super_admin',
      permissions: ['users:read','kyc:manage','payments:read','refunds:manage','exchange:manage','ledger:read','audit:read','admin:manage','disputes:manage'],
      createdAt: new Date().toISOString()
    });
    writeDb(db);
  }
}
ensureAdmin();

app.get('/', (req, res) => res.json({ app: 'Global Exchanger API', status: 'running' }));

app.post('/api/auth/register', registerLimiter, async (req, res) => {
  const { name, email, phone, country, address, houseNumber, password, referralCode } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  if (!isStrongPassword(password)) return res.status(400).json({ error: 'Password must be at least 8 characters and include both letters and numbers.' });
  const db = readDb();
  if (db.users.find(u => u.email === email)) return res.status(409).json({ error: 'Email already exists' });

  let referrer = null;
  if (referralCode) {
    referrer = db.users.find(u => u.referralCode === String(referralCode).trim().toUpperCase());
    if (!referrer) return res.status(400).json({ error: 'Invalid referral code' });
  }

  const user = {
    id: uuid(), name, email, phone, country, address, houseNumber,
    passwordHash: await bcrypt.hash(password, 10),
    securityPinHash: null,
    kycStatus: 'pending',
    emailVerified: false,
    referralCode: `GX${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
    referredBy: referralCode || null,
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  db.wallets.push({ userId: user.id, balances: { INR: 0, USD: 0, EUR: 0, BTC: 0, ETH: 0, XRP: 0 }, locked: {}, rewardBalances: { INR: 0, USD: 0, EUR: 0, BTC: 0, ETH: 0, XRP: 0 } });

  if (referrer && referrer.id !== user.id) {
    db.referrals.push({
      id: uuid(), referrerCode: referralCode, referrerUserId: referrer.id, referredUserId: user.id,
      reward: 100, currency: 'INR', status: 'pending_first_transaction', createdAt: new Date().toISOString()
    });
  }

  const session = issueAuthSession(db, { ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  writeDb(db);
  res.json({ ...session, user: publicUser(user) });
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Invalid login' });
  const db = readDb();
  const user = db.users.find(u => u.email === email);
  const passwordHash = user?.passwordHash || '$2a$10$CwTycUXWue0Thq9StjUM0uJ8gI0mZzn0EXAMPLEHASHVALUEXXXXX';
  const passwordOk = await bcrypt.compare(password, passwordHash);
  if (!user || !passwordOk) return res.status(401).json({ error: 'Invalid email or password' });
  const session = issueAuthSession(db, { ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  writeDb(db);
  res.json({ ...session, user: publicUser(user) });
});

app.post('/api/admin/login', adminLoginLimiter, async (req, res) => {
  const { email, password, specialKey } = req.body;
  if (!email || !password || !specialKey) return res.status(400).json({ error: 'Invalid admin login' });
  const db = readDb();
  const admin = db.admins.find(a => a.email === email);
  if (!admin) return res.status(401).json({ error: 'Invalid admin login' });
  const ok = await bcrypt.compare(password, admin.passwordHash) && await bcrypt.compare(specialKey, admin.specialKeyHash);
  if (!ok) return res.status(401).json({ error: 'Invalid admin login' });
  auditLog(db, { adminId: admin.id, action: 'admin.login', entityType: 'admin', entityId: admin.id, req });
  const session = issueAuthSession(db, { ownerType: 'admin', ownerId: admin.id, payload: { id: admin.id, role: 'admin' }, req });
  writeDb(db);
  res.json({ ...session, admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

// Refresh + logout endpoints — see server_pg.js for full rationale.
app.post('/api/auth/refresh', (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });
  const db = readDb();
  const result = rotateRefreshTokenJson(db, refreshToken, req);
  writeDb(db);
  if (!result.ok) {
    const messages = {
      invalid: 'Invalid refresh token. Please log in again.',
      reused: 'This session was used from another device or has expired. For your security, please log in again.',
      expired: 'Your session has expired. Please log in again.',
    };
    return res.status(401).json({ error: messages[result.reason] || 'Please log in again.' });
  }
  const accessToken = signAccessToken(JWT_SECRET, { id: result.ownerId, role: result.ownerType });
  res.json({ token: accessToken, refreshToken: result.refreshToken, refreshTokenExpiresAt: result.expiresAt });
});

app.post('/api/auth/logout', (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    const db = readDb();
    revokeRefreshTokenJson(db, refreshToken);
    writeDb(db);
  }
  res.json({ success: true });
});

app.post('/api/auth/logout-all', auth('any'), (req, res) => {
  const db = readDb();
  revokeAllForOwnerJson(db, req.auth.role, req.auth.id);
  writeDb(db);
  res.json({ success: true });
});

app.get('/api/me', auth('user'), (req, res) => {
  const db = readDb();
  const user = db.users.find(u => u.id === req.auth.id);
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  res.json({ user: publicUser(user), wallet });
});

app.get('/api/referrals/mine', auth('user'), (req, res) => {
  const db = readDb();
  const me = db.users.find(u => u.id === req.auth.id);
  const referrals = (db.referrals || [])
    .filter(r => r.referrerUserId === req.auth.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(r => {
      const referredUser = db.users.find(u => u.id === r.referredUserId);
      return {
        id: r.id,
        status: r.status,
        reward: r.reward,
        currency: r.currency,
        rewardedAt: r.rewardedAt || null,
        createdAt: r.createdAt,
        referredUser: referredUser ? { name: referredUser.name, email: referredUser.email } : null,
      };
    });
  const totalReferred = referrals.length;
  const totalRewarded = referrals.filter(r => r.status === 'rewarded').length;
  const totalEarned = referrals.filter(r => r.status === 'rewarded').reduce((sum, r) => sum + Number(r.reward || 0), 0);
  res.json({ referralCode: me?.referralCode, totalReferred, totalRewarded, totalEarned, referrals });
});

app.post('/api/security/pin', auth('user'), async (req, res) => {
  const { pin } = req.body;
  const pinStr = String(pin || '');
  if (!/^\d{4,6}$/.test(pinStr)) return res.status(400).json({ error: 'PIN must be 4-6 digits' });
  // Reject only the most obviously guessable PINs: all-same-digit or a fully
  // ascending/descending run. Common PINs like 1234/5678 are otherwise allowed.
  const isAllSameDigit = /^(\d)\1+$/.test(pinStr);
  const digits = pinStr.split('').map(Number);
  const isAscendingRun = digits.every((d, i) => i === 0 || d === digits[i - 1] + 1);
  const isDescendingRun = digits.every((d, i) => i === 0 || d === digits[i - 1] - 1);
  if (isAllSameDigit || isAscendingRun || isDescendingRun) {
    return res.status(400).json({ error: 'This PIN is too easy to guess (all same digit or a straight sequence). Please choose a different one.' });
  }
  const db = readDb();
  const user = db.users.find(u => u.id === req.auth.id);
  user.securityPinHash = await bcrypt.hash(pinStr, 10);
  writeDb(db);
  res.json({ message: 'Security PIN created' });
});

// KYC documents are accepted as base64 data URLs from the app (no external
// storage account needed). We cap the number/size of documents so a bad or
// huge upload can't blow up the JSON db file.
const MAX_KYC_DOCUMENTS = 5;
const MAX_KYC_DOCUMENT_BYTES = 4 * 1024 * 1024; // ~4MB per document (post base64-decode)
const ALLOWED_KYC_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

function sanitizeKycDocuments(documents) {
  if (!Array.isArray(documents)) return [];
  if (documents.length > MAX_KYC_DOCUMENTS) throw new Error(`Maximum ${MAX_KYC_DOCUMENTS} documents allowed`);
  return documents.map((doc, i) => {
    const label = String(doc?.label || `Document ${i + 1}`).slice(0, 100);
    const mimeType = String(doc?.mimeType || '');
    const dataBase64 = String(doc?.dataBase64 || '');
    if (!ALLOWED_KYC_MIME_TYPES.includes(mimeType)) throw new Error(`Unsupported document type: ${mimeType || 'unknown'}`);
    if (!dataBase64) throw new Error(`${label}: document data is empty`);
    const approxBytes = Math.floor((dataBase64.length * 3) / 4);
    if (approxBytes > MAX_KYC_DOCUMENT_BYTES) throw new Error(`${label} is too large (max 4MB per document)`);
    return { label, mimeType, dataBase64, uploadedAt: new Date().toISOString() };
  });
}

app.post('/api/kyc', auth('user'), (req, res) => {
  try {
    const { nationalId, taxId, country, documents = [], aliasNames = [] } = req.body;
    const sanitizedDocs = sanitizeKycDocuments(documents);
    const documentNames = sanitizedDocs.map(d => d.label);
    const db = readDb();
    const user = db.users.find(u => u.id === req.auth.id);

    // Sanctions/PEP screening — required as part of FIU-IND's AML/CFT
    // compliance expectations for VDA Service Providers. Screens the
    // user's registered name (plus any alias names they optionally
    // declare) against the local sanctions dataset. A match NEVER
    // auto-rejects the KYC — it only flags it for mandatory admin review,
    // since name-based screening has a meaningful false-positive rate
    // (see SANCTIONS_SCREENING_GUIDE.md).
    const screeningResult = screenKycSubmission({ fullName: user?.name, aliasNames: Array.isArray(aliasNames) ? aliasNames : [] });

    const kyc = {
      id: uuid(), userId: req.auth.id, nationalId, taxId, country, documentNames, documents: sanitizedDocs,
      status: 'under_review',
      sanctionsScreening: { flagged: screeningResult.flagged, matches: screeningResult.matches, screenedAt: new Date().toISOString() },
      createdAt: new Date().toISOString(),
    };
    db.kycRequests.push(kyc);
    user.kycStatus = 'under_review';
    auditLog(db, { userId: req.auth.id, action: 'kyc.submitted', entityType: 'kyc_request', entityId: kyc.id, metadata: { userId: kyc.userId, status: kyc.status, documentCount: sanitizedDocs.length, sanctionsFlagged: screeningResult.flagged }, req });
    if (screeningResult.flagged) {
      auditLog(db, { userId: req.auth.id, action: 'sanctions.screening.flagged', entityType: 'kyc_request', entityId: kyc.id, metadata: { matchCount: screeningResult.matches.length, topMatch: screeningResult.matches[0]?.entry?.name, topScore: screeningResult.matches[0]?.score }, req });
    }
    writeDb(db);
    const { documents: _omit, sanctionsScreening: _omitScreening, ...kycWithoutDocs } = kyc;
    res.json({ kyc: kycWithoutDocs });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/kyc/me', auth('user'), (req, res) => {
  const db = readDb();
  const rows = db.kycRequests.filter(k => k.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const latest = rows[0];
  if (!latest) return res.json({ kyc: null });
  const { documents: _omit, ...kycWithoutDocs } = latest;
  res.json({ kyc: kycWithoutDocs });
});

app.post('/api/bank-accounts', auth('user'), (req, res) => {
  const { holderName, bankName, accountNumber, ifscSwiftIban, country } = req.body;
  if (!holderName || !bankName || !accountNumber || !ifscSwiftIban) {
    return res.status(400).json({ error: 'holderName, bankName, accountNumber and ifscSwiftIban are required' });
  }
  const db = readDb();
  const account = { id: uuid(), userId: req.auth.id, holderName, bankName, accountNumberMasked: String(accountNumber || '').slice(-4).padStart(8, '*'), ifscSwiftIban, country, status: 'pending_verification', isDeleted: false, verifiedAt: null, verificationNote: null, createdAt: new Date().toISOString() };
  db.bankAccounts.push(account);
  writeDb(db);
  res.json({ account });
});

app.get('/api/bank-accounts', auth('user'), (req, res) => {
  const db = readDb();
  const rows = db.bankAccounts.filter(a => a.userId === req.auth.id && !a.isDeleted).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(rows);
});

app.delete('/api/bank-accounts/:id', auth('user'), (req, res) => {
  const db = readDb();
  const active = (db.withdrawals || []).find(w => w.bankAccountId === req.params.id && ['pending', 'approved', 'processing'].includes(w.status));
  if (active) return res.status(400).json({ error: 'Cannot remove a bank account with an active withdrawal in progress.' });
  const account = db.bankAccounts.find(a => a.id === req.params.id && a.userId === req.auth.id);
  if (!account) return res.status(404).json({ error: 'Bank account not found' });
  account.isDeleted = true;
  writeDb(db);
  res.json({ success: true });
});

app.get('/api/wallet', auth('user'), (req, res) => {
  const db = readDb();
  res.json(db.wallets.find(w => w.userId === req.auth.id));
});

// Move reward wallet balance into the main spendable wallet balance for one currency.
app.post('/api/wallet/redeem-rewards', auth('user'), (req, res) => {
  const { currency = 'INR' } = req.body;
  const db = readDb();
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  wallet.rewardBalances = wallet.rewardBalances || {};
  const amount = Number(wallet.rewardBalances[currency] || 0);
  if (amount <= 0) return res.status(400).json({ error: 'No reward balance available to redeem for this currency' });
  wallet.rewardBalances[currency] = 0;
  wallet.balances[currency] = Number(wallet.balances[currency] || 0) + amount;
  postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, amount, currency, referenceType: 'reward_redeem', referenceId: req.auth.id, description: 'Reward wallet redeemed into main wallet balance' });
  writeDb(db);
  res.json({ redeemed: amount, currency, wallet });
});

// ---------------------------------------------------------------------------
// Price Alerts
// ---------------------------------------------------------------------------
app.post('/api/price-alerts', auth('user'), (req, res) => {
  const { pair, direction, targetPrice } = req.body;
  if (!isSupportedPair(pair)) return res.status(400).json({ error: `Unsupported pair. Supported: ${SUPPORTED_PAIRS.join(', ')}` });
  if (!['above', 'below'].includes(direction)) return res.status(400).json({ error: "direction must be 'above' or 'below'" });
  const price = Number(targetPrice);
  if (!price || price <= 0) return res.status(400).json({ error: 'positive targetPrice required' });
  const db = readDb();
  db.priceAlerts = db.priceAlerts || [];
  const alert = { id: uuid(), userId: req.auth.id, pair: String(pair).toUpperCase(), direction, targetPrice: price, status: 'active', createdAt: new Date().toISOString() };
  db.priceAlerts.push(alert);
  writeDb(db);
  res.json({ alert });
});

app.get('/api/price-alerts', auth('user'), (req, res) => {
  const db = readDb();
  const alerts = (db.priceAlerts || []).filter(a => a.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(alerts);
});

app.delete('/api/price-alerts/:id', auth('user'), (req, res) => {
  const db = readDb();
  const alert = (db.priceAlerts || []).find(a => a.id === req.params.id && a.userId === req.auth.id);
  if (!alert) return res.status(404).json({ error: 'Alert not found' });
  alert.status = 'cancelled';
  writeDb(db);
  res.json({ alert });
});

// ---------------------------------------------------------------------------
// Favorites / Watchlist
// ---------------------------------------------------------------------------
app.post('/api/watchlist', auth('user'), (req, res) => {
  const { pair } = req.body;
  if (!isSupportedPair(pair)) return res.status(400).json({ error: `Unsupported pair. Supported: ${SUPPORTED_PAIRS.join(', ')}` });
  const db = readDb();
  db.watchlistPairs = db.watchlistPairs || [];
  const normalizedPair = String(pair).toUpperCase();
  if (db.watchlistPairs.find(w => w.userId === req.auth.id && w.pair === normalizedPair)) {
    return res.status(409).json({ error: 'Pair already in watchlist' });
  }
  const item = { id: uuid(), userId: req.auth.id, pair: normalizedPair, createdAt: new Date().toISOString() };
  db.watchlistPairs.push(item);
  writeDb(db);
  res.json({ item });
});

app.get('/api/watchlist', auth('user'), (req, res) => {
  const db = readDb();
  const items = (db.watchlistPairs || []).filter(w => w.userId === req.auth.id).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  res.json(items);
});

app.delete('/api/watchlist/:id', auth('user'), (req, res) => {
  const db = readDb();
  db.watchlistPairs = db.watchlistPairs || [];
  const before = db.watchlistPairs.length;
  db.watchlistPairs = db.watchlistPairs.filter(w => !(w.id === req.params.id && w.userId === req.auth.id));
  if (db.watchlistPairs.length === before) return res.status(404).json({ error: 'Watchlist item not found' });
  writeDb(db);
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// App Settings — theme preference + notification toggles, synced to the
// account (not just stored locally) so they follow the user across devices.
// ---------------------------------------------------------------------------
app.get('/api/settings', auth('user'), (req, res) => {
  const db = readDb();
  const user = db.users.find(u => u.id === req.auth.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({
    themePreference: user.themePreference || 'system',
    emailNotificationsEnabled: user.emailNotificationsEnabled !== false,
    pushNotificationsEnabled: user.pushNotificationsEnabled !== false,
  });
});

app.patch('/api/settings', auth('user'), (req, res) => {
  const { themePreference, emailNotificationsEnabled, pushNotificationsEnabled } = req.body;
  if (themePreference !== undefined && !['light', 'dark', 'system'].includes(themePreference)) {
    return res.status(400).json({ error: "themePreference must be 'light', 'dark' or 'system'" });
  }
  const db = readDb();
  const user = db.users.find(u => u.id === req.auth.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (themePreference !== undefined) user.themePreference = themePreference;
  if (emailNotificationsEnabled !== undefined) user.emailNotificationsEnabled = Boolean(emailNotificationsEnabled);
  if (pushNotificationsEnabled !== undefined) user.pushNotificationsEnabled = Boolean(pushNotificationsEnabled);
  writeDb(db);
  res.json({
    themePreference: user.themePreference || 'system',
    emailNotificationsEnabled: user.emailNotificationsEnabled !== false,
    pushNotificationsEnabled: user.pushNotificationsEnabled !== false,
  });
});

// ---------------------------------------------------------------------------
// Transaction Statement Export (PDF-via-print + CSV)
// ---------------------------------------------------------------------------
const statementTokenLimiter = rateLimit({ windowMs: 5 * 60_000, max: 15, keyFn: (req) => `stmt:${req.auth?.id || req.ip}`, message: 'Too many statement requests. Please try again shortly.' });

function normalizeTxnForStatement(txn, userId) {
  const direction = (txn.type === 'wallet_topup' || txn.type === 'refund' || txn.type === 'exchange_complete' || txn.toUserId === userId) ? 'credit' : 'debit';
  return { id: txn.id, type: txn.type, currency: txn.currency, amount: txn.amount, status: txn.status, direction, createdAt: txn.createdAt };
}

app.post('/api/statements/token', auth('user'), statementTokenLimiter, (req, res) => {
  const { fromDate, toDate } = req.body;
  const db = readDb();
  db.statementTokens = db.statementTokens || [];
  const token = generateStatementToken();
  const expiresAt = new Date(Date.now() + 15 * 60_000).toISOString();
  db.statementTokens.push({ token, userId: req.auth.id, fromDate: fromDate || null, toDate: toDate || null, expiresAt });
  writeDb(db);
  res.json({ token, url: `/api/statements/${token}`, csvUrl: `/api/statements/${token}/csv`, expiresAt });
});

// IMPORTANT: the /csv route must be registered BEFORE the bare /:token
// route below — Express path params (`:token`) match any character except
// `/`, so `/api/statements/abc123/csv` would otherwise never be reached if
// a broader pattern were declared first. Using a `/csv` sub-path (rather
// than a `.csv` suffix on the same segment) avoids the ambiguity entirely.
app.get('/api/statements/:token/csv', (req, res) => {
  const token = req.params.token;
  const db = readDb();
  const record = (db.statementTokens || []).find(t => t.token === token);
  if (!record) return res.status(404).json({ error: 'Statement link not found' });
  if (new Date(record.expiresAt).getTime() < Date.now()) return res.status(410).json({ error: 'Statement link expired' });
  let rows = (db.transactions || []).filter(t => t.fromUserId === record.userId || t.toUserId === record.userId);
  if (record.fromDate) rows = rows.filter(t => new Date(t.createdAt) >= new Date(record.fromDate));
  if (record.toDate) rows = rows.filter(t => new Date(t.createdAt) <= new Date(new Date(record.toDate).getTime() + 24 * 3600_000 - 1));
  rows = rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map(t => normalizeTxnForStatement(t, record.userId));
  const csv = renderStatementCsv(rows);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="global-exchanger-statement.csv"');
  res.send(csv);
});

app.get('/api/statements/:token', (req, res) => {
  const db = readDb();
  const record = (db.statementTokens || []).find(t => t.token === req.params.token);
  if (!record) return res.status(404).send('<h2>Statement link not found.</h2>');
  if (new Date(record.expiresAt).getTime() < Date.now()) return res.status(410).send('<h2>This statement link has expired. Please generate a new one from the app.</h2>');
  const user = db.users.find(u => u.id === record.userId);
  if (!user) return res.status(404).send('<h2>User not found.</h2>');
  let rows = (db.transactions || []).filter(t => t.fromUserId === record.userId || t.toUserId === record.userId);
  if (record.fromDate) rows = rows.filter(t => new Date(t.createdAt) >= new Date(record.fromDate));
  if (record.toDate) rows = rows.filter(t => new Date(t.createdAt) <= new Date(new Date(record.toDate).getTime() + 24 * 3600_000 - 1));
  rows = rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map(t => normalizeTxnForStatement(t, record.userId));
  const html = renderStatementHtml({ user, fromDate: record.fromDate, toDate: record.toDate, rows });
  res.send(wrapStatementPage(html));
});

// ---------------------------------------------------------------------------
// Withdrawals — see server_pg.js for the full design rationale (escrow-style
// locking, KYC requirement, bank verification requirement).
// ---------------------------------------------------------------------------
const MIN_WITHDRAWAL_AMOUNT = { INR: 100, USD: 5, EUR: 5 };
const withdrawalLimiter = rateLimit({ windowMs: 60 * 60_000, max: 10, keyFn: (req) => `withdraw:${req.auth?.id || req.ip}`, message: 'Too many withdrawal requests. Please try again later.' });

app.post('/api/withdrawals', auth('user'), withdrawalLimiter, (req, res) => {
  try {
    const { bankAccountId, amount, currency = 'INR' } = req.body;
    const numericAmount = Number(amount);
    if (!bankAccountId) throw new Error('bankAccountId is required');
    if (!numericAmount || numericAmount <= 0) throw new Error('A positive amount is required');
    const minAmount = MIN_WITHDRAWAL_AMOUNT[currency] || 0;
    if (numericAmount < minAmount) throw new Error(`Minimum withdrawal amount for ${currency} is ${minAmount}`);

    const db = readDb();
    const user = db.users.find(u => u.id === req.auth.id);
    if (user?.kycStatus !== 'approved') throw new Error('KYC approval is required before you can withdraw funds. Please complete KYC verification first.');
    const limitCheck = enforceTierLimits(db, user, { action: 'withdrawal', amount: numericAmount, currency });

    const bank = db.bankAccounts.find(b => b.id === bankAccountId && b.userId === req.auth.id && !b.isDeleted);
    if (!bank) throw new Error('Bank account not found');
    if (!bank.verifiedAt) throw new Error('This bank account is not yet verified by our team. Please wait for verification or add a different account.');

    const wallet = db.wallets.find(w => w.userId === req.auth.id);
    const available = Number(wallet.balances[currency] || 0);
    if (available < numericAmount) throw new Error('Insufficient balance for this withdrawal');

    const fee = 0;
    const netAmount = numericAmount - fee;
    wallet.balances[currency] = available - numericAmount;
    wallet.locked[currency] = Number(wallet.locked[currency] || 0) + numericAmount;

    const withdrawal = { id: uuid(), userId: req.auth.id, bankAccountId, amount: numericAmount, currency, fee, netAmount, status: 'pending', adminNote: null, processedBy: null, processedAt: null, createdAt: new Date().toISOString() };
    db.withdrawals = db.withdrawals || [];
    db.withdrawals.push(withdrawal);

    postLedger(db, {
      debit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
      credit: { ownerType: 'user_wallet', ownerId: req.auth.id },
      amount: numericAmount, currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
      description: 'Withdrawal amount locked pending admin processing',
    });
    checkAmlAndBalanceCap(db, user, { amountInr: limitCheck.amountInr, referenceType: 'withdrawal', referenceId: withdrawal.id, note: 'withdrawal request' });

    writeDb(db);
    res.json({ withdrawal });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/withdrawals', auth('user'), (req, res) => {
  const db = readDb();
  const rows = (db.withdrawals || [])
    .filter(w => w.userId === req.auth.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(w => ({ ...w, bankAccount: db.bankAccounts.find(b => b.id === w.bankAccountId) || null }));
  res.json(rows);
});

app.post('/api/withdrawals/:id/cancel', auth('user'), (req, res) => {
  try {
    const db = readDb();
    const withdrawal = (db.withdrawals || []).find(w => w.id === req.params.id && w.userId === req.auth.id);
    if (!withdrawal) throw new Error('Withdrawal not found');
    if (withdrawal.status !== 'pending') throw new Error('Only pending withdrawals can be cancelled');

    const wallet = db.wallets.find(w => w.userId === req.auth.id);
    wallet.locked[withdrawal.currency] = Math.max(0, Number(wallet.locked[withdrawal.currency] || 0) - Number(withdrawal.amount));
    wallet.balances[withdrawal.currency] = Number(wallet.balances[withdrawal.currency] || 0) + Number(withdrawal.amount);

    withdrawal.status = 'cancelled';
    withdrawal.processedAt = new Date().toISOString();

    postLedger(db, {
      debit: { ownerType: 'user_wallet', ownerId: req.auth.id },
      credit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
      amount: withdrawal.amount, currency: withdrawal.currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
      description: 'Withdrawal cancelled by user, funds returned to wallet',
    });

    writeDb(db);
    res.json({ withdrawal });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/admin/bank-accounts', auth('admin'), requirePermission('payments:read'), (req, res) => {
  const db = readDb();
  const rows = db.bankAccounts.filter(a => !a.isDeleted).map(a => ({ ...a, user: publicUser(db.users.find(u => u.id === a.userId) || {}) }));
  res.json(rows);
});

app.patch('/api/admin/bank-accounts/:id/verify', auth('admin'), requirePermission('payments:read'), (req, res) => {
  const { verified, note } = req.body;
  const db = readDb();
  const account = db.bankAccounts.find(a => a.id === req.params.id);
  if (!account) return res.status(404).json({ error: 'Bank account not found' });
  account.verifiedAt = verified ? new Date().toISOString() : null;
  account.verificationNote = note || null;
  auditLog(db, { adminId: req.auth.id, action: verified ? 'bank_account.verified' : 'bank_account.unverified', entityType: 'bank_account', entityId: account.id, req });
  writeDb(db);
  res.json({ account });
});

app.get('/api/admin/withdrawals', auth('admin'), requirePermission('refunds:manage'), (req, res) => {
  const db = readDb();
  const rows = (db.withdrawals || [])
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(w => ({ ...w, user: publicUser(db.users.find(u => u.id === w.userId) || {}), bankAccount: db.bankAccounts.find(b => b.id === w.bankAccountId) || null }));
  res.json(rows);
});

app.patch('/api/admin/withdrawals/:id', auth('admin'), requirePermission('refunds:manage'), (req, res) => {
  try {
    const { status, adminNote } = req.body;
    const allowed = ['approved', 'processing', 'completed', 'rejected'];
    if (!allowed.includes(status)) throw new Error(`status must be one of: ${allowed.join(', ')}`);

    const db = readDb();
    const withdrawal = (db.withdrawals || []).find(w => w.id === req.params.id);
    if (!withdrawal) throw new Error('Withdrawal not found');
    if (['completed', 'rejected', 'cancelled'].includes(withdrawal.status)) throw new Error('This withdrawal has already reached a final state');

    if (status === 'rejected') {
      const wallet = db.wallets.find(w => w.userId === withdrawal.userId);
      wallet.locked[withdrawal.currency] = Math.max(0, Number(wallet.locked[withdrawal.currency] || 0) - Number(withdrawal.amount));
      wallet.balances[withdrawal.currency] = Number(wallet.balances[withdrawal.currency] || 0) + Number(withdrawal.amount);
      postLedger(db, {
        debit: { ownerType: 'user_wallet', ownerId: withdrawal.userId },
        credit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
        amount: withdrawal.amount, currency: withdrawal.currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
        description: 'Withdrawal rejected by admin, funds returned to wallet',
      });
    } else if (status === 'completed') {
      // Money has now actually left the platform — clear it from `locked`
      // too, not just the ledger.
      const wallet = db.wallets.find(w => w.userId === withdrawal.userId);
      wallet.locked[withdrawal.currency] = Math.max(0, Number(wallet.locked[withdrawal.currency] || 0) - Number(withdrawal.amount));
      postLedger(db, {
        debit: { ownerType: 'withdrawal_escrow', ownerId: withdrawal.id },
        credit: { ownerType: 'platform_cash', ownerId: 'bank_payout' },
        amount: withdrawal.amount, currency: withdrawal.currency, referenceType: 'withdrawal', referenceId: withdrawal.id,
        description: 'Withdrawal completed — funds sent to user bank account',
      });
    }

    withdrawal.status = status;
    if (adminNote) withdrawal.adminNote = adminNote;
    withdrawal.processedBy = req.auth.id;
    withdrawal.processedAt = new Date().toISOString();
    auditLog(db, { adminId: req.auth.id, action: `withdrawal.${status}`, entityType: 'withdrawal', entityId: withdrawal.id, metadata: { userId: withdrawal.userId, amount: withdrawal.amount, currency: withdrawal.currency }, req });

    const wUser = db.users.find(u => u.id === withdrawal.userId);
    const statusMessages = {
      approved: 'Aapki withdrawal request approve ho gayi hai aur process ho rahi hai.',
      processing: 'Aapki withdrawal process ho rahi hai, jaldi hi aapke bank account mein credit hogi.',
      completed: `Aapki withdrawal of ${withdrawal.currency} ${withdrawal.netAmount} successfully aapke bank account mein bhej di gayi hai.`,
      rejected: `Aapki withdrawal reject ho gayi hai. Amount aapke wallet mein wapas kar diya gaya hai.${adminNote ? ' Reason: ' + adminNote : ''}`,
    };
    notifyUserJson(db, {
      userId: withdrawal.userId,
      userEmail: wUser?.email,
      type: `withdrawal_${status}`,
      title: `Withdrawal ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      message: statusMessages[status] || `Withdrawal status updated to ${status}`,
      metadata: { withdrawalId: withdrawal.id, amount: withdrawal.amount, currency: withdrawal.currency, status },
    });

    writeDb(db);
    res.json({ withdrawal });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// ---------------------------------------------------------------------------
// Live exchange rates (forex + crypto), fetched from free public APIs and
// cached in-memory for 60 seconds. Falls back to last known good rates (or
// the original static demo numbers if we've never fetched successfully) so
// the app never breaks even if the upstream providers are down.
// ---------------------------------------------------------------------------
let _ratesCache = null;
let _ratesCacheExpiry = 0;
const RATES_CACHE_MS = 60_000;
const STATIC_FALLBACK_RATES = {
  forex: { USD_INR: 83.5, EUR_INR: 90.2, GBP_INR: 106.1, AED_INR: 22.7 },
  crypto: { BTC_USD: 65000, ETH_USD: 3400, XRP_USD: 0.52, BTC_INR: 5427500 }
};

async function fetchLiveRates() {
  const [forexRes, cryptoRes] = await Promise.allSettled([
    fetch('https://open.er-api.com/v6/latest/USD').then(r => r.json()),
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,ripple&vs_currencies=usd,inr').then(r => r.json())
  ]);

  let forex = null;
  if (forexRes.status === 'fulfilled' && forexRes.value?.result === 'success') {
    const r = forexRes.value.rates;
    forex = {
      USD_INR: r.INR,
      EUR_INR: r.INR / r.EUR,
      GBP_INR: r.INR / r.GBP,
      AED_INR: r.INR / r.AED
    };
  }

  let crypto = null;
  if (cryptoRes.status === 'fulfilled' && cryptoRes.value?.bitcoin) {
    const c = cryptoRes.value;
    crypto = {
      BTC_USD: c.bitcoin?.usd,
      ETH_USD: c.ethereum?.usd,
      XRP_USD: c.ripple?.usd,
      BTC_INR: c.bitcoin?.inr
    };
  }

  if (!forex && !crypto) throw new Error('Both forex and crypto providers failed');
  return { forex, crypto };
}

async function getRates() {
  const now = Date.now();
  if (_ratesCache && now < _ratesCacheExpiry) return _ratesCache;

  try {
    const live = await fetchLiveRates();
    _ratesCache = {
      source: 'live',
      updatedAt: new Date().toISOString(),
      forex: live.forex || _ratesCache?.forex || STATIC_FALLBACK_RATES.forex,
      crypto: live.crypto || _ratesCache?.crypto || STATIC_FALLBACK_RATES.crypto
    };
  } catch (e) {
    console.error('Live rate fetch failed, using fallback:', e.message);
    _ratesCache = _ratesCache || {
      source: 'demo_fallback',
      updatedAt: new Date().toISOString(),
      forex: STATIC_FALLBACK_RATES.forex,
      crypto: STATIC_FALLBACK_RATES.crypto
    };
  }

  _ratesCacheExpiry = now + RATES_CACHE_MS;
  return _ratesCache;
}

// Checks every currently-active price alert against a freshly-fetched
// rates snapshot and fires notifications for any that have crossed their
// target. See price_alerts.js for why this is opportunistic (called from
// GET /api/rates) rather than a real background cron — Render's free tier
// has no reliable always-on timer.
function checkPriceAlerts(db, rates) {
  db.priceAlerts = db.priceAlerts || [];
  const active = db.priceAlerts.filter(a => a.status === 'active');
  if (active.length === 0) return;
  const flat = flattenRates(rates);
  const triggered = findTriggeredAlerts(active, flat);
  if (triggered.length === 0) return;

  for (const t of triggered) {
    const alert = db.priceAlerts.find(a => a.id === t.id);
    if (!alert) continue;
    alert.status = 'triggered';
    alert.triggeredAt = new Date().toISOString();
    alert.triggeredPrice = t.currentPrice;
    const user = db.users.find(u => u.id === alert.userId);
    notifyUserJson(db, {
      userId: alert.userId,
      userEmail: user?.email,
      sendEmail: user?.emailNotificationsEnabled !== false,
      type: 'price_alert_triggered',
      title: `Price Alert: ${formatPairLabel(alert.pair)}`,
      message: `${formatPairLabel(alert.pair)} is now ${t.currentPrice} — your target was ${alert.direction} ${alert.targetPrice}.`,
      metadata: { pair: alert.pair, targetPrice: alert.targetPrice, currentPrice: t.currentPrice, direction: alert.direction },
    });
  }
  writeDb(db);
}

app.get('/api/rates', async (req, res) => {
  const rates = await getRates();
  try {
    const db = readDb();
    checkPriceAlerts(db, rates);
  } catch (e) {
    console.error('Price alert check failed:', e.message);
  }
  res.json(rates);
});

const sendMoneyPinLimiter = rateLimit({ windowMs: 15 * 60_000, max: 8, keyFn: (req) => `pin:${req.auth?.id || req.ip}`, message: 'Too many incorrect PIN attempts. Please try again in 15 minutes.' });

app.post('/api/transactions/send', auth('user'), sendMoneyPinLimiter, async (req, res) => {
  const { toUserId, receiver, toEmail, amount, currency = 'INR', pin, note = '' } = req.body;
  const numericAmount = Number(amount);
  if (!numericAmount || numericAmount <= 0) return res.status(400).json({ error: 'positive amount required' });
  const db = readDb();
  const sender = db.users.find(u => u.id === req.auth.id);
  if (!sender.securityPinHash || !(await bcrypt.compare(String(pin), sender.securityPinHash))) return res.status(403).json({ error: 'Invalid security PIN' });
  const receiverKey = String(toUserId || receiver || toEmail || '').trim();
  if (!receiverKey) return res.status(400).json({ error: 'receiver email or userId required' });
  const receiverUser = db.users.find(u => u.id === receiverKey || String(u.email).toLowerCase() === receiverKey.toLowerCase() || String(u.phone || '') === receiverKey);
  if (!receiverUser) return res.status(404).json({ error: 'Receiver not found' });
  if (receiverUser.id === req.auth.id) return res.status(400).json({ error: 'Cannot send money to yourself' });
  const fromWallet = db.wallets.find(w => w.userId === req.auth.id);
  const toWallet = db.wallets.find(w => w.userId === receiverUser.id);
  if (!toWallet) return res.status(404).json({ error: 'Receiver wallet not found' });
  if ((fromWallet.balances[currency] || 0) < numericAmount) return res.status(400).json({ error: 'Insufficient balance' });
  let limitCheck;
  try {
    limitCheck = enforceTierLimits(db, sender, { action: 'send', amount: numericAmount, currency });
  } catch (e) {
    return res.status(403).json({ error: e.message });
  }
  fromWallet.balances[currency] -= numericAmount;
  toWallet.balances[currency] = (toWallet.balances[currency] || 0) + numericAmount;
  const txn = { id: uuid(), type: 'send', fromUserId: req.auth.id, toUserId: receiverUser.id, amount: numericAmount, currency, status: 'completed', note, createdAt: new Date().toISOString() };
  db.transactions.push(txn);
  postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: receiverUser.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: numericAmount, currency, referenceType: 'transaction', referenceId: txn.id, description: 'User to user wallet send/receive' });
  checkAmlAndBalanceCap(db, sender, { amountInr: limitCheck.amountInr, referenceType: 'transaction', referenceId: txn.id, note: 'send money' });

  // Travel Rule data capture — required for VDA (crypto) transfers under
  // FIU-IND AML/CFT guidance, which treats VDA transfers like wire
  // transfers. See travel_rule.js for full rationale.
  if (VDA_CURRENCIES.includes(currency)) {
    const senderKyc = db.kycRequests.filter(k => k.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    const receiverKyc = db.kycRequests.filter(k => k.userId === receiverUser.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    captureTravelRuleData(db, uuid, {
      originatorUser: sender, beneficiaryUser: receiverUser, currency, amount: numericAmount,
      referenceType: 'transaction', referenceId: txn.id,
      originatorNationalId: senderKyc?.nationalId, beneficiaryNationalId: receiverKyc?.nationalId,
    });
  }

  maybePayReferralRewardJson(db, req.auth.id);
  writeDb(db);
  res.json({ transaction: txn, receiver: publicUser(receiverUser) });
});

app.post('/api/exchange/orders', auth('user'), (req, res) => {
  const { fromCurrency, toCurrency, amount, mode = 'convert' } = req.body;
  const commission = Number(amount) * 0.01;
  const adminCommission = Number(amount) * 0.008;
  const sellerCommission = Number(amount) * 0.002;
  const db = readDb();
  const exchangeUser = db.users.find(u => u.id === req.auth.id);
  try {
    enforceTierLimits(db, exchangeUser, { action: 'exchange', amount: Number(amount), currency: fromCurrency });
  } catch (e) {
    return res.status(403).json({ error: e.message });
  }
  const order = { id: uuid(), userId: req.auth.id, mode, fromCurrency, toCurrency, amount, status: 'pending_match', escrowStatus: 'not_locked', commission, adminCommission, sellerCommission, createdAt: new Date().toISOString() };
  db.exchangeOrders.push(order);
  db.commissions.push({ id: uuid(), orderId: order.id, adminCommission, sellerCommission, status: 'pending', createdAt: order.createdAt });
  // Commission ledger structure: pending commission receivable and split liabilities.
  postLedger(db, { debit: { ownerType: 'platform_commission_receivable', ownerId: 'exchange' }, credit: { ownerType: 'exchange_user_payable', ownerId: req.auth.id }, amount: commission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '1% exchange commission accrued' });
  postLedger(db, { debit: { ownerType: 'admin_commission_earning', ownerId: 'admin' }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: adminCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.8% admin commission split' });
  postLedger(db, { debit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% seller/user commission split' });

  // Reward wallet credit: move 0.2% (sellerCommission) into the user's rewardBalances
  // so it is actually visible/usable, not just recorded in the ledger.
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  wallet.rewardBalances = wallet.rewardBalances || {};
  wallet.rewardBalances[fromCurrency] = (wallet.rewardBalances[fromCurrency] || 0) + sellerCommission;
  postLedger(db, { debit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, credit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% reward credited to user reward wallet' });

  const rewardUser = db.users.find(u => u.id === req.auth.id);
  notifyUserJson(db, {
    userId: req.auth.id,
    userEmail: rewardUser?.email,
    type: 'reward_credited',
    title: 'Reward Credited',
    message: `Aapko ${fromCurrency} ${sellerCommission.toFixed(4)} ka reward mila hai is exchange order par. Wallet screen ke "Reward Wallet" section mein dekhein.`,
    metadata: { orderId: order.id, amount: sellerCommission, currency: fromCurrency },
    sendEmail: false,
  });

  writeDb(db);
  res.json({ order });
});


app.post('/api/exchange/orders/:id/lock-escrow', auth('user'), async (req, res) => {
  const db = readDb();
  const order = db.exchangeOrders.find(o => o.id === req.params.id && o.userId === req.auth.id);
  if (!order) return res.status(404).json({ error: 'Exchange order not found' });
  if (order.escrowStatus === 'locked') return res.status(400).json({ error: 'Escrow already locked' });
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  if ((wallet.balances[order.fromCurrency] || 0) < Number(order.amount)) return res.status(400).json({ error: 'Insufficient balance for escrow' });
  wallet.balances[order.fromCurrency] -= Number(order.amount);
  wallet.locked[order.fromCurrency] = (wallet.locked[order.fromCurrency] || 0) + Number(order.amount);
  order.status = 'escrow_locked';
  order.escrowStatus = 'locked';
  postLedger(db, { debit: { ownerType: 'exchange_escrow', ownerId: order.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: order.amount, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Exchange amount locked in escrow' });
  writeDb(db);
  res.json({ order });
});

app.post('/api/admin/exchange/orders/:id/complete', auth('admin'), requirePermission('exchange:manage'), (req, res) => {
  const { rate, receiveAmount } = req.body;
  const db = readDb();
  const order = db.exchangeOrders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Exchange order not found' });
  if (order.escrowStatus !== 'locked') return res.status(400).json({ error: 'Escrow must be locked before completion' });
  const wallet = db.wallets.find(w => w.userId === order.userId);
  const orderUser = db.users.find(u => u.id === order.userId);
  let finalReceive = Number(receiveAmount || (Number(order.amount) * Number(rate || 1)));
  wallet.locked[order.fromCurrency] = Math.max(0, Number(wallet.locked[order.fromCurrency] || 0) - Number(order.amount));

  // Crypto (VDA) TDS under Section 194S: applies when the user is disposing
  // of a VDA (selling/converting AWAY FROM crypto), regardless of what
  // they're converting into. See limits.js and TECHNICAL_SAFEGUARDS_GUIDE.md.
  let tdsInfo = { tdsAmountInr: 0, netCreditAmount: finalReceive };
  if (VDA_CURRENCIES.includes(order.fromCurrency)) {
    tdsInfo = applyCryptoTds(db, orderUser, {
      grossAmount: order.amount, grossCurrency: order.fromCurrency,
      creditCurrency: order.toCurrency, creditAmount: finalReceive,
      referenceType: 'exchange_order', referenceId: order.id,
    });
    finalReceive = tdsInfo.netCreditAmount;
  }

  wallet.balances[order.toCurrency] = Number(wallet.balances[order.toCurrency] || 0) + finalReceive;
  order.status = 'completed';
  order.escrowStatus = 'released';
  order.rate = Number(rate || 1);
  order.receiveAmount = finalReceive;
  order.tdsDeductedInr = tdsInfo.tdsAmountInr || 0;
  order.completedAt = new Date().toISOString();
  db.transactions.push({ id: uuid(), type: 'exchange_complete', fromUserId: order.userId, toUserId: order.userId, amount: finalReceive, currency: order.toCurrency, status: 'completed', createdAt: new Date().toISOString() });
  postLedger(db, { debit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow source currency released to exchange pool' });
  postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: order.userId }, credit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, amount: finalReceive, currency: order.toCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Converted currency credited to user wallet (net of TDS if applicable)' });
  auditLog(db, { adminId: req.auth.id, action: 'exchange.complete', entityType: 'exchange_order', entityId: order.id, metadata: { rate: order.rate, receiveAmount: finalReceive, tdsDeductedInr: tdsInfo.tdsAmountInr }, req });
  checkAmlAndBalanceCap(db, orderUser, { amountInr: toApproxInr(order.amount, order.fromCurrency), referenceType: 'exchange_order', referenceId: order.id, note: 'currency/crypto exchange completed' });

  // Travel Rule data capture — this exchange order is a self-conversion
  // (same user is both originator and beneficiary within the platform),
  // but is still recorded for a complete VDA transfer audit trail, since
  // one leg of the conversion involves a VDA currency.
  if (VDA_CURRENCIES.includes(order.fromCurrency) || VDA_CURRENCIES.includes(order.toCurrency)) {
    const orderUserKyc = db.kycRequests.filter(k => k.userId === order.userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    captureTravelRuleData(db, uuid, {
      originatorUser: orderUser, beneficiaryUser: orderUser,
      currency: VDA_CURRENCIES.includes(order.fromCurrency) ? order.fromCurrency : order.toCurrency,
      amount: VDA_CURRENCIES.includes(order.fromCurrency) ? order.amount : finalReceive,
      referenceType: 'exchange_order', referenceId: order.id,
      originatorNationalId: orderUserKyc?.nationalId, beneficiaryNationalId: orderUserKyc?.nationalId,
    });
  }
  maybePayReferralRewardJson(db, order.userId);

  const exUser = db.users.find(u => u.id === order.userId);
  notifyUserJson(db, {
    userId: order.userId,
    userEmail: exUser?.email,
    type: 'exchange_completed',
    title: 'Exchange Order Completed',
    message: `Aapka ${order.fromCurrency} to ${order.toCurrency} exchange complete ho gaya hai. Aapko ${order.toCurrency} ${finalReceive} mila hai.`,
    metadata: { orderId: order.id, receiveAmount: finalReceive, toCurrency: order.toCurrency },
  });

  writeDb(db);
  res.json({ order });
});

app.post('/api/admin/exchange/orders/:id/cancel', auth('admin'), requirePermission('exchange:manage'), (req, res) => {
  const db = readDb();
  const order = db.exchangeOrders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Exchange order not found' });
  if (order.status === 'cancelled') return res.status(400).json({ error: 'Order already cancelled' });
  if (order.status === 'completed') return res.status(400).json({ error: 'Cannot cancel a completed order' });
  const wallet = db.wallets.find(w => w.userId === order.userId);
  if (order.escrowStatus === 'locked') {
    wallet.locked[order.fromCurrency] = Math.max(0, Number(wallet.locked[order.fromCurrency] || 0) - Number(order.amount));
    wallet.balances[order.fromCurrency] = Number(wallet.balances[order.fromCurrency] || 0) + Number(order.amount);
    postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: order.userId }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow returned to user after cancellation' });
  }

  // Reverse the 0.2% reward that was credited when the order was created.
  // Priority 1: take it back from the reward wallet (normal case).
  // Priority 2: if already redeemed into the main wallet, claw back what's left there
  //             (never push balance below zero). Anything still unrecovered is audit-logged.
  wallet.rewardBalances = wallet.rewardBalances || {};
  const sellerCommission = Number(order.sellerCommission || 0);
  if (sellerCommission > 0) {
    let remaining = sellerCommission;

    const currentReward = Number(wallet.rewardBalances[order.fromCurrency] || 0);
    const fromReward = Math.min(currentReward, remaining);
    if (fromReward > 0) {
      wallet.rewardBalances[order.fromCurrency] = currentReward - fromReward;
      remaining -= fromReward;
      postLedger(db, { debit: { ownerType: 'seller_commission_earning', ownerId: order.userId }, credit: { ownerType: 'user_reward_wallet', ownerId: order.userId }, amount: fromReward, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% reward reversed due to order cancellation' });
    }

    if (remaining > 0) {
      const currentMainBalance = Number(wallet.balances[order.fromCurrency] || 0);
      const fromMainWallet = Math.min(currentMainBalance, remaining);
      if (fromMainWallet > 0) {
        wallet.balances[order.fromCurrency] = currentMainBalance - fromMainWallet;
        remaining -= fromMainWallet;
        postLedger(db, { debit: { ownerType: 'seller_commission_earning', ownerId: order.userId }, credit: { ownerType: 'user_wallet', ownerId: order.userId }, amount: fromMainWallet, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% already-redeemed reward clawed back from main wallet due to order cancellation' });
      }
    }

    if (remaining > 0) {
      auditLog(db, { adminId: req.auth.id, action: 'exchange.cancel.reward_reversal_incomplete', entityType: 'exchange_order', entityId: order.id, metadata: { currency: order.fromCurrency, unrecovered: remaining }, req });
    }
  }

  order.status = 'cancelled';
  order.escrowStatus = 'cancelled';
  auditLog(db, { adminId: req.auth.id, action: 'exchange.cancel', entityType: 'exchange_order', entityId: order.id, req });

  const cancelUser = db.users.find(u => u.id === order.userId);
  notifyUserJson(db, {
    userId: order.userId,
    userEmail: cancelUser?.email,
    type: 'exchange_cancelled',
    title: 'Exchange Order Cancelled',
    message: `Aapka ${order.fromCurrency} to ${order.toCurrency} exchange order cancel kar diya gaya hai. Locked amount aapke wallet mein wapas kar diya gaya hai.`,
    metadata: { orderId: order.id },
  });

  writeDb(db);
  res.json({ order });
});

app.get('/api/admin/exchange/orders', auth('admin'), requirePermission('exchange:manage'), (req, res) => {
  const db = readDb();
  res.json(db.exchangeOrders.map(o => ({ ...o, user: publicUser(db.users.find(u => u.id === o.userId) || {}) })));
});


app.post('/api/disputes', auth('user'), (req, res) => {
  const { transactionId, reason, message, evidence = [] } = req.body;
  if (!reason || !message) return res.status(400).json({ error: 'reason and message required' });
  const db = readDb();
  db.disputes = db.disputes || [];
  const dispute = { id: uuid(), userId: req.auth.id, transactionId: transactionId || null, reason, message, evidence, status: 'submitted', adminNote: null, resolution: null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  db.disputes.push(dispute);
  writeDb(db);
  res.json({ dispute });
});

app.get('/api/disputes', auth('user'), (req, res) => {
  const db = readDb();
  res.json((db.disputes || []).filter(d => d.userId === req.auth.id));
});

app.get('/api/admin/disputes', auth('admin'), requirePermission('disputes:manage'), (req, res) => {
  const db = readDb();
  const rows = (db.disputes || []).map(d => ({ ...d, user: publicUser(db.users.find(u => u.id === d.userId) || {}) }));
  res.json(rows);
});

app.patch('/api/admin/disputes/:id', auth('admin'), requirePermission('disputes:manage'), (req, res) => {
  const { status, adminNote, resolution } = req.body;
  const db = readDb();
  const dispute = (db.disputes || []).find(d => d.id === req.params.id);
  if (!dispute) return res.status(404).json({ error: 'Dispute not found' });
  if (status) dispute.status = status;
  if (adminNote !== undefined) dispute.adminNote = adminNote;
  if (resolution !== undefined) dispute.resolution = resolution;
  dispute.updatedAt = new Date().toISOString();
  auditLog(db, { adminId: req.auth.id, action: `dispute.${dispute.status}`, entityType: 'dispute', entityId: dispute.id, metadata: { userId: dispute.userId, status: dispute.status }, req });
  writeDb(db);
  res.json({ dispute });
});

app.post('/api/complaints', auth('user'), (req, res) => {
  const { subject, message, transactionId } = req.body;
  const db = readDb();
  const complaint = { id: uuid(), userId: req.auth.id, subject, message, transactionId, status: 'submitted', createdAt: new Date().toISOString() };
  db.complaints.push(complaint);
  writeDb(db);
  res.json({ complaint });
});

app.get('/api/complaints', auth('user'), (req, res) => {
  const db = readDb();
  res.json(db.complaints.filter(c => c.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
});

// ---------------------------------------------------------------------------
// In-App Support Chat — real back-and-forth messages within a complaint
// ("case"), on top of the original one-shot complaint submission above.
// Polling-based (no websockets) to keep the Render free-tier deployment
// simple; the app polls GET .../messages while the chat screen is open.
// ---------------------------------------------------------------------------
app.post('/api/complaints/:id/messages', auth('user'), (req, res) => {
  const { message } = req.body;
  if (!message || !String(message).trim()) return res.status(400).json({ error: 'message required' });
  const db = readDb();
  const complaint = (db.complaints || []).find(c => c.id === req.params.id && c.userId === req.auth.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });
  const user = db.users.find(u => u.id === req.auth.id);
  db.complaintMessages = db.complaintMessages || [];
  const msg = { id: uuid(), complaintId: complaint.id, senderType: 'user', senderId: req.auth.id, senderName: user?.name || 'User', message: String(message).trim(), createdAt: new Date().toISOString() };
  db.complaintMessages.push(msg);
  complaint.lastMessageAt = msg.createdAt;
  complaint.lastUserReadAt = msg.createdAt;
  writeDb(db);
  res.json({ message: msg });
});

app.get('/api/complaints/:id/messages', auth('user'), (req, res) => {
  const db = readDb();
  const complaint = (db.complaints || []).find(c => c.id === req.params.id && c.userId === req.auth.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });
  db.complaintMessages = db.complaintMessages || [];
  const messages = db.complaintMessages.filter(m => m.complaintId === complaint.id).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  complaint.lastUserReadAt = new Date().toISOString();
  writeDb(db);
  res.json({ messages, complaint });
});

app.get('/api/admin/complaints/:id/messages', auth('admin'), (req, res) => {
  const db = readDb();
  const complaint = (db.complaints || []).find(c => c.id === req.params.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });
  db.complaintMessages = db.complaintMessages || [];
  const messages = db.complaintMessages.filter(m => m.complaintId === complaint.id).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  complaint.lastAdminReadAt = new Date().toISOString();
  writeDb(db);
  res.json({ messages, complaint });
});

app.post('/api/admin/complaints/:id/messages', auth('admin'), (req, res) => {
  const { message } = req.body;
  if (!message || !String(message).trim()) return res.status(400).json({ error: 'message required' });
  const db = readDb();
  const complaint = (db.complaints || []).find(c => c.id === req.params.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });
  const admin = db.admins.find(a => a.id === req.auth.id);
  db.complaintMessages = db.complaintMessages || [];
  const msg = { id: uuid(), complaintId: complaint.id, senderType: 'admin', senderId: req.auth.id, senderName: admin?.email || 'Support Team', message: String(message).trim(), createdAt: new Date().toISOString() };
  db.complaintMessages.push(msg);
  complaint.lastMessageAt = msg.createdAt;
  complaint.lastAdminReadAt = msg.createdAt;

  const complainant = db.users.find(u => u.id === complaint.userId);
  notifyUserJson(db, {
    userId: complaint.userId,
    userEmail: complainant?.email,
    sendEmail: complainant?.emailNotificationsEnabled !== false,
    type: 'support_reply',
    title: 'New reply on your support ticket',
    message: `Support team ne aapki complaint "${complaint.subject || ''}" par reply kiya hai.`,
    metadata: { complaintId: complaint.id },
  });

  writeDb(db);
  res.json({ message: msg });
});

app.get('/api/transactions', auth('user'), (req, res) => {
  const { type, status, from, to, search, limit = 50, offset = 0 } = req.query;
  const db = readDb();
  let rows = db.transactions.filter(t => t.fromUserId === req.auth.id || t.toUserId === req.auth.id);
  if (type) rows = rows.filter(t => t.type === type);
  if (status) rows = rows.filter(t => t.status === status);
  if (from) rows = rows.filter(t => new Date(t.createdAt) >= new Date(from));
  if (to) rows = rows.filter(t => new Date(t.createdAt) <= new Date(to));
  if (search) {
    const s = search.toLowerCase();
    rows = rows.filter(t => (t.id || '').toLowerCase().includes(s) || (t.currency || '').toLowerCase().includes(s));
  }
  rows = rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const limitNum = Math.min(parseInt(limit) || 50, 200);
  const offsetNum = parseInt(offset) || 0;
  res.json(rows.slice(offsetNum, offsetNum + limitNum));
});

app.get('/api/exchange/orders/mine', auth('user'), (req, res) => {
  const { status, limit = 50, offset = 0 } = req.query;
  const db = readDb();
  let rows = db.exchangeOrders.filter(o => o.userId === req.auth.id);
  if (status) rows = rows.filter(o => o.status === status);
  rows = rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const limitNum = Math.min(parseInt(limit) || 50, 200);
  const offsetNum = parseInt(offset) || 0;
  res.json(rows.slice(offsetNum, offsetNum + limitNum));
});

const receiptTokenLimiter = rateLimit({ windowMs: 60_000, max: 20, keyFn: (req) => `receipt:${req.auth?.id || req.ip}` });

app.post('/api/receipts/token', auth('user'), receiptTokenLimiter, (req, res) => {
  const { transactionId, exchangeOrderId } = req.body;
  if (!transactionId && !exchangeOrderId) return res.status(400).json({ error: 'transactionId or exchangeOrderId required' });
  const db = readDb();

  if (transactionId) {
    const t = db.transactions.find(t => t.id === transactionId && (t.fromUserId === req.auth.id || t.toUserId === req.auth.id));
    if (!t) return res.status(404).json({ error: 'Transaction not found' });
  }
  if (exchangeOrderId) {
    const o = db.exchangeOrders.find(o => o.id === exchangeOrderId && o.userId === req.auth.id);
    if (!o) return res.status(404).json({ error: 'Exchange order not found' });
  }

  const token = generateReceiptToken();
  const expiresAt = new Date(Date.now() + 15 * 60_000).toISOString();
  db.receiptTokens = db.receiptTokens || [];
  db.receiptTokens.push({ token, userId: req.auth.id, transactionId: transactionId || null, exchangeOrderId: exchangeOrderId || null, expiresAt });
  writeDb(db);
  res.json({ token, url: `/api/receipts/${token}`, expiresAt });
});

app.get('/api/receipts/:token', (req, res) => {
  const db = readDb();
  const record = (db.receiptTokens || []).find(r => r.token === req.params.token);
  if (!record) return res.status(404).send('<h2>Receipt link not found or already expired.</h2>');
  if (new Date(record.expiresAt).getTime() < Date.now()) return res.status(410).send('<h2>This receipt link has expired. Please generate a new one from the app.</h2>');

  const user = db.users.find(u => u.id === record.userId) || {};

  if (record.transactionId) {
    const t = db.transactions.find(t => t.id === record.transactionId);
    if (!t) return res.status(404).send('<h2>Transaction not found.</h2>');
    return res.send(wrapReceiptPage(renderTransactionReceiptJson({ transaction: t, user: { ...user, id: record.userId } })));
  }

  if (record.exchangeOrderId) {
    const o = db.exchangeOrders.find(o => o.id === record.exchangeOrderId);
    if (!o) return res.status(404).send('<h2>Exchange order not found.</h2>');
    return res.send(wrapReceiptPage(renderExchangeReceiptJson({ order: o, user })));
  }

  res.status(404).send('<h2>Receipt not found.</h2>');
});

function _isToday(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
}

app.get('/api/admin/dashboard', auth('admin'), (req, res) => {
  const db = readDb();
  const adminCommission = db.commissions.reduce((sum, c) => sum + (c.adminCommission || 0), 0);
  const todayCommission = db.commissions.filter(c => _isToday(c.createdAt)).reduce((sum, c) => sum + (c.adminCommission || 0), 0);
  const todayUsers = db.users.filter(u => _isToday(u.createdAt)).length;
  const todayTransactions = db.transactions.filter(t => _isToday(t.createdAt)).length;
  const todayPaymentVolume = (db.paymentOrders || []).filter(o => o.status === 'paid' && _isToday(o.createdAt)).reduce((sum, o) => sum + Number(o.amount || 0), 0);
  const openComplaints = db.complaints.filter(c => !['resolved', 'rejected'].includes(c.status)).length;
  const openDisputes = (db.disputes || []).filter(d => !['resolved', 'rejected'].includes(d.status)).length;

  res.json({
    users: db.users.length,
    kycPending: db.kycRequests.filter(k => k.status !== 'approved').length,
    transactions: db.transactions.length,
    complaints: db.complaints.length,
    exchangeOrders: db.exchangeOrders.length,
    adminCommission,
    today: { newUsers: todayUsers, transactions: todayTransactions, revenue: todayCommission, paymentVolume: todayPaymentVolume },
    openComplaints,
    openDisputes,
  });
});

app.get('/api/admin/analytics', auth('admin'), (req, res) => {
  const days = Math.min(parseInt(req.query.days) || 30, 90);
  const db = readDb();
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const dayKey = (d) => new Date(d).toISOString().slice(0, 10);

  const withinWindow = (dateStr) => new Date(dateStr) >= cutoff;

  const revenueMap = {};
  db.commissions.filter(c => withinWindow(c.createdAt)).forEach(c => {
    const k = dayKey(c.createdAt);
    if (!revenueMap[k]) revenueMap[k] = { day: k, revenue: 0, userRewards: 0 };
    revenueMap[k].revenue += Number(c.adminCommission || 0);
    revenueMap[k].userRewards += Number(c.sellerCommission || 0);
  });

  const usersMap = {};
  db.users.filter(u => withinWindow(u.createdAt)).forEach(u => {
    const k = dayKey(u.createdAt);
    usersMap[k] = (usersMap[k] || 0) + 1;
  });

  const txnMap = {};
  db.transactions.filter(t => withinWindow(t.createdAt)).forEach(t => {
    const k = dayKey(t.createdAt);
    txnMap[k] = (txnMap[k] || 0) + 1;
  });

  const exchangeByCurrencyMap = {};
  db.exchangeOrders.filter(o => withinWindow(o.createdAt)).forEach(o => {
    const k = `${o.fromCurrency}->${o.toCurrency}`;
    if (!exchangeByCurrencyMap[k]) exchangeByCurrencyMap[k] = { from_currency: o.fromCurrency, to_currency: o.toCurrency, order_count: 0, total_amount: 0 };
    exchangeByCurrencyMap[k].order_count += 1;
    exchangeByCurrencyMap[k].total_amount += Number(o.amount || 0);
  });

  const paymentStatusMap = {};
  (db.paymentOrders || []).filter(o => withinWindow(o.createdAt)).forEach(o => {
    if (!paymentStatusMap[o.status]) paymentStatusMap[o.status] = { status: o.status, count: 0, total_amount: 0 };
    paymentStatusMap[o.status].count += 1;
    paymentStatusMap[o.status].total_amount += Number(o.amount || 0);
  });

  const exchangeStatusMap = {};
  db.exchangeOrders.filter(o => withinWindow(o.createdAt)).forEach(o => {
    exchangeStatusMap[o.status] = (exchangeStatusMap[o.status] || 0) + 1;
  });

  const kycMap = {};
  db.kycRequests.forEach(k => { kycMap[k.status] = (kycMap[k.status] || 0) + 1; });

  res.json({
    periodDays: days,
    revenueByDay: Object.values(revenueMap).sort((a, b) => a.day.localeCompare(b.day)),
    usersByDay: Object.entries(usersMap).map(([day, count]) => ({ day, count })).sort((a, b) => a.day.localeCompare(b.day)),
    transactionsByDay: Object.entries(txnMap).map(([day, count]) => ({ day, count })).sort((a, b) => a.day.localeCompare(b.day)),
    exchangeByCurrency: Object.values(exchangeByCurrencyMap).sort((a, b) => b.order_count - a.order_count).slice(0, 10),
    paymentStatusBreakdown: Object.values(paymentStatusMap),
    exchangeStatusBreakdown: Object.entries(exchangeStatusMap).map(([status, count]) => ({ status, count })),
    kycBreakdown: Object.entries(kycMap).map(([status, count]) => ({ status, count })),
  });
});

app.get('/api/admin/users', auth('admin'), (req, res) => {
  const db = readDb();
  res.json(db.users.map(publicUser));
});


// OTP and Email Verification APIs
// SECURITY: the OTP is only echoed back in the response when the operator
// explicitly opts in via ALLOW_DEV_OTP_IN_RESPONSE=true (NODE_ENV alone is
// not reliable on most hosts, so it must never be used as this gate).
app.post('/api/auth/request-otp', otpRequestLimiter, async (req, res) => {
  const { email, purpose = 'email_verification' } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  const db = readDb();
  db.otpCodes = db.otpCodes || [];
  const otp = generateOtp();
  db.otpCodes.push({ id: uuid(), email, purpose, otpHash: await hashOtp(otp), expiresAt: otpExpiry(10), used: false, createdAt: new Date().toISOString() });
  writeDb(db);
  await sendOtpEmail({ email, otp, purpose });
  res.json({ message: 'OTP sent', purpose, devOtp: DEV_OTP_IN_RESPONSE ? otp : undefined });
});

app.post('/api/auth/verify-email-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const db = readDb();
  const item = (db.otpCodes || []).reverse().find(o => o.email === email && o.purpose === 'email_verification' && !o.used);
  if (!item || isExpired(item.expiresAt) || !(await compareOtp(otp, item.otpHash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  item.used = true;
  const user = db.users.find(u => u.email === email);
  if (user) user.emailVerified = true;
  writeDb(db);
  res.json({ message: 'Email verified' });
});

app.post('/api/auth/login-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const db = readDb();
  const item = (db.otpCodes || []).reverse().find(o => o.email === email && o.purpose === 'login' && !o.used);
  if (!item || isExpired(item.expiresAt) || !(await compareOtp(otp, item.otpHash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  const user = db.users.find(u => u.email === email);
  if (!user) return res.status(404).json({ error: 'User not found' });
  item.used = true;
  const session = issueAuthSession(db, { ownerType: 'user', ownerId: user.id, payload: { id: user.id, role: 'user' }, req });
  writeDb(db);
  res.json({ ...session, user: publicUser(user) });
});

// Payment Gateway Structure APIs
app.post('/api/payments/orders', auth('user'), async (req, res) => {
  const { amount, currency = 'INR', purpose = 'wallet_topup' } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'positive amount required' });
  const db = readDb();
  if (purpose === 'wallet_topup') {
    const user = db.users.find(u => u.id === req.auth.id);
    try {
      enforceTierLimits(db, user, { action: 'topup', amount: Number(amount), currency });
    } catch (e) {
      return res.status(403).json({ error: e.message });
    }
  }
  const provider = getPaymentProvider();
  const gatewayOrder = await provider.createOrder({ amount: Number(amount), currency, receipt: `GX_${Date.now()}`, notes: { userId: req.auth.id, purpose } });
  db.paymentOrders = db.paymentOrders || [];
  const order = { id: uuid(), userId: req.auth.id, provider: gatewayOrder.provider, gatewayOrderId: gatewayOrder.gatewayOrderId, amount: Number(amount), currency, purpose, status: 'created', gatewayResponse: gatewayOrder, createdAt: new Date().toISOString() };
  db.paymentOrders.push(order);
  writeDb(db);
  res.json({ order, gatewayOrder });
});

app.post('/api/payments/verify', auth('user'), async (req, res) => {
  const { orderId, gatewayOrderId, gatewayPaymentId, gatewaySignature } = req.body;
  const db = readDb();
  const order = (db.paymentOrders || []).find(o => o.id === orderId && o.userId === req.auth.id);
  if (!order) return res.status(404).json({ error: 'Payment order not found' });
  const provider = getPaymentProvider(order.provider);
  const verification = await provider.verifyPayment({ gatewayOrderId: gatewayOrderId || order.gatewayOrderId, gatewayPaymentId, gatewaySignature });
  order.status = verification.verified ? 'paid' : 'verification_failed';
  order.verification = verification;
  if (verification.verified && order.purpose === 'wallet_topup') {
    const wallet = db.wallets.find(w => w.userId === req.auth.id);
    const topupUser = db.users.find(u => u.id === req.auth.id);
    wallet.balances[order.currency] = (wallet.balances[order.currency] || 0) + Number(order.amount);
    try {
      enforceWalletBalanceCap(topupUser, wallet, order.currency);
    } catch (e) {
      // Roll back the credit — the payment gateway has already captured the
      // money, so this is refunded/held rather than silently lost; a real
      // implementation should trigger an automatic refund via the payment
      // provider here. For now we flag it for admin manual handling.
      wallet.balances[order.currency] -= Number(order.amount);
      db.auditLogs = db.auditLogs || [];
      db.auditLogs.push({ id: uuid(), adminId: null, userId: req.auth.id, action: 'topup.blocked.wallet_cap_exceeded', entityType: 'payment_order', entityId: order.id, metadata: { amount: order.amount, currency: order.currency, reason: e.message }, createdAt: new Date().toISOString() });
      writeDb(db);
      return res.status(403).json({ error: e.message + ' Your payment was captured but could not be credited — please contact support for a refund or to complete KYC.' });
    }
    const txn = { id: uuid(), type: 'wallet_topup', fromUserId: null, toUserId: req.auth.id, amount: order.amount, currency: order.currency, status: 'completed', createdAt: new Date().toISOString() };
    db.transactions.push(txn);
    postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, amount: order.amount, currency: order.currency, referenceType: 'payment_order', referenceId: order.id, description: 'Wallet top-up via payment gateway' });
    checkAmlAndBalanceCap(db, topupUser, { amountInr: toApproxInr(order.amount, order.currency), referenceType: 'payment_order', referenceId: order.id, note: 'wallet top-up' });
    maybePayReferralRewardJson(db, req.auth.id);
  }

  const payUser = db.users.find(u => u.id === req.auth.id);
  if (verification.verified) {
    notifyUserJson(db, {
      userId: req.auth.id,
      userEmail: payUser?.email,
      type: 'payment_success',
      title: 'Payment Successful',
      message: `Aapka payment of ${order.currency} ${order.amount} successful ho gaya hai aur wallet mein credit ho gaya hai.`,
      metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
    });
  } else {
    notifyUserJson(db, {
      userId: req.auth.id,
      userEmail: payUser?.email,
      type: 'payment_failed',
      title: 'Payment Failed',
      message: `Aapka payment of ${order.currency} ${order.amount} verify nahi ho paya. Kripya dobara try karein ya support se contact karein.`,
      metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
    });
  }

  writeDb(db);
  res.json({ order, verification });
});

app.post('/api/payments/webhook', async (req, res) => {
  const provider = getPaymentProvider(process.env.PAYMENT_PROVIDER || 'mock');
  const signature = req.headers['x-razorpay-signature'];
  const raw = req.rawBody ? req.rawBody.toString() : JSON.stringify(req.body);

  if (process.env.PAYMENT_PROVIDER === 'razorpay') {
    if (!process.env.RAZORPAY_WEBHOOK_SECRET) {
      console.error('SECURITY: RAZORPAY_WEBHOOK_SECRET is not set while PAYMENT_PROVIDER=razorpay. Rejecting webhook.');
      return res.status(500).json({ error: 'Webhook not configured correctly' });
    }
    const verified = provider.verifyWebhookSignature(raw, signature, process.env.RAZORPAY_WEBHOOK_SECRET);
    if (!verified) return res.status(400).json({ error: 'Invalid webhook signature' });
    return res.json({ received: true, verified: true });
  }

  // Production: event idempotency and event type handling required.
  res.json({ received: true, verified: true });
});

app.post('/api/payments/refund', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const { orderId, gatewayPaymentId, amount, reason = 'admin_refund' } = req.body;
  const db = readDb();
  const order = (db.paymentOrders || []).find(o => o.id === orderId);
  if (!order) return res.status(404).json({ error: 'Payment order not found' });
  if (order.status !== 'paid') return res.status(400).json({ error: 'Only paid orders can be refunded' });
  const provider = getPaymentProvider(order.provider);
  const refund = await provider.refundPayment({ gatewayPaymentId: gatewayPaymentId || order.verification?.gatewayPaymentId, amount: amount || order.amount, notes: { reason, orderId } });
  db.refunds = db.refunds || [];
  const refundRecord = { id: uuid(), orderId, provider: order.provider, amount: Number(amount || order.amount), currency: order.currency, reason, status: refund.status || 'processed', gatewayRefund: refund, createdAt: new Date().toISOString() };
  db.refunds.push(refundRecord);
  order.status = 'refunded';
  const wallet = db.wallets.find(w => w.userId === order.userId);
  if (wallet) wallet.balances[order.currency] = Number(wallet.balances[order.currency] || 0) - Number(refundRecord.amount);
  db.transactions.push({ id: uuid(), type: 'refund', fromUserId: order.userId, toUserId: null, amount: refundRecord.amount, currency: order.currency, status: 'completed', createdAt: new Date().toISOString() });
  postLedger(db, { debit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, credit: { ownerType: 'user_wallet', ownerId: order.userId }, amount: refundRecord.amount, currency: order.currency, referenceType: 'refund', referenceId: refundRecord.id, description: 'Payment refund from wallet' });
  auditLog(db, { adminId: req.auth.id, action: 'payment.refund', entityType: 'payment_order', entityId: orderId, metadata: { refundId: refundRecord.id, amount: refundRecord.amount, currency: order.currency }, req });
  writeDb(db);
  res.json({ refund: refundRecord });
});


app.get('/api/admin/kyc-requests', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const db = readDb();
  // Exclude the heavy `documents` field from the list view; admin fetches it
  // individually via the endpoint below.
  const rows = db.kycRequests.map(k => {
    const { documents: _omit, ...rest } = k;
    return { ...rest, user: publicUser(db.users.find(u => u.id === k.userId) || {}) };
  });
  res.json(rows);
});

app.get('/api/admin/kyc-requests/:id/documents', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const db = readDb();
  const kyc = db.kycRequests.find(k => k.id === req.params.id);
  if (!kyc) return res.status(404).json({ error: 'KYC request not found' });
  auditLog(db, { adminId: req.auth.id, action: 'kyc.documents_viewed', entityType: 'kyc_request', entityId: req.params.id, req });
  writeDb(db);
  res.json({ documents: kyc.documents || [] });
});

app.get('/api/admin/refunds', auth('admin'), (req, res) => {
  const db = readDb();
  res.json(db.refunds || []);
});

app.get('/api/admin/payment-orders', auth('admin'), requirePermission('payments:read'), (req, res) => {
  const db = readDb();
  const rows = (db.paymentOrders || []).map(o => ({ ...o, user: publicUser(db.users.find(u => u.id === o.userId) || {}) }));
  res.json(rows);
});

app.get('/api/admin/ledger', auth('admin'), requirePermission('ledger:read'), (req, res) => {
  const db = readDb();
  res.json({ accounts: db.ledgerAccounts || [], entries: db.ledgerEntries || [] });
});



app.get('/api/admin/admins', auth('admin'), requirePermission('admin:manage'), (req, res) => {
  const db = readDb();
  res.json(db.admins.map(a => ({ id: a.id, email: a.email, role: a.role || 'admin', permissions: a.permissions || [], createdAt: a.createdAt })));
});

app.patch('/api/admin/admins/:id/role', auth('admin'), requirePermission('admin:manage'), (req, res) => {
  const { role, permissions } = req.body;
  const db = readDb();
  const admin = db.admins.find(a => a.id === req.params.id);
  if (!admin) return res.status(404).json({ error: 'Admin not found' });
  if (role) admin.role = role;
  if (Array.isArray(permissions)) admin.permissions = permissions;
  auditLog(db, { adminId: req.auth.id, action: 'admin.role_update', entityType: 'admin', entityId: admin.id, metadata: { role: admin.role, permissions: admin.permissions }, req });
  writeDb(db);
  res.json({ admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

app.get('/api/admin/audit-logs', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const db = readDb();
  res.json((db.auditLogs || []).slice().reverse().slice(0, 500));
});

// AML flags: a filtered view of audit logs specifically for large/unusual
// transactions that crossed the AML review thresholds in limits.js. See
// TECHNICAL_SAFEGUARDS_GUIDE.md for the rationale and how to tune
// thresholds via environment variables.
app.get('/api/admin/aml-flags', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const db = readDb();
  const flags = (db.auditLogs || [])
    .filter(a => a.action === 'aml.flag.large_transaction')
    .slice().reverse().slice(0, 500)
    .map(a => ({ ...a, user: publicUser(db.users.find(u => u.id === a.userId) || {}) }));
  res.json(flags);
});

// Crypto TDS (Section 194S) records: per-user, per-financial-year cumulative
// gross VDA-transfer value and TDS withheld, plus the individual deduction
// entries — this is what your CA needs to prepare Form 26QE filings.
app.get('/api/admin/tds-records', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const db = readDb();
  const records = (db.tdsRecords || []).map(r => ({ ...r, user: publicUser(db.users.find(u => u.id === r.userId) || {}) }));
  res.json(records);
});

// Sanctions/PEP screening flags — KYC submissions that matched an entry in
// the local sanctions dataset (see screening.js). These are NEVER
// auto-rejected; they require manual admin review to confirm/dismiss.
app.get('/api/admin/sanctions-flags', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const db = readDb();
  const flagged = (db.kycRequests || [])
    .filter(k => k.sanctionsScreening?.flagged)
    .map(k => ({
      kycRequestId: k.id,
      userId: k.userId,
      user: publicUser(db.users.find(u => u.id === k.userId) || {}),
      kycStatus: k.status,
      matches: k.sanctionsScreening.matches,
      screenedAt: k.sanctionsScreening.screenedAt,
      reviewStatus: k.sanctionsScreening.reviewStatus || 'pending_review',
      reviewNote: k.sanctionsScreening.reviewNote || null,
    }))
    .sort((a, b) => new Date(b.screenedAt) - new Date(a.screenedAt));
  res.json({ metadata: getSanctionsListMetadata(), flags: flagged });
});

// Admin marks a sanctions flag as reviewed (either confirming a genuine
// match — in which case the linked KYC should also be rejected/escalated
// separately — or dismissing it as a false positive, which is expected to
// be the common case for common names).
app.patch('/api/admin/sanctions-flags/:kycRequestId', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const { reviewStatus, reviewNote } = req.body; // reviewStatus: 'confirmed_match' | 'false_positive'
  if (!['confirmed_match', 'false_positive'].includes(reviewStatus)) return res.status(400).json({ error: "reviewStatus must be 'confirmed_match' or 'false_positive'" });
  const db = readDb();
  const kyc = db.kycRequests.find(k => k.id === req.params.kycRequestId);
  if (!kyc || !kyc.sanctionsScreening) return res.status(404).json({ error: 'Sanctions-flagged KYC request not found' });
  kyc.sanctionsScreening.reviewStatus = reviewStatus;
  kyc.sanctionsScreening.reviewNote = reviewNote || null;
  kyc.sanctionsScreening.reviewedBy = req.auth.id;
  kyc.sanctionsScreening.reviewedAt = new Date().toISOString();
  auditLog(db, { adminId: req.auth.id, action: 'sanctions.screening.reviewed', entityType: 'kyc_request', entityId: kyc.id, metadata: { reviewStatus, userId: kyc.userId }, req });
  writeDb(db);
  res.json({ kyc: { id: kyc.id, sanctionsScreening: kyc.sanctionsScreening } });
});

// Manually triggers a full re-sync of the sanctions dataset from the
// official OFAC + UN sources (see sanctions_sync.js). Exists specifically
// so an admin WITHOUT server shell access (e.g. Render free tier, or
// operating purely from a phone) can refresh the list from the admin
// panel — "🚫 Sanctions/PEP Screening Flags" section has a "Sync Now"
// button wired to this. Rate-limited since each call downloads several MB
// from external government sources and can take 10-30+ seconds.
const sanctionsSyncLimiter = rateLimit({ windowMs: 60 * 60_000, max: 6, keyFn: (req) => `sanctions-sync:${req.auth?.id || req.ip}`, message: 'Sanctions list sync can only be run a few times per hour. Please wait before trying again.' });
app.post('/api/admin/sanctions-sync', auth('admin'), requirePermission('kyc:manage'), sanctionsSyncLimiter, async (req, res) => {
  try {
    const summary = await syncSanctionsList({ writeToFile: true });
    const db = readDb();
    auditLog(db, { adminId: req.auth.id, action: 'sanctions.list.synced', entityType: 'sanctions_list', entityId: 'global', metadata: { entryCount: summary.entryCount, sources: summary.sources, errors: summary.errors }, req });
    writeDb(db);
    if (summary.entryCount === 0) {
      return res.status(502).json({ error: 'Sync failed for all sources — the sanctions list was NOT changed. Try again later.', summary });
    }
    res.json({ message: `Sanctions list synced: ${summary.entryCount} entries from ${summary.sources.filter(s => s.status !== 'failed').length} source(s).`, summary });
  } catch (e) {
    res.status(500).json({ error: 'Sync failed unexpectedly: ' + e.message });
  }
});

// Returns just the current sanctions list's metadata (source list, entry
// count, last-updated timestamp) — used by the admin panel to show "last
// synced: X" without downloading the full flags list.
app.get('/api/admin/sanctions-list-metadata', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  res.json(getSanctionsListMetadata());
});

// ---------------------------------------------------------------------------
// Cron-friendly sanctions sync trigger — deliberately separate from the
// admin-authenticated /api/admin/sanctions-sync endpoint above, so an
// external scheduler (the GitHub Actions weekly workflow — see
// .github/workflows/sanctions-sync.yml and SANCTIONS_AUTO_UPDATE_GUIDE.md)
// can trigger a sync WITHOUT needing your real admin email/password stored
// as a GitHub secret. Protected instead by a separate, single-purpose
// shared secret (SANCTIONS_CRON_SECRET env var) that only grants
// permission to do this one thing — if it ever leaked, the blast radius is
// "someone can force a sanctions-list refresh," not "someone has your
// admin login." If SANCTIONS_CRON_SECRET is not configured, this endpoint
// is disabled entirely (404) rather than silently accepting no auth.
// ---------------------------------------------------------------------------
app.post('/api/cron/sanctions-sync', sanctionsSyncLimiter, async (req, res) => {
  const configuredSecret = process.env.SANCTIONS_CRON_SECRET;
  if (!configuredSecret) return res.status(404).json({ error: 'Not found' });
  const providedSecret = req.headers['x-cron-secret'] || req.body?.secret;
  if (!providedSecret || providedSecret !== configuredSecret) return res.status(403).json({ error: 'Invalid or missing cron secret' });
  try {
    const summary = await syncSanctionsList({ writeToFile: true });
    const db = readDb();
    auditLog(db, { adminId: null, action: 'sanctions.list.synced', entityType: 'sanctions_list', entityId: 'global', metadata: { entryCount: summary.entryCount, sources: summary.sources, errors: summary.errors, trigger: 'cron' } });
    writeDb(db);
    if (summary.entryCount === 0) {
      return res.status(502).json({ error: 'Sync failed for all sources.', summary });
    }
    res.json({ message: `Sanctions list synced via cron: ${summary.entryCount} entries.`, summary });
  } catch (e) {
    res.status(500).json({ error: 'Sync failed unexpectedly: ' + e.message });
  }
});

// Travel Rule records — originator/beneficiary data captured for every VDA
// (crypto) transfer, as required under FIU-IND's AML/CFT guidance. This is
// the data you'd export/share with a counterparty VASP or provide to
// authorities on request. See travel_rule.js.
app.get('/api/admin/travel-rule-records', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const db = readDb();
  const records = (db.travelRuleRecords || []).slice().reverse().slice(0, 500);
  res.json(records);
});

// ---------------------------------------------------------------------------
// Suspicious Transaction Report (STR) workflow. Turns an AML flag (from
// checkAmlAndBalanceCap) or a sanctions match into a formal, trackable STR
// case that your Principal Officer can manage — with the data organized in
// the shape needed to actually file with FIU-IND (a manual portal
// submission process on FIU-IND's side, not an API this app can call
// directly — see FIU_IND_REGISTRATION_GUIDE.md).
// ---------------------------------------------------------------------------

// Admin creates a formal STR case from a flagged transaction/user.
app.post('/api/admin/str-reports', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const { userId, reason, sourceType, sourceId, notes = '' } = req.body;
  if (!userId || !reason) return res.status(400).json({ error: 'userId and reason are required' });
  const db = readDb();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  db.strReports = db.strReports || [];
  const str = {
    id: uuid(), userId, userSnapshot: publicUser(user), reason, sourceType: sourceType || null, sourceId: sourceId || null,
    notes, status: 'draft', // draft -> filed -> acknowledged (manually updated once actually submitted to FIU-IND)
    createdBy: req.auth.id, createdAt: new Date().toISOString(), filedAt: null, updatedAt: new Date().toISOString(),
  };
  db.strReports.push(str);
  auditLog(db, { adminId: req.auth.id, action: 'str.created', entityType: 'str_report', entityId: str.id, metadata: { userId, reason, sourceType, sourceId }, req });
  writeDb(db);
  res.json({ str });
});

app.get('/api/admin/str-reports', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const db = readDb();
  const rows = (db.strReports || []).slice().reverse();
  res.json(rows);
});

// Update an STR's status as it moves through the real-world filing process
// (draft -> filed once your PO actually submits it via FIU-IND's portal ->
// acknowledged once FIU-IND confirms receipt). This app does not and
// cannot auto-file with FIU-IND — filing is a manual, out-of-band
// compliance action; this endpoint just tracks that lifecycle for your
// records.
app.patch('/api/admin/str-reports/:id', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const { status, notes } = req.body;
  if (!['draft', 'filed', 'acknowledged', 'closed'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const db = readDb();
  const str = (db.strReports || []).find(s => s.id === req.params.id);
  if (!str) return res.status(404).json({ error: 'STR report not found' });
  str.status = status;
  if (notes !== undefined) str.notes = notes;
  if (status === 'filed' && !str.filedAt) str.filedAt = new Date().toISOString();
  str.updatedAt = new Date().toISOString();
  auditLog(db, { adminId: req.auth.id, action: 'str.status_updated', entityType: 'str_report', entityId: str.id, metadata: { status }, req });
  writeDb(db);
  res.json({ str });
});

app.get('/api/admin/roles', auth('admin'), requirePermission('admin:manage'), (req, res) => {
  res.json({
    roles: [
      { role: 'super_admin', permissions: ['*'] },
      { role: 'kyc_manager', permissions: ['users:read','kyc:manage','audit:read'] },
      { role: 'finance_manager', permissions: ['payments:read','refunds:manage','ledger:read','exchange:manage','audit:read'] },
      { role: 'support_agent', permissions: ['users:read','payments:read','disputes:manage','audit:read'] }
    ]
  });
});


app.patch('/api/admin/complaints/:id', auth('admin'), (req, res) => {
  const { status } = req.body;
  const db = readDb();
  const complaint = (db.complaints || []).find(c => c.id === req.params.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });
  complaint.status = status || complaint.status;
  complaint.updatedAt = new Date().toISOString();
  auditLog(db, { adminId: req.auth.id, action: `complaint.${complaint.status}`, entityType: 'complaint', entityId: complaint.id, metadata: { userId: complaint.userId, status: complaint.status }, req });
  writeDb(db);
  res.json({ complaint });
});

app.get('/api/admin/complaints', auth('admin'), (req, res) => {
  const db = readDb();
  res.json(db.complaints);
});

app.get('/api/admin/referrals', auth('admin'), (req, res) => {
  const db = readDb();
  const rows = (db.referrals || []).map(r => ({
    ...r,
    referrer: publicUser(db.users.find(u => u.id === r.referrerUserId) || {}),
    referred: publicUser(db.users.find(u => u.id === r.referredUserId) || {}),
  }));
  res.json(rows);
});

app.patch('/api/admin/kyc/:id', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const { status } = req.body;
  const db = readDb();
  const kyc = db.kycRequests.find(k => k.id === req.params.id);
  if (!kyc) return res.status(404).json({ error: 'KYC not found' });
  kyc.status = status;
  const user = db.users.find(u => u.id === kyc.userId);
  if (user) user.kycStatus = status;

  const isApproved = status === 'approved';
  notifyUserJson(db, {
    userId: kyc.userId,
    userEmail: user?.email,
    type: isApproved ? 'kyc_approved' : 'kyc_rejected',
    title: isApproved ? 'KYC Verified Successfully' : 'KYC Verification Update',
    message: isApproved
      ? 'Aapka KYC verify ho gaya hai. Ab aap bina limit ke transactions kar sakte hain.'
      : 'Aapka KYC document verify nahi ho paya. Kripya sahi/clear documents ke saath dobara submit karein.',
    metadata: { kycRequestId: kyc.id, status },
  });

  writeDb(db);
  res.json({ kyc });
});

// ---------------------------------------------------------------------------
// In-app notifications
// ---------------------------------------------------------------------------
app.get('/api/notifications', auth('user'), (req, res) => {
  const db = readDb();
  const limit = Math.min(parseInt(req.query.limit) || 30, 100);
  const offset = parseInt(req.query.offset) || 0;
  const all = (db.notifications || []).filter(n => n.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const notifications = all.slice(offset, offset + limit);
  const unreadCount = all.filter(n => !n.isRead).length;
  res.json({ notifications, unreadCount });
});

app.post('/api/notifications/:id/read', auth('user'), (req, res) => {
  const db = readDb();
  const notif = (db.notifications || []).find(n => n.id === req.params.id && n.userId === req.auth.id);
  if (!notif) return res.status(404).json({ error: 'Notification not found' });
  notif.isRead = true;
  writeDb(db);
  res.json({ notification: notif });
});

app.post('/api/notifications/read-all', auth('user'), (req, res) => {
  const db = readDb();
  (db.notifications || []).forEach(n => { if (n.userId === req.auth.id) n.isRead = true; });
  writeDb(db);
  res.json({ success: true });
});

// Global error-handling middleware — must be registered LAST. Catches
// everything forwarded by wrapAsyncHandler() above plus any synchronous
// throw in a middleware, instead of letting it crash the process. See
// server_pg.js for the fuller explanation of why this matters.
app.use((err, req, res, next) => {
  console.error('[unhandled route error]', req.method, req.path, err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Something went wrong on our end. Please try again.' });
});

process.on('uncaughtException', (err) => {
  console.error('[FATAL] Uncaught exception (process will continue running):', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[FATAL] Unhandled promise rejection (process will continue running):', reason);
});

app.listen(PORT, () => {
  console.log(`Global Exchanger API running on http://localhost:${PORT}`);
  // Fire-and-forget: does not block startup. See sanctions_sync.js's
  // maybeAutoSyncIfStale() doc comment for why this matters on Render's
  // free tier (no reliable long-running background timers between sleeps).
  maybeAutoSyncIfStale();
});
