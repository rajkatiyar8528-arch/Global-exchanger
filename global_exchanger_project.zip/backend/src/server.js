require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const fs = require('fs');
const path = require('path');
const { getPaymentProvider } = require('./payments/provider');
const { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail } = require('./otp');
const { notifyUserJson } = require('./notifications_json');
const { rateLimit, ipAndFieldKey, securityHeaders, isStrongPassword, buildCorsOptions } = require('./security');

const app = express();
app.set('trust proxy', true); // Render sits behind Cloudflare + its own internal proxy (multiple hops); trust all of them so req.ip reflects the real client IP for rate limiting.
app.use(securityHeaders);
app.use(cors(buildCorsOptions()));
app.use(express.json({ limit: '20mb', verify: (req, res, buf) => { req.rawBody = buf; } }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is not set. Refusing to start with an insecure default.');
  process.exit(1);
}
const DB_PATH = path.join(__dirname, '../data/db.json');

const loginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many login attempts. Please try again in 15 minutes.' });
const adminLoginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many admin login attempts. Please try again in 15 minutes.' });
const otpRequestLimiter = rateLimit({ windowMs: 10 * 60_000, max: 5, keyFn: ipAndFieldKey('email'), message: 'Too many OTP requests. Please wait before requesting again.' });
const otpVerifyLimiter = rateLimit({ windowMs: 10 * 60_000, max: 10, keyFn: ipAndFieldKey('email'), message: 'Too many OTP verification attempts. Please try again later.' });
const registerLimiter = rateLimit({ windowMs: 60 * 60_000, max: 10, keyFn: (req) => req.ip, message: 'Too many signup attempts from this network. Please try again later.' });
const generalApiLimiter = rateLimit({ windowMs: 60_000, max: 120, keyFn: (req) => req.ip, message: 'Too many requests. Please slow down.' });
app.use('/api', generalApiLimiter);
const DEV_OTP_IN_RESPONSE = String(process.env.ALLOW_DEV_OTP_IN_RESPONSE || '').toLowerCase() === 'true';

function readDb() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function writeDb(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}
function sign(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}
function auth(role = 'user') {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (role !== 'any' && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.auth = decoded;
      next();
    } catch (e) {
      return res.status(401).json({ error: 'Invalid token' });
    }
  };
}
function publicUser(user) {
  const { passwordHash, securityPinHash, ...safe } = user;
  return safe;
}


function auditLog(db, { adminId = null, userId = null, action, entityType, entityId, metadata = {}, req = null }) {
  db.auditLogs = db.auditLogs || [];
  const log = {
    id: uuid(), adminId, userId, action, entityType, entityId,
    metadata,
    ip: req?.ip || null,
    userAgent: req?.headers?.['user-agent'] || null,
    createdAt: new Date().toISOString()
  };
  db.auditLogs.push(log);
  return log;
}

function requirePermission(permission) {
  return (req, res, next) => {
    const db = readDb();
    const admin = db.admins.find(a => a.id === req.auth.id);
    if (!admin) return res.status(403).json({ error: 'Admin not found' });
    const permissions = admin.permissions || [];
    if (!permissions.includes(permission) && admin.role !== 'super_admin') return res.status(403).json({ error: `Missing permission: ${permission}` });
    req.admin = admin;
    next();
  };
}

function getLedgerAccount(db, ownerType, ownerId, currency) {
  db.ledgerAccounts = db.ledgerAccounts || [];
  let account = db.ledgerAccounts.find(a => a.ownerType === ownerType && a.ownerId === ownerId && a.currency === currency);
  if (!account) {
    account = { id: uuid(), ownerType, ownerId, currency, balance: 0, createdAt: new Date().toISOString() };
    db.ledgerAccounts.push(account);
  }
  return account;
}

function postLedger(db, { debit, credit, amount, currency, referenceType, referenceId, description }) {
  db.ledgerEntries = db.ledgerEntries || [];
  if (!amount || Number(amount) <= 0) throw new Error('Ledger amount must be positive');
  const debitAccount = getLedgerAccount(db, debit.ownerType, debit.ownerId, currency);
  const creditAccount = getLedgerAccount(db, credit.ownerType, credit.ownerId, currency);
  debitAccount.balance = Number(debitAccount.balance || 0) + Number(amount);
  creditAccount.balance = Number(creditAccount.balance || 0) - Number(amount);
  const groupId = uuid();
  const createdAt = new Date().toISOString();
  db.ledgerEntries.push({ id: uuid(), groupId, accountId: debitAccount.id, direction: 'debit', amount: Number(amount), currency, referenceType, referenceId, description, createdAt });
  db.ledgerEntries.push({ id: uuid(), groupId, accountId: creditAccount.id, direction: 'credit', amount: Number(amount), currency, referenceType, referenceId, description, createdAt });
  return { groupId, debitAccount, creditAccount };
}

function ensureAdmin() {
  const db = readDb();
  const email = process.env.ADMIN_EMAIL || 'admin@globalexchanger.com';
  if (!db.admins.find(a => a.email === email)) {
    db.admins.push({
      id: uuid(),
      email,
      passwordHash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Admin@12345', 10),
      specialKeyHash: bcrypt.hashSync(process.env.ADMIN_SPECIAL_KEY || 'GX-SUPER-KEY-2026', 10),
      role: 'super_admin',
      permissions: ['users:read','kyc:manage','payments:read','refunds:manage','exchange:manage','ledger:read','audit:read','admin:manage','disputes:manage'],
      createdAt: new Date().toISOString()
    });
    writeDb(db);
  }
}
ensureAdmin();

app.get('/', (req, res) => res.json({ app: 'Global Exchanger API', status: 'running' }));

app.post('/api/auth/register', registerLimiter, async (req, res) => {
  const { name, email, phone, country, address, houseNumber, password, referralCode } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  if (!isStrongPassword(password)) return res.status(400).json({ error: 'Password must be at least 8 characters and include both letters and numbers.' });
  const db = readDb();
  if (db.users.find(u => u.email === email)) return res.status(409).json({ error: 'Email already exists' });
  const user = {
    id: uuid(), name, email, phone, country, address, houseNumber,
    passwordHash: await bcrypt.hash(password, 10),
    securityPinHash: null,
    kycStatus: 'pending',
    emailVerified: false,
    referralCode: `GX${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
    referredBy: referralCode || null,
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  db.wallets.push({ userId: user.id, balances: { INR: 0, USD: 0, EUR: 0, BTC: 0, ETH: 0, XRP: 0 }, locked: {}, rewardBalances: { INR: 0, USD: 0, EUR: 0, BTC: 0, ETH: 0, XRP: 0 } });
  if (referralCode) db.referrals.push({ id: uuid(), referrerCode: referralCode, referredUserId: user.id, reward: 100, currency: 'INR', status: 'pending_account_created', createdAt: new Date().toISOString() });
  writeDb(db);
  res.json({ token: sign({ id: user.id, role: 'user' }), user: publicUser(user) });
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Invalid login' });
  const db = readDb();
  const user = db.users.find(u => u.email === email);
  const passwordHash = user?.passwordHash || '$2a$10$CwTycUXWue0Thq9StjUM0uJ8gI0mZzn0EXAMPLEHASHVALUEXXXXX';
  const passwordOk = await bcrypt.compare(password, passwordHash);
  if (!user || !passwordOk) return res.status(401).json({ error: 'Invalid email or password' });
  res.json({ token: sign({ id: user.id, role: 'user' }), user: publicUser(user) });
});

app.post('/api/admin/login', adminLoginLimiter, async (req, res) => {
  const { email, password, specialKey } = req.body;
  if (!email || !password || !specialKey) return res.status(400).json({ error: 'Invalid admin login' });
  const db = readDb();
  const admin = db.admins.find(a => a.email === email);
  if (!admin) return res.status(401).json({ error: 'Invalid admin login' });
  const ok = await bcrypt.compare(password, admin.passwordHash) && await bcrypt.compare(specialKey, admin.specialKeyHash);
  if (!ok) return res.status(401).json({ error: 'Invalid admin login' });
  auditLog(db, { adminId: admin.id, action: 'admin.login', entityType: 'admin', entityId: admin.id, req });
  writeDb(db);
  res.json({ token: sign({ id: admin.id, role: 'admin' }), admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

app.get('/api/me', auth('user'), (req, res) => {
  const db = readDb();
  const user = db.users.find(u => u.id === req.auth.id);
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  res.json({ user: publicUser(user), wallet });
});

app.post('/api/security/pin', auth('user'), async (req, res) => {
  const { pin } = req.body;
  const pinStr = String(pin || '');
  if (!/^\d{4,6}$/.test(pinStr)) return res.status(400).json({ error: 'PIN must be 4-6 digits' });
  const isAllSameDigit = /^(\d)\1+$/.test(pinStr);
  const isSequential = '0123456789'.includes(pinStr) || '9876543210'.includes(pinStr);
  if (isAllSameDigit || isSequential) return res.status(400).json({ error: 'This PIN is too easy to guess. Please choose a different one.' });
  const db = readDb();
  const user = db.users.find(u => u.id === req.auth.id);
  user.securityPinHash = await bcrypt.hash(pinStr, 10);
  writeDb(db);
  res.json({ message: 'Security PIN created' });
});

// KYC documents are accepted as base64 data URLs from the app (no external
// storage account needed). We cap the number/size of documents so a bad or
// huge upload can't blow up the JSON db file.
const MAX_KYC_DOCUMENTS = 5;
const MAX_KYC_DOCUMENT_BYTES = 4 * 1024 * 1024; // ~4MB per document (post base64-decode)
const ALLOWED_KYC_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

function sanitizeKycDocuments(documents) {
  if (!Array.isArray(documents)) return [];
  if (documents.length > MAX_KYC_DOCUMENTS) throw new Error(`Maximum ${MAX_KYC_DOCUMENTS} documents allowed`);
  return documents.map((doc, i) => {
    const label = String(doc?.label || `Document ${i + 1}`).slice(0, 100);
    const mimeType = String(doc?.mimeType || '');
    const dataBase64 = String(doc?.dataBase64 || '');
    if (!ALLOWED_KYC_MIME_TYPES.includes(mimeType)) throw new Error(`Unsupported document type: ${mimeType || 'unknown'}`);
    if (!dataBase64) throw new Error(`${label}: document data is empty`);
    const approxBytes = Math.floor((dataBase64.length * 3) / 4);
    if (approxBytes > MAX_KYC_DOCUMENT_BYTES) throw new Error(`${label} is too large (max 4MB per document)`);
    return { label, mimeType, dataBase64, uploadedAt: new Date().toISOString() };
  });
}

app.post('/api/kyc', auth('user'), (req, res) => {
  try {
    const { nationalId, taxId, country, documents = [] } = req.body;
    const sanitizedDocs = sanitizeKycDocuments(documents);
    const documentNames = sanitizedDocs.map(d => d.label);
    const db = readDb();
    const kyc = { id: uuid(), userId: req.auth.id, nationalId, taxId, country, documentNames, documents: sanitizedDocs, status: 'under_review', createdAt: new Date().toISOString() };
    db.kycRequests.push(kyc);
    const user = db.users.find(u => u.id === req.auth.id);
    user.kycStatus = 'under_review';
    auditLog(db, { userId: req.auth.id, action: 'kyc.submitted', entityType: 'kyc_request', entityId: kyc.id, metadata: { userId: kyc.userId, status: kyc.status, documentCount: sanitizedDocs.length }, req });
    writeDb(db);
    const { documents: _omit, ...kycWithoutDocs } = kyc;
    res.json({ kyc: kycWithoutDocs });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/kyc/me', auth('user'), (req, res) => {
  const db = readDb();
  const rows = db.kycRequests.filter(k => k.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const latest = rows[0];
  if (!latest) return res.json({ kyc: null });
  const { documents: _omit, ...kycWithoutDocs } = latest;
  res.json({ kyc: kycWithoutDocs });
});

app.post('/api/bank-accounts', auth('user'), (req, res) => {
  const { holderName, bankName, accountNumber, ifscSwiftIban, country } = req.body;
  const db = readDb();
  const account = { id: uuid(), userId: req.auth.id, holderName, bankName, accountNumberMasked: String(accountNumber || '').slice(-4).padStart(8, '*'), ifscSwiftIban, country, status: 'pending_verification', createdAt: new Date().toISOString() };
  db.bankAccounts.push(account);
  writeDb(db);
  res.json({ account });
});

app.get('/api/wallet', auth('user'), (req, res) => {
  const db = readDb();
  res.json(db.wallets.find(w => w.userId === req.auth.id));
});

// Move reward wallet balance into the main spendable wallet balance for one currency.
app.post('/api/wallet/redeem-rewards', auth('user'), (req, res) => {
  const { currency = 'INR' } = req.body;
  const db = readDb();
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  wallet.rewardBalances = wallet.rewardBalances || {};
  const amount = Number(wallet.rewardBalances[currency] || 0);
  if (amount <= 0) return res.status(400).json({ error: 'No reward balance available to redeem for this currency' });
  wallet.rewardBalances[currency] = 0;
  wallet.balances[currency] = Number(wallet.balances[currency] || 0) + amount;
  postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, amount, currency, referenceType: 'reward_redeem', referenceId: req.auth.id, description: 'Reward wallet redeemed into main wallet balance' });
  writeDb(db);
  res.json({ redeemed: amount, currency, wallet });
});

// ---------------------------------------------------------------------------
// Live exchange rates (forex + crypto), fetched from free public APIs and
// cached in-memory for 60 seconds. Falls back to last known good rates (or
// the original static demo numbers if we've never fetched successfully) so
// the app never breaks even if the upstream providers are down.
// ---------------------------------------------------------------------------
let _ratesCache = null;
let _ratesCacheExpiry = 0;
const RATES_CACHE_MS = 60_000;
const STATIC_FALLBACK_RATES = {
  forex: { USD_INR: 83.5, EUR_INR: 90.2, GBP_INR: 106.1, AED_INR: 22.7 },
  crypto: { BTC_USD: 65000, ETH_USD: 3400, XRP_USD: 0.52, BTC_INR: 5427500 }
};

async function fetchLiveRates() {
  const [forexRes, cryptoRes] = await Promise.allSettled([
    fetch('https://open.er-api.com/v6/latest/USD').then(r => r.json()),
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,ripple&vs_currencies=usd,inr').then(r => r.json())
  ]);

  let forex = null;
  if (forexRes.status === 'fulfilled' && forexRes.value?.result === 'success') {
    const r = forexRes.value.rates;
    forex = {
      USD_INR: r.INR,
      EUR_INR: r.INR / r.EUR,
      GBP_INR: r.INR / r.GBP,
      AED_INR: r.INR / r.AED
    };
  }

  let crypto = null;
  if (cryptoRes.status === 'fulfilled' && cryptoRes.value?.bitcoin) {
    const c = cryptoRes.value;
    crypto = {
      BTC_USD: c.bitcoin?.usd,
      ETH_USD: c.ethereum?.usd,
      XRP_USD: c.ripple?.usd,
      BTC_INR: c.bitcoin?.inr
    };
  }

  if (!forex && !crypto) throw new Error('Both forex and crypto providers failed');
  return { forex, crypto };
}

async function getRates() {
  const now = Date.now();
  if (_ratesCache && now < _ratesCacheExpiry) return _ratesCache;

  try {
    const live = await fetchLiveRates();
    _ratesCache = {
      source: 'live',
      updatedAt: new Date().toISOString(),
      forex: live.forex || _ratesCache?.forex || STATIC_FALLBACK_RATES.forex,
      crypto: live.crypto || _ratesCache?.crypto || STATIC_FALLBACK_RATES.crypto
    };
  } catch (e) {
    console.error('Live rate fetch failed, using fallback:', e.message);
    _ratesCache = _ratesCache || {
      source: 'demo_fallback',
      updatedAt: new Date().toISOString(),
      forex: STATIC_FALLBACK_RATES.forex,
      crypto: STATIC_FALLBACK_RATES.crypto
    };
  }

  _ratesCacheExpiry = now + RATES_CACHE_MS;
  return _ratesCache;
}

app.get('/api/rates', async (req, res) => {
  const rates = await getRates();
  res.json(rates);
});

const sendMoneyPinLimiter = rateLimit({ windowMs: 15 * 60_000, max: 8, keyFn: (req) => `pin:${req.auth?.id || req.ip}`, message: 'Too many incorrect PIN attempts. Please try again in 15 minutes.' });

app.post('/api/transactions/send', auth('user'), sendMoneyPinLimiter, async (req, res) => {
  const { toUserId, receiver, toEmail, amount, currency = 'INR', pin, note = '' } = req.body;
  const numericAmount = Number(amount);
  if (!numericAmount || numericAmount <= 0) return res.status(400).json({ error: 'positive amount required' });
  const db = readDb();
  const sender = db.users.find(u => u.id === req.auth.id);
  if (!sender.securityPinHash || !(await bcrypt.compare(String(pin), sender.securityPinHash))) return res.status(403).json({ error: 'Invalid security PIN' });
  const receiverKey = String(toUserId || receiver || toEmail || '').trim();
  if (!receiverKey) return res.status(400).json({ error: 'receiver email or userId required' });
  const receiverUser = db.users.find(u => u.id === receiverKey || String(u.email).toLowerCase() === receiverKey.toLowerCase() || String(u.phone || '') === receiverKey);
  if (!receiverUser) return res.status(404).json({ error: 'Receiver not found' });
  if (receiverUser.id === req.auth.id) return res.status(400).json({ error: 'Cannot send money to yourself' });
  const fromWallet = db.wallets.find(w => w.userId === req.auth.id);
  const toWallet = db.wallets.find(w => w.userId === receiverUser.id);
  if (!toWallet) return res.status(404).json({ error: 'Receiver wallet not found' });
  if ((fromWallet.balances[currency] || 0) < numericAmount) return res.status(400).json({ error: 'Insufficient balance' });
  fromWallet.balances[currency] -= numericAmount;
  toWallet.balances[currency] = (toWallet.balances[currency] || 0) + numericAmount;
  const txn = { id: uuid(), type: 'send', fromUserId: req.auth.id, toUserId: receiverUser.id, amount: numericAmount, currency, status: 'completed', note, createdAt: new Date().toISOString() };
  db.transactions.push(txn);
  postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: receiverUser.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: numericAmount, currency, referenceType: 'transaction', referenceId: txn.id, description: 'User to user wallet send/receive' });
  writeDb(db);
  res.json({ transaction: txn, receiver: publicUser(receiverUser) });
});

app.post('/api/exchange/orders', auth('user'), (req, res) => {
  const { fromCurrency, toCurrency, amount, mode = 'convert' } = req.body;
  const commission = Number(amount) * 0.01;
  const adminCommission = Number(amount) * 0.008;
  const sellerCommission = Number(amount) * 0.002;
  const db = readDb();
  const order = { id: uuid(), userId: req.auth.id, mode, fromCurrency, toCurrency, amount, status: 'pending_match', escrowStatus: 'not_locked', commission, adminCommission, sellerCommission, createdAt: new Date().toISOString() };
  db.exchangeOrders.push(order);
  db.commissions.push({ id: uuid(), orderId: order.id, adminCommission, sellerCommission, status: 'pending' });
  // Commission ledger structure: pending commission receivable and split liabilities.
  postLedger(db, { debit: { ownerType: 'platform_commission_receivable', ownerId: 'exchange' }, credit: { ownerType: 'exchange_user_payable', ownerId: req.auth.id }, amount: commission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '1% exchange commission accrued' });
  postLedger(db, { debit: { ownerType: 'admin_commission_earning', ownerId: 'admin' }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: adminCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.8% admin commission split' });
  postLedger(db, { debit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, credit: { ownerType: 'platform_commission_pool', ownerId: 'exchange' }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% seller/user commission split' });

  // Reward wallet credit: move 0.2% (sellerCommission) into the user's rewardBalances
  // so it is actually visible/usable, not just recorded in the ledger.
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  wallet.rewardBalances = wallet.rewardBalances || {};
  wallet.rewardBalances[fromCurrency] = (wallet.rewardBalances[fromCurrency] || 0) + sellerCommission;
  postLedger(db, { debit: { ownerType: 'user_reward_wallet', ownerId: req.auth.id }, credit: { ownerType: 'seller_commission_earning', ownerId: req.auth.id }, amount: sellerCommission, currency: fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% reward credited to user reward wallet' });

  const rewardUser = db.users.find(u => u.id === req.auth.id);
  notifyUserJson(db, {
    userId: req.auth.id,
    userEmail: rewardUser?.email,
    type: 'reward_credited',
    title: 'Reward Credited',
    message: `Aapko ${fromCurrency} ${sellerCommission.toFixed(4)} ka reward mila hai is exchange order par. Wallet screen ke "Reward Wallet" section mein dekhein.`,
    metadata: { orderId: order.id, amount: sellerCommission, currency: fromCurrency },
    sendEmail: false,
  });

  writeDb(db);
  res.json({ order });
});


app.post('/api/exchange/orders/:id/lock-escrow', auth('user'), async (req, res) => {
  const db = readDb();
  const order = db.exchangeOrders.find(o => o.id === req.params.id && o.userId === req.auth.id);
  if (!order) return res.status(404).json({ error: 'Exchange order not found' });
  if (order.escrowStatus === 'locked') return res.status(400).json({ error: 'Escrow already locked' });
  const wallet = db.wallets.find(w => w.userId === req.auth.id);
  if ((wallet.balances[order.fromCurrency] || 0) < Number(order.amount)) return res.status(400).json({ error: 'Insufficient balance for escrow' });
  wallet.balances[order.fromCurrency] -= Number(order.amount);
  wallet.locked[order.fromCurrency] = (wallet.locked[order.fromCurrency] || 0) + Number(order.amount);
  order.status = 'escrow_locked';
  order.escrowStatus = 'locked';
  postLedger(db, { debit: { ownerType: 'exchange_escrow', ownerId: order.id }, credit: { ownerType: 'user_wallet', ownerId: req.auth.id }, amount: order.amount, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Exchange amount locked in escrow' });
  writeDb(db);
  res.json({ order });
});

app.post('/api/admin/exchange/orders/:id/complete', auth('admin'), requirePermission('exchange:manage'), (req, res) => {
  const { rate, receiveAmount } = req.body;
  const db = readDb();
  const order = db.exchangeOrders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Exchange order not found' });
  if (order.escrowStatus !== 'locked') return res.status(400).json({ error: 'Escrow must be locked before completion' });
  const wallet = db.wallets.find(w => w.userId === order.userId);
  const finalReceive = Number(receiveAmount || (Number(order.amount) * Number(rate || 1)));
  wallet.locked[order.fromCurrency] = Math.max(0, Number(wallet.locked[order.fromCurrency] || 0) - Number(order.amount));
  wallet.balances[order.toCurrency] = Number(wallet.balances[order.toCurrency] || 0) + finalReceive;
  order.status = 'completed';
  order.escrowStatus = 'released';
  order.rate = Number(rate || 1);
  order.receiveAmount = finalReceive;
  order.completedAt = new Date().toISOString();
  db.transactions.push({ id: uuid(), type: 'exchange_complete', fromUserId: order.userId, toUserId: order.userId, amount: finalReceive, currency: order.toCurrency, status: 'completed', createdAt: new Date().toISOString() });
  postLedger(db, { debit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow source currency released to exchange pool' });
  postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: order.userId }, credit: { ownerType: 'exchange_liquidity', ownerId: 'pool' }, amount: finalReceive, currency: order.toCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Converted currency credited to user wallet' });
  auditLog(db, { adminId: req.auth.id, action: 'exchange.complete', entityType: 'exchange_order', entityId: order.id, metadata: { rate: order.rate, receiveAmount: finalReceive }, req });

  const exUser = db.users.find(u => u.id === order.userId);
  notifyUserJson(db, {
    userId: order.userId,
    userEmail: exUser?.email,
    type: 'exchange_completed',
    title: 'Exchange Order Completed',
    message: `Aapka ${order.fromCurrency} to ${order.toCurrency} exchange complete ho gaya hai. Aapko ${order.toCurrency} ${finalReceive} mila hai.`,
    metadata: { orderId: order.id, receiveAmount: finalReceive, toCurrency: order.toCurrency },
  });

  writeDb(db);
  res.json({ order });
});

app.post('/api/admin/exchange/orders/:id/cancel', auth('admin'), requirePermission('exchange:manage'), (req, res) => {
  const db = readDb();
  const order = db.exchangeOrders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Exchange order not found' });
  if (order.status === 'cancelled') return res.status(400).json({ error: 'Order already cancelled' });
  if (order.status === 'completed') return res.status(400).json({ error: 'Cannot cancel a completed order' });
  const wallet = db.wallets.find(w => w.userId === order.userId);
  if (order.escrowStatus === 'locked') {
    wallet.locked[order.fromCurrency] = Math.max(0, Number(wallet.locked[order.fromCurrency] || 0) - Number(order.amount));
    wallet.balances[order.fromCurrency] = Number(wallet.balances[order.fromCurrency] || 0) + Number(order.amount);
    postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: order.userId }, credit: { ownerType: 'exchange_escrow', ownerId: order.id }, amount: order.amount, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: 'Escrow returned to user after cancellation' });
  }

  // Reverse the 0.2% reward that was credited when the order was created.
  // Priority 1: take it back from the reward wallet (normal case).
  // Priority 2: if already redeemed into the main wallet, claw back what's left there
  //             (never push balance below zero). Anything still unrecovered is audit-logged.
  wallet.rewardBalances = wallet.rewardBalances || {};
  const sellerCommission = Number(order.sellerCommission || 0);
  if (sellerCommission > 0) {
    let remaining = sellerCommission;

    const currentReward = Number(wallet.rewardBalances[order.fromCurrency] || 0);
    const fromReward = Math.min(currentReward, remaining);
    if (fromReward > 0) {
      wallet.rewardBalances[order.fromCurrency] = currentReward - fromReward;
      remaining -= fromReward;
      postLedger(db, { debit: { ownerType: 'seller_commission_earning', ownerId: order.userId }, credit: { ownerType: 'user_reward_wallet', ownerId: order.userId }, amount: fromReward, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% reward reversed due to order cancellation' });
    }

    if (remaining > 0) {
      const currentMainBalance = Number(wallet.balances[order.fromCurrency] || 0);
      const fromMainWallet = Math.min(currentMainBalance, remaining);
      if (fromMainWallet > 0) {
        wallet.balances[order.fromCurrency] = currentMainBalance - fromMainWallet;
        remaining -= fromMainWallet;
        postLedger(db, { debit: { ownerType: 'seller_commission_earning', ownerId: order.userId }, credit: { ownerType: 'user_wallet', ownerId: order.userId }, amount: fromMainWallet, currency: order.fromCurrency, referenceType: 'exchange_order', referenceId: order.id, description: '0.2% already-redeemed reward clawed back from main wallet due to order cancellation' });
      }
    }

    if (remaining > 0) {
      auditLog(db, { adminId: req.auth.id, action: 'exchange.cancel.reward_reversal_incomplete', entityType: 'exchange_order', entityId: order.id, metadata: { currency: order.fromCurrency, unrecovered: remaining }, req });
    }
  }

  order.status = 'cancelled';
  order.escrowStatus = 'cancelled';
  auditLog(db, { adminId: req.auth.id, action: 'exchange.cancel', entityType: 'exchange_order', entityId: order.id, req });

  const cancelUser = db.users.find(u => u.id === order.userId);
  notifyUserJson(db, {
    userId: order.userId,
    userEmail: cancelUser?.email,
    type: 'exchange_cancelled',
    title: 'Exchange Order Cancelled',
    message: `Aapka ${order.fromCurrency} to ${order.toCurrency} exchange order cancel kar diya gaya hai. Locked amount aapke wallet mein wapas kar diya gaya hai.`,
    metadata: { orderId: order.id },
  });

  writeDb(db);
  res.json({ order });
});

app.get('/api/admin/exchange/orders', auth('admin'), requirePermission('exchange:manage'), (req, res) => {
  const db = readDb();
  res.json(db.exchangeOrders.map(o => ({ ...o, user: publicUser(db.users.find(u => u.id === o.userId) || {}) })));
});


app.post('/api/disputes', auth('user'), (req, res) => {
  const { transactionId, reason, message, evidence = [] } = req.body;
  if (!reason || !message) return res.status(400).json({ error: 'reason and message required' });
  const db = readDb();
  db.disputes = db.disputes || [];
  const dispute = { id: uuid(), userId: req.auth.id, transactionId: transactionId || null, reason, message, evidence, status: 'submitted', adminNote: null, resolution: null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  db.disputes.push(dispute);
  writeDb(db);
  res.json({ dispute });
});

app.get('/api/disputes', auth('user'), (req, res) => {
  const db = readDb();
  res.json((db.disputes || []).filter(d => d.userId === req.auth.id));
});

app.get('/api/admin/disputes', auth('admin'), requirePermission('disputes:manage'), (req, res) => {
  const db = readDb();
  const rows = (db.disputes || []).map(d => ({ ...d, user: publicUser(db.users.find(u => u.id === d.userId) || {}) }));
  res.json(rows);
});

app.patch('/api/admin/disputes/:id', auth('admin'), requirePermission('disputes:manage'), (req, res) => {
  const { status, adminNote, resolution } = req.body;
  const db = readDb();
  const dispute = (db.disputes || []).find(d => d.id === req.params.id);
  if (!dispute) return res.status(404).json({ error: 'Dispute not found' });
  if (status) dispute.status = status;
  if (adminNote !== undefined) dispute.adminNote = adminNote;
  if (resolution !== undefined) dispute.resolution = resolution;
  dispute.updatedAt = new Date().toISOString();
  auditLog(db, { adminId: req.auth.id, action: `dispute.${dispute.status}`, entityType: 'dispute', entityId: dispute.id, metadata: { userId: dispute.userId, status: dispute.status }, req });
  writeDb(db);
  res.json({ dispute });
});

app.post('/api/complaints', auth('user'), (req, res) => {
  const { subject, message, transactionId } = req.body;
  const db = readDb();
  const complaint = { id: uuid(), userId: req.auth.id, subject, message, transactionId, status: 'submitted', createdAt: new Date().toISOString() };
  db.complaints.push(complaint);
  writeDb(db);
  res.json({ complaint });
});

app.get('/api/transactions', auth('user'), (req, res) => {
  const db = readDb();
  res.json(db.transactions.filter(t => t.fromUserId === req.auth.id || t.toUserId === req.auth.id));
});

app.get('/api/admin/dashboard', auth('admin'), (req, res) => {
  const db = readDb();
  const adminCommission = db.commissions.reduce((sum, c) => sum + (c.adminCommission || 0), 0);
  res.json({
    users: db.users.length,
    kycPending: db.kycRequests.filter(k => k.status !== 'approved').length,
    transactions: db.transactions.length,
    complaints: db.complaints.length,
    exchangeOrders: db.exchangeOrders.length,
    adminCommission
  });
});

app.get('/api/admin/users', auth('admin'), (req, res) => {
  const db = readDb();
  res.json(db.users.map(publicUser));
});


// OTP and Email Verification APIs
// SECURITY: the OTP is only echoed back in the response when the operator
// explicitly opts in via ALLOW_DEV_OTP_IN_RESPONSE=true (NODE_ENV alone is
// not reliable on most hosts, so it must never be used as this gate).
app.post('/api/auth/request-otp', otpRequestLimiter, async (req, res) => {
  const { email, purpose = 'email_verification' } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Valid email required' });
  const db = readDb();
  db.otpCodes = db.otpCodes || [];
  const otp = generateOtp();
  db.otpCodes.push({ id: uuid(), email, purpose, otpHash: await hashOtp(otp), expiresAt: otpExpiry(10), used: false, createdAt: new Date().toISOString() });
  writeDb(db);
  await sendOtpEmail({ email, otp, purpose });
  res.json({ message: 'OTP sent', purpose, devOtp: DEV_OTP_IN_RESPONSE ? otp : undefined });
});

app.post('/api/auth/verify-email-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const db = readDb();
  const item = (db.otpCodes || []).reverse().find(o => o.email === email && o.purpose === 'email_verification' && !o.used);
  if (!item || isExpired(item.expiresAt) || !(await compareOtp(otp, item.otpHash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  item.used = true;
  const user = db.users.find(u => u.email === email);
  if (user) user.emailVerified = true;
  writeDb(db);
  res.json({ message: 'Email verified' });
});

app.post('/api/auth/login-otp', otpVerifyLimiter, async (req, res) => {
  const { email, otp } = req.body;
  const db = readDb();
  const item = (db.otpCodes || []).reverse().find(o => o.email === email && o.purpose === 'login' && !o.used);
  if (!item || isExpired(item.expiresAt) || !(await compareOtp(otp, item.otpHash))) return res.status(400).json({ error: 'Invalid or expired OTP' });
  const user = db.users.find(u => u.email === email);
  if (!user) return res.status(404).json({ error: 'User not found' });
  item.used = true;
  writeDb(db);
  res.json({ token: sign({ id: user.id, role: 'user' }), user: publicUser(user) });
});

// Payment Gateway Structure APIs
app.post('/api/payments/orders', auth('user'), async (req, res) => {
  const { amount, currency = 'INR', purpose = 'wallet_topup' } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'positive amount required' });
  const provider = getPaymentProvider();
  const gatewayOrder = await provider.createOrder({ amount: Number(amount), currency, receipt: `GX_${Date.now()}`, notes: { userId: req.auth.id, purpose } });
  const db = readDb();
  db.paymentOrders = db.paymentOrders || [];
  const order = { id: uuid(), userId: req.auth.id, provider: gatewayOrder.provider, gatewayOrderId: gatewayOrder.gatewayOrderId, amount: Number(amount), currency, purpose, status: 'created', gatewayResponse: gatewayOrder, createdAt: new Date().toISOString() };
  db.paymentOrders.push(order);
  writeDb(db);
  res.json({ order, gatewayOrder });
});

app.post('/api/payments/verify', auth('user'), async (req, res) => {
  const { orderId, gatewayOrderId, gatewayPaymentId, gatewaySignature } = req.body;
  const db = readDb();
  const order = (db.paymentOrders || []).find(o => o.id === orderId && o.userId === req.auth.id);
  if (!order) return res.status(404).json({ error: 'Payment order not found' });
  const provider = getPaymentProvider(order.provider);
  const verification = await provider.verifyPayment({ gatewayOrderId: gatewayOrderId || order.gatewayOrderId, gatewayPaymentId, gatewaySignature });
  order.status = verification.verified ? 'paid' : 'verification_failed';
  order.verification = verification;
  if (verification.verified && order.purpose === 'wallet_topup') {
    const wallet = db.wallets.find(w => w.userId === req.auth.id);
    wallet.balances[order.currency] = (wallet.balances[order.currency] || 0) + Number(order.amount);
    const txn = { id: uuid(), type: 'wallet_topup', fromUserId: null, toUserId: req.auth.id, amount: order.amount, currency: order.currency, status: 'completed', createdAt: new Date().toISOString() };
    db.transactions.push(txn);
    postLedger(db, { debit: { ownerType: 'user_wallet', ownerId: req.auth.id }, credit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, amount: order.amount, currency: order.currency, referenceType: 'payment_order', referenceId: order.id, description: 'Wallet top-up via payment gateway' });
  }

  const payUser = db.users.find(u => u.id === req.auth.id);
  if (verification.verified) {
    notifyUserJson(db, {
      userId: req.auth.id,
      userEmail: payUser?.email,
      type: 'payment_success',
      title: 'Payment Successful',
      message: `Aapka payment of ${order.currency} ${order.amount} successful ho gaya hai aur wallet mein credit ho gaya hai.`,
      metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
    });
  } else {
    notifyUserJson(db, {
      userId: req.auth.id,
      userEmail: payUser?.email,
      type: 'payment_failed',
      title: 'Payment Failed',
      message: `Aapka payment of ${order.currency} ${order.amount} verify nahi ho paya. Kripya dobara try karein ya support se contact karein.`,
      metadata: { orderId: order.id, amount: order.amount, currency: order.currency },
    });
  }

  writeDb(db);
  res.json({ order, verification });
});

app.post('/api/payments/webhook', async (req, res) => {
  const provider = getPaymentProvider(process.env.PAYMENT_PROVIDER || 'mock');
  const signature = req.headers['x-razorpay-signature'];
  const raw = req.rawBody ? req.rawBody.toString() : JSON.stringify(req.body);

  if (process.env.PAYMENT_PROVIDER === 'razorpay') {
    if (!process.env.RAZORPAY_WEBHOOK_SECRET) {
      console.error('SECURITY: RAZORPAY_WEBHOOK_SECRET is not set while PAYMENT_PROVIDER=razorpay. Rejecting webhook.');
      return res.status(500).json({ error: 'Webhook not configured correctly' });
    }
    const verified = provider.verifyWebhookSignature(raw, signature, process.env.RAZORPAY_WEBHOOK_SECRET);
    if (!verified) return res.status(400).json({ error: 'Invalid webhook signature' });
    return res.json({ received: true, verified: true });
  }

  // Production: event idempotency and event type handling required.
  res.json({ received: true, verified: true });
});

app.post('/api/payments/refund', auth('admin'), requirePermission('refunds:manage'), async (req, res) => {
  const { orderId, gatewayPaymentId, amount, reason = 'admin_refund' } = req.body;
  const db = readDb();
  const order = (db.paymentOrders || []).find(o => o.id === orderId);
  if (!order) return res.status(404).json({ error: 'Payment order not found' });
  if (order.status !== 'paid') return res.status(400).json({ error: 'Only paid orders can be refunded' });
  const provider = getPaymentProvider(order.provider);
  const refund = await provider.refundPayment({ gatewayPaymentId: gatewayPaymentId || order.verification?.gatewayPaymentId, amount: amount || order.amount, notes: { reason, orderId } });
  db.refunds = db.refunds || [];
  const refundRecord = { id: uuid(), orderId, provider: order.provider, amount: Number(amount || order.amount), currency: order.currency, reason, status: refund.status || 'processed', gatewayRefund: refund, createdAt: new Date().toISOString() };
  db.refunds.push(refundRecord);
  order.status = 'refunded';
  const wallet = db.wallets.find(w => w.userId === order.userId);
  if (wallet) wallet.balances[order.currency] = Number(wallet.balances[order.currency] || 0) - Number(refundRecord.amount);
  db.transactions.push({ id: uuid(), type: 'refund', fromUserId: order.userId, toUserId: null, amount: refundRecord.amount, currency: order.currency, status: 'completed', createdAt: new Date().toISOString() });
  postLedger(db, { debit: { ownerType: 'platform_cash', ownerId: 'gateway_settlement' }, credit: { ownerType: 'user_wallet', ownerId: order.userId }, amount: refundRecord.amount, currency: order.currency, referenceType: 'refund', referenceId: refundRecord.id, description: 'Payment refund from wallet' });
  auditLog(db, { adminId: req.auth.id, action: 'payment.refund', entityType: 'payment_order', entityId: orderId, metadata: { refundId: refundRecord.id, amount: refundRecord.amount, currency: order.currency }, req });
  writeDb(db);
  res.json({ refund: refundRecord });
});


app.get('/api/admin/kyc-requests', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const db = readDb();
  // Exclude the heavy `documents` field from the list view; admin fetches it
  // individually via the endpoint below.
  const rows = db.kycRequests.map(k => {
    const { documents: _omit, ...rest } = k;
    return { ...rest, user: publicUser(db.users.find(u => u.id === k.userId) || {}) };
  });
  res.json(rows);
});

app.get('/api/admin/kyc-requests/:id/documents', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const db = readDb();
  const kyc = db.kycRequests.find(k => k.id === req.params.id);
  if (!kyc) return res.status(404).json({ error: 'KYC request not found' });
  auditLog(db, { adminId: req.auth.id, action: 'kyc.documents_viewed', entityType: 'kyc_request', entityId: req.params.id, req });
  writeDb(db);
  res.json({ documents: kyc.documents || [] });
});

app.get('/api/admin/refunds', auth('admin'), (req, res) => {
  const db = readDb();
  res.json(db.refunds || []);
});

app.get('/api/admin/payment-orders', auth('admin'), requirePermission('payments:read'), (req, res) => {
  const db = readDb();
  const rows = (db.paymentOrders || []).map(o => ({ ...o, user: publicUser(db.users.find(u => u.id === o.userId) || {}) }));
  res.json(rows);
});

app.get('/api/admin/ledger', auth('admin'), requirePermission('ledger:read'), (req, res) => {
  const db = readDb();
  res.json({ accounts: db.ledgerAccounts || [], entries: db.ledgerEntries || [] });
});



app.get('/api/admin/admins', auth('admin'), requirePermission('admin:manage'), (req, res) => {
  const db = readDb();
  res.json(db.admins.map(a => ({ id: a.id, email: a.email, role: a.role || 'admin', permissions: a.permissions || [], createdAt: a.createdAt })));
});

app.patch('/api/admin/admins/:id/role', auth('admin'), requirePermission('admin:manage'), (req, res) => {
  const { role, permissions } = req.body;
  const db = readDb();
  const admin = db.admins.find(a => a.id === req.params.id);
  if (!admin) return res.status(404).json({ error: 'Admin not found' });
  if (role) admin.role = role;
  if (Array.isArray(permissions)) admin.permissions = permissions;
  auditLog(db, { adminId: req.auth.id, action: 'admin.role_update', entityType: 'admin', entityId: admin.id, metadata: { role: admin.role, permissions: admin.permissions }, req });
  writeDb(db);
  res.json({ admin: { id: admin.id, email: admin.email, role: admin.role, permissions: admin.permissions || [] } });
});

app.get('/api/admin/audit-logs', auth('admin'), requirePermission('audit:read'), (req, res) => {
  const db = readDb();
  res.json((db.auditLogs || []).slice().reverse().slice(0, 500));
});

app.get('/api/admin/roles', auth('admin'), requirePermission('admin:manage'), (req, res) => {
  res.json({
    roles: [
      { role: 'super_admin', permissions: ['*'] },
      { role: 'kyc_manager', permissions: ['users:read','kyc:manage','audit:read'] },
      { role: 'finance_manager', permissions: ['payments:read','refunds:manage','ledger:read','exchange:manage','audit:read'] },
      { role: 'support_agent', permissions: ['users:read','payments:read','disputes:manage','audit:read'] }
    ]
  });
});


app.patch('/api/admin/complaints/:id', auth('admin'), (req, res) => {
  const { status } = req.body;
  const db = readDb();
  const complaint = (db.complaints || []).find(c => c.id === req.params.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });
  complaint.status = status || complaint.status;
  complaint.updatedAt = new Date().toISOString();
  auditLog(db, { adminId: req.auth.id, action: `complaint.${complaint.status}`, entityType: 'complaint', entityId: complaint.id, metadata: { userId: complaint.userId, status: complaint.status }, req });
  writeDb(db);
  res.json({ complaint });
});

app.get('/api/admin/complaints', auth('admin'), (req, res) => {
  const db = readDb();
  res.json(db.complaints);
});

app.patch('/api/admin/kyc/:id', auth('admin'), requirePermission('kyc:manage'), (req, res) => {
  const { status } = req.body;
  const db = readDb();
  const kyc = db.kycRequests.find(k => k.id === req.params.id);
  if (!kyc) return res.status(404).json({ error: 'KYC not found' });
  kyc.status = status;
  const user = db.users.find(u => u.id === kyc.userId);
  if (user) user.kycStatus = status;

  const isApproved = status === 'approved';
  notifyUserJson(db, {
    userId: kyc.userId,
    userEmail: user?.email,
    type: isApproved ? 'kyc_approved' : 'kyc_rejected',
    title: isApproved ? 'KYC Verified Successfully' : 'KYC Verification Update',
    message: isApproved
      ? 'Aapka KYC verify ho gaya hai. Ab aap bina limit ke transactions kar sakte hain.'
      : 'Aapka KYC document verify nahi ho paya. Kripya sahi/clear documents ke saath dobara submit karein.',
    metadata: { kycRequestId: kyc.id, status },
  });

  writeDb(db);
  res.json({ kyc });
});

// ---------------------------------------------------------------------------
// In-app notifications
// ---------------------------------------------------------------------------
app.get('/api/notifications', auth('user'), (req, res) => {
  const db = readDb();
  const limit = Math.min(parseInt(req.query.limit) || 30, 100);
  const offset = parseInt(req.query.offset) || 0;
  const all = (db.notifications || []).filter(n => n.userId === req.auth.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const notifications = all.slice(offset, offset + limit);
  const unreadCount = all.filter(n => !n.isRead).length;
  res.json({ notifications, unreadCount });
});

app.post('/api/notifications/:id/read', auth('user'), (req, res) => {
  const db = readDb();
  const notif = (db.notifications || []).find(n => n.id === req.params.id && n.userId === req.auth.id);
  if (!notif) return res.status(404).json({ error: 'Notification not found' });
  notif.isRead = true;
  writeDb(db);
  res.json({ notification: notif });
});

app.post('/api/notifications/read-all', auth('user'), (req, res) => {
  const db = readDb();
  (db.notifications || []).forEach(n => { if (n.userId === req.auth.id) n.isRead = true; });
  writeDb(db);
  res.json({ success: true });
});

app.listen(PORT, () => console.log(`Global Exchanger API running on http://localhost:${PORT}`));
