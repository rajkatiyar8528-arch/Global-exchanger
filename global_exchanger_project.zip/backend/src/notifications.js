const nodemailer = require('nodemailer');
const { sendToTokens } = require('./push');

/**
 * Generic transactional email sender — reuses the same Brevo / Resend / SMTP
 * providers already configured for OTP emails (see otp.js / BREVO_EMAIL_API_SETUP.md),
 * but for arbitrary subject/html content (payment, KYC, exchange, reward updates).
 * Falls back to console logging in development if no provider is configured.
 *
 * EMAIL_TEMPLATES_GUIDE.md documents the visual design + the security fix
 * this round: every dynamic value (message text, admin notes, complaint
 * subjects, broadcast titles, etc.) is HTML-escaped before being embedded
 * in the email body — previously it was interpolated raw, which meant any
 * user-supplied or admin-supplied text containing HTML/script-like
 * characters would be injected unescaped into the email's HTML, a classic
 * stored-XSS-via-email risk (most modern webmail clients strip <script>,
 * but unescaped HTML can still break the layout or inject misleading
 * links/formatting — escaping is the correct fix regardless).
 */

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function parseFromEmail(from) {
  const fallback = process.env.SMTP_USER || 'no-reply@globalexchanger.com';
  const value = from || fallback;
  const match = value.match(/^(.*?)\s*<(.+?)>$/);
  if (match) return { name: match[1].trim() || 'Global Exchanger', email: match[2].trim() };
  return { name: 'Global Exchanger', email: value.trim() };
}

// ---------------------------------------------------------------------------
// Branded email shell — used by both this file's transactional emails AND
// otp.js's OTP emails (see otp.js require of `emailShell` below), so every
// email the platform sends shares one consistent, professional look:
// a colored top accent bar (varies by category — success/failure/warning/
// info), an icon+title header, the (already-escaped) body content, and a
// footer with support contact + legal links. Table-based layout avoided in
// favor of simple div/inline-styles since this targets modern email
// clients (Gmail, Outlook web, Apple Mail) that all render this fine; kept
// intentionally simple (no external images/fonts) so it also renders
// correctly with images/remote-content blocked, which is the default in
// most mail clients.
// ---------------------------------------------------------------------------
const CATEGORY_STYLES = {
  success: { color: '#00B876', bg: '#E8FFF5', icon: '✅' },
  failure: { color: '#E53935', bg: '#FEEEEE', icon: '❌' },
  warning: { color: '#FFA000', bg: '#FFF6E5', icon: '⚠️' },
  info: { color: '#0967FF', bg: '#EFF5FF', icon: '🔔' },
};

// Maps a notification `type` (see server.js/server_pg.js's various
// notifyUser/notifyUserJson call sites) to one of the four visual
// categories above. Deliberately a simple keyword-based classifier rather
// than an exhaustive explicit map, since new notification types get added
// over time (this app now has 15+ distinct types) — a substring/prefix
// match keeps new types looking reasonable by default without needing to
// remember to update this file every time a new notification type is
// added elsewhere.
function categoryForType(type) {
  const t = String(type || '').toLowerCase();
  if (/(failed|rejected|cancelled|reject)/.test(t)) return 'failure';
  if (/(paused|alert|warning)/.test(t)) return 'warning';
  if (/(success|approved|completed|credited|verified)/.test(t)) return 'success';
  return 'info';
}

function emailShell({ title, bodyHtml, category }) {
  const appName = escapeHtml(process.env.APP_NAME || 'Global Exchanger');
  const style = CATEGORY_STYLES[category] || CATEGORY_STYLES.info;
  const supportEmail = process.env.SUPPORT_EMAIL || 'support@globalexchanger.com';
  const legalBase = 'https://rajkatiyar8528-arch.github.io/Global-exchanger/legal';
  return `
    <div style="background:#F4F8FF;padding:24px 12px;font-family:Arial,Helvetica,sans-serif">
      <div style="max-width:520px;margin:auto;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e5e7eb">
        <div style="height:6px;background:${style.color}"></div>
        <div style="padding:28px 28px 8px">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px">
            <span style="font-weight:900;font-size:20px;color:#102033">${appName}</span>
          </div>
          <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:16px">
            <div style="width:40px;height:40px;min-width:40px;border-radius:12px;background:${style.bg};display:flex;align-items:center;justify-content:center;font-size:20px">${style.icon}</div>
            <div style="padding-top:6px">
              <h2 style="margin:0;font-size:18px;color:#102033;font-weight:800">${escapeHtml(title)}</h2>
            </div>
          </div>
          <div style="color:#333;font-size:15px;line-height:1.6;margin-bottom:8px">${bodyHtml}</div>
        </div>
        <div style="height:1px;background:#eef2fb;margin:8px 28px"></div>
        <div style="padding:16px 28px 24px">
          <p style="color:#888;font-size:12px;margin:0 0 8px">
            Ye ek automated message hai ${appName} se. Notification preferences App Settings mein change kar sakte hain.
          </p>
          <p style="color:#888;font-size:12px;margin:0 0 8px">
            Sawal hai? <a href="mailto:${supportEmail}" style="color:${style.color};text-decoration:none">${supportEmail}</a> par likhein.
          </p>
          <p style="color:#aaa;font-size:11px;margin:0">
            <a href="${legalBase}/privacy.html" style="color:#aaa;text-decoration:underline">Privacy Policy</a> &nbsp;·&nbsp;
            <a href="${legalBase}/terms.html" style="color:#aaa;text-decoration:underline">Terms & Conditions</a> &nbsp;·&nbsp;
            <a href="${legalBase}/grievance.html" style="color:#aaa;text-decoration:underline">Grievance Redressal</a>
          </p>
        </div>
      </div>
    </div>
  `;
}

async function sendViaBrevo({ email, subject, html, text }) {
  const sender = parseFromEmail(process.env.SMTP_FROM || process.env.BREVO_FROM || process.env.SMTP_USER);
  const res = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: { 'accept': 'application/json', 'api-key': process.env.BREVO_API_KEY, 'content-type': 'application/json' },
    body: JSON.stringify({ sender, to: [{ email }], subject, htmlContent: html, textContent: text }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Brevo email failed: ${body}`);
  return { sent: true, mode: 'brevo' };
}

async function sendViaResend({ email, subject, html, text }) {
  const from = process.env.SMTP_FROM || process.env.RESEND_FROM || 'Global Exchanger <onboarding@resend.dev>';
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [email], subject, html, text }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Resend email failed: ${body}`);
  return { sent: true, mode: 'resend' };
}

function smtpConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

async function sendViaSmtp({ email, subject, html, text }) {
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || port === 465;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port, secure,
    connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 20000,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to: email, subject, text, html });
  return { sent: true, mode: 'smtp' };
}

// `category` picks the accent color/icon (see CATEGORY_STYLES above); if
// omitted, `type` (a notification type string like 'payment_success') is
// used to infer one automatically via categoryForType(). `bodyHtml` is
// assumed to already be safe/escaped HTML by the time it reaches here —
// callers (notifyUser/notifyUserJson below) are responsible for escaping
// any dynamic/user-supplied text before building it.
async function sendTransactionalEmail({ email, subject, title, bodyHtml, text, category, type }) {
  const resolvedCategory = category || categoryForType(type);
  const html = emailShell({ title, bodyHtml, category: resolvedCategory });
  const plainText = text || bodyHtml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  try {
    if (process.env.BREVO_API_KEY) return await sendViaBrevo({ email, subject, html, text: plainText });
    if (process.env.RESEND_API_KEY) return await sendViaResend({ email, subject, html, text: plainText });
    if (smtpConfigured()) return await sendViaSmtp({ email, subject, html, text: plainText });
    console.log(`[DEV EMAIL] to=${email} subject="${subject}"`);
    return { sent: false, mode: 'console' };
  } catch (e) {
    // Never let a notification-email failure break the main business flow
    // (payment/exchange/KYC actions must still succeed even if email fails).
    console.error('Notification email failed:', e.message);
    return { sent: false, mode: 'error', error: e.message };
  }
}

/**
 * Creates an in-app notification (always, instantly queryable by the app)
 * and fires off a best-effort email in parallel (does not block/throw).
 *
 * @param {object} db - pg pool or a checked-out client
 * @param {object} params
 * @param {string} params.userId
 * @param {string} params.userEmail - required only if you want an email sent too
 * @param {string} params.type - e.g. 'payment_success', 'kyc_approved', 'exchange_completed', 'reward_credited'
 * @param {string} params.title
 * @param {string} params.message
 * @param {object} [params.metadata]
 * @param {boolean} [params.sendEmail=true]
 */
// `sendPush` defaults to true, mirroring `sendEmail`'s default. UNLIKE
// sendEmail (where every call site already explicitly passes the user's
// email_notifications_enabled preference), push respects the user's
// push_notifications_enabled preference AUTOMATICALLY inside this
// function via its own lookup query — this means every existing
// notifyUser() call site across server_pg.js gets real push notifications
// for free, without needing to be individually updated.
//
// IMPORTANT: `db` here is always the shared `pool` (never a checked-out
// transaction `client`) at every call site in server_pg.js — verified via
// grep. That matters because the preference/push-token lookups below
// issue their own independent queries rather than participating in any
// caller's transaction; if this were ever called with a `client`
// mid-transaction, the lookups could see uncommitted data or (worse) run
// after a ROLLBACK. Keep all call sites using `pool`.
async function notifyUser(db, { userId, userEmail, type, title, message, metadata = {}, sendEmail = true, sendPush = true }) {
  await db.query(
    'INSERT INTO notifications(user_id, type, title, message, metadata) VALUES ($1,$2,$3,$4,$5)',
    [userId, type, title, message, JSON.stringify(metadata)]
  );

  if (sendEmail && userEmail) {
    // Fire-and-forget: don't await inline in a way that could delay/throw in the caller.
    // `message` is escaped here — it may contain admin-entered text (e.g. a
    // withdrawal rejection reason) or be built from user-entered text (e.g.
    // a complaint subject) elsewhere in server_pg.js, so it must never be
    // trusted as pre-sanitized HTML by the time it reaches an email body.
    sendTransactionalEmail({
      email: userEmail,
      subject: title,
      title,
      type,
      bodyHtml: `<p style="margin:0">${escapeHtml(message)}</p>`,
    }).catch(err => console.error('notifyUser email dispatch failed:', err.message));
  }

  if (sendPush) {
    // Fire-and-forget, same pattern as email above — a slow/failed push
    // send must never delay or break the caller's main business flow.
    db.query('SELECT push_notifications_enabled FROM users WHERE id=$1', [userId])
      .then(async (userResult) => {
        if (userResult.rows[0]?.push_notifications_enabled === false) return; // user opted out
        const r = await db.query('SELECT token FROM push_tokens WHERE user_id=$1', [userId]);
        const tokens = r.rows.map(row => row.token);
        if (tokens.length === 0) return;
        const { invalidTokens } = await sendToTokens(tokens, { title, body: message, data: { type, ...Object.fromEntries(Object.entries(metadata).map(([k, v]) => [k, String(v)])) } });
        if (invalidTokens.length > 0) {
          await db.query('DELETE FROM push_tokens WHERE token = ANY($1)', [invalidTokens]);
        }
      })
      .catch(err => console.error('notifyUser push dispatch failed:', err.message));
  }
}

module.exports = { sendTransactionalEmail, notifyUser, emailShell, escapeHtml, categoryForType };
