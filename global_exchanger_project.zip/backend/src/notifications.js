const nodemailer = require('nodemailer');

/**
 * Generic transactional email sender — reuses the same Brevo / Resend / SMTP
 * providers already configured for OTP emails (see otp.js / BREVO_EMAIL_API_SETUP.md),
 * but for arbitrary subject/html content (payment, KYC, exchange, reward updates).
 * Falls back to console logging in development if no provider is configured.
 */

function parseFromEmail(from) {
  const fallback = process.env.SMTP_USER || 'no-reply@globalexchanger.com';
  const value = from || fallback;
  const match = value.match(/^(.*?)\s*<(.+?)>$/);
  if (match) return { name: match[1].trim() || 'Global Exchanger', email: match[2].trim() };
  return { name: 'Global Exchanger', email: value.trim() };
}

function wrapHtml({ title, bodyHtml }) {
  const appName = process.env.APP_NAME || 'Global Exchanger';
  return `
    <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:20px;border:1px solid #e5e7eb;border-radius:14px">
      <h2 style="color:#0967ff;margin:0 0 12px">${appName}</h2>
      <h3 style="margin:0 0 10px">${title}</h3>
      <div style="color:#333;font-size:15px;line-height:1.5">${bodyHtml}</div>
      <p style="color:#888;font-size:12px;margin-top:20px">This is an automated message from ${appName}.</p>
    </div>
  `;
}

async function sendViaBrevo({ email, subject, html, text }) {
  const sender = parseFromEmail(process.env.SMTP_FROM || process.env.BREVO_FROM || process.env.SMTP_USER);
  const res = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: { 'accept': 'application/json', 'api-key': process.env.BREVO_API_KEY, 'content-type': 'application/json' },
    body: JSON.stringify({ sender, to: [{ email }], subject, htmlContent: html, textContent: text }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Brevo email failed: ${body}`);
  return { sent: true, mode: 'brevo' };
}

async function sendViaResend({ email, subject, html, text }) {
  const from = process.env.SMTP_FROM || process.env.RESEND_FROM || 'Global Exchanger <onboarding@resend.dev>';
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [email], subject, html, text }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Resend email failed: ${body}`);
  return { sent: true, mode: 'resend' };
}

function smtpConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

async function sendViaSmtp({ email, subject, html, text }) {
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || port === 465;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port, secure,
    connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 20000,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to: email, subject, text, html });
  return { sent: true, mode: 'smtp' };
}

async function sendTransactionalEmail({ email, subject, title, bodyHtml, text }) {
  const html = wrapHtml({ title, bodyHtml });
  const plainText = text || bodyHtml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  try {
    if (process.env.BREVO_API_KEY) return await sendViaBrevo({ email, subject, html, text: plainText });
    if (process.env.RESEND_API_KEY) return await sendViaResend({ email, subject, html, text: plainText });
    if (smtpConfigured()) return await sendViaSmtp({ email, subject, html, text: plainText });
    console.log(`[DEV EMAIL] to=${email} subject="${subject}"`);
    return { sent: false, mode: 'console' };
  } catch (e) {
    // Never let a notification-email failure break the main business flow
    // (payment/exchange/KYC actions must still succeed even if email fails).
    console.error('Notification email failed:', e.message);
    return { sent: false, mode: 'error', error: e.message };
  }
}

/**
 * Creates an in-app notification (always, instantly queryable by the app)
 * and fires off a best-effort email in parallel (does not block/throw).
 *
 * @param {object} db - pg pool or a checked-out client
 * @param {object} params
 * @param {string} params.userId
 * @param {string} params.userEmail - required only if you want an email sent too
 * @param {string} params.type - e.g. 'payment_success', 'kyc_approved', 'exchange_completed', 'reward_credited'
 * @param {string} params.title
 * @param {string} params.message
 * @param {object} [params.metadata]
 * @param {boolean} [params.sendEmail=true]
 */
async function notifyUser(db, { userId, userEmail, type, title, message, metadata = {}, sendEmail = true }) {
  await db.query(
    'INSERT INTO notifications(user_id, type, title, message, metadata) VALUES ($1,$2,$3,$4,$5)',
    [userId, type, title, message, JSON.stringify(metadata)]
  );

  if (sendEmail && userEmail) {
    // Fire-and-forget: don't await inline in a way that could delay/throw in the caller.
    sendTransactionalEmail({
      email: userEmail,
      subject: title,
      title,
      bodyHtml: `<p>${message}</p>`,
    }).catch(err => console.error('notifyUser email dispatch failed:', err.message));
  }
}

module.exports = { sendTransactionalEmail, notifyUser };
