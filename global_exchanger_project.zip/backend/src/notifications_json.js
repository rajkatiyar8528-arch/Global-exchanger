// Same notification/email logic as notifications.js, adapted for the JSON
// file-based demo backend (server.js) which stores data via readDb/writeDb
// instead of PostgreSQL.
const { sendTransactionalEmail } = require('./notifications');
const { v4: uuid } = require('uuid');

function notifyUserJson(db, { userId, userEmail, type, title, message, metadata = {}, sendEmail = true }) {
  db.notifications = db.notifications || [];
  db.notifications.push({
    id: uuid(),
    userId,
    type,
    title,
    message,
    metadata,
    isRead: false,
    createdAt: new Date().toISOString(),
  });

  if (sendEmail && userEmail) {
    sendTransactionalEmail({
      email: userEmail,
      subject: title,
      title,
      bodyHtml: `<p>${message}</p>`,
    }).catch(err => console.error('notifyUserJson email dispatch failed:', err.message));
  }
}

module.exports = { notifyUserJson };
