// Same notification/email logic as notifications.js, adapted for the JSON
// file-based demo backend (server.js) which stores data via readDb/writeDb
// instead of PostgreSQL.
const { sendTransactionalEmail } = require('./notifications');
const { sendToTokens } = require('./push');
const { v4: uuid } = require('uuid');

// `sendPush` defaults to true, mirroring `sendEmail`'s default. UNLIKE
// sendEmail (where every call site already explicitly passes the user's
// emailNotificationsEnabled preference), push respects the user's
// pushNotificationsEnabled preference AUTOMATICALLY inside this function
// by looking up the user record — this means every existing
// notifyUserJson() call site across server.js gets real push notifications
// for free, without needing to be individually updated to pass a
// per-call push preference.
function notifyUserJson(db, { userId, userEmail, type, title, message, metadata = {}, sendEmail = true, sendPush = true }) {
  db.notifications = db.notifications || [];
  db.notifications.push({
    id: uuid(),
    userId,
    type,
    title,
    message,
    metadata,
    isRead: false,
    createdAt: new Date().toISOString(),
  });

  if (sendEmail && userEmail) {
    sendTransactionalEmail({
      email: userEmail,
      subject: title,
      title,
      bodyHtml: `<p>${message}</p>`,
    }).catch(err => console.error('notifyUserJson email dispatch failed:', err.message));
  }

  const user = db.users.find(u => u.id === userId);
  const userAllowsPush = user?.pushNotificationsEnabled !== false;
  if (sendPush && userAllowsPush) {
    db.pushTokens = db.pushTokens || [];
    const tokens = db.pushTokens.filter(t => t.userId === userId).map(t => t.token);
    if (tokens.length > 0) {
      sendToTokens(tokens, { title, body: message, data: { type, ...Object.fromEntries(Object.entries(metadata).map(([k, v]) => [k, String(v)])) } })
        .then(({ invalidTokens }) => {
          if (invalidTokens.length > 0) pruneInvalidTokens(invalidTokens);
        })
        .catch(err => console.error('notifyUserJson push dispatch failed:', err.message));
    }
  }
}

// Prunes permanently-invalid push tokens (app uninstalled, token rotated,
// etc.) reported back by a fire-and-forget send that completes AFTER the
// original request/response cycle already finished. Deliberately does a
// fresh read-modify-write of the db file here (rather than reusing the
// `db` object captured by the notifyUserJson closure above), since that
// object could be stale by the time this callback runs — writing a stale
// copy back would silently clobber any other changes the app made to
// db.json in the meantime (this JSON-file backend has no row-level
// locking, so a fresh read right before the write is the safest option).
const fs = require('fs');
const path = require('path');
const DB_PATH_FOR_PUSH_CLEANUP = path.join(__dirname, '../data/db.json');

function pruneInvalidTokens(invalidTokens) {
  try {
    const fresh = JSON.parse(fs.readFileSync(DB_PATH_FOR_PUSH_CLEANUP, 'utf8'));
    fresh.pushTokens = (fresh.pushTokens || []).filter(t => !invalidTokens.includes(t.token));
    fs.writeFileSync(DB_PATH_FOR_PUSH_CLEANUP, JSON.stringify(fresh, null, 2));
  } catch (e) {
    console.error('Failed to prune invalid push tokens:', e.message);
  }
}

module.exports = { notifyUserJson };
