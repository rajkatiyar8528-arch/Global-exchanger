const crypto = require('crypto');

/**
 * receipts.js
 * -----------------------------------------------------------------------
 * Generates a printable/downloadable HTML receipt for a transaction or
 * exchange order. The app requests a short-lived, single-purpose token
 * (see /api/receipts/token) and opens `${baseUrl}/api/receipts/:token` in
 * the phone's browser — from there the user can use the browser's built-in
 * "Print" / "Save as PDF" feature. This avoids adding a PDF-generation
 * dependency to the Node backend (keeps the Codemagic/Render build simple)
 * while still giving users a real, savable/printable receipt.
 * -----------------------------------------------------------------------
 */

function generateReceiptToken() {
  return crypto.randomBytes(24).toString('hex');
}

function money(amount, currency) {
  const n = Number(amount || 0);
  const symbol = currency === 'INR' ? '₹' : currency === 'USD' ? '$' : currency === 'EUR' ? '€' : `${currency} `;
  return `${symbol}${n.toFixed(currency === 'BTC' || currency === 'ETH' || currency === 'XRP' ? 8 : 2)}`;
}

function renderTransactionReceipt({ transaction, user }) {
  const t = transaction;
  const direction = t.type === 'wallet_topup' ? 'Wallet Top-up'
    : t.type === 'refund' ? 'Refund'
    : t.type === 'exchange_complete' ? 'Exchange Completed'
    : t.from_user_id === user.id ? 'Money Sent' : 'Money Received';

  return `
    <div class="receipt">
      <div class="brand">Global Exchanger</div>
      <div class="title">${direction}</div>
      <div class="amount">${money(t.amount, t.currency)}</div>
      <div class="status status-${(t.status || '').toLowerCase()}">${t.status || ''}</div>
      <table class="details">
        <tr><td>Transaction ID</td><td>${t.id}</td></tr>
        <tr><td>Type</td><td>${t.type}</td></tr>
        <tr><td>Date &amp; Time</td><td>${new Date(t.created_at).toLocaleString()}</td></tr>
        <tr><td>Amount</td><td>${money(t.amount, t.currency)}</td></tr>
        <tr><td>Currency</td><td>${t.currency}</td></tr>
        <tr><td>Status</td><td>${t.status}</td></tr>
        <tr><td>Account Holder</td><td>${user.name || ''} (${user.email || ''})</td></tr>
      </table>
      <div class="footer">This is a system-generated receipt from Global Exchanger. For support, contact us via the app's Help section.</div>
    </div>
  `;
}

function renderExchangeReceipt({ order, user }) {
  return `
    <div class="receipt">
      <div class="brand">Global Exchanger</div>
      <div class="title">Currency Exchange Receipt</div>
      <div class="amount">${money(order.amount, order.from_currency)} → ${order.to_currency}</div>
      <div class="status status-${(order.status || '').toLowerCase()}">${order.status || ''}</div>
      <table class="details">
        <tr><td>Order ID</td><td>${order.id}</td></tr>
        <tr><td>Date &amp; Time</td><td>${new Date(order.created_at).toLocaleString()}</td></tr>
        <tr><td>From Currency</td><td>${order.from_currency}</td></tr>
        <tr><td>To Currency</td><td>${order.to_currency}</td></tr>
        <tr><td>Amount</td><td>${money(order.amount, order.from_currency)}</td></tr>
        <tr><td>Status</td><td>${order.status}</td></tr>
        <tr><td>Escrow Status</td><td>${order.escrow_status || ''}</td></tr>
        <tr class="section"><td colspan="2">Commission Breakdown (1% total)</td></tr>
        <tr><td>Total Commission (1%)</td><td>${money(order.commission, order.from_currency)}</td></tr>
        <tr><td>Platform Share (0.8%)</td><td>${money(order.admin_commission, order.from_currency)}</td></tr>
        <tr><td>Your Reward (0.2%)</td><td>${money(order.seller_commission, order.from_currency)}</td></tr>
        <tr><td>Account Holder</td><td>${user.name || ''} (${user.email || ''})</td></tr>
      </table>
      <div class="footer">This is a system-generated receipt from Global Exchanger. Your 0.2% reward has been credited to your Reward Wallet. For support, contact us via the app's Help section.</div>
    </div>
  `;
}

function wrapReceiptPage(innerHtml) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Global Exchanger Receipt</title>
  <style>
    * { box-sizing: border-box; font-family: Arial, sans-serif; }
    body { background: #eef4ff; margin: 0; padding: 24px; }
    .receipt { max-width: 480px; margin: 0 auto; background: white; border-radius: 20px; padding: 28px; box-shadow: 0 10px 30px rgba(0,0,0,.08); text-align: center; }
    .brand { font-weight: 900; font-size: 20px; color: #0967ff; margin-bottom: 6px; }
    .title { font-size: 16px; color: #555; margin-bottom: 10px; }
    .amount { font-size: 32px; font-weight: 900; margin-bottom: 10px; }
    .status { display: inline-block; padding: 6px 14px; border-radius: 999px; font-weight: 800; font-size: 12px; margin-bottom: 20px; background: #e8fff5; color: #00935e; }
    .status-failed, .status-cancelled, .status-rejected { background: #ffe8e8; color: #cc0000; }
    .status-pending, .status-under_review, .status-pending_match { background: #fff6e0; color: #a66a00; }
    .details { width: 100%; border-collapse: collapse; text-align: left; margin-top: 10px; }
    .details td { padding: 10px 4px; border-bottom: 1px solid #eee; font-size: 13px; word-break: break-all; }
    .details td:first-child { color: #888; width: 40%; }
    .details tr.section td { color: #0967ff; font-weight: 800; border-bottom: 2px solid #0967ff; padding-top: 18px; }
    .footer { margin-top: 20px; font-size: 11px; color: #999; }
    @media print {
      body { background: white; padding: 0; }
      .receipt { box-shadow: none; }
    }
  </style>
</head>
<body>
  ${innerHtml}
  <div style="text-align:center;margin-top:16px;" class="no-print">
    <button onclick="window.print()" style="padding:12px 24px;border:0;border-radius:12px;background:#0967ff;color:white;font-weight:800;cursor:pointer">Print / Save as PDF</button>
  </div>
</body>
</html>`;
}

module.exports = { generateReceiptToken, renderTransactionReceipt, renderExchangeReceipt, wrapReceiptPage };
