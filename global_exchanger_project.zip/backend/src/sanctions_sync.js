/**
 * sanctions_sync.js
 * -----------------------------------------------------------------------
 * Fetches, parses, and merges the FULL official sanctions datasets from:
 *   1. OFAC SDN List (US Treasury) — main entries + aliases (two CSV files)
 *   2. UN Security Council Consolidated List — individuals + entities (XML)
 *
 * ...and writes the merged result to `data/sanctions_list.json`, replacing
 * the small starter sample that ships by default. This is the automatic
 * update mechanism referenced in SANCTIONS_SCREENING_GUIDE.md.
 *
 * Design notes:
 *   - Dependency-free: uses Node's built-in `fetch` (Node 18+) and a small
 *     hand-rolled XML tag extractor (regex-based) instead of pulling in an
 *     XML parsing library, to avoid adding a new dependency that could
 *     break the Codemagic/Render build.
 *   - Fail-safe: if a fetch fails (network issue, source down, rate
 *     limited), that source is SKIPPED (logged as a warning) rather than
 *     crashing the whole sync — the other source(s) still get merged, and
 *     if ALL sources fail, the existing sanctions_list.json is left
 *     untouched (never overwritten with empty/partial data).
 *   - Idempotent / safe to run repeatedly (e.g. from a daily cron job) —
 *     each run does a full fetch + full rebuild of the merged file rather
 *     than an incremental diff, which is simpler and avoids drift bugs at
 *     the cost of slightly more bandwidth (a few MB, run at most daily).
 *   - This module does NOT run automatically on every server start by
 *     default (a slow, 3-10 second network-dependent operation on the
 *     critical path of every deploy/restart would be bad for uptime).
 *     Instead: run it manually via `npm run sync:sanctions`, or better,
 *     set up a scheduled job (see SANCTIONS_AUTO_UPDATE_GUIDE.md) that
 *     calls this on a daily/weekly cadence independent of app restarts.
 * -----------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');

const SANCTIONS_PATH = path.join(__dirname, '../data/sanctions_list.json');
const FETCH_TIMEOUT_MS = 45_000;

const SOURCES = {
  ofacSdnCsv: 'https://www.treasury.gov/ofac/downloads/sdn.csv',
  ofacAltCsv: 'https://www.treasury.gov/ofac/downloads/alt.csv',
  unConsolidatedXml: 'https://scsanctions.un.org/resources/xml/en/consolidated.xml',
};

async function fetchText(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { 'User-Agent': 'GlobalExchanger-ComplianceSync/1.0' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// Minimal CSV line parser handling quoted fields (OFAC's CSVs quote every
// field and escape embedded quotes as "" per standard CSV rules). Avoids
// pulling in a CSV-parsing dependency for this fairly simple, regular format.
// ---------------------------------------------------------------------------
function parseCsvLine(line) {
  const fields = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; } else { inQuotes = false; }
      } else {
        cur += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      fields.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  fields.push(cur.trim());
  return fields;
}

function parseCsvRows(text) {
  // OFAC CSVs use CRLF and have no header row; each logical row is one line
  // (no embedded newlines within quoted fields in these particular files).
  return text.split(/\r?\n/).filter(l => l.trim().length > 0).map(parseCsvLine);
}

// ---------------------------------------------------------------------------
// OFAC SDN main list parsing (sdn.csv)
// Columns (12 total, verified against the live file — an earlier version
// of this parser assumed 11 columns and silently mis-indexed `remarks`,
// which meant embedded "a.k.a. '...'" aliases inside the remarks column
// were being dropped for every single entry; caught via full-dataset
// testing when a known alias, "BNC" for Banco Nacional de Cuba, failed to
// screen after a sync despite being present in the source data):
//   0=uid, 1=name, 2=sdnType ("individual" or blank/entity), 3=programs,
//   4=title, 5=callSign, 6=vesselType, 7=tonnage, 8=grt, 9=vesselFlag,
//   10=vesselOwner, 11=remarks
// ---------------------------------------------------------------------------
function parseOfacSdn(csvText) {
  const rows = parseCsvRows(csvText);
  const entries = new Map(); // uid -> entry
  for (const row of rows) {
    if (row.length < 4) continue;
    const [uid, name, sdnType, programs, , , , , , , , remarks] = row;
    if (!uid || !name || name === '-0-') continue;
    const type = sdnType === 'individual' ? 'individual' : 'entity';
    const remarksText = remarks && remarks !== '-0-' ? remarks : '';
    const akaMatches = [...remarksText.matchAll(/a\.k\.a\. '([^']+)'/g)].map(m => m[1]);
    entries.set(uid, {
      id: `OFAC-${uid}`,
      name,
      type,
      programs: (programs || '').replace(/\]\s*\[/g, ', ').replace(/[[\]]/g, ''),
      aliases: akaMatches,
      remarks: remarksText,
      source: 'OFAC SDN List (US Treasury)',
    });
  }
  return entries;
}

// ---------------------------------------------------------------------------
// OFAC alias list parsing (alt.csv) — adds additional a.k.a. names onto
// entries already found in the main SDN list, keyed by the shared uid.
// Columns: uid(parent entry uid, matches sdn.csv's first column), altNum
// (this alias record's own id), type("aka"/"fka"/"nka"), aliasName, remarks
// Example row: 306,220,"aka","NATIONAL BANK OF CUBA",-0-
//              ^uid ^altNum ^type ^aliasName          ^remarks
// ---------------------------------------------------------------------------
function mergeOfacAliases(entries, altCsvText) {
  const rows = parseCsvRows(altCsvText);
  let mergedCount = 0;
  for (const row of rows) {
    if (row.length < 4) continue;
    const [uid, , , aliasName] = row;
    if (!uid || !aliasName || aliasName === '-0-') continue;
    const entry = entries.get(uid);
    if (entry && !entry.aliases.includes(aliasName)) {
      entry.aliases.push(aliasName);
      mergedCount++;
    }
  }
  return mergedCount;
}

// ---------------------------------------------------------------------------
// UN Security Council Consolidated List parsing (XML). Hand-rolled tag
// extraction rather than a full XML parser — the format is regular enough
// (no attributes we need, simple nested tags) that regex-per-record-block
// extraction is reliable and avoids a new dependency.
// ---------------------------------------------------------------------------
function extractTag(block, tag) {
  const m = block.match(new RegExp(`<${tag}>([^<]*)<\\/${tag}>`));
  return m ? m[1].trim() : '';
}

function extractAllBlocks(xml, tagName) {
  const blocks = [];
  const openTag = `<${tagName}>`;
  const closeTag = `</${tagName}>`;
  let idx = 0;
  while (true) {
    const start = xml.indexOf(openTag, idx);
    if (start === -1) break;
    const end = xml.indexOf(closeTag, start);
    if (end === -1) break;
    blocks.push(xml.slice(start + openTag.length, end));
    idx = end + closeTag.length;
  }
  return blocks;
}

function parseUnConsolidated(xmlText) {
  const entries = [];

  for (const block of extractAllBlocks(xmlText, 'INDIVIDUAL')) {
    const dataId = extractTag(block, 'DATAID');
    const first = extractTag(block, 'FIRST_NAME');
    const second = extractTag(block, 'SECOND_NAME');
    const third = extractTag(block, 'THIRD_NAME');
    const fourth = extractTag(block, 'FOURTH_NAME');
    const name = [first, second, third, fourth].filter(Boolean).join(' ').trim();
    if (!name || !dataId) continue;
    const listType = extractTag(block, 'UN_LIST_TYPE') || extractTag(block, 'REFERENCE_NUMBER');
    const aliasMatches = [...block.matchAll(/<ALIAS_NAME>([^<]+)<\/ALIAS_NAME>/g)].map(m => m[1].trim()).filter(Boolean);
    entries.push({
      id: `UN-${dataId}`,
      name,
      type: 'individual',
      programs: listType || 'UN Consolidated List',
      aliases: aliasMatches,
      remarks: extractTag(block, 'COMMENTS1').slice(0, 300),
      source: 'UN Security Council Consolidated List',
    });
  }

  for (const block of extractAllBlocks(xmlText, 'ENTITY')) {
    const dataId = extractTag(block, 'DATAID');
    const first = extractTag(block, 'FIRST_NAME');
    const name = first.trim();
    if (!name || !dataId) continue;
    const listType = extractTag(block, 'UN_LIST_TYPE') || extractTag(block, 'REFERENCE_NUMBER');
    const aliasMatches = [...block.matchAll(/<ALIAS_NAME>([^<]+)<\/ALIAS_NAME>/g)].map(m => m[1].trim()).filter(Boolean);
    entries.push({
      id: `UN-${dataId}`,
      name,
      type: 'entity',
      programs: listType || 'UN Consolidated List',
      aliases: aliasMatches,
      remarks: extractTag(block, 'COMMENTS1').slice(0, 300),
      source: 'UN Security Council Consolidated List',
    });
  }

  return entries;
}

// ---------------------------------------------------------------------------
// Main sync entrypoint. Returns a summary object; writes the merged file to
// disk on success. Never throws for a single-source failure — only throws
// if ALL sources fail (nothing to write).
// ---------------------------------------------------------------------------
async function syncSanctionsList({ writeToFile = true } = {}) {
  const summary = { sources: [], errors: [], entryCount: 0, startedAt: new Date().toISOString() };
  let mergedEntries = [];

  // --- OFAC SDN + aliases ---
  try {
    const sdnCsv = await fetchText(SOURCES.ofacSdnCsv);
    const ofacMap = parseOfacSdn(sdnCsv);
    try {
      const altCsv = await fetchText(SOURCES.ofacAltCsv);
      const mergedAliasCount = mergeOfacAliases(ofacMap, altCsv);
      summary.sources.push({ name: 'OFAC SDN List (US Treasury)', entryCount: ofacMap.size, aliasesMerged: mergedAliasCount, status: 'ok' });
    } catch (e) {
      summary.errors.push(`OFAC alias list fetch failed (main SDN list still used): ${e.message}`);
      summary.sources.push({ name: 'OFAC SDN List (US Treasury)', entryCount: ofacMap.size, aliasesMerged: 0, status: 'partial (aliases unavailable)' });
    }
    mergedEntries.push(...ofacMap.values());
  } catch (e) {
    summary.errors.push(`OFAC SDN list fetch failed entirely: ${e.message}`);
    summary.sources.push({ name: 'OFAC SDN List (US Treasury)', entryCount: 0, status: 'failed' });
  }

  // --- UN Consolidated List ---
  try {
    const unXml = await fetchText(SOURCES.unConsolidatedXml);
    const unEntries = parseUnConsolidated(unXml);
    summary.sources.push({ name: 'UN Security Council Consolidated List', entryCount: unEntries.length, status: 'ok' });
    mergedEntries.push(...unEntries);
  } catch (e) {
    summary.errors.push(`UN Consolidated List fetch failed: ${e.message}`);
    summary.sources.push({ name: 'UN Security Council Consolidated List', entryCount: 0, status: 'failed' });
  }

  summary.entryCount = mergedEntries.length;
  summary.finishedAt = new Date().toISOString();

  if (mergedEntries.length === 0) {
    summary.errors.push('All sources failed — existing sanctions_list.json left UNCHANGED to avoid wiping out the current dataset.');
    return summary;
  }

  if (writeToFile) {
    const payload = {
      metadata: {
        sources: summary.sources.filter(s => s.status !== 'failed').map(s => s.name),
        note: summary.errors.length > 0
          ? `Sync completed with warnings: ${summary.errors.join(' | ')}`
          : 'Full official OFAC SDN List + UN Security Council Consolidated List, auto-synced.',
        lastUpdated: summary.finishedAt,
        entryCount: mergedEntries.length,
        syncSummary: summary.sources,
      },
      entries: mergedEntries,
    };
    fs.writeFileSync(SANCTIONS_PATH, JSON.stringify(payload, null, 2));
  }

  return summary;
}

module.exports = { syncSanctionsList, SOURCES };
