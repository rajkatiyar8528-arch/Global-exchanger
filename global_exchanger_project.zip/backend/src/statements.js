/**
 * statements.js
 * -----------------------------------------------------------------------
 * Renders a printable/downloadable HTML "Account Statement" (a date-ranged
 * list of transactions), mirroring the same dependency-free
 * print-to-PDF approach used for single-transaction receipts in
 * receipts.js / receipts_json.js (no server-side PDF library needed —
 * keeps the Codemagic/Render build simple). Also offers a CSV export,
 * which needs no HTML/print step at all and downloads directly.
 * -----------------------------------------------------------------------
 */
const crypto = require('crypto');

function generateStatementToken() {
  return crypto.randomBytes(24).toString('hex');
}

function money(amount, currency) {
  const n = Number(amount || 0);
  const symbol = currency === 'INR' ? '₹' : currency === 'USD' ? '$' : currency === 'EUR' ? '€' : `${currency} `;
  return `${symbol}${n.toFixed(currency === 'BTC' || currency === 'ETH' || currency === 'XRP' ? 8 : 2)}`;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// `rows` is a normalized array of { id, type, currency, amount, status, direction, createdAt } —
// both backends map their own field naming (camelCase JSON vs snake_case Postgres) into this
// shape before calling this renderer, so the renderer itself never needs to know which backend
// produced the data.
function renderStatementHtml({ user, fromDate, toDate, rows }) {
  const rangeLabel = fromDate && toDate ? `${fromDate} to ${toDate}` : fromDate ? `From ${fromDate}` : toDate ? `Up to ${toDate}` : 'All Time';
  const totalIn = rows.filter(r => r.direction === 'credit').reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const totalOut = rows.filter(r => r.direction === 'debit').reduce((sum, r) => sum + Number(r.amount || 0), 0);

  const tableRows = rows.map(r => `
    <tr>
      <td>${escapeHtml(new Date(r.createdAt).toLocaleString())}</td>
      <td>${escapeHtml(r.type)}</td>
      <td class="${r.direction === 'credit' ? 'credit' : 'debit'}">${r.direction === 'credit' ? '+' : '-'}${escapeHtml(money(r.amount, r.currency))}</td>
      <td>${escapeHtml(r.status)}</td>
      <td class="mono">${escapeHtml((r.id || '').slice(0, 8))}</td>
    </tr>
  `).join('');

  return `
    <div class="statement">
      <div class="brand">Global Exchanger</div>
      <div class="title">Account Statement</div>
      <div class="subtitle">${escapeHtml(user.name || '')} (${escapeHtml(user.email || '')})</div>
      <div class="subtitle">Period: ${escapeHtml(rangeLabel)}</div>
      <div class="summary">
        <div class="summary-box"><div class="summary-label">Total Credited</div><div class="summary-value credit">+${escapeHtml(money(totalIn, 'INR'))}</div></div>
        <div class="summary-box"><div class="summary-label">Total Debited</div><div class="summary-value debit">-${escapeHtml(money(totalOut, 'INR'))}</div></div>
        <div class="summary-box"><div class="summary-label">Transactions</div><div class="summary-value">${rows.length}</div></div>
      </div>
      <table class="details">
        <thead><tr><th>Date &amp; Time</th><th>Type</th><th>Amount</th><th>Status</th><th>Ref ID</th></tr></thead>
        <tbody>${tableRows || '<tr><td colspan="5" style="text-align:center;color:#999;padding:20px">No transactions in this period.</td></tr>'}</tbody>
      </table>
      <div class="footer">This is a system-generated statement from Global Exchanger, generated on ${escapeHtml(new Date().toLocaleString())}. For support, contact us via the app's Help section.</div>
    </div>
  `;
}

function wrapStatementPage(innerHtml) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Global Exchanger Statement</title>
  <style>
    * { box-sizing: border-box; font-family: Arial, sans-serif; }
    body { background: #eef4ff; margin: 0; padding: 24px; }
    .statement { max-width: 760px; margin: 0 auto; background: white; border-radius: 20px; padding: 28px; box-shadow: 0 10px 30px rgba(0,0,0,.08); }
    .brand { font-weight: 900; font-size: 20px; color: #0967ff; margin-bottom: 4px; text-align: center; }
    .title { font-size: 18px; font-weight: 800; margin-bottom: 6px; text-align: center; }
    .subtitle { font-size: 13px; color: #666; text-align: center; margin-bottom: 4px; }
    .summary { display: flex; gap: 12px; margin: 20px 0; }
    .summary-box { flex: 1; background: #f3f6ff; border-radius: 14px; padding: 14px; text-align: center; }
    .summary-label { font-size: 11px; color: #888; margin-bottom: 4px; }
    .summary-value { font-size: 18px; font-weight: 900; }
    .credit { color: #00935e; }
    .debit { color: #cc0000; }
    table.details { width: 100%; border-collapse: collapse; margin-top: 10px; }
    table.details th { text-align: left; font-size: 11px; color: #888; padding: 8px 6px; border-bottom: 2px solid #0967ff; }
    table.details td { padding: 8px 6px; border-bottom: 1px solid #eee; font-size: 12px; }
    .mono { font-family: monospace; color: #888; }
    .footer { margin-top: 20px; font-size: 11px; color: #999; text-align: center; }
    @media print {
      body { background: white; padding: 0; }
      .statement { box-shadow: none; }
    }
  </style>
</head>
<body>
  ${innerHtml}
  <div style="text-align:center;margin-top:16px;" class="no-print">
    <button onclick="window.print()" style="padding:12px 24px;border:0;border-radius:12px;background:#0967ff;color:white;font-weight:800;cursor:pointer">Print / Save as PDF</button>
  </div>
</body>
</html>`;
}

// CSV export — no HTML wrapper needed, downloads directly via
// Content-Disposition. `rows` uses the same normalized shape as above.
function renderStatementCsv(rows) {
  const header = 'Date,Type,Direction,Amount,Currency,Status,ReferenceId\n';
  const lines = rows.map(r => {
    const dateStr = new Date(r.createdAt).toISOString();
    const escaped = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    return [dateStr, r.type, r.direction, r.amount, r.currency, r.status, r.id].map(escaped).join(',');
  });
  return header + lines.join('\n');
}

module.exports = { generateStatementToken, renderStatementHtml, wrapStatementPage, renderStatementCsv, escapeHtml };
