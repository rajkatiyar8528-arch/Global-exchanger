/**
 * price_alerts.js
 * -----------------------------------------------------------------------
 * Dependency-free, pure helper functions for the Price Alerts feature.
 * Shared by both server.js (JSON) and server_pg.js (Postgres) so the
 * actual trigger logic can't drift between the two backends.
 *
 * IMPORTANT (Render free-tier constraint): there is no reliable always-on
 * background timer/cron on Render's free web-service tier (the process can
 * sleep after ~15 min of inactivity). Rather than promising real-time push
 * alerts (which would need a paid always-on worker), alerts are evaluated
 * OPPORTUNISTICALLY every time `GET /api/rates` is called (which happens
 * often anyway — home screen, convert screen, etc. all call it) and also
 * once right after a manual "Check Alerts Now" pull-to-refresh from the
 * app. This is documented clearly to the user in PRICE_ALERTS_GUIDE.md and
 * in the app's Price Alerts screen copy, so expectations are set correctly
 * (checked "every time someone opens the app / pulls rates", not exactly
 * every second).
 * -----------------------------------------------------------------------
 */

// All pairs the app can alert on — mirrors the shape returned by
// getRates() (forex + crypto blocks) in both backends.
const SUPPORTED_PAIRS = ['USD_INR', 'EUR_INR', 'GBP_INR', 'AED_INR', 'BTC_USD', 'ETH_USD', 'XRP_USD', 'BTC_INR'];

function isSupportedPair(pair) {
  return SUPPORTED_PAIRS.includes(String(pair || '').toUpperCase());
}

// Flattens the { forex: {...}, crypto: {...} } rates object into a single
// { PAIR: price } map for easy lookup.
function flattenRates(rates) {
  return { ...(rates?.forex || {}), ...(rates?.crypto || {}) };
}

// Given a list of active alerts (plain objects with at least
// { id, pair, direction, targetPrice }) and the current flattened rates
// map, returns the subset of alerts that should fire right now.
function findTriggeredAlerts(activeAlerts, flatRates) {
  const triggered = [];
  for (const alert of activeAlerts) {
    const currentPrice = flatRates[alert.pair];
    if (currentPrice === undefined || currentPrice === null) continue;
    const target = Number(alert.targetPrice);
    const price = Number(currentPrice);
    const fires = alert.direction === 'above' ? price >= target : price <= target;
    if (fires) triggered.push({ ...alert, currentPrice: price });
  }
  return triggered;
}

function formatPairLabel(pair) {
  return String(pair || '').replace('_', '/');
}

module.exports = { SUPPORTED_PAIRS, isSupportedPair, flattenRates, findTriggeredAlerts, formatPairLabel };
