// Same receipt rendering as receipts.js, adapted for the JSON demo backend's
// camelCase field naming (server_pg.js uses Postgres snake_case columns).
const { generateReceiptToken, wrapReceiptPage } = require('./receipts');

function money(amount, currency) {
  const n = Number(amount || 0);
  const symbol = currency === 'INR' ? '₹' : currency === 'USD' ? '$' : currency === 'EUR' ? '€' : `${currency} `;
  return `${symbol}${n.toFixed(currency === 'BTC' || currency === 'ETH' || currency === 'XRP' ? 8 : 2)}`;
}

function renderTransactionReceiptJson({ transaction, user }) {
  const t = transaction;
  const direction = t.type === 'wallet_topup' ? 'Wallet Top-up'
    : t.type === 'refund' ? 'Refund'
    : t.type === 'exchange_complete' ? 'Exchange Completed'
    : t.fromUserId === user.id ? 'Money Sent' : 'Money Received';

  return `
    <div class="receipt">
      <div class="brand">Global Exchanger</div>
      <div class="title">${direction}</div>
      <div class="amount">${money(t.amount, t.currency)}</div>
      <div class="status status-${(t.status || '').toLowerCase()}">${t.status || ''}</div>
      <table class="details">
        <tr><td>Transaction ID</td><td>${t.id}</td></tr>
        <tr><td>Type</td><td>${t.type}</td></tr>
        <tr><td>Date &amp; Time</td><td>${new Date(t.createdAt).toLocaleString()}</td></tr>
        <tr><td>Amount</td><td>${money(t.amount, t.currency)}</td></tr>
        <tr><td>Currency</td><td>${t.currency}</td></tr>
        <tr><td>Status</td><td>${t.status}</td></tr>
        <tr><td>Account Holder</td><td>${user.name || ''} (${user.email || ''})</td></tr>
      </table>
      <div class="footer">This is a system-generated receipt from Global Exchanger. For support, contact us via the app's Help section.</div>
    </div>
  `;
}

function renderExchangeReceiptJson({ order, user }) {
  return `
    <div class="receipt">
      <div class="brand">Global Exchanger</div>
      <div class="title">Currency Exchange Receipt</div>
      <div class="amount">${money(order.amount, order.fromCurrency)} → ${order.toCurrency}</div>
      <div class="status status-${(order.status || '').toLowerCase()}">${order.status || ''}</div>
      <table class="details">
        <tr><td>Order ID</td><td>${order.id}</td></tr>
        <tr><td>Date &amp; Time</td><td>${new Date(order.createdAt).toLocaleString()}</td></tr>
        <tr><td>From Currency</td><td>${order.fromCurrency}</td></tr>
        <tr><td>To Currency</td><td>${order.toCurrency}</td></tr>
        <tr><td>Amount</td><td>${money(order.amount, order.fromCurrency)}</td></tr>
        <tr><td>Status</td><td>${order.status}</td></tr>
        <tr><td>Escrow Status</td><td>${order.escrowStatus || ''}</td></tr>
        <tr class="section"><td colspan="2">Commission Breakdown (1% total)</td></tr>
        <tr><td>Total Commission (1%)</td><td>${money(order.commission, order.fromCurrency)}</td></tr>
        <tr><td>Platform Share (0.8%)</td><td>${money(order.adminCommission, order.fromCurrency)}</td></tr>
        <tr><td>Your Reward (0.2%)</td><td>${money(order.sellerCommission, order.fromCurrency)}</td></tr>
        <tr><td>Account Holder</td><td>${user.name || ''} (${user.email || ''})</td></tr>
      </table>
      <div class="footer">This is a system-generated receipt from Global Exchanger. Your 0.2% reward has been credited to your Reward Wallet. For support, contact us via the app's Help section.</div>
    </div>
  `;
}

module.exports = { generateReceiptToken, renderTransactionReceiptJson, renderExchangeReceiptJson, wrapReceiptPage };
