/**
 * push.js
 * -----------------------------------------------------------------------
 * Real background push notifications via Firebase Cloud Messaging (FCM),
 * using FCM's modern "HTTP v1" API directly over `fetch` + Node's built-in
 * `crypto` module for the OAuth2 service-account JWT flow — deliberately
 * dependency-free (no `firebase-admin` package) to keep this consistent
 * with the rest of the backend and avoid a heavy dependency just for
 * sending push messages.
 *
 * SETUP (see PUSH_NOTIFICATIONS_SETUP_GUIDE.md for full step-by-step
 * Hinglish instructions): requires one environment variable,
 * `FIREBASE_SERVICE_ACCOUNT_JSON`, containing the FULL JSON contents of a
 * Firebase service-account key (Firebase Console > Project Settings >
 * Service Accounts > Generate New Private Key), minified to a single line.
 * If this env var is not set, every function here becomes a safe no-op
 * (logs once and returns) — so the rest of the app (in-app notifications,
 * email) continues to work completely normally with push simply disabled,
 * exactly like how OTP email sending falls back to console-logging when
 * SMTP/Brevo/Resend aren't configured (see otp.js).
 * -----------------------------------------------------------------------
 */
const crypto = require('crypto');

let _serviceAccount = null;
let _serviceAccountParseAttempted = false;
let _warnedMissingConfig = false;

function getServiceAccount() {
  if (_serviceAccountParseAttempted) return _serviceAccount;
  _serviceAccountParseAttempted = true;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) return null;
  try {
    _serviceAccount = JSON.parse(raw);
    if (!_serviceAccount.client_email || !_serviceAccount.private_key || !_serviceAccount.project_id) {
      console.error('[push] FIREBASE_SERVICE_ACCOUNT_JSON is set but missing client_email/private_key/project_id — push notifications disabled.');
      _serviceAccount = null;
    }
  } catch (e) {
    console.error('[push] FIREBASE_SERVICE_ACCOUNT_JSON is not valid JSON — push notifications disabled:', e.message);
    _serviceAccount = null;
  }
  return _serviceAccount;
}

function isPushConfigured() {
  return getServiceAccount() !== null;
}

function warnOnceIfNotConfigured() {
  if (!_warnedMissingConfig && !isPushConfigured()) {
    _warnedMissingConfig = true;
    console.log('[push] FIREBASE_SERVICE_ACCOUNT_JSON not configured — push notifications are disabled (in-app + email notifications still work normally). See PUSH_NOTIFICATIONS_SETUP_GUIDE.md.');
  }
}

// Base64url encode (no padding) — used for building the JWT manually,
// since Node's built-in base64 encoding uses standard (not URL-safe)
// alphabet by default.
function base64url(input) {
  return Buffer.from(input).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

// Exchanges the service-account credentials for a short-lived (1 hour)
// OAuth2 access token, via the standard "JWT Bearer" grant used by Google
// service accounts. Cached in-memory until ~5 minutes before expiry.
let _cachedAccessToken = null;
let _cachedAccessTokenExpiresAt = 0;

async function getAccessToken() {
  const now = Date.now();
  if (_cachedAccessToken && now < _cachedAccessTokenExpiresAt - 5 * 60_000) return _cachedAccessToken;

  const sa = getServiceAccount();
  if (!sa) return null;

  const header = { alg: 'RS256', typ: 'JWT' };
  const nowSec = Math.floor(now / 1000);
  const claimSet = {
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: nowSec,
    exp: nowSec + 3600,
  };
  const unsigned = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(claimSet))}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer.sign(sa.private_key).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const jwt = `${unsigned}.${signature}`;

  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: jwt }),
  });
  const body = await res.json();
  if (!res.ok) throw new Error(`Firebase OAuth2 token exchange failed: ${body.error_description || body.error || res.status}`);

  _cachedAccessToken = body.access_token;
  _cachedAccessTokenExpiresAt = now + (body.expires_in || 3600) * 1000;
  return _cachedAccessToken;
}

// FCM error codes that mean "this token will never work again" (app
// uninstalled, token rotated, etc.) — the caller should remove these
// tokens from storage so future sends don't keep wasting time on them.
const PERMANENTLY_INVALID_ERROR_CODES = new Set(['UNREGISTERED', 'INVALID_ARGUMENT', 'NOT_FOUND', 'SENDER_ID_MISMATCH']);

// Sends one push notification to one FCM registration token via the HTTP
// v1 API. Returns { ok: true } on success, or { ok: false, permanentlyInvalid: bool, error }
// on failure — never throws, so a bad token can't take down a batch send.
async function sendToToken(token, { title, body, data = {} }) {
  const sa = getServiceAccount();
  if (!sa) return { ok: false, permanentlyInvalid: false, error: 'Push not configured' };

  try {
    const accessToken = await getAccessToken();
    const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
      body: JSON.stringify({
        message: {
          token,
          notification: { title, body },
          // All values in FCM's `data` payload must be strings.
          data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
          android: { priority: 'high', notification: { channel_id: 'global_exchanger_default' } },
        },
      }),
    });
    if (res.ok) return { ok: true };
    const errBody = await res.json().catch(() => ({}));
    const errorCode = errBody?.error?.details?.find(d => d['@type']?.includes('ErrorInfo'))?.reason || errBody?.error?.status;
    return { ok: false, permanentlyInvalid: PERMANENTLY_INVALID_ERROR_CODES.has(errorCode), error: errBody?.error?.message || `HTTP ${res.status}` };
  } catch (e) {
    return { ok: false, permanentlyInvalid: false, error: e.message };
  }
}

// Sends the same notification to multiple tokens (e.g. a user's several
// registered devices) in parallel, and reports which tokens turned out to
// be permanently invalid so the caller can prune them from storage.
async function sendToTokens(tokens, { title, body, data = {} }) {
  warnOnceIfNotConfigured();
  if (!isPushConfigured() || tokens.length === 0) return { sent: 0, invalidTokens: [] };

  const results = await Promise.all(tokens.map(async (token) => ({ token, result: await sendToToken(token, { title, body, data }) })));
  const sent = results.filter(r => r.result.ok).length;
  const invalidTokens = results.filter(r => r.result.permanentlyInvalid).map(r => r.token);
  return { sent, invalidTokens };
}

module.exports = { isPushConfigured, sendToTokens };
