const bcrypt = require('bcryptjs');

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function hashOtp(otp) {
  return bcrypt.hash(String(otp), 10);
}

async function compareOtp(otp, hash) {
  return bcrypt.compare(String(otp), hash);
}

function otpExpiry(minutes = 10) {
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

function isExpired(expiresAt) {
  return new Date(expiresAt).getTime() < Date.now();
}

async function sendOtpEmail({ email, otp, purpose }) {
  // Production me SMTP/SendGrid/AWS SES use karein.
  // Dev mode me console par OTP print hota hai.
  console.log(`[DEV EMAIL OTP] email=${email} purpose=${purpose} otp=${otp}`);
  return true;
}

module.exports = { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail };
