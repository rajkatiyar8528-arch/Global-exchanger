const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const { emailShell, escapeHtml } = require('./notifications');

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function hashOtp(otp) {
  return bcrypt.hash(String(otp), 10);
}

async function compareOtp(otp, hash) {
  return bcrypt.compare(String(otp), hash);
}

function otpExpiry(minutes = 10) {
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

function isExpired(expiresAt) {
  return new Date(expiresAt).getTime() < Date.now();
}

// Per-purpose subject line + a short explanatory sentence shown above the
// OTP code — lets the same OTP delivery mechanism serve email verification,
// login, and password-reset flows while still telling the recipient
// exactly why they're getting this email (important for password_reset in
// particular, since a user who did NOT request a reset should immediately
// understand "someone tried to reset my password" rather than being
// confused by a generic "here's your code" message).
const PURPOSE_COPY = {
  login: { subject: 'Login OTP', blurb: 'Aap Global Exchanger mein login kar rahe hain. Ye raha aapka one-time login code:' },
  email_verification: { subject: 'Email Verification OTP', blurb: 'Apna email address verify karne ke liye, ye code app mein daalein:' },
  password_reset: { subject: 'Password Reset OTP', blurb: 'Aapne apna password reset karne ki request ki hai. Ye raha aapka one-time code — agar ye request aapne nahi ki, to is email ko ignore karein, aapka password nahi badlega.' },
};

function appEmailContent({ otp, purpose }) {
  const appName = process.env.APP_NAME || 'Global Exchanger';
  const copy = PURPOSE_COPY[purpose] || PURPOSE_COPY.email_verification;
  const subject = `${appName} ${copy.subject}`;
  const text = `${copy.blurb}\n\n${otp}\n\nThis OTP is valid for 10 minutes. Do not share it with anyone.`;
  const bodyHtml = `
    <p style="margin:0 0 16px">${escapeHtml(copy.blurb)}</p>
    <div style="font-size:32px;font-weight:900;letter-spacing:8px;background:#F3F7FF;color:#0967FF;padding:18px;border-radius:14px;text-align:center;margin-bottom:16px">${escapeHtml(otp)}</div>
    <p style="color:#555;margin:0 0 8px">Ye OTP sirf <b>10 minute</b> ke liye valid hai. Kisi ke saath share na karein — Global Exchanger ki team kabhi bhi aapse OTP nahi maangti.</p>
    ${purpose === 'password_reset' ? '<p style="color:#E53935;margin:8px 0 0;font-size:13px">Agar ye request aapne nahi ki, to turant apna password change karein ya humein support par contact karein.</p>' : ''}
  `;
  const html = emailShell({ title: copy.subject, bodyHtml, category: purpose === 'password_reset' ? 'warning' : 'info' });
  return { appName, subject, text, html };
}

function parseFromEmail(from) {
  const fallback = process.env.SMTP_USER || 'no-reply@globalexchanger.com';
  const value = from || fallback;
  const match = value.match(/^(.*?)\s*<(.+?)>$/);
  if (match) return { name: match[1].trim() || 'Global Exchanger', email: match[2].trim() };
  return { name: 'Global Exchanger', email: value.trim() };
}

async function sendViaBrevo({ email, otp, purpose }) {
  const { subject, text, html } = appEmailContent({ otp, purpose });
  const sender = parseFromEmail(process.env.SMTP_FROM || process.env.BREVO_FROM || process.env.SMTP_USER);
  const res = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      'accept': 'application/json',
      'api-key': process.env.BREVO_API_KEY,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      sender,
      to: [{ email }],
      subject,
      htmlContent: html,
      textContent: text,
    }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Brevo email failed: ${body}`);
  console.log(`[EMAIL OTP SENT VIA BREVO] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'brevo' };
}

async function sendViaResend({ email, otp, purpose }) {
  const { subject, text, html } = appEmailContent({ otp, purpose });
  const from = process.env.SMTP_FROM || process.env.RESEND_FROM || 'Global Exchanger <onboarding@resend.dev>';
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from, to: [email], subject, html, text }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Resend email failed: ${body}`);
  console.log(`[EMAIL OTP SENT VIA RESEND] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'resend' };
}

function smtpConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

async function sendViaSmtp({ email, otp, purpose }) {
  const { subject, text, html } = appEmailContent({ otp, purpose });
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || port === 465;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure,
    connectionTimeout: 15000,
    greetingTimeout: 15000,
    socketTimeout: 20000,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject,
    text,
    html,
  });
  console.log(`[EMAIL OTP SENT VIA SMTP] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'smtp' };
}

async function sendOtpEmail({ email, otp, purpose }) {
  // Prefer HTTPS email APIs on Render because SMTP ports may timeout.
  if (process.env.BREVO_API_KEY) return sendViaBrevo({ email, otp, purpose });
  if (process.env.RESEND_API_KEY) return sendViaResend({ email, otp, purpose });
  if (smtpConfigured()) return sendViaSmtp({ email, otp, purpose });

  // Fallback for development/testing.
  console.log(`[DEV EMAIL OTP] email=${email} purpose=${purpose} otp=${otp}`);
  return { sent: false, mode: 'console' };
}

module.exports = { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail };
