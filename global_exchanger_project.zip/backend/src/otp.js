const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function hashOtp(otp) {
  return bcrypt.hash(String(otp), 10);
}

async function compareOtp(otp, hash) {
  return bcrypt.compare(String(otp), hash);
}

function otpExpiry(minutes = 10) {
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

function isExpired(expiresAt) {
  return new Date(expiresAt).getTime() < Date.now();
}

function appEmailContent({ otp, purpose }) {
  const appName = process.env.APP_NAME || 'Global Exchanger';
  const subject = purpose === 'login'
    ? `${appName} Login OTP`
    : `${appName} Email Verification OTP`;
  const text = `Your ${appName} OTP is ${otp}. This OTP is valid for 10 minutes. Do not share it with anyone.`;
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:20px;border:1px solid #e5e7eb;border-radius:14px">
      <h2 style="color:#0967ff;margin:0 0 12px">${appName}</h2>
      <p>Your OTP is:</p>
      <div style="font-size:32px;font-weight:800;letter-spacing:6px;background:#f3f7ff;padding:16px;border-radius:12px;text-align:center">${otp}</div>
      <p style="color:#555">This OTP is valid for 10 minutes. Do not share it with anyone.</p>
      <p style="color:#888;font-size:12px">If you did not request this OTP, please ignore this email.</p>
    </div>
  `;
  return { appName, subject, text, html };
}

function parseFromEmail(from) {
  const fallback = process.env.SMTP_USER || 'no-reply@globalexchanger.com';
  const value = from || fallback;
  const match = value.match(/^(.*?)\s*<(.+?)>$/);
  if (match) return { name: match[1].trim() || 'Global Exchanger', email: match[2].trim() };
  return { name: 'Global Exchanger', email: value.trim() };
}

async function sendViaBrevo({ email, otp, purpose }) {
  const { subject, text, html } = appEmailContent({ otp, purpose });
  const sender = parseFromEmail(process.env.SMTP_FROM || process.env.BREVO_FROM || process.env.SMTP_USER);
  const res = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      'accept': 'application/json',
      'api-key': process.env.BREVO_API_KEY,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      sender,
      to: [{ email }],
      subject,
      htmlContent: html,
      textContent: text,
    }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Brevo email failed: ${body}`);
  console.log(`[EMAIL OTP SENT VIA BREVO] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'brevo' };
}

async function sendViaResend({ email, otp, purpose }) {
  const { subject, text, html } = appEmailContent({ otp, purpose });
  const from = process.env.SMTP_FROM || process.env.RESEND_FROM || 'Global Exchanger <onboarding@resend.dev>';
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from, to: [email], subject, html, text }),
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Resend email failed: ${body}`);
  console.log(`[EMAIL OTP SENT VIA RESEND] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'resend' };
}

function smtpConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

async function sendViaSmtp({ email, otp, purpose }) {
  const { subject, text, html } = appEmailContent({ otp, purpose });
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || port === 465;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure,
    connectionTimeout: 15000,
    greetingTimeout: 15000,
    socketTimeout: 20000,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject,
    text,
    html,
  });
  console.log(`[EMAIL OTP SENT VIA SMTP] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'smtp' };
}

async function sendOtpEmail({ email, otp, purpose }) {
  // Prefer HTTPS email APIs on Render because SMTP ports may timeout.
  if (process.env.BREVO_API_KEY) return sendViaBrevo({ email, otp, purpose });
  if (process.env.RESEND_API_KEY) return sendViaResend({ email, otp, purpose });
  if (smtpConfigured()) return sendViaSmtp({ email, otp, purpose });

  // Fallback for development/testing.
  console.log(`[DEV EMAIL OTP] email=${email} purpose=${purpose} otp=${otp}`);
  return { sent: false, mode: 'console' };
}

module.exports = { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail };
