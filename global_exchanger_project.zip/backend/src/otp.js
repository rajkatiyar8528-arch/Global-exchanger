const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function hashOtp(otp) {
  return bcrypt.hash(String(otp), 10);
}

async function compareOtp(otp, hash) {
  return bcrypt.compare(String(otp), hash);
}

function otpExpiry(minutes = 10) {
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

function isExpired(expiresAt) {
  return new Date(expiresAt).getTime() < Date.now();
}

function smtpConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

async function sendOtpEmail({ email, otp, purpose }) {
  const appName = process.env.APP_NAME || 'Global Exchanger';
  const subject = purpose === 'login'
    ? `${appName} Login OTP`
    : `${appName} Email Verification OTP`;

  const text = `Your ${appName} OTP is ${otp}. This OTP is valid for 10 minutes. Do not share it with anyone.`;
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:20px;border:1px solid #e5e7eb;border-radius:14px">
      <h2 style="color:#0967ff;margin:0 0 12px">${appName}</h2>
      <p>Your OTP is:</p>
      <div style="font-size:32px;font-weight:800;letter-spacing:6px;background:#f3f7ff;padding:16px;border-radius:12px;text-align:center">${otp}</div>
      <p style="color:#555">This OTP is valid for 10 minutes. Do not share it with anyone.</p>
      <p style="color:#888;font-size:12px">If you did not request this OTP, please ignore this email.</p>
    </div>
  `;

  if (!smtpConfigured()) {
    // Fallback for development/testing.
    console.log(`[DEV EMAIL OTP] email=${email} purpose=${purpose} otp=${otp}`);
    return { sent: false, mode: 'console' };
  }

  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || port === 465;

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject,
    text,
    html,
  });

  console.log(`[EMAIL OTP SENT] email=${email} purpose=${purpose}`);
  return { sent: true, mode: 'smtp' };
}

module.exports = { generateOtp, hashOtp, compareOtp, otpExpiry, isExpired, sendOtpEmail };
