const crypto = require('crypto');

class MockPaymentProvider {
  constructor() {
    this.name = 'mock';
  }

  async createOrder({ amount, currency = 'INR', receipt, notes = {} }) {
    return {
      provider: this.name,
      gatewayOrderId: `mock_order_${crypto.randomBytes(8).toString('hex')}`,
      amount,
      currency,
      receipt,
      notes,
      status: 'created',
      createdAt: new Date().toISOString()
    };
  }

  async verifyPayment({ gatewayOrderId, gatewayPaymentId, gatewaySignature }) {
    return {
      verified: Boolean(gatewayOrderId && gatewayPaymentId),
      gatewayOrderId,
      gatewayPaymentId,
      gatewaySignature: gatewaySignature || 'mock_signature'
    };
  }

  verifyWebhookSignature() {
    return true;
  }

  async refundPayment({ gatewayPaymentId, amount, notes = {} }) {
    return {
      provider: this.name,
      refundId: `mock_refund_${crypto.randomBytes(8).toString('hex')}`,
      gatewayPaymentId,
      amount,
      notes,
      status: 'processed',
      createdAt: new Date().toISOString()
    };
  }
}

class RazorpayStructureProvider {
  constructor({ keyId, keySecret }) {
    this.name = 'razorpay';
    this.keyId = keyId;
    this.keySecret = keySecret;
  }

  async createOrder({ amount, currency = 'INR', receipt, notes = {} }) {
    if (!this.keyId || !this.keySecret) throw new Error('Razorpay keys missing');
    const auth = Buffer.from(`${this.keyId}:${this.keySecret}`).toString('base64');
    const response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        amount: Math.round(Number(amount) * 100),
        currency,
        receipt,
        notes
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data?.error?.description || 'Razorpay order creation failed');
    return {
      provider: this.name,
      gatewayOrderId: data.id,
      amount,
      currency,
      receipt,
      notes,
      status: data.status,
      publicKey: this.keyId,
      raw: data,
      createdAt: new Date().toISOString()
    };
  }

  async verifyPayment({ gatewayOrderId, gatewayPaymentId, gatewaySignature }) {
    const body = `${gatewayOrderId}|${gatewayPaymentId}`;
    const expected = crypto.createHmac('sha256', this.keySecret || '').update(body).digest('hex');
    return {
      verified: expected === gatewaySignature,
      gatewayOrderId,
      gatewayPaymentId
    };
  }

  verifyWebhookSignature(rawBody, signature, webhookSecret) {
    if (!webhookSecret || !signature || !rawBody) return false;
    const expected = crypto.createHmac('sha256', webhookSecret).update(rawBody).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  }

  async refundPayment({ gatewayPaymentId, amount, notes = {} }) {
    if (!this.keyId || !this.keySecret) throw new Error('Razorpay keys missing');
    if (!gatewayPaymentId) throw new Error('gatewayPaymentId required');
    const auth = Buffer.from(`${this.keyId}:${this.keySecret}`).toString('base64');
    const response = await fetch(`https://api.razorpay.com/v1/payments/${gatewayPaymentId}/refund`, {
      method: 'POST',
      headers: { 'Authorization': `Basic ${auth}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: amount ? Math.round(Number(amount) * 100) : undefined, notes })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data?.error?.description || 'Razorpay refund failed');
    return { provider: this.name, refundId: data.id, gatewayPaymentId, amount, status: data.status, raw: data, createdAt: new Date().toISOString() };
  }
}

class CashfreeStructureProvider {
  constructor({ clientId, clientSecret }) {
    this.name = 'cashfree';
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  async createOrder({ amount, currency = 'INR', receipt, notes = {} }) {
    // Structure only. Production me Cashfree PG Orders API call use karein.
    return {
      provider: this.name,
      gatewayOrderId: `cf_structure_${Date.now()}`,
      paymentSessionId: `session_${crypto.randomBytes(10).toString('hex')}`,
      amount,
      currency,
      receipt,
      notes,
      status: 'created',
      createdAt: new Date().toISOString()
    };
  }

  async verifyPayment({ gatewayOrderId, gatewayPaymentId }) {
    // Production me Cashfree order status API se verify karein.
    return { verified: Boolean(gatewayOrderId && gatewayPaymentId), gatewayOrderId, gatewayPaymentId };
  }

  verifyWebhookSignature() {
    // Production me Cashfree webhook signature logic add karein.
    return true;
  }

  async refundPayment({ gatewayPaymentId, amount, notes = {} }) {
    // Production me Cashfree refund API call use karein.
    return { provider: this.name, refundId: `cf_refund_${Date.now()}`, gatewayPaymentId, amount, notes, status: 'processed', createdAt: new Date().toISOString() };
  }
}

function getPaymentProvider(name = process.env.PAYMENT_PROVIDER || 'mock') {
  if (name === 'razorpay') {
    return new RazorpayStructureProvider({ keyId: process.env.RAZORPAY_KEY_ID, keySecret: process.env.RAZORPAY_KEY_SECRET });
  }
  if (name === 'cashfree') {
    return new CashfreeStructureProvider({ clientId: process.env.CASHFREE_CLIENT_ID, clientSecret: process.env.CASHFREE_CLIENT_SECRET });
  }
  return new MockPaymentProvider();
}

module.exports = { getPaymentProvider };
