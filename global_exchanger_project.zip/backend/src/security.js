/**
 * security.js
 * -----------------------------------------------------------------------
 * Lightweight, dependency-free security helpers for the Global Exchanger
 * backend: in-memory rate limiting, security headers, and basic input
 * validation. Kept dependency-free (no express-rate-limit/helmet) so it
 * can't break the Codemagic build if npm install has any hiccups.
 * -----------------------------------------------------------------------
 */

// ---------------------------------------------------------------------------
// In-memory rate limiter (per-process). Good enough for a single Render
// instance; if you scale to multiple instances, replace the Map with Redis.
// ---------------------------------------------------------------------------
const _buckets = new Map();
let _limiterSeq = 0;

// IMPORTANT: every call to rateLimit() gets its own unique namespace prefix
// on top of whatever keyFn produces. Without this, two different limiters
// that happen to use the same keyFn (e.g. both just `req.ip`, as
// registerLimiter and generalApiLimiter did) would silently SHARE the same
// counter bucket in the Map, since the Map key would be identical. That bug
// meant ordinary API traffic (wallet checks, payments, etc., counted by the
// global generalApiLimiter) was incrementing the SAME counter used by the
// registration endpoint's own, much stricter limiter — so active users on a
// shared/NAT'd IP (e.g. office WiFi, mobile carrier NAT) could accidentally
// cause brand-new signups from that IP to be wrongly blocked with a "Too
// many signup attempts" error after just a handful of unrelated requests.
// Namespacing each limiter's keys fixes this: each limiter now always gets
// its own independent bucket per key, regardless of what other limiters
// exist or what keyFn they use.
function rateLimit({ windowMs = 60_000, max = 20, keyFn = (req) => req.ip, message = 'Too many requests, please try again later.' } = {}) {
  const namespace = `rl${_limiterSeq++}`;
  return (req, res, next) => {
    const key = `${namespace}:${keyFn(req)}`;
    const now = Date.now();
    let bucket = _buckets.get(key);
    if (!bucket || now > bucket.resetAt) {
      bucket = { count: 0, resetAt: now + windowMs };
      _buckets.set(key, bucket);
    }
    bucket.count += 1;
    if (bucket.count > max) {
      const retryAfterSec = Math.ceil((bucket.resetAt - now) / 1000);
      res.setHeader('Retry-After', String(retryAfterSec));
      return res.status(429).json({ error: message });
    }
    next();
  };
}


// Periodically clean up old buckets so the Map doesn't grow forever.
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of _buckets.entries()) {
    if (now > bucket.resetAt) _buckets.delete(key);
  }
}, 5 * 60_000).unref?.();

// Keys by IP + email/body field when available, so rate limiting is per
// account attempt as well as per IP (mitigates both distributed and
// single-source brute force attempts).
function ipAndFieldKey(field) {
  return (req) => `${req.ip}:${String(req.body?.[field] || '').toLowerCase()}`;
}

// ---------------------------------------------------------------------------
// Basic security headers (subset of what `helmet` would set), added manually
// to avoid pulling in an extra dependency.
// ---------------------------------------------------------------------------
function securityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '0'); // deprecated header, explicitly disabled per modern guidance
  res.setHeader('Referrer-Policy', 'no-referrer-when-downgrade');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  next();
}

// ---------------------------------------------------------------------------
// Password strength check — used at registration and PIN/password changes.
// Requires: min 8 chars, at least one letter and one number.
// ---------------------------------------------------------------------------
function isStrongPassword(password) {
  if (typeof password !== 'string' || password.length < 8) return false;
  const hasLetter = /[A-Za-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  return hasLetter && hasNumber;
}

// ---------------------------------------------------------------------------
// CORS origin allowlist. If CORS_ALLOWED_ORIGINS is not set, falls back to
// allowing all origins (keeps existing behavior for anyone who hasn't
// configured it yet) but logs a warning so it's visible in Render logs.
// ---------------------------------------------------------------------------
function buildCorsOptions() {
  const configured = process.env.CORS_ALLOWED_ORIGINS;
  if (!configured) {
    console.warn('[security] CORS_ALLOWED_ORIGINS not set — allowing all origins. Set it in production for tighter security.');
    return {};
  }
  const allowed = configured.split(',').map(s => s.trim()).filter(Boolean);
  return {
    origin(origin, callback) {
      // Allow non-browser requests (no Origin header, e.g. curl/mobile app via http package)
      if (!origin) return callback(null, true);
      if (allowed.includes(origin)) return callback(null, true);
      return callback(new Error('Not allowed by CORS'));
    },
  };
}

module.exports = { rateLimit, ipAndFieldKey, securityHeaders, isStrongPassword, buildCorsOptions };
