const jwt = require('jsonwebtoken');
const crypto = require('crypto');

/**
 * auth_tokens.js
 * -----------------------------------------------------------------------
 * Implements short-lived access tokens + rotating, revocable refresh tokens.
 *
 * Previously the app used a single JWT valid for 7 days with no way to
 * revoke it before it naturally expired — if a token leaked (stolen phone,
 * exposed log, etc.) an attacker had up to 7 days of full account access
 * with nothing the user or admin could do to stop it.
 *
 * New design:
 *   - Access token: JWT, 15 minutes, used for every normal API call.
 *   - Refresh token: opaque random string, 30 days, used ONLY to obtain a
 *     new access token. Stored server-side as a bcrypt-independent SHA-256
 *     hash (fast lookups are fine here since it's already a high-entropy
 *     random token, not a user-chosen password).
 *   - Rotation: each use of a refresh token immediately revokes it and
 *     issues a new one in the same "family". If a revoked/already-used
 *     refresh token is ever presented again, that's a strong signal of
 *     token theft/replay — the entire family is revoked, forcing re-login
 *     everywhere that family's tokens were active.
 *   - Logout revokes the current refresh token (and, optionally, the whole
 *     family for "logout everywhere").
 * -----------------------------------------------------------------------
 */

const ACCESS_TOKEN_TTL = '15m';
const REFRESH_TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

function signAccessToken(JWT_SECRET, payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_TOKEN_TTL });
}

function generateOpaqueToken() {
  return crypto.randomBytes(40).toString('hex');
}

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * Issues a brand new refresh token (new family) — used at login/register.
 */
async function issueNewRefreshTokenFamily(db, { ownerType, ownerId, req }) {
  const token = generateOpaqueToken();
  const tokenHash = hashToken(token);
  const familyId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_MS).toISOString();

  await db.query(
    `INSERT INTO refresh_tokens (token_hash, family_id, owner_type, owner_id, user_agent, ip, expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [tokenHash, familyId, ownerType, ownerId, req?.headers?.['user-agent'] || null, req?.ip || null, expiresAt]
  );

  return { refreshToken: token, familyId, expiresAt };
}

/**
 * Rotates a refresh token: validates it, revokes it, and issues a new one
 * in the same family. Detects reuse of an already-revoked token (likely
 * theft/replay) and revokes the whole family as a precaution.
 *
 * @returns {object} { ok: true, ownerType, ownerId, refreshToken, expiresAt }
 *                    or { ok: false, reason: 'invalid'|'reused'|'expired' }
 */
async function rotateRefreshToken(db, presentedToken, req) {
  const tokenHash = hashToken(presentedToken);
  const r = await db.query('SELECT * FROM refresh_tokens WHERE token_hash=$1', [tokenHash]);
  const record = r.rows[0];

  if (!record) return { ok: false, reason: 'invalid' };

  if (record.revoked) {
    // This token was already used/rotated away, or explicitly revoked
    // (e.g. logout). Presenting it again is a red flag for token replay —
    // revoke the entire family so any attacker holding a copy is also
    // locked out, and the legitimate user simply has to log in again.
    await db.query('UPDATE refresh_tokens SET revoked=true WHERE family_id=$1', [record.family_id]);
    return { ok: false, reason: 'reused' };
  }

  if (new Date(record.expires_at).getTime() < Date.now()) {
    return { ok: false, reason: 'expired' };
  }

  const newToken = generateOpaqueToken();
  const newTokenHash = hashToken(newToken);
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_MS).toISOString();

  await db.query('UPDATE refresh_tokens SET revoked=true, replaced_by=$1 WHERE id=$2', [newTokenHash, record.id]);
  await db.query(
    `INSERT INTO refresh_tokens (token_hash, family_id, owner_type, owner_id, user_agent, ip, expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [newTokenHash, record.family_id, record.owner_type, record.owner_id, req?.headers?.['user-agent'] || null, req?.ip || null, expiresAt]
  );

  return { ok: true, ownerType: record.owner_type, ownerId: record.owner_id, refreshToken: newToken, expiresAt };
}

/**
 * Revokes a single refresh token (used at logout). Silently no-ops if the
 * token doesn't exist / already revoked.
 */
async function revokeRefreshToken(db, presentedToken) {
  const tokenHash = hashToken(presentedToken);
  await db.query('UPDATE refresh_tokens SET revoked=true WHERE token_hash=$1', [tokenHash]);
}

/**
 * Revokes every refresh token for a given owner (user or admin) — "logout
 * everywhere" / admin-initiated force-logout (e.g. if a device is reported
 * stolen).
 */
async function revokeAllForOwner(db, ownerType, ownerId) {
  await db.query('UPDATE refresh_tokens SET revoked=true WHERE owner_type=$1 AND owner_id=$2 AND revoked=false', [ownerType, ownerId]);
}

module.exports = {
  signAccessToken,
  issueNewRefreshTokenFamily,
  rotateRefreshToken,
  revokeRefreshToken,
  revokeAllForOwner,
};
