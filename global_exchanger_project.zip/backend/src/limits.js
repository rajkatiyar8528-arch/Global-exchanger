/**
 * limits.js
 * -----------------------------------------------------------------------
 * Shared, dependency-free configuration and pure helper functions for:
 *   1. KYC-tier transaction/wallet limits (inspired by RBI's Small PPI vs
 *      Full-KYC PPI framework under the Master Directions on Prepaid
 *      Payment Instruments — see LEGAL_COMPLIANCE_CHECKLIST.md section 1).
 *   2. AML large-transaction flagging thresholds.
 *   3. Crypto Virtual Digital Asset (VDA) TDS calculation per Section 194S
 *      of the Income Tax Act, 1961.
 *
 * This module has NO database access — both server.js (JSON) and
 * server_pg.js (Postgres) import these pure constants/functions and do
 * their own DB reads/writes around them. This keeps the actual regulatory
 * numbers/logic in exactly one place so the two backends can't drift.
 *
 * All thresholds are configurable via environment variables so they can be
 * tuned without a code change/redeploy as your compliance posture evolves
 * or as you obtain formal licensing (see LEGAL_COMPLIANCE_CHECKLIST.md).
 *
 * IMPORTANT: This is a practical, conservative engineering implementation
 * of publicly known regulatory frameworks as of mid-2026. It is NOT a
 * substitute for review by a chartered accountant / compliance lawyer —
 * see the disclaimers in LEGAL_COMPLIANCE_CHECKLIST.md and
 * TECHNICAL_SAFEGUARDS_GUIDE.md.
 * -----------------------------------------------------------------------
 */

// Currencies treated as Virtual Digital Assets (VDA) for TDS/AML purposes.
const VDA_CURRENCIES = ['BTC', 'ETH', 'XRP'];

// ---------------------------------------------------------------------------
// 1. KYC-tier wallet / transaction limits.
// ---------------------------------------------------------------------------
// "minKyc" = user has NOT completed KYC (kycStatus !== 'approved'). Modeled
// loosely on RBI's "Small PPI" category: limited monthly loading, no
// peer-to-peer transfer, no currency/crypto exchange, no withdrawal.
//
// "fullKyc" = user's KYC has been approved by admin. Modeled loosely on
// RBI's "Full-KYC PPI" category: higher wallet balance cap, capped monthly
// P2P transfer amount, and configurable per-transaction/daily aggregate
// limits as a general AML/fraud safeguard (not just an RBI-specific figure).
const LIMITS = {
  minKyc: {
    maxWalletBalance: Number(process.env.LIMIT_MIN_KYC_MAX_BALANCE_INR || 10000),
    monthlyLoadLimit: Number(process.env.LIMIT_MIN_KYC_MONTHLY_LOAD_INR || 10000),
    allowP2PSend: false,
    allowExchange: false,
    allowWithdrawal: false,
  },
  fullKyc: {
    maxWalletBalance: Number(process.env.LIMIT_FULL_KYC_MAX_BALANCE_INR || 200000),
    perTransactionLimit: Number(process.env.LIMIT_FULL_KYC_PER_TXN_INR || 200000),
    dailyTransactionLimit: Number(process.env.LIMIT_FULL_KYC_DAILY_INR || 200000),
    monthlyP2PLimit: Number(process.env.LIMIT_FULL_KYC_MONTHLY_P2P_INR || 25000),
    allowP2PSend: true,
    allowExchange: true,
    allowWithdrawal: true,
  },
};

function tierFor(kycStatus) {
  return kycStatus === 'approved' ? LIMITS.fullKyc : LIMITS.minKyc;
}

// ---------------------------------------------------------------------------
// 2. AML large-transaction flagging thresholds. These do NOT block a
//    transaction by themselves (unless it also breaches a hard limit above)
//    — they create an admin-reviewable flag so unusual activity is visible
//    rather than silently invisible, which is a baseline AML good-practice
//    even before formal licensing/AML program maturity.
// ---------------------------------------------------------------------------
const AML_SINGLE_TXN_THRESHOLD_INR = Number(process.env.AML_SINGLE_TXN_THRESHOLD_INR || 200000);
const AML_DAILY_AGGREGATE_THRESHOLD_INR = Number(process.env.AML_DAILY_AGGREGATE_THRESHOLD_INR || 300000);

// Rough static INR-equivalent conversion used ONLY for comparing amounts
// against INR-denominated limits/thresholds above. This is intentionally
// approximate (not the live market rate used for actual exchange execution)
// — it exists purely as a fast, synchronous safety check. Update
// periodically to stay roughly in line with real rates.
const APPROX_INR_RATE = { INR: 1, USD: 83, EUR: 90, GBP: 106, BTC: 5500000, ETH: 280000, XRP: 45 };
function toApproxInr(amount, currency) {
  const rate = APPROX_INR_RATE[currency] ?? 1;
  return Number(amount || 0) * rate;
}

// ---------------------------------------------------------------------------
// 3. Crypto (VDA) TDS — Section 194S, Income Tax Act, 1961.
// ---------------------------------------------------------------------------
// Applies when a user disposes of (sells/converts away from) a VDA. Rate is
// currently 1% as per publicly known law. Threshold: to keep this
// conservative and avoid mis-classifying "specified persons" (which
// requires knowing the user's turnover/income — not something we can
// reliably determine), we use a single, LOWER threshold (default ₹10,000
// per financial year) rather than trying to guess which higher threshold
// (₹50,000) a given user might qualify for. This means we may deduct TDS
// slightly more often/earlier than the strict legal minimum for some users
// — a deliberate conservative choice (a CA can always help a user reclaim
// excess TDS via their income tax return; UNDER-deduction is the bigger
// compliance risk for the platform).
const CRYPTO_TDS_RATE = Number(process.env.CRYPTO_TDS_RATE || 0.01); // 1%
const CRYPTO_TDS_THRESHOLD_INR = Number(process.env.CRYPTO_TDS_THRESHOLD_INR || 10000);

// Indian Financial Year runs 1 April - 31 March. Returns a string like
// "2026-27" for any date between 1 Apr 2026 and 31 Mar 2027.
function currentFinancialYear(date = new Date()) {
  const y = date.getFullYear();
  const m = date.getMonth(); // 0-indexed; April = 3
  const startYear = m >= 3 ? y : y - 1;
  return `${startYear}-${String((startYear + 1) % 100).padStart(2, '0')}`;
}

// Given the user's cumulative gross VDA-transfer value so far this
// financial year (BEFORE this transaction) and this transaction's gross
// value (both already converted to INR-equivalent), returns the TDS amount
// (in INR-equivalent) to deduct on THIS transaction.
//   - If cumulative-after stays at/under threshold: TDS = 0.
//   - If cumulative-before already exceeded threshold: TDS applies to the
//     full current transaction amount.
//   - If this transaction is the one that pushes cumulative over the
//     threshold: TDS applies only to the portion of THIS transaction that
//     is above the threshold (i.e., the excess).
function computeCryptoTds(cumulativeBeforeInr, grossAmountInr) {
  const before = Number(cumulativeBeforeInr || 0);
  const gross = Number(grossAmountInr || 0);
  const after = before + gross;
  if (after <= CRYPTO_TDS_THRESHOLD_INR) return 0;
  const taxableAmount = before >= CRYPTO_TDS_THRESHOLD_INR ? gross : after - CRYPTO_TDS_THRESHOLD_INR;
  return Math.round(taxableAmount * CRYPTO_TDS_RATE * 100) / 100;
}

module.exports = {
  VDA_CURRENCIES,
  LIMITS,
  tierFor,
  AML_SINGLE_TXN_THRESHOLD_INR,
  AML_DAILY_AGGREGATE_THRESHOLD_INR,
  toApproxInr,
  CRYPTO_TDS_RATE,
  CRYPTO_TDS_THRESHOLD_INR,
  currentFinancialYear,
  computeCryptoTds,
};
