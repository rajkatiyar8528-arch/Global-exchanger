/**
 * analytics.js
 * -----------------------------------------------------------------------
 * Dependency-free, pure helper functions that turn a flat list of a
 * single user's transactions into the aggregates the Spending Analytics
 * screen needs (monthly in/out trend, category breakdown, top
 * counterparties). Shared by both server.js (JSON) and server_pg.js
 * (Postgres) so both backends compute identical numbers from identical
 * input shapes — each backend maps its own field naming (camelCase JSON
 * vs. snake_case Postgres) into the normalized shape below before calling
 * these functions.
 *
 * Normalized transaction shape expected by every function here:
 *   { id, type, currency, amount, status, direction, createdAt, counterpartyId, counterpartyLabel }
 * `direction` is 'credit' (money in) or 'debit' (money out) from THIS
 * user's point of view — same convention as statements.js.
 * -----------------------------------------------------------------------
 */

// Maps a transaction `type` to a human-friendly "category" for the pie
// chart. Kept intentionally simple (no ML/guessing) — the app doesn't
// collect merchant-category data, so categories are derived purely from
// the transaction type already known to the system.
function categoryForType(type, direction) {
  switch (type) {
    case 'wallet_topup': return 'Wallet Top-up';
    case 'refund': return 'Refunds';
    case 'exchange_complete': return 'Currency Exchange';
    case 'send': return direction === 'credit' ? 'Received from Others' : 'Sent to Others';
    default: return 'Other';
  }
}

// Groups completed transactions by calendar month (UTC, "YYYY-MM") and
// sums credit/debit amounts separately, converting everything to an
// approximate INR-equivalent so multi-currency activity can be compared
// on one chart. `toApproxInrFn` is injected (from limits.js's
// toApproxInr) rather than imported directly, keeping this module
// dependency-free/pure and easily unit-testable.
function monthlyTrend(transactions, toApproxInrFn, monthsBack = 6) {
  const now = new Date();
  const months = [];
  for (let i = monthsBack - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    months.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
  }
  const buckets = Object.fromEntries(months.map(m => [m, { month: m, creditInr: 0, debitInr: 0 }]));

  for (const t of transactions) {
    if (t.status !== 'completed') continue;
    const d = new Date(t.createdAt);
    const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
    if (!buckets[key]) continue; // outside the requested window
    const amountInr = toApproxInrFn(t.amount, t.currency);
    if (t.direction === 'credit') buckets[key].creditInr += amountInr;
    else buckets[key].debitInr += amountInr;
  }

  return months.map(m => buckets[m]);
}

// Breaks down total DEBIT (money-out) volume by category, for a pie/bar
// chart of "where did my money go". Only debits are included since
// "spending" analytics is about outflow; credits are shown separately in
// the monthly trend chart's "in" line.
function categoryBreakdown(transactions, toApproxInrFn) {
  const totals = {};
  for (const t of transactions) {
    if (t.status !== 'completed' || t.direction !== 'debit') continue;
    const category = categoryForType(t.type, t.direction);
    totals[category] = (totals[category] || 0) + toApproxInrFn(t.amount, t.currency);
  }
  return Object.entries(totals)
    .map(([category, amountInr]) => ({ category, amountInr }))
    .sort((a, b) => b.amountInr - a.amountInr);
}

// Top counterparties by total debit volume sent to them (for "send"-type
// transactions only, where a counterparty is meaningful) — answers "who do
// I send the most money to".
function topCounterparties(transactions, toApproxInrFn, limit = 5) {
  const totals = {};
  for (const t of transactions) {
    if (t.status !== 'completed' || t.direction !== 'debit' || t.type !== 'send' || !t.counterpartyId) continue;
    const key = t.counterpartyId;
    if (!totals[key]) totals[key] = { counterpartyId: key, counterpartyLabel: t.counterpartyLabel || 'Unknown', amountInr: 0, count: 0 };
    totals[key].amountInr += toApproxInrFn(t.amount, t.currency);
    totals[key].count += 1;
  }
  return Object.values(totals).sort((a, b) => b.amountInr - a.amountInr).slice(0, limit);
}

// Overall summary numbers for the top of the Analytics screen.
function overallSummary(transactions, toApproxInrFn) {
  let totalInInr = 0, totalOutInr = 0, completedCount = 0;
  for (const t of transactions) {
    if (t.status !== 'completed') continue;
    completedCount += 1;
    const amountInr = toApproxInrFn(t.amount, t.currency);
    if (t.direction === 'credit') totalInInr += amountInr;
    else totalOutInr += amountInr;
  }
  return { totalInInr, totalOutInr, netInr: totalInInr - totalOutInr, completedCount };
}

module.exports = { categoryForType, monthlyTrend, categoryBreakdown, topCounterparties, overallSummary };
