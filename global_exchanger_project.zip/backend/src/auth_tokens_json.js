// Same access/refresh token logic as auth_tokens.js, adapted for the JSON
// file-based demo backend (server.js), which stores everything in a single
// db object via readDb()/writeDb() instead of PostgreSQL.
const crypto = require('crypto');
const { signAccessToken } = require('./auth_tokens');

const REFRESH_TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000;

function generateOpaqueToken() {
  return crypto.randomBytes(40).toString('hex');
}

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function issueNewRefreshTokenFamilyJson(db, { ownerType, ownerId, req }) {
  db.refreshTokens = db.refreshTokens || [];
  const token = generateOpaqueToken();
  const tokenHash = hashToken(token);
  const familyId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_MS).toISOString();

  db.refreshTokens.push({
    id: crypto.randomUUID(),
    tokenHash,
    familyId,
    ownerType,
    ownerId,
    revoked: false,
    replacedBy: null,
    userAgent: req?.headers?.['user-agent'] || null,
    ip: req?.ip || null,
    expiresAt,
    createdAt: new Date().toISOString(),
  });

  return { refreshToken: token, familyId, expiresAt };
}

function rotateRefreshTokenJson(db, presentedToken, req) {
  db.refreshTokens = db.refreshTokens || [];
  const tokenHash = hashToken(presentedToken);
  const record = db.refreshTokens.find(t => t.tokenHash === tokenHash);

  if (!record) return { ok: false, reason: 'invalid' };

  if (record.revoked) {
    db.refreshTokens.filter(t => t.familyId === record.familyId).forEach(t => { t.revoked = true; });
    return { ok: false, reason: 'reused' };
  }

  if (new Date(record.expiresAt).getTime() < Date.now()) {
    return { ok: false, reason: 'expired' };
  }

  const newToken = generateOpaqueToken();
  const newTokenHash = hashToken(newToken);
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_MS).toISOString();

  record.revoked = true;
  record.replacedBy = newTokenHash;

  db.refreshTokens.push({
    id: crypto.randomUUID(),
    tokenHash: newTokenHash,
    familyId: record.familyId,
    ownerType: record.ownerType,
    ownerId: record.ownerId,
    revoked: false,
    replacedBy: null,
    userAgent: req?.headers?.['user-agent'] || null,
    ip: req?.ip || null,
    expiresAt,
    createdAt: new Date().toISOString(),
  });

  return { ok: true, ownerType: record.ownerType, ownerId: record.ownerId, refreshToken: newToken, expiresAt };
}

function revokeRefreshTokenJson(db, presentedToken) {
  db.refreshTokens = db.refreshTokens || [];
  const tokenHash = hashToken(presentedToken);
  const record = db.refreshTokens.find(t => t.tokenHash === tokenHash);
  if (record) record.revoked = true;
}

function revokeAllForOwnerJson(db, ownerType, ownerId) {
  db.refreshTokens = db.refreshTokens || [];
  db.refreshTokens.filter(t => t.ownerType === ownerType && t.ownerId === ownerId && !t.revoked).forEach(t => { t.revoked = true; });
}

module.exports = {
  signAccessToken,
  issueNewRefreshTokenFamilyJson,
  rotateRefreshTokenJson,
  revokeRefreshTokenJson,
  revokeAllForOwnerJson,
};
