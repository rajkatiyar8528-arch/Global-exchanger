#!/usr/bin/env node
/**
 * sync_sanctions_cli.js
 * -----------------------------------------------------------------------
 * Command-line entrypoint for backend/src/sanctions_sync.js. Run this to
 * refresh `data/sanctions_list.json` with the full, current official OFAC
 * SDN List + UN Security Council Consolidated List.
 *
 * Usage:
 *   node src/sync_sanctions_cli.js
 *   npm run sync:sanctions       (same thing, via package.json script)
 *
 * Exit codes:
 *   0 = success (at least one source synced, file written)
 *   1 = failure (all sources failed, file left unchanged)
 *
 * See SANCTIONS_AUTO_UPDATE_GUIDE.md for how to run this automatically on
 * a schedule (e.g. a daily Render Cron Job) rather than manually.
 * -----------------------------------------------------------------------
 */

const { syncSanctionsList } = require('./sanctions_sync');

(async () => {
  console.log('[sanctions-sync] Starting sync from official sources...');
  const summary = await syncSanctionsList({ writeToFile: true });

  console.log('\n[sanctions-sync] Summary:');
  for (const s of summary.sources) {
    console.log(`  - ${s.name}: ${s.entryCount} entries (${s.status})`);
  }
  console.log(`  Total merged entries: ${summary.entryCount}`);

  if (summary.errors.length > 0) {
    console.log('\n[sanctions-sync] Warnings/errors:');
    for (const e of summary.errors) console.log(`  ! ${e}`);
  }

  if (summary.entryCount === 0) {
    console.error('\n[sanctions-sync] FAILED — no entries synced from any source. sanctions_list.json was NOT modified.');
    process.exit(1);
  }

  console.log('\n[sanctions-sync] Done. data/sanctions_list.json updated.');
  process.exit(0);
})();
