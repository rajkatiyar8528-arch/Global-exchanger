# Dispute & Complaint Management — User-Side UI

## What Was Missing

The backend already had full dispute/complaint support (submit, admin
review, status updates), but the app only let users **submit** a complaint
or dispute — there was no way to ever see it again afterwards. A user had
no idea if their dispute was being looked at, resolved, or rejected, short
of contacting support separately.

Specifically:
- `GET /api/complaints` (a user's own complaints) **did not exist at all**
  — only the admin-only list endpoint existed.
- `ApiService.myDisputes()` existed in the app's API client but was never
  called from any screen.
- The dispute submission form required manually typing a Transaction ID
  with no way to pick from your actual transaction history.

## What's New

### New Endpoint
```
GET /api/complaints
```
Returns the logged-in user's own complaints (previously only
`POST /api/complaints` existed for users — there was no way to check status
afterwards).

### Redesigned "Help & Support" Screen
Now has two tabs:

**Complaints tab**
- Submit form (subject + details)
- "My Complaints" list below, showing status (submitted / under_review /
  resolved / rejected) with a color-coded badge, and the submission date

**Disputes tab**
- Submit form with a **dropdown to pick the related transaction** from your
  actual transaction history (instead of manually typing a transaction ID,
  which was error-prone and easy to get wrong)
- Reason + details fields
- "My Disputes" list below, showing status, and — when the admin has
  provided them — the **admin's note** and **resolution**, so the user
  actually finds out what happened to their dispute

### Removed
The old "AI Help Agent" section was a non-functional placeholder (its
button just showed "AI agent integration next phase me add hoga" and did
nothing). It's been removed to make room for the real, working
complaint/dispute tracking — a fake feature was replaced with the working
one that was actually needed.

## Where It Shows Up

- **Home screen → "AI Help" tile** (bottom nav) now opens the real Help &
  Support screen with working Complaints/Disputes tabs (the label wasn't
  changed to avoid unrelated navigation-label churn, but the destination is
  now a fully functional support center).
- **Transaction Detail screen → "Raise Complaint / Dispute"** button also
  opens this same screen.

## Admin Side

No changes were needed here — the admin panel already had working
Complaints and Disputes management sections (`admin_panel/index.html`,
"Complaints" and "Dispute Management" cards) that let an admin update
status, add notes, and provide a resolution. This work was specifically
about closing the loop so users can actually see those updates.
