# End-to-End Testing Guide (v1.8.0+10)

This document records what was already automatically tested in this
development session, and gives you a manual test checklist you can run
yourself from your Android phone on the live app before considering it
launch-ready.

## What was already tested automatically (this session)

A full simulated user journey was run locally against the JSON demo backend
(`server.js`) using 40 automated checks covering the entire app lifecycle in
one continuous flow. **All 40 checks passed.** This covered:

1. User registration (2 users, one referred by the other via referral code)
2. Admin login with default admin credentials
3. KYC submission → Admin approves KYC
4. Wallet top-up via mock payment gateway → balance reflects correctly
5. Setting a Security PIN for both users
6. Send Money between users (PIN-protected)
7. **Referral reward** correctly fires only on the referred user's first
   qualifying transaction (not at signup) — confirmed ₹100 credited
8. Currency exchange order creation → escrow lock → admin completes it →
   commission (0.8%/0.2% split) and reward correctly credited to wallet
9. Bank account add → admin verifies it
10. Withdrawal request → funds correctly locked in wallet → admin
    approves → processing → completed → **locked amount correctly cleared**
    on completion (this was Bug #5 found & fixed in an earlier session —
    re-confirmed still fixed)
11. Complaint submission and listing
12. Dispute submission (linked to a real transaction) and listing
13. Receipt token generation and HTML receipt rendering (no-auth access via
    short-lived token, as designed)
14. In-app notifications generated correctly for KYC/payment/exchange/
    withdrawal events
15. Admin dashboard and analytics endpoints return correct today/period stats
16. **Rate limiting** correctly blocks repeated bad admin login attempts
    (429 after threshold) — re-confirmed the earlier `trust proxy` fix still
    works correctly

Also confirmed:
- `server.js` (JSON demo) and `server_pg.js` (PostgreSQL production) have
  **exactly the same 67 API routes** — no drift between the two backends.
- `db/schema.sql` has all 21 required tables matching the 21 `db.json`
  top-level keys — no missing migrations.
- Both backend files pass `node -c` syntax validation.
- `main.dart` and `api_service.dart` pass brace/paren balance checks.

This gives high confidence the *backend logic* is sound. What automated
testing **cannot** cover from this sandboxed environment: the actual Flutter
UI on a real device, real Razorpay payment popups, real SMS/email delivery,
camera/gallery KYC photo upload, and real bank withdrawal processing (which
in this app is manual/admin-driven, not connected to a real payout API yet).

## Manual test checklist (do this on your phone with the real APK)

Do this on the **live production app** (pointed at Render backend), ideally
with 2 real phone numbers/email addresses (or 2 test accounts) so you can
test sending money between them.

### A. Account basics
- [ ] Sign up a new account with a real email — do you receive the OTP
      email? (Check spam folder too.)
- [ ] Log in with correct password → success
- [ ] Log in with wrong password 6 times quickly → should get blocked
      ("Too many login attempts") — this is the rate limiter working
- [ ] Log out → Log back in → your data (wallet balance, history) is intact
- [ ] "Logout From All Devices" → app should force you back to login

### B. KYC
- [ ] Submit KYC with Aadhaar/PAN numbers + upload real photos (Aadhaar
      front/back, PAN, Selfie) using both Camera and Gallery options
- [ ] Try uploading a >4MB photo → should be rejected with a clear message
- [ ] Try uploading a non-image file → should be rejected
- [ ] As admin (web panel), open the KYC request and view the uploaded
      documents — are they clear/legible?
- [ ] Admin approves KYC → user should get a notification + email

### C. Wallet & Payments (⚠️ REAL MONEY — use a small amount first, e.g. ₹10-50)
- [ ] Add Money via Razorpay with a real/test card or UPI — does the
      Razorpay checkout open correctly?
- [ ] After successful payment, does wallet balance update within a few
      seconds?
- [ ] Check your bank/card statement — was the correct amount actually
      charged, matching what the app shows?
- [ ] Try closing the Razorpay popup without paying → app should show
      "Payment failed" and NOT credit the wallet

### D. Send Money / Receive Money
- [ ] Set a Security PIN (try a "too easy" PIN like `1234` — should still
      work per the earlier fix, but truly sequential ones stay blocked
      internally — try `1111` and confirm it's rejected)
- [ ] Send money to a second test account by email
- [ ] Try sending with wrong PIN → should be rejected without moving funds
- [ ] Scan a Receive QR code from the second account and confirm amount/
      note auto-fill correctly in Send Money screen

### E. Currency Exchange / Convert
- [ ] Create a Convert order (e.g. INR → USD)
- [ ] Lock escrow
- [ ] As admin, complete the exchange order
- [ ] Confirm your USD balance increased and INR balance decreased by the
      correct amount, and a small reward appeared in Reward Wallet

### F. Withdraw to Bank (⚠️ Currently admin-manual — no real bank payout API)
- [ ] Add a bank account
- [ ] As admin, verify the bank account
- [ ] Request a withdrawal — confirm the amount becomes "locked" in wallet
      (not spendable, but also not gone)
- [ ] As admin, walk it through approved → processing → completed
- [ ] Confirm wallet's locked amount clears to 0 after completion
- [ ] **IMPORTANT**: since there is no real payout API connected, "completed"
      here is just a status flag — YOU (the business) must manually transfer
      the real money to the user's bank account outside the app when you
      mark it completed. This is a manual operational process, not
      automated. Make sure whoever operates the admin panel understands this.

### G. Support: Complaints & Disputes
- [ ] Submit a complaint → check it shows up in "My Complaints"
- [ ] Submit a dispute against a real transaction → check it shows in "My
      Disputes"
- [ ] As admin, respond to/resolve both and confirm the user sees the
      updated status + gets a notification

### H. Notifications & Receipts
- [ ] Confirm the notification bell badge count updates after actions like
      payment success, KYC approval, exchange completion
- [ ] Open a transaction, tap "View/Download Receipt" → confirms a browser
      tab opens with a printable receipt page

### I. Network resilience (new in v1.8.0+10 — UI/UX Polish)
- [ ] Turn on Airplane Mode, open Home/History/Wallet/Notifications/Bank
      Accounts/Withdrawals/Complaints/Disputes/Referrals screens — each
      should show a friendly "No internet connection" message + Retry
      button, not a crash or blank screen
- [ ] Turn Airplane Mode off, tap Retry on each → should load normally
- [ ] Pull down to refresh on each of the above screens — should show a
      refresh spinner and reload data

### J. Referral System
- [ ] Sign up a 3rd account using an existing user's referral code
- [ ] Confirm referral shows as "Waiting for First Transaction" until the
      new user does their first send/topup/exchange
- [ ] After that first transaction, confirm ₹100 reward appears in the
      referrer's Reward Wallet and the referral status flips to "Rewarded"

## What to do if something fails
Note down: (1) which step failed, (2) exact error message shown on screen,
(3) screenshot if possible. Report back and it will be fixed in the next
round before moving further.
