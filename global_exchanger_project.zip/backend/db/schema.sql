CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  country TEXT,
  address TEXT,
  house_number TEXT,
  password_hash TEXT NOT NULL,
  security_pin_hash TEXT,
  kyc_status TEXT NOT NULL DEFAULT 'pending',
  referral_code TEXT UNIQUE NOT NULL,
  referred_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  special_key_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  balances JSONB NOT NULL DEFAULT '{"INR":0,"USD":0,"EUR":0,"BTC":0,"ETH":0,"XRP":0}',
  locked JSONB NOT NULL DEFAULT '{}',
  reward_balances JSONB NOT NULL DEFAULT '{"INR":0,"USD":0,"EUR":0,"BTC":0,"ETH":0,"XRP":0}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Migration-safe: adds reward_balances to wallets created before this column existed
ALTER TABLE wallets ADD COLUMN IF NOT EXISTS reward_balances JSONB NOT NULL DEFAULT '{"INR":0,"USD":0,"EUR":0,"BTC":0,"ETH":0,"XRP":0}';

CREATE TABLE IF NOT EXISTS kyc_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  national_id TEXT,
  tax_id TEXT,
  country TEXT,
  document_names JSONB NOT NULL DEFAULT '[]',
  documents JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'under_review',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Migration-safe: adds real document storage to KYC requests created before this existed.
-- Each entry in `documents` looks like:
--   { "label": "Aadhaar Front", "mimeType": "image/jpeg", "dataBase64": "..." }
ALTER TABLE kyc_requests ADD COLUMN IF NOT EXISTS documents JSONB NOT NULL DEFAULT '[]';

CREATE TABLE IF NOT EXISTS bank_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  holder_name TEXT,
  bank_name TEXT,
  account_number_masked TEXT,
  ifsc_swift_iban TEXT,
  country TEXT,
  status TEXT NOT NULL DEFAULT 'pending_verification',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type TEXT NOT NULL,
  from_user_id UUID REFERENCES users(id),
  to_user_id UUID REFERENCES users(id),
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL,
  status TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS complaints (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT,
  message TEXT,
  transaction_id UUID,
  status TEXT NOT NULL DEFAULT 'submitted',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS referrals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_code TEXT NOT NULL,
  referrer_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  referred_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  reward NUMERIC(18,2) NOT NULL DEFAULT 100,
  currency TEXT NOT NULL DEFAULT 'INR',
  status TEXT NOT NULL DEFAULT 'pending_first_transaction',
  rewarded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Migration-safe: adds referrer_user_id + rewarded_at to referrals rows created
-- before the referral system was completed, and updates the default status
-- from the old "pending_account_created" (reward was never actually paid) to
-- the new fraud-resistant "pending_first_transaction" flow.
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS referrer_user_id UUID REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS rewarded_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_referrals_referrer_user ON referrals(referrer_user_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred_user ON referrals(referred_user_id);
CREATE INDEX IF NOT EXISTS idx_referrals_status ON referrals(status);

CREATE TABLE IF NOT EXISTS exchange_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mode TEXT NOT NULL DEFAULT 'convert',
  from_currency TEXT NOT NULL,
  to_currency TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_match',
  escrow_status TEXT NOT NULL DEFAULT 'not_locked',
  commission NUMERIC(24,8) NOT NULL,
  admin_commission NUMERIC(24,8) NOT NULL,
  seller_commission NUMERIC(24,8) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS commissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES exchange_orders(id) ON DELETE CASCADE,
  admin_commission NUMERIC(24,8) NOT NULL,
  seller_commission NUMERIC(24,8) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_users ON transactions(from_user_id, to_user_id);
CREATE INDEX IF NOT EXISTS idx_complaints_user ON complaints(user_id);
CREATE INDEX IF NOT EXISTS idx_exchange_user ON exchange_orders(user_id);

ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS otp_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL,
  purpose TEXT NOT NULL,
  otp_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  gateway_order_id TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL,
  purpose TEXT NOT NULL DEFAULT 'wallet_topup',
  status TEXT NOT NULL DEFAULT 'created',
  gateway_response JSONB NOT NULL DEFAULT '{}',
  verification JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_otp_email_purpose ON otp_codes(email, purpose);
CREATE INDEX IF NOT EXISTS idx_payment_orders_user ON payment_orders(user_id);

CREATE TABLE IF NOT EXISTS ledger_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_type TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  currency TEXT NOT NULL,
  balance NUMERIC(24,8) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(owner_type, owner_id, currency)
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id UUID NOT NULL,
  account_id UUID NOT NULL REFERENCES ledger_accounts(id),
  direction TEXT NOT NULL CHECK(direction IN ('debit','credit')),
  amount NUMERIC(24,8) NOT NULL CHECK(amount > 0),
  currency TEXT NOT NULL,
  reference_type TEXT,
  reference_id TEXT,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ledger_entries_group ON ledger_entries(group_id);
CREATE INDEX IF NOT EXISTS idx_ledger_accounts_owner ON ledger_accounts(owner_type, owner_id, currency);

CREATE TABLE IF NOT EXISTS refunds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES payment_orders(id),
  provider TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL,
  reason TEXT,
  status TEXT NOT NULL,
  gateway_refund JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE admins ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'super_admin';
ALTER TABLE admins ADD COLUMN IF NOT EXISTS permissions JSONB NOT NULL DEFAULT '["users:read","kyc:manage","payments:read","refunds:manage","exchange:manage","ledger:read","audit:read","admin:manage"]';

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id UUID,
  user_id UUID,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}',
  ip TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_admin ON audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);

CREATE TABLE IF NOT EXISTS disputes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID,
  reason TEXT NOT NULL,
  message TEXT NOT NULL,
  evidence JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'submitted',
  admin_note TEXT,
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_disputes_user ON disputes(user_id);
CREATE INDEX IF NOT EXISTS idx_disputes_status ON disputes(status);

-- ---------------------------------------------------------------------------
-- In-app notifications (payment success/fail, KYC status, exchange status,
-- reward credited, etc). Shown instantly inside the app without depending on
-- email delivery; an email is also sent in parallel when email is configured.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);

-- ---------------------------------------------------------------------------
-- Short-lived, single-purpose tokens used to let a signed-in user open a
-- printable/downloadable receipt in an external browser tab without ever
-- putting their real JWT in a URL. Each token is scoped to exactly one
-- transaction or exchange order and expires quickly.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS receipt_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID,
  exchange_order_id UUID,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_receipt_tokens_token ON receipt_tokens(token);

-- ---------------------------------------------------------------------------
-- Refresh tokens: enables short-lived (15 min) access tokens for regular API
-- calls, backed by a long-lived (30 day) refresh token that is stored here
-- (hashed, never in plaintext) so it can be revoked server-side — e.g. on
-- logout, or if a device/token is reported lost/stolen. This is a major
-- improvement over the previous design where a single 7-day JWT was the only
-- credential and could never be revoked before it naturally expired.
--
-- Rotation: every time a refresh token is used, it is immediately marked
-- revoked and a brand new refresh token is issued. If a leaked/stolen refresh
-- token is ever replayed after the legitimate user has already rotated past
-- it, the reused-old-token attempt is detected and the ENTIRE token family is
-- revoked (logging the user/attacker out everywhere), limiting the damage
-- from a leaked token.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token_hash TEXT UNIQUE NOT NULL,
  family_id UUID NOT NULL,
  owner_type TEXT NOT NULL DEFAULT 'user', -- 'user' | 'admin'
  owner_id UUID NOT NULL,
  revoked BOOLEAN NOT NULL DEFAULT FALSE,
  replaced_by TEXT,
  user_agent TEXT,
  ip TEXT,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_hash ON refresh_tokens(token_hash);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_family ON refresh_tokens(family_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_owner ON refresh_tokens(owner_type, owner_id);
