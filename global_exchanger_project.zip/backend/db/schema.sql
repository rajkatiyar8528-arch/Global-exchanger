CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  country TEXT,
  address TEXT,
  house_number TEXT,
  password_hash TEXT NOT NULL,
  security_pin_hash TEXT,
  kyc_status TEXT NOT NULL DEFAULT 'pending',
  referral_code TEXT UNIQUE NOT NULL,
  referred_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  special_key_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  balances JSONB NOT NULL DEFAULT '{"INR":0,"USD":0,"EUR":0,"BTC":0,"ETH":0,"XRP":0}',
  locked JSONB NOT NULL DEFAULT '{}',
  reward_balances JSONB NOT NULL DEFAULT '{"INR":0,"USD":0,"EUR":0,"BTC":0,"ETH":0,"XRP":0}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Migration-safe: adds reward_balances to wallets created before this column existed
ALTER TABLE wallets ADD COLUMN IF NOT EXISTS reward_balances JSONB NOT NULL DEFAULT '{"INR":0,"USD":0,"EUR":0,"BTC":0,"ETH":0,"XRP":0}';

CREATE TABLE IF NOT EXISTS kyc_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  national_id TEXT,
  tax_id TEXT,
  country TEXT,
  document_names JSONB NOT NULL DEFAULT '[]',
  documents JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'under_review',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Migration-safe: adds real document storage to KYC requests created before this existed.
-- Each entry in `documents` looks like:
--   { "label": "Aadhaar Front", "mimeType": "image/jpeg", "dataBase64": "..." }
ALTER TABLE kyc_requests ADD COLUMN IF NOT EXISTS documents JSONB NOT NULL DEFAULT '[]';

CREATE TABLE IF NOT EXISTS bank_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  holder_name TEXT,
  bank_name TEXT,
  account_number_masked TEXT,
  ifsc_swift_iban TEXT,
  country TEXT,
  status TEXT NOT NULL DEFAULT 'pending_verification',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type TEXT NOT NULL,
  from_user_id UUID REFERENCES users(id),
  to_user_id UUID REFERENCES users(id),
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL,
  status TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS complaints (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT,
  message TEXT,
  transaction_id UUID,
  status TEXT NOT NULL DEFAULT 'submitted',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Marks a complaint row as the user's single "General Support Chat" thread
-- (opened directly via the "💬 Chat with Support" button, with no
-- subject/details form required first) rather than a normal filed
-- complaint. See SUPPORT_DIRECT_CHAT_GUIDE.md.
ALTER TABLE complaints ADD COLUMN IF NOT EXISTS is_general_chat BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS referrals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_code TEXT NOT NULL,
  referrer_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  referred_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  reward NUMERIC(18,2) NOT NULL DEFAULT 100,
  currency TEXT NOT NULL DEFAULT 'INR',
  status TEXT NOT NULL DEFAULT 'pending_first_transaction',
  rewarded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Migration-safe: adds referrer_user_id + rewarded_at to referrals rows created
-- before the referral system was completed, and updates the default status
-- from the old "pending_account_created" (reward was never actually paid) to
-- the new fraud-resistant "pending_first_transaction" flow.
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS referrer_user_id UUID REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS rewarded_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_referrals_referrer_user ON referrals(referrer_user_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred_user ON referrals(referred_user_id);
CREATE INDEX IF NOT EXISTS idx_referrals_status ON referrals(status);

CREATE TABLE IF NOT EXISTS exchange_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mode TEXT NOT NULL DEFAULT 'convert',
  from_currency TEXT NOT NULL,
  to_currency TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_match',
  escrow_status TEXT NOT NULL DEFAULT 'not_locked',
  commission NUMERIC(24,8) NOT NULL,
  admin_commission NUMERIC(24,8) NOT NULL,
  seller_commission NUMERIC(24,8) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS commissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES exchange_orders(id) ON DELETE CASCADE,
  admin_commission NUMERIC(24,8) NOT NULL,
  seller_commission NUMERIC(24,8) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_users ON transactions(from_user_id, to_user_id);
CREATE INDEX IF NOT EXISTS idx_complaints_user ON complaints(user_id);
CREATE INDEX IF NOT EXISTS idx_exchange_user ON exchange_orders(user_id);

ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS otp_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL,
  purpose TEXT NOT NULL,
  otp_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  gateway_order_id TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL,
  purpose TEXT NOT NULL DEFAULT 'wallet_topup',
  status TEXT NOT NULL DEFAULT 'created',
  gateway_response JSONB NOT NULL DEFAULT '{}',
  verification JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_otp_email_purpose ON otp_codes(email, purpose);
CREATE INDEX IF NOT EXISTS idx_payment_orders_user ON payment_orders(user_id);

CREATE TABLE IF NOT EXISTS ledger_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_type TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  currency TEXT NOT NULL,
  balance NUMERIC(24,8) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(owner_type, owner_id, currency)
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id UUID NOT NULL,
  account_id UUID NOT NULL REFERENCES ledger_accounts(id),
  direction TEXT NOT NULL CHECK(direction IN ('debit','credit')),
  amount NUMERIC(24,8) NOT NULL CHECK(amount > 0),
  currency TEXT NOT NULL,
  reference_type TEXT,
  reference_id TEXT,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ledger_entries_group ON ledger_entries(group_id);
CREATE INDEX IF NOT EXISTS idx_ledger_accounts_owner ON ledger_accounts(owner_type, owner_id, currency);

CREATE TABLE IF NOT EXISTS refunds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES payment_orders(id),
  provider TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL,
  reason TEXT,
  status TEXT NOT NULL,
  gateway_refund JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE admins ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'super_admin';
ALTER TABLE admins ADD COLUMN IF NOT EXISTS permissions JSONB NOT NULL DEFAULT '["users:read","kyc:manage","payments:read","refunds:manage","exchange:manage","ledger:read","audit:read","admin:manage"]';

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id UUID,
  user_id UUID,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}',
  ip TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_admin ON audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);

CREATE TABLE IF NOT EXISTS disputes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID,
  reason TEXT NOT NULL,
  message TEXT NOT NULL,
  evidence JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'submitted',
  admin_note TEXT,
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_disputes_user ON disputes(user_id);
CREATE INDEX IF NOT EXISTS idx_disputes_status ON disputes(status);

-- ---------------------------------------------------------------------------
-- In-app notifications (payment success/fail, KYC status, exchange status,
-- reward credited, etc). Shown instantly inside the app without depending on
-- email delivery; an email is also sent in parallel when email is configured.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);

-- ---------------------------------------------------------------------------
-- Short-lived, single-purpose tokens used to let a signed-in user open a
-- printable/downloadable receipt in an external browser tab without ever
-- putting their real JWT in a URL. Each token is scoped to exactly one
-- transaction or exchange order and expires quickly.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS receipt_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID,
  exchange_order_id UUID,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_receipt_tokens_token ON receipt_tokens(token);

-- ---------------------------------------------------------------------------
-- Refresh tokens: enables short-lived (15 min) access tokens for regular API
-- calls, backed by a long-lived (30 day) refresh token that is stored here
-- (hashed, never in plaintext) so it can be revoked server-side — e.g. on
-- logout, or if a device/token is reported lost/stolen. This is a major
-- improvement over the previous design where a single 7-day JWT was the only
-- credential and could never be revoked before it naturally expired.
--
-- Rotation: every time a refresh token is used, it is immediately marked
-- revoked and a brand new refresh token is issued. If a leaked/stolen refresh
-- token is ever replayed after the legitimate user has already rotated past
-- it, the reused-old-token attempt is detected and the ENTIRE token family is
-- revoked (logging the user/attacker out everywhere), limiting the damage
-- from a leaked token.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token_hash TEXT UNIQUE NOT NULL,
  family_id UUID NOT NULL,
  owner_type TEXT NOT NULL DEFAULT 'user', -- 'user' | 'admin'
  owner_id UUID NOT NULL,
  revoked BOOLEAN NOT NULL DEFAULT FALSE,
  replaced_by TEXT,
  user_agent TEXT,
  ip TEXT,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_hash ON refresh_tokens(token_hash);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_family ON refresh_tokens(family_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_owner ON refresh_tokens(owner_type, owner_id);

-- ---------------------------------------------------------------------------
-- Bank account management: previously the app only had an unused "Add Bank
-- Account" button with no way to list, verify, or remove accounts, and no
-- link to withdrawals. bank_accounts already existed for storing masked
-- account details; this adds the fields needed for real verification and
-- soft-deletion (kept for audit trail rather than hard-deleted).
-- ---------------------------------------------------------------------------
ALTER TABLE bank_accounts ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE bank_accounts ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
ALTER TABLE bank_accounts ADD COLUMN IF NOT EXISTS verification_note TEXT;
CREATE INDEX IF NOT EXISTS idx_bank_accounts_user ON bank_accounts(user_id);

-- ---------------------------------------------------------------------------
-- Withdrawals: moves money from a user's wallet (balances) into a "locked"
-- state (mirroring the existing exchange-order escrow pattern) as soon as a
-- withdrawal is requested, so the user can't spend the same money twice
-- while the withdrawal is pending admin processing. If the admin rejects or
-- cancels it, the locked amount is returned to the spendable balance; if
-- completed, the locked amount is simply released (money has left the
-- platform to the user's bank account).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS withdrawals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  bank_account_id UUID NOT NULL REFERENCES bank_accounts(id),
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  fee NUMERIC(24,8) NOT NULL DEFAULT 0,
  net_amount NUMERIC(24,8) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | processing | completed | rejected | cancelled
  admin_note TEXT,
  processed_by UUID REFERENCES admins(id),
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_user ON withdrawals(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status);

-- Crypto (Virtual Digital Asset) TDS tracking under Section 194S, Income Tax
-- Act 1961. One row per user per Indian financial year (e.g. "2026-27"),
-- tracking cumulative gross VDA-transfer value and cumulative TDS withheld,
-- with an `entries` JSONB array logging each individual deduction (used to
-- prepare Form 26QE filings). See backend/src/limits.js and
-- TECHNICAL_SAFEGUARDS_GUIDE.md for full rationale.
CREATE TABLE IF NOT EXISTS tds_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_year TEXT NOT NULL,
  cumulative_gross_inr NUMERIC(24,2) NOT NULL DEFAULT 0,
  cumulative_tds_inr NUMERIC(24,2) NOT NULL DEFAULT 0,
  entries JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, financial_year)
);

CREATE INDEX IF NOT EXISTS idx_tds_records_user ON tds_records(user_id);
CREATE INDEX IF NOT EXISTS idx_tds_records_fy ON tds_records(financial_year);

-- Adds sanctions/PEP screening results onto each KYC submission. Populated
-- at submission time by backend/src/screening.js. Never causes an
-- automatic rejection — `review_status` starts NULL/pending and must be
-- set by an admin (see /api/admin/sanctions-flags endpoints).
ALTER TABLE kyc_requests ADD COLUMN IF NOT EXISTS sanctions_screening JSONB;

-- Travel Rule data capture for VDA (crypto) transfers — required under
-- FIU-IND's AML/CFT guidance, which treats VDA transfers like wire
-- transfers requiring originator/beneficiary identity data. See
-- backend/src/travel_rule.js for full rationale and data-minimization
-- notes (only last-4 of national ID is stored here; full KYC documents
-- remain in kyc_requests).
CREATE TABLE IF NOT EXISTS travel_rule_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  currency TEXT NOT NULL,
  amount NUMERIC(24,8) NOT NULL,
  reference_type TEXT NOT NULL,
  reference_id UUID NOT NULL,
  originator JSONB NOT NULL,
  beneficiary JSONB NOT NULL,
  captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_travel_rule_reference ON travel_rule_records(reference_type, reference_id);
CREATE INDEX IF NOT EXISTS idx_travel_rule_captured_at ON travel_rule_records(captured_at);

-- Suspicious Transaction Report (STR) case tracking. This app cannot file
-- STRs with FIU-IND directly (that's a manual portal submission process on
-- FIU-IND's side) — this table lets your Principal Officer track cases
-- from initial flag through to actual filing and FIU-IND acknowledgement.
-- See FIU_IND_REGISTRATION_GUIDE.md.
CREATE TABLE IF NOT EXISTS str_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  reason TEXT NOT NULL,
  source_type TEXT,
  source_id TEXT,
  notes TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft', -- draft | filed | acknowledged | closed
  created_by UUID REFERENCES admins(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  filed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_str_reports_user ON str_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_str_reports_status ON str_reports(status);

-- ---------------------------------------------------------------------------
-- FEATURE PACK: Price Alerts, In-App Support Chat, Transaction
-- Statement Export, Dark Mode / App Settings, Favorites Watchlist.
-- ---------------------------------------------------------------------------

-- 1. Price Alerts — user picks a currency/crypto pair + target price +
-- direction (above/below); checked opportunistically whenever /api/rates
-- is computed (see backend/src/server.js and server_pg.js). Render's free
-- tier has no reliable always-on background timer, so alerts are evaluated
-- on-demand against the latest fetched rate rather than via a real cron —
-- documented in PRICE_ALERTS_GUIDE.md.
CREATE TABLE IF NOT EXISTS price_alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pair TEXT NOT NULL, -- e.g. 'USD_INR', 'EUR_INR', 'GBP_INR', 'AED_INR', 'BTC_USD', 'ETH_USD', 'XRP_USD', 'BTC_INR'
  direction TEXT NOT NULL, -- 'above' | 'below'
  target_price NUMERIC(24,8) NOT NULL,
  status TEXT NOT NULL DEFAULT 'active', -- active | triggered | cancelled
  triggered_at TIMESTAMPTZ,
  triggered_price NUMERIC(24,8),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_price_alerts_user ON price_alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_price_alerts_active ON price_alerts(status) WHERE status = 'active';

-- 2. In-App Support Chat — upgrades the existing one-shot "Complaint" into
-- a real back-and-forth thread between the user and admin support staff.
-- The `complaints` row remains the ticket/case; this table holds the
-- individual chat messages within that case.
CREATE TABLE IF NOT EXISTS complaint_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  complaint_id UUID NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL, -- 'user' | 'admin'
  sender_id UUID NOT NULL,
  sender_name TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_complaint_messages_complaint ON complaint_messages(complaint_id, created_at);

-- Tracks last-read pointers so unread-message badges can be shown to both
-- sides without a full websocket/push infrastructure (polling-friendly).
ALTER TABLE complaints ADD COLUMN IF NOT EXISTS last_user_read_at TIMESTAMPTZ;
ALTER TABLE complaints ADD COLUMN IF NOT EXISTS last_admin_read_at TIMESTAMPTZ;
ALTER TABLE complaints ADD COLUMN IF NOT EXISTS last_message_at TIMESTAMPTZ;

-- 3. Transaction Statement Export — short-lived tokens (mirrors
-- receipt_tokens) that let a signed-in user open a printable, date-ranged
-- HTML statement of all their transactions in the phone's browser, where
-- they can "Print / Save as PDF" — same dependency-free approach used for
-- single-transaction receipts (see receipts.js).
CREATE TABLE IF NOT EXISTS statement_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  from_date DATE,
  to_date DATE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_statement_tokens_token ON statement_tokens(token);

-- 4. Dark Mode / App Settings — per-user preferences, synced across
-- devices (rather than only stored locally on the phone) so theme +
-- notification preferences follow the account.
ALTER TABLE users ADD COLUMN IF NOT EXISTS theme_preference TEXT NOT NULL DEFAULT 'system'; -- 'light' | 'dark' | 'system'
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS push_notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE;

-- 5. Favorites / Watchlist — lets a user pin the currency/crypto pairs
-- they care about most for quick access on the home screen.
CREATE TABLE IF NOT EXISTS watchlist_pairs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pair TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, pair)
);

CREATE INDEX IF NOT EXISTS idx_watchlist_pairs_user ON watchlist_pairs(user_id);

-- ---------------------------------------------------------------------------
-- FEATURE PACK 2: Multi-Language, Scheduled/Recurring Payments, Spending
-- Analytics, Biometric Login (client-side, no schema needed), Referral
-- Leaderboard (aggregation only, no schema needed).
-- ---------------------------------------------------------------------------

-- Multi-Language — same synced-to-account pattern as theme_preference.
ALTER TABLE users ADD COLUMN IF NOT EXISTS language_preference TEXT NOT NULL DEFAULT 'en'; -- 'en' | 'hi'

-- Scheduled / Recurring Payments ("autopay"-style mandate). The security
-- PIN is verified once at MANDATE CREATION time (proving the user
-- authorized this recurring send) — subsequent automatic executions do
-- NOT re-prompt for the PIN, same as how real UPI Autopay mandates work.
-- See backend/src/scheduled_payments.js for the execution/next-run-date
-- logic shared by both backends.
CREATE TABLE IF NOT EXISTS scheduled_payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  receiver_key TEXT NOT NULL, -- email/userId/phone exactly as entered at setup
  receiver_user_id UUID REFERENCES users(id), -- resolved at setup time
  amount NUMERIC(24,8) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  frequency TEXT NOT NULL, -- 'daily' | 'weekly' | 'monthly'
  note TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active', -- active | paused | cancelled
  next_run_at TIMESTAMPTZ NOT NULL,
  last_run_at TIMESTAMPTZ,
  last_run_status TEXT,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scheduled_payments_user ON scheduled_payments(user_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_payments_due ON scheduled_payments(status, next_run_at);

-- Execution history — lets a user see exactly which cycles succeeded vs.
-- failed (e.g. due to insufficient balance) for a given mandate.
CREATE TABLE IF NOT EXISTS scheduled_payment_runs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  scheduled_payment_id UUID NOT NULL REFERENCES scheduled_payments(id) ON DELETE CASCADE,
  status TEXT NOT NULL, -- completed | failed
  transaction_id UUID,
  error_message TEXT,
  run_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scheduled_payment_runs_parent ON scheduled_payment_runs(scheduled_payment_id, run_at DESC);

-- ---------------------------------------------------------------------------
-- Firebase Cloud Messaging (real background push notifications).
-- ---------------------------------------------------------------------------
-- A user can have multiple registered devices (phone + tablet, or a
-- reinstall creating a new token) — store each FCM registration token
-- separately rather than one column on `users`, so notifications go to
-- every device the user is actually logged into. Tokens are upserted on
-- every app launch (FCM tokens can rotate) and removed on logout.
CREATE TABLE IF NOT EXISTS push_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'android',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(token)
);

CREATE INDEX IF NOT EXISTS idx_push_tokens_user ON push_tokens(user_id);

