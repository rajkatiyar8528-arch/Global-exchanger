# Legal & Regulatory Compliance Checklist — Global Exchanger (India)

**Read this before taking the app live with real users at scale.** This is not
a substitute for a real lawyer/chartered accountant — it is a structured list
of the specific regulatory areas this app touches, based on its actual
features, so you know exactly what to ask a professional about. Ignoring
these is a genuine business/criminal-liability risk in India for a
money-handling app, not just a "nice to have."

---

## 0. Why this app needs special legal attention

Global Exchanger currently does ALL of the following in one app, each of
which is separately regulated in India:

| Feature in the app | What it actually is, legally | Regulator |
|---|---|---|
| Wallet: hold INR/USD/EUR balances, send/receive money between users | A **Prepaid Payment Instrument (PPI) / e-wallet** | RBI |
| "Convert"/"Exchange" between INR and USD/EUR | **Foreign exchange dealing** | RBI / FEMA |
| Hold and exchange BTC/ETH/XRP | **Virtual Digital Asset (VDA) / crypto exchange** service | FIU-IND, Income Tax Dept |
| Collecting KYC documents (Aadhaar, PAN, Selfie) | Personal data processing incl. Aadhaar | DPDP Act 2023, Aadhaar Act |
| Taking real payments via Razorpay (LIVE mode confirmed) | Real money collection from the public | RBI payment aggregator rules |
| Referral cash rewards | Marketing/incentive scheme | Consumer protection, tax (TDS on payouts if large) |

**As of today, this app has NONE of the corresponding licenses** (no PPI
authorisation, no AD-Category forex authorisation, no FIU-IND VDA
registration confirmed). Operating a wallet + forex exchange + crypto
exchange for the Indian public without these is a serious regulatory
violation, not a minor technicality — RBI and FIU-IND have both actively
blocked/penalized non-compliant apps and exchanges in the past.

---

## 1. RBI: Wallet / PPI (Prepaid Payment Instrument) requirements

Since the app lets users load money, hold a balance, and send money
peer-to-peer, this is functionally a digital wallet — which under the RBI's
2026 PPI framework needs:
- [ ] Non-bank PPI issuers need **RBI authorisation** with minimum net worth
      **₹5 crore at application, rising to ₹15 crore by year 3**.
- [ ] Full-KYC PPI wallets have caps: max balance ₹2,00,000, P2P transfers
      capped at ₹25,000/month per user (your app currently has **no such
      caps enforced in code** — this should be added regardless of
      licensing status, as a basic AML control).
- [ ] Without RBI PPI authorisation, you cannot legally operate this wallet
      model for the general public at any real scale.
- **Action**: Consult a fintech lawyer about either (a) obtaining PPI
  authorisation, or (b) restructuring the wallet to only integrate with
  RBI-licensed rails (e.g., route every "wallet" balance through a licensed
  bank/PPI partner via API, so you're a technology provider, not the PPI
  issuer yourself — many fintech startups start this way).

## 2. RBI/FEMA: Currency exchange ("Convert" feature)

- [ ] Buying/selling foreign currency (INR↔USD, INR↔EUR) for the public
      requires **RBI Authorised Dealer (Category I/II/III)** status under
      the new FEMA 401/2026-RB regulations (effective 6 May 2026).
- [ ] RBI has **stopped accepting new Full-Fledged Money Changer (FFMC)
      applications** — the route now is AD Category-II/III or becoming a
      Forex Correspondent (agent) under an existing AD.
- [ ] AD Category-II entities need a minimum net worth and, if via the FFMC/
      Forex Correspondent route, **2 years of operating history with ₹50 cr
      annual forex turnover** — not realistically available to a new app.
- [ ] The realistic path for a new fintech: become a **Forex Correspondent
      (agent)** of an existing AD Category-I bank or AD Category-II NBFC,
      operating under their license and compliance umbrella, rather than
      seeking your own AD license from scratch.
- **Action**: Do NOT offer real INR↔USD/EUR conversion to end users until
  either (a) partnered with a licensed AD as a Forex Correspondent, or (b)
  you have your own authorisation. Consider disabling/gating the live
  "Convert" feature for forex pairs until this is resolved, even though
  crypto conversion (BTC/ETH) is a separate legal track (see below).

## 3. Crypto (BTC/ETH/XRP): FIU-IND registration + tax

- [ ] Any platform in India dealing in Virtual Digital Assets must **register
      with FIU-IND (Financial Intelligence Unit) under PMLA** — this has
      been mandatory since March 2023, and FIU has actively **blocked/
      penalised unregistered exchanges** (Binance, KuCoin, WazirX-related
      actions, ₹28 crore+ in penalties across the industry in FY24-25).
- [ ] Registration requires appointing a **Principal Officer** and
      **Designated Director** personally accountable for AML/CFT compliance.
- [ ] Must implement the **"Travel Rule"** — capturing and exchanging
      originator/beneficiary information for every VDA transfer.
- [ ] Must retain transaction records for a **minimum of 5 years**.
- [ ] **1% TDS** must be deducted on every qualifying crypto transaction
      (₹10,000+/year threshold for most users, ₹50,000 for specified
      persons) under Section 194S, deposited via Form 26QE.
- [ ] Crypto gains are taxed at a **flat 30% + 4% cess**, with **no loss
      offsetting allowed** — this affects how you should present any
      "profit/loss" info to users, if at all.
- [ ] **18% GST** applies to your platform's service/commission fees on
      crypto trades (separate from the TDS/30% tax on the user's gains).
- **Action**: Your app currently has **no FIU-IND registration confirmed,
  no TDS deduction logic, and no Travel Rule data capture** for the BTC/
  ETH/XRP wallet features. This is the single most urgent legal gap if
  crypto features are live for real users — either implement TDS + FIU
  registration properly, or disable real crypto conversion/exchange
  entirely until compliant.

## 4. Payment Aggregator / Razorpay considerations

- [ ] Confirmed: `PAYMENT_PROVIDER=razorpay` is set to **LIVE mode** — real
      money is flowing through Razorpay today.
- [ ] Razorpay itself is RBI-authorised as a Payment Aggregator — using them
      is fine for **collecting** payments, but does NOT itself license you
      to operate a wallet or forex/crypto exchange on top of that money —
      those are separate licensing questions (sections 1-3 above).
- [ ] Check your Razorpay merchant agreement/KYC — Razorpair may have its
      own restrictions on using their gateway to fund wallet balances that
      get exchanged into forex/crypto; violating their terms can result in
      account freezing (which would trap user funds).
- **Action**: Read your Razorpay merchant agreement carefully for any
  clause restricting "wallet top-up used for currency/crypto exchange"
  use cases — this is common in payment aggregator agreements precisely
  because of the regulatory grey area above.

## 5. Data protection: KYC documents (Aadhaar, PAN, Selfie)

- [ ] Aadhaar data has special protections under the **Aadhaar Act, 2016**
      — storing/processing raw Aadhaar numbers without being an authorised
      AUA/KUA entity is restricted. Storing a photo/scan of an Aadhaar card
      is generally more permissible than doing live Aadhaar number
      verification against UIDAI's database, but you should NOT store
      Aadhaar numbers in plaintext long-term without a clear legal basis
      and strong encryption.
- [ ] The **Digital Personal Data Protection (DPDP) Act, 2023** requires:
      consent notices, purpose limitation, data minimization, breach
      notification to the Data Protection Board, and a grievance officer.
- [ ] Your KYC documents are currently stored as **base64 in a JSONB
      column** — confirm this column is encrypted at rest in Postgres
      (Render's managed Postgres — check if encryption-at-rest is enabled)
      and that access is tightly restricted to admin roles only via RBAC
      (you have `requirePermission('kyc:manage')` — good, keep it that way).
- **Action**: Add a clear Privacy Policy (you have a stub in `legal/`)
  specifically mentioning KYC document collection, Aadhaar/PAN handling,
  retention period, and user rights to request deletion. Appoint a
  Grievance Officer / Data Protection contact as required by DPDP Act.

## 6. AML / KYC operational controls (regardless of licensing)

Even before/while pursuing formal licenses, these are baseline anti-money-
laundering practices any real fintech should have, and most are currently
**missing** from the app:
- [ ] Per-transaction and daily/monthly transaction limits per user
      (currently unlimited — a user with an approved KYC can send/exchange
      any amount)
- [ ] Automated flagging of unusual patterns (e.g., many small referral
      accounts funnelling money to one account, rapid send-receive loops)
- [ ] Sanctions/PEP (Politically Exposed Person) screening during KYC
- [ ] Suspicious Transaction Report (STR) filing capability/process for
      the admin team
- [ ] A documented AML policy, even if informal at this stage
- **Action**: At minimum, add configurable per-transaction and daily limits
  in the admin panel (e.g., ₹50,000/day cap unless additionally verified),
  since this is both a regulatory good-practice and a practical fraud
  control.

## 7. Terms of Service & Consumer Protection

- [ ] Your `legal/terms-and-conditions.md` and `legal/privacy-policy.md`
      exist but should be reviewed by a lawyer to ensure they:
      - Clearly state what happens if a transaction is disputed/reversed
      - Clearly state the manual nature of withdrawals (see below)
      - Include a refund policy compliant with RBI's PA/PG guidelines
      - Include arbitration/jurisdiction clauses
- [ ] Under the Consumer Protection (E-Commerce) Rules, apps handling
      payments must have a functioning grievance redressal mechanism (you
      have Complaints/Disputes screens — good start, but response-time SLAs
      should be documented and followed).

## 8. Operational/business risk (not strictly "legal" but related)

- [ ] **Withdrawals are currently 100% manual** — when admin marks a
      withdrawal "completed," no real money actually moves; a human must
      manually transfer funds via NEFT/IMPS/UPI outside the app. If this
      step is missed or delayed, it's effectively **holding customer funds
      without paying out** — a serious trust and potential legal issue if
      it happens at any scale. Make sure whoever runs the admin panel has
      a strict same-day payout process once marking something "completed."
- [ ] Reconcile Razorpay settlement reports against wallet ledger entries
      regularly (daily/weekly) to make sure the money that hits your bank
      account from Razorpay actually matches what's reflected across all
      user wallets — mismatches compound quickly in a live system.
- [ ] Consider Professional Indemnity / Cyber Insurance given real money
      and personal data (Aadhaar/PAN) are being handled.

---

## Suggested immediate next steps (practical, in order)

1. **Talk to a fintech-focused lawyer or compliance consultant** — this
   checklist tells you *what* to ask, not a substitute for their advice.
   Given the scope (wallet + forex + crypto), this is not a DIY situation
   at meaningful transaction volumes.
2. In the meantime, as a pragmatic risk-reduction step, consider:
   - Adding hard per-transaction/daily/monthly limits (cheap to build,
     reduces AML exposure and worst-case financial exposure).
   - Clearly labeling forex/crypto conversion as "beta"/"limited" and
     keeping volumes low and KYC-gated until licensing is sorted.
   - Getting FIU-IND registration in motion specifically for the crypto
     leg — this is the most time-boxed, well-defined of the three
     licensing tracks and has clear precedent/process.
3. Keep the admin panel's audit log (`audit_logs`) and ledger
   (`ledger_entries`/`ledger_accounts`) intact and backed up regularly —
   these are exactly what regulators and your own accountant will want to
   see for any compliance review or STR filing.

This checklist reflects publicly available regulatory information as of
mid-2026 and is not exhaustive or a legal opinion — please verify current
requirements with a qualified professional before making licensing
decisions.
