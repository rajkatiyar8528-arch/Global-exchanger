# Dispute Evidence Upload — Guide

Ye guide batati hai ki naya **Dispute Evidence Upload** feature kaise kaam karta hai — pehle dispute sirf text ke saath submit hota tha, ab user screenshot/photo evidence bhi attach kar sakta hai.

## User Ke Liye — Dispute Submit Karte Waqt

1. App me **Help/Support** → "Disputes" tab kholein
2. Reason aur Details likhein (jaisa pehle se tha)
3. Ab neeche **"Evidence (optional, max 3 screenshots)"** section dikhega — 3 khaali boxes
4. Kisi bhi box par tap karke gallery se screenshot/photo select karein (jaise wrong payment ka screenshot, ya bank statement ka photo)
5. "Submit Dispute" dabayein

Baad me apne submitted disputes me, agar evidence attach kiya tha, to **"X evidence files — dekhein"** link dikhega — tap karke poori image dekh sakte hain.

## Admin Ke Liye

Admin Panel → "Dispute Management" section me, jin disputes me evidence attach hai unke row me **"📎 X Evidence"** button dikhega — click karte hi ek naya tab khulega jisme sabhi attached images dikhengi.

## Technical Summary

- Naye API endpoints: `GET /api/disputes/:id/evidence` (user apni khud ki dispute ka evidence dekh sakta hai), `GET /api/admin/disputes/:id/evidence` (admin kisi bhi dispute ka evidence dekh sakta hai)
- **Security**: ek user dusre user ki dispute ka evidence access nahi kar sakta (verified via test — 404 milta hai)
- Evidence images base64 format me store hoti hain (KYC documents jaisa hi pattern) — koi external storage service ki zaroorat nahi
- **Limits**: max 3 evidence files per dispute, har file max 4MB, sirf JPG/PNG/WEBP/PDF allowed
- List endpoints (`GET /api/disputes`, `GET /api/admin/disputes`) heavy evidence data **nahi** bhejte — sirf `evidenceCount` (kitne files hain) — taaki dispute list fast load ho. Full evidence sirf specific dispute open karne par fetch hoti hai
- **19 automated tests** (dono backends) — evidence upload, limit enforcement (max 3), invalid file type rejection, cross-user access blocking, admin access — sab verify kiya gaya
- Koi purana dispute break nahi hua — evidence-less disputes (jaisa pehle sab the) abhi bhi bilkul normal kaam karte hain

## Business Note

Ye feature disputes resolve karne me help karega — user apna proof (screenshot, receipt) seedha attach kar sakta hai, jisse admin ko faster aur accurate decision lene me madad milegi, aur wapas-wapas email/WhatsApp se proof mangwane ki zaroorat kam hogi.
