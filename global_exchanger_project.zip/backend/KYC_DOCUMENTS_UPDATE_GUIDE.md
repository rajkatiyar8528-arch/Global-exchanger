# KYC Documents Update (for Already-Approved Users) — Guide

## What this feature does

Before this feature, once a user's KYC was `approved`, there was **no way for
them to submit updated documents** — the "re-upload" flow (built earlier this
project, see `KYC_REUPLOAD_GUIDE.md`) only appeared for users whose KYC was
`pending` / `under_review` / `rejected`. An approved user who got a new
Aadhaar card, moved house, or renewed an expired ID had no in-app way to
update their KYC on file.

This feature adds a **"Documents Update"** flow reachable from the Profile
screen even when KYC status is `approved`, so users can submit fresh
documents/details at any time, and admins can review and approve/reject the
update without ever losing the user's original verified status if the update
itself doesn't work out.

## Why this design (block-immediately, not keep-old-access-active)

Two designs were considered when an approved user submits an update:

- **Option A (chosen): block immediately.** The moment new documents are
  submitted, the user's live `kycStatus` flips to `under_review` and they
  drop to the `minKyc` tier (`tierFor()` in `limits.js` — lower wallet cap,
  no P2P/exchange/withdrawal) until admin reviews the new submission.
- **Option B (not chosen): keep old access active.** The user would keep
  transacting at their full-KYC tier on the strength of their *old* approved
  documents while the new ones sit in a review queue in the background.

Option A was explicitly chosen by the business owner for regulatory safety:
at no point should a user be simultaneously "transacting freely" while their
most recently submitted identity documents are unverified. The (small)
downside — a brief window of reduced limits while admin reviews — was judged
an acceptable trade for AML/KYC cleanliness in a live forex/crypto app.

## Backend changes

### `POST /api/kyc` (both `server.js` and `server_pg.js`)

1. **Duplicate-submission guard**: if the user's most recent KYC request is
   still `under_review` (regardless of whether it's their first submission,
   a post-rejection resubmission, or a re-verification), a new submission is
   rejected with **`409 Conflict`** and a friendly Hinglish message asking
   them to wait for the existing review. This prevents an approved user (or
   anyone) from spamming the admin queue with duplicate pending requests.
2. **`isReverification` flag**: computed as `user.kycStatus === 'approved'`
   at the moment of submission, stored on the new `kyc_requests` row
   (`is_reverification` column, JSON backend: `kyc.isReverification` field).
   This is purely informational (drives the admin panel badge + the
   rejection-handling behavior below) — it does not change any approval
   logic itself.
3. On successful submission, `user.kycStatus` is immediately set to
   `'under_review'` — same behavior for a first-time submission, a
   post-rejection resubmission, AND a re-verification. This is what
   implements the "block immediately" design decision above.

### `PATCH /api/admin/kyc/:id` (both backends) — the important behavior change

When admin **rejects** a KYC request:

- If it was a **normal** submission (`isReverification: false`): the user's
  `kycStatus` becomes `'rejected'` — same as before this feature.
- If it was a **re-verification** (`isReverification: true`) — i.e. the user
  was already `approved` before they submitted this update — rejecting it
  **reverts the user's `kycStatus` back to `'approved'`**, NOT `'rejected'`.

  **Rationale**: the user didn't do anything to lose their original verified
  status — only their *update attempt* didn't pass review (e.g. blurry new
  photo). It would be unfair and confusing for a user to go from "verified,
  full access" to "rejected, minimal access" just because they *tried* to
  update a document and that specific attempt needed a retry. Their original
  approved KYC record is untouched; only the new update attempt is marked
  `rejected` in `kyc_requests` history (which the admin panel now visibly
  tags with a "🔄 Docs Update (already approved)" badge, so the audit trail
  is fully preserved).

When admin **approves** a re-verification request, the user's `kycStatus`
becomes `'approved'` (using the fresh documents) exactly as normal.

### `GET /api/kyc/me` and `GET /api/admin/kyc-requests`

Both now also return `isReverification` (and, for the PostgreSQL admin list
endpoint, `rejectionReason`/`rejectedDocumentLabels` which were previously
missing from the list view — a small pre-existing gap fixed as part of this
work) so both the Flutter app and the admin panel can show the right
badges/messaging.

## Database schema changes

`db/schema.sql` — new migration-safe column:

```sql
ALTER TABLE kyc_requests ADD COLUMN IF NOT EXISTS is_reverification BOOLEAN NOT NULL DEFAULT FALSE;
```

Auto-applied on every backend startup via `autoMigrate()` — no manual Render
Shell step needed (Render free tier has no Shell access).

## Flutter app changes

- **`ProfileScreen`**: the KYC status card, previously a static/non-clickable
  `InfoCard` when status was `approved`, is now a clickable
  `ProfessionalCard` titled "KYC Status: Approved ✅" with the subtitle
  "Documents update karne hain? (Naya Aadhaar/address, etc.) Yahan tap
  karein." — tapping it opens `KycScreen`.
- **`KycScreen`**:
  - On load, if the user's prior KYC status is `approved`, the text fields
    (National ID, Tax ID, Country) are **pre-filled** from their last
    submission — an approved user doesn't need to retype everything, only
    correct/replace what actually changed.
  - Shows a new blue info banner: "Aapka KYC Pehle Se Approved Hai ✅" with an
    explanation that submitting updates will temporarily reduce their tier
    until admin re-verifies.
  - The page title and submit button text adapt: "KYC Documents Update
    Karein" / "Documents Update Submit Karein" instead of the generic
    signup-flow wording.
  - The success snackbar message is also adapted to explain the temporary
    tier reduction.
  - Error messages (e.g. the new 409 "already under review" case) are shown
    verbatim from the backend (Hinglish, already user-friendly) instead of
    a raw `Exception: ...` string — the `Exception: ` prefix is now stripped
    before display everywhere in this screen.

## Admin panel changes

The KYC Requests table row now shows a "🔄 Docs Update (already approved)"
badge next to the status pill whenever `isReverification` is true, so admins
immediately understand this is a documents-refresh from an already-verified
user (context that matters for how much scrutiny/urgency to apply), without
needing to cross-reference the user's account separately.

## Testing

A dedicated 23-check automated test script (`/tmp/test_kyc_reverify.py`,
ephemeral — not part of the repo) was run against BOTH backends
(JSON `server.js` on port 5099, PostgreSQL `server_pg.js` on port 5098 with a
throwaway local `gx_test` database) and passed 23/23 on both, covering:

- First-time KYC submission works normally (`isReverification: false`).
- Duplicate submission while `under_review` is blocked with `409`.
- Admin approval moves user to `approved`.
- An approved user's re-verification submission correctly sets
  `isReverification: true` on the new record AND immediately flips the
  user's live `kycStatus` to `under_review` (the "block immediately"
  design).
- A second duplicate submission while that re-verification is pending is
  also blocked with `409`.
- **Critically**: admin *rejecting* the re-verification reverts the user's
  live `kycStatus` back to `approved` (not `rejected`), while the specific
  `kyc_requests` row itself still correctly shows `status: 'rejected'` with
  its `rejectionReason` — proving the audit trail and the live user status
  are correctly decoupled.
- A second re-verification round-trip where admin *approves* instead
  correctly leaves the user at `approved`.

## Related bug fix shipped in the same round

While investigating why a Codemagic build was failing, a genuine Dart syntax
bug was found and fixed: `const Container(...)` was used in the Referral
Milestones screen's "all milestones complete" success banner. `Container` in
Flutter has no `const` constructor (it's a convenience wrapper composing
several other widgets internally), so this is always a compile error in
strict release builds. Fixed by moving `const` onto the individual
properties (`padding`, `margin`, `decoration`, `child`) instead of the
`Container` itself. This was blocking EVERY feature shipped since the
Referral Milestones round from ever reaching a real device via Codemagic —
so KYC Re-upload, Dispute Evidence Upload, and Admin Notification Center are
all now finally reaching users for the first time via this round's APK,
alongside this new KYC Documents Update feature.
