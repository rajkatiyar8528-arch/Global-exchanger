# Legal Documents Website Publishing Guide (v1.8.3+13)

This round did two things: (1) converted the 4 legal Markdown documents
into styled, standalone HTML pages ready to publish via GitHub Pages
(the same free hosting mechanism already used for the admin panel), and
(2) wrote a step-by-step FIU-IND registration guide for the crypto/VDA
side of the business.

## 1. Legal documents — now live-publishable HTML pages

The 4 Markdown files in `legal/` (Terms & Conditions, Privacy Policy,
Refund & Cancellation Policy, Grievance Redressal Policy) have each been
converted into a matching styled `.html` page, PLUS a new `legal/index.html`
that links all 4 together, using the same visual style (blue/dark gradient
header, card-based layout) as the rest of the app.

New files inside `legal/` (alongside the original `.md` source files, which
remain untouched as the source of truth if you need to edit and
re-generate):
- `legal/index.html` — landing page linking all 4 documents
- `legal/terms.html`
- `legal/privacy.html`
- `legal/refund.html`
- `legal/grievance.html`

### How to publish these (same pattern as the admin panel)

Your GitHub repo already serves `admin_panel/index.html` via GitHub Pages
at `https://rajkatiyar8528-arch.github.io/Global-exchanger/admin_panel/`.
The exact same mechanism now needs the `legal/` folder too:

1. Upload the 5 new HTML files (`index.html`, `terms.html`, `privacy.html`,
   `refund.html`, `grievance.html`) to your GitHub repo, **inside a `legal/`
   folder at the repo root** — i.e. the final paths in GitHub should be
   `legal/index.html`, `legal/terms.html`, etc. (Do NOT put them inside
   `admin_panel/` — they need their own top-level `legal/` folder, same
   level as `admin_panel/` in the repo.)
2. Wait a minute or two for GitHub Pages to pick up the new files (it
   auto-redeploys on every push to the branch Pages is configured for,
   same as it already does for the admin panel).
3. The documents will then be live at:
   - `https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/`
   - `https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/terms.html`
   - `https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/privacy.html`
   - `https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/refund.html`
   - `https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/grievance.html`
4. **These exact URLs are now hardcoded into the app's `TermsScreen`**
   (Profile → Terms & Privacy) — tapping any of the 4 cards opens the
   corresponding page in the phone's browser. If you ever rename the repo,
   change the GitHub username, or move these files, update the URLs in
   `main.dart`'s `TermsScreen` class to match.

### ⚠️ Still needs your input before this is "final"

The underlying Markdown documents still have `[INSERT ...]` placeholders
(your legal entity name, Grievance Officer's real name, operational SLAs,
jurisdiction city) — these were flagged in the previous
`LEGAL_DOCUMENTS_UPDATE_GUIDE.md`. **Fill those in the `.md` files, then
re-run the conversion** (or ask in a future session to regenerate the
HTML from updated Markdown) before treating the published pages as your
real, final legal documents. Right now they're a complete, professional-
looking, correctly-structured placeholder — not yet ready to be the
actual binding legal text without those specifics filled in and a lawyer's
review.

### A note on the app's Terms & Privacy screen

Previously this screen showed static text URLs (not clickable). It now
shows 4 tappable cards that open the actual hosted pages in the phone's
browser (using the same `url_launcher` package already used for receipts),
plus the existing forex/crypto compliance warning box.

## 2. FIU-IND Registration Guide

New document: `backend/FIU_IND_REGISTRATION_GUIDE.md` — a comprehensive,
step-by-step guide specifically for registering the crypto/VDA (BTC/ETH/
XRP) side of Global Exchanger with FIU-IND as required under PMLA since
March 2023. Covers:

- **Why this is mandatory** (not optional) once crypto features are live
  for real Indian users, and the real consequences of not registering
  (fines, access-blocking — FIU-IND has already acted against major
  exchanges).
- **Prerequisites you need in place BEFORE applying**: Principal Officer,
  Designated Director, written AML/CFT policy, working KYC/AML technical
  systems, cybersecurity audit certificate.
- **The 3-stage registration process** via the FINGate 2.0 portal:
  self-enrolment → document submission + mandatory in-person meeting with
  live compliance-system demo → final approval and RE-ID issuance.
- **Full document checklist** (corporate, financial, personnel,
  compliance documents) to gather in advance.
- **Ongoing obligations after registration** — this isn't a one-time task
  (STR/CTR filing, 5-year record retention, annual policy review, etc.).
- **An honest gap-analysis table** showing exactly what's already built in
  the app (KYC, record-keeping, AML flagging, crypto TDS — all from
  `TECHNICAL_SAFEGUARDS_GUIDE.md`) vs. what's still missing (sanctions/PEP
  screening, Travel Rule data capture, formal STR filing workflow, and the
  organizational/legal steps that aren't code at all).
- **Suggested next technical steps** if you want to keep closing the gaps
  in parallel with the formal registration process (sanctions screening,
  Travel Rule capture, STR export tooling).

This guide makes clear that **formal registration itself requires engaging
a CA/compliance firm experienced with FIU-IND VDA filings** — it's not a
pure-code task, since it involves an in-person meeting, corporate document
review, and judgment calls about AML/CFT system adequacy that a
specialist should own.

## 3. Version

Bumped to **v1.8.3+13** — small/patch bump since this round is mostly
documentation + a URL/navigation change in `TermsScreen`; no backend
routes, database schema, or core business logic changed.
