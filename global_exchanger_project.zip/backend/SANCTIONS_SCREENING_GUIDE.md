# Sanctions/PEP Screening & Travel Rule Guide (v1.9.0+14)

This round builds the two biggest technical gaps identified in
`FIU_IND_REGISTRATION_GUIDE.md`'s gap-analysis: **sanctions/PEP screening**
at KYC time, and **Travel Rule data capture** for crypto (VDA) transfers —
plus a formal **Suspicious Transaction Report (STR) case-tracking
workflow** to turn AML/sanctions flags into an actionable compliance
process. All three are wired into both `server.js` (JSON) and
`server_pg.js` (Postgres) identically.

## 1. Sanctions/PEP Screening (`backend/src/screening.js`)

### What it does
Every time a user submits KYC (`POST /api/kyc`), their registered name
(plus any optional alias names they declare) is automatically checked
against a local sanctions dataset (`backend/data/sanctions_list.json`).

### How matching works
- **Dependency-free fuzzy matching** — no npm package, no external API
  call, so it can't break the build or depend on a paid service being up.
- Combines two techniques:
  1. **Levenshtein-distance similarity** (catches misspellings/typos)
  2. **Fuzzy token overlap** (catches name-order differences and
     transliteration variants, e.g. "Sheikh" vs "Shaikh")
- Configurable match threshold via `SANCTIONS_MATCH_THRESHOLD` env var
  (default 0.82 — tuned to catch real near-matches like "Khalid Sheikh
  Mohammed" → "MOHAMMED, Khalid Shaikh" while NOT flagging unrelated common
  Indian names like "Raj Katiyar" or "Amit Sharma").
- **Verified via testing**: common Indian names produce zero false
  positives; known sanctioned individuals (even with spelling variants)
  are correctly matched.

### ⚠️ CRITICAL: this ships with a STARTER SAMPLE dataset, not the full list
`backend/data/sanctions_list.json` currently contains **42 real entries**
manually sampled from the official US Treasury OFAC SDN list, as a working
demonstration of the screening mechanism. **This is nowhere near the full
official list** (which has 10,000+ entries across OFAC, UN, EU, and other
sanctions regimes) and is NOT sufficient for real compliance on its own.

**Before relying on this for actual FIU-IND compliance, you must:**
1. Replace `sanctions_list.json` with the complete, current official
   dataset(s) — at minimum the full OFAC SDN list
   (`https://www.treasury.gov/ofac/downloads/sdn.csv` or the newer
   `sanctionslistservice.ofac.treasury.gov` API) and the UN Security
   Council Consolidated List (`https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list`,
   available in XML). India-specific lists (e.g. UAPA-designated
   individuals/entities under the Unlawful Activities (Prevention) Act,
   published by India's Ministry of Home Affairs) should also be added for
   FIU-IND's expectations specifically.
2. **Set up periodic automatic re-fetching** of these lists (they update
   frequently — weekly at minimum, ideally daily) and regenerate
   `sanctions_list.json` from them. This is NOT currently automated — a
   scheduled job (e.g. a daily cron/Render cron job) should be added to
   fetch, parse, and replace this file. The `metadata.lastUpdated` field
   in the file should reflect when this last happened.
3. For real production use at scale, seriously consider a dedicated
   sanctions-screening vendor (ComplyAdvantage, Refinitiv World-Check, Dow
   Jones Risk & Compliance, or similar) — they maintain complete,
   professionally-curated, properly-licensed datasets with much better
   fuzzy-matching (phonetic algorithms, cross-script transliteration) than
   this starter implementation. FIU-IND's live-demo requirement during
   registration (see `FIU_IND_REGISTRATION_GUIDE.md`) will scrutinize the
   completeness/quality of your screening system.

### What happens on a match — NEVER auto-rejects
A sanctions match **never automatically blocks or rejects** a KYC
submission or user. It only:
1. Stores the match details on the KYC request (`sanctionsScreening` field
   / `sanctions_screening` JSONB column).
2. Creates an audit log entry (`sanctions.screening.flagged`).
3. Surfaces in the new admin panel section "🚫 Sanctions/PEP Screening
   Flags" and via `GET /api/admin/sanctions-flags`, where an admin must
   manually mark it `confirmed_match` or `false_positive` via
   `PATCH /api/admin/sanctions-flags/:kycRequestId`.

This design choice is deliberate: name-based screening has a real
false-positive rate (common names legitimately overlap with sanctioned
individuals' names), and auto-rejecting would both hurt legitimate users
and create a false sense of "the system handled it" — a human must always
make the final call on a genuine hit.

## 2. Travel Rule Data Capture (`backend/src/travel_rule.js`)

### What it does
Whenever a VDA (BTC/ETH/XRP) transfer happens — either a direct user-to-
user send (`POST /api/transactions/send`) or an exchange order completion
involving a VDA currency (`POST /api/admin/exchange/orders/:id/complete`)
— a Travel Rule record is captured, storing:
- The transferred currency and amount
- **Originator** (sender) identity: user ID, name, last 4 digits of their
  KYC national ID
- **Beneficiary** (receiver) identity: same fields
- Timestamp

This satisfies FIU-IND's guidance, which explicitly treats VDA transfers
"on the lines of wire transfers" requiring originator/beneficiary data
exchange — see `FIU_IND_REGISTRATION_GUIDE.md`.

### Data minimization choice
Only the **last 4 digits** of the national ID are stored in the Travel
Rule record itself (not the full number) — this balances the "sufficient
identity data" requirement against DPDP Act data-minimization principles.
The **full KYC document/national ID remains separately stored** in
`kyc_requests` for complete identity verification if ever needed for an
actual investigation or STR filing.

### Current scope: internal transfers only
Global Exchanger currently only moves VDA value **between accounts within
the platform** — there's no external blockchain withdrawal/deposit feature
yet (i.e., no "send BTC to an external wallet address" function). This
module captures data for that internal case today. If/when an external
wallet withdrawal/deposit feature is added, the same `buildTravelRuleRecord()`
function can be extended to also capture the external counterparty's VASP
name/wallet address, without needing a data-model redesign — this was
designed with that future extension in mind.

**New admin endpoint**: `GET /api/admin/travel-rule-records` — full list,
exportable for sharing with a counterparty VASP or providing to
authorities on request.
**New admin panel section**: "✈️ Travel Rule Records (VDA Transfers)".

## 3. Suspicious Transaction Report (STR) Case Tracking

**This app cannot file STRs with FIU-IND directly** — filing is a manual,
out-of-band process your Principal Officer performs via the FIU-IND
FINGate portal (see `FIU_IND_REGISTRATION_GUIDE.md`). What this feature
adds is a structured way to **track that process** from your side:

- `POST /api/admin/str-reports` — admin creates a draft STR case from any
  flagged user/transaction (an AML flag, a sanctions match, or manual
  observation), capturing the reason and a snapshot of the user's details
  at the time.
- `GET /api/admin/str-reports` — lists all STR cases.
- `PATCH /api/admin/str-reports/:id` — updates status through the
  lifecycle: `draft` → `filed` (once your PO actually submits it to
  FIU-IND) → `acknowledged` (once FIU-IND confirms receipt) → `closed`.
- **New admin panel section**: "📋 Suspicious Transaction Reports (STR)"
  with a simple create-form and status dropdown per case.

This turns the previously admin-panel-only AML/sanctions flags into a
trackable compliance workflow with a paper trail — exactly what an
auditor or FIU-IND inspection would want to see.

## 4. Testing performed this round

- **Unit-style tests** of the fuzzy-matching engine (`node -e`): confirmed
  correct matches on real sanctioned names (including spelling variants
  like "Sheikh"/"Shaikh"), zero false positives on common Indian names
  (Raj Katiyar, Amit Sharma, Priya Patel), and expected higher false-
  positive sensitivity on genuinely very common/short names (e.g. bare
  "Ahmed") — a known, documented limitation of name-only screening.
- **Full end-to-end test suite (14 new checks)** covering: sanctions-
  matching name gets flagged, normal name does NOT get flagged, admin can
  list and review sanctions flags, KYC approval flow still works,
  crypto (BTC) send correctly triggers Travel Rule capture with accurate
  originator/beneficiary data, STR case creation/listing/status updates —
  run against BOTH `server.js` and `server_pg.js` (real local PostgreSQL)
  — **all 14/14 passed on both backends**.
- **Re-ran the original 40-check full-app E2E test suite** on both
  backends after these changes — **all 40/40 still passed**, confirming no
  regressions to existing features.
- Confirmed both backends have **exactly the same 75 API routes** (up from
  69 before this round) and confirmed the new `travel_rule_records`,
  `str_reports` tables and `sanctions_screening` column auto-migrate
  correctly via the existing `autoMigrate()` startup hook.

## 5. What changed in the database

- **New column** `sanctions_screening` (JSONB) on `kyc_requests` /
  `sanctionsScreening` field on JSON `kycRequests` entries.
- **New table** `travel_rule_records` (Postgres) / **new array**
  `travelRuleRecords` (JSON).
- **New table** `str_reports` (Postgres) / **new array** `strReports`
  (JSON).
- All migrate automatically, no manual steps needed.

## 6. Configuration (environment variables, all optional)

```
SANCTIONS_MATCH_THRESHOLD=0.82   # 0-1, higher = stricter matching, fewer flags
TRAVEL_RULE_THRESHOLD_INR=0      # currently unused for gating (always captures); reserved for future tuning
```

## 7. Remaining gaps vs. full FIU-IND readiness

Even with these three additions, per the honest gap-analysis in
`FIU_IND_REGISTRATION_GUIDE.md`, you still need (organizational/legal, not
code):
- Appoint a real Principal Officer and Designated Director
- Write a formal AML/CFT policy document
- Get a cybersecurity audit certificate
- **Replace the sanctions dataset with the complete, auto-updating
  official lists** (see section 1's warning above — this is the most
  urgent remaining technical gap)
- Actually go through the FIU-IND registration process (in-person meeting,
  live system demo) with a CA/compliance firm's help

## 8. Version

Bumped to **v1.9.0+14** — a meaningful minor version bump since this adds
substantial new compliance infrastructure (3 new modules, 6 new admin
endpoints, 3 new admin panel sections), even though most existing user-
facing behavior is unchanged.
