# Feature Pack 3: Multi-Language, Scheduled Payments, Spending Analytics, Biometric Login, Referral Leaderboard (v1.11.0+22)

Five user-facing features requested together in one go. All five are
implemented in **both** backends (`server.js` JSON demo and
`server_pg.js` PostgreSQL production) with matching behaviour, and wired
into the Flutter app + Admin Panel where relevant.

## 1. Scheduled / Recurring Payments ("Autopay"-style mandates)

**What it does:** a user can set up a recurring send-money mandate (e.g.
"send ₹500 to my landlord every month") — daily, weekly, or monthly
frequency. Security PIN is verified **once**, at mandate-creation time
(proving the user authorized this recurring send); automatic executions
afterwards do NOT re-prompt for the PIN — same UX as real UPI Autopay.

**Files:**
- `backend/src/scheduled_payments.js` — shared, dependency-free helpers
  (`FREQUENCIES`, `isValidFrequency`, `computeNextRunAt`,
  `MAX_CONSECUTIVE_FAILURES`), used identically by both backends.
- `scheduled_payments` + `scheduled_payment_runs` tables (Postgres) /
  `db.scheduledPayments` + `db.scheduledPaymentRuns` arrays (JSON).
- Endpoints: `POST/GET /api/scheduled-payments`,
  `GET /api/scheduled-payments/:id/runs`,
  `PATCH /api/scheduled-payments/:id` (active/paused/cancelled).
- Flutter: `ScheduledPaymentsScreen` (Profile > Scheduled Payments) — set
  up form, list with pause/resume/cancel actions, execution-history bottom
  sheet.
- Admin Panel: new "🔁 Scheduled / Recurring Payments" table showing every
  user's mandates, with rows highlighted red once a mandate has 2+
  consecutive failures (support/fraud signal worth a look).

**Execution model — same Render free-tier constraint as Price Alerts:**
there's no reliable always-on background timer, so due mandates
(`next_run_at <= now`) execute **opportunistically**:
1. Every time the signed-in user's app calls `GET /api/me` (happens very
   often — home, wallet, profile screens all call it) — that user's own
   due mandates run right then.
2. `POST /api/cron/run-scheduled-payments`, protected by a `CRON_SECRET`
   env var (same shared-secret pattern as the existing sanctions-sync
   cron), meant to be pinged by an external scheduler (e.g. adapt the
   existing `.github/workflows/sanctions-sync.yml` pattern, or any
   uptime-ping service) so mandates for users who haven't opened the app
   recently still get executed.

**Failure handling:** if a mandate's execution fails (e.g. insufficient
balance, receiver account deleted), it's recorded in
`scheduled_payment_runs` with an error message, and the user gets a
notification. After `MAX_CONSECUTIVE_FAILURES` (default 3, configurable
via env var) consecutive failures, the mandate **auto-pauses** and the
user gets a distinct "auto-paused" notification — so a failing mandate
never silently fails forever unnoticed.

**Verified via automated testing (both backends):** mandate creation
(with PIN verification, receiver validation, self-send rejection,
invalid-frequency rejection), pause/resume/cancel lifecycle, and — using
direct DB manipulation to simulate a due mandate (setting `next_run_at`
to the past) — full end-to-end execution: balance debited from sender,
credited to receiver, execution recorded as `completed`, `next_run_at`
correctly advanced to the next cycle, success notification sent, and
confirmed it does NOT execute again on a second immediate call (not due
yet). Also verified the KYC-tier-limit failure path (tier limits correctly
block an unverified user's scheduled payment, recording it as `failed`
with the real error message) — this is a deliberate safety feature, not a
bug: scheduled payments respect all the same limits/AML checks as manual
sends.

## 2. Spending Analytics

**What it does:** a new Analytics screen shows the user's own spending
patterns: total in/out summary, a 6-month (configurable 1-12) in/out
trend, a category breakdown (Wallet Top-up / Refunds / Currency Exchange /
Sent to Others / Received from Others), and top-5 people they send money
to most.

**Files:**
- `backend/src/analytics.js` — shared, pure aggregation functions
  (`monthlyTrend`, `categoryBreakdown`, `topCounterparties`,
  `overallSummary`) that take a normalized transaction list + an
  INR-conversion function and return chart-ready data — both backends
  normalize their own transaction rows (camelCase JSON vs. snake_case
  Postgres) into the same shape before calling these.
- Endpoint: `GET /api/analytics/spending?months=N`.
- Flutter: `SpendingAnalyticsScreen` (Profile > Spending Analytics) —
  summary cards, a lightweight bar-style monthly trend (built with
  `LinearProgressIndicator` bars, no external charting package needed),
  category breakdown bars, top-counterparties list.

**Categories are derived purely from existing transaction `type` values**
(no new merchant-category data collection) — kept intentionally simple and
honest about what data actually exists, rather than guessing/inventing
categories the system has no real way to know.

**Verified via automated testing (both backends):** summary/monthlyTrend/
categoryBreakdown/topCounterparties all present and correctly shaped;
`totalInInr > 0` correctly reflects a real wallet top-up; `?months=3`
param correctly returns exactly 3 months of trend data.

## 3. Biometric Login + Session Persistence

**What it does:** two related fixes bundled together, since biometric
login is meaningless without the first one:

1. **Session persistence (new):** previously, `ApiService.refreshToken`
   was purely in-memory — closing/reopening the app always forced a fresh
   login, even though the backend's refresh token is valid for 30 days.
   Now the refresh token is persisted to `SharedPreferences` on every
   login/refresh, and `ApiService.tryRestoreSession()` is called once at
   app launch to silently restore the session (skips the Login screen
   entirely, straight to the Biometric Gate or Main app).
2. **Biometric Login (new, on top of #1):** once a session is being
   silently restored, if the user previously turned on "Biometric Login"
   (Profile > App Settings), a `BiometricGateScreen` requires a successful
   fingerprint/face match (via the `local_auth` plugin) before actually
   entering the app — so a phone left unlocked doesn't automatically hand
   over an active Global Exchanger session to whoever picks it up.

**Important clarification (security model):** biometrics here are a
**local convenience/re-lock layer only** — they unlock an *already
server-authenticated* session (the persisted refresh token). The backend
has no concept of "biometric auth" at all; nothing about this changes
server-side authentication. This is the same model used by most banking/
payment apps' "app lock" features.

**Files:**
- `pubspec.yaml`: added `local_auth: ^2.3.0` and `shared_preferences:
  ^2.3.2`.
- `lib/services/api_service.dart`: `_persistRefreshToken()`,
  `tryRestoreSession()`, `isBiometricAvailable()`,
  `isBiometricEnabled()`/`setBiometricEnabled()`,
  `authenticateWithBiometrics()`. `logout()`/`logoutEverywhere()` now also
  clear the persisted token and turn biometric login back off (a session
  that no longer exists shouldn't have a "biometric unlock" toggle left on
  for it).
- `lib/main.dart`: `GlobalExchangerApp` converted to a `StatefulWidget`
  that calls `tryRestoreSession()` once at startup and routes to either
  `BiometricGateScreen` (if a session was restored) or the normal
  `SplashScreen` (fresh install / logged out). New `BiometricGateScreen`
  shows a fingerprint icon + "Unlock" button, with a "Logout Instead"
  escape hatch if the user can't/won't pass the biometric check.
  `AppSettingsScreen` gained a "Biometric Login" toggle section — turning
  it ON requires passing a biometric check immediately (so a user can't
  enable it without ever proving they can actually unlock it later,
  which would lock them out).
- `codemagic.yaml`: added the `USE_BIOMETRIC`/`USE_FINGERPRINT` Android
  permissions, and — critically — a new patch step that rewrites the
  generated `MainActivity` to extend `FlutterFragmentActivity` instead of
  the default `FlutterActivity`. **This is a hard requirement for
  `local_auth` to work on Android** — without it, the biometric prompt
  silently fails or crashes, since `local_auth`'s Android implementation
  needs a `FragmentActivity` host to show its prompt dialog. Handles both
  Kotlin (`.kt`, the modern default) and Java (`.java`, legacy) generated
  activity files.

**Not verified in this sandbox:** actual biometric hardware
interaction — this sandbox has no Flutter SDK/Android emulator with
fingerprint hardware to test against. The `local_auth` integration
pattern (permissions, `FlutterFragmentActivity` requirement, API usage)
follows the plugin's own documented Android setup requirements exactly.
**Ask the user to test this specific feature carefully on their real
phone** after the next Codemagic build — specifically: (a) does the
biometric prompt appear when enabling the toggle, (b) does closing and
reopening the app show the fingerprint unlock screen, (c) does a failed
scan let them retry or log out instead.

## 4. Referral Leaderboard

**What it does:** a new Leaderboard screen shows the top referrers
(ranked by number of successfully **rewarded** referrals — same
fraud-resistant "friend completed their first transaction" definition
used everywhere else in the referral system, not just signups), with
masked names for privacy (e.g. "Rajesh Kumar" → "Rajesh K."), plus the
current user's own rank even if they're outside the visible top N.

**Files:**
- Endpoint: `GET /api/referrals/leaderboard?limit=N` (default 10, max 50).
  `maskNameForLeaderboard()` helper (duplicated identically in both
  backends) shows first-name + last-initial, or a truncated fallback for
  single-word names/emails.
- Flutter: `ReferralLeaderboardScreen` (Profile > Referral Leaderboard) —
  gradient "Your Rank" hero card, medal-colored (gold/silver/bronze) rank
  badges for top 3, current user's own row highlighted if visible in the
  list.

**Privacy note:** only a masked first-name + initial is ever shown
publicly — full names/emails are never exposed to other users through
this endpoint.

**Verified via automated testing (both backends):** endpoint returns
`leaderboard`/`myRank`/`totalRankedUsers` fields with correct shape.

## 5. Multi-Language (English / Hindi)

**What it does:** adds a proper language toggle (Profile > App Settings >
Language) between English and Hindi (हिन्दी), synced to the user's
account (same pattern as Dark Mode) so the choice follows them across
devices/reinstalls.

**Files:**
- `lib/l10n/app_strings.dart` — a lightweight, dependency-free
  `AppStrings.t(key)` lookup + `LanguageController` (a global
  `ValueNotifier<String>`, same reactive pattern as `ThemeController`) —
  no `intl`/ARB-file machinery, just a plain string map, since the app
  didn't have any i18n infrastructure to begin with.
- `users.language_preference` column (`'en'`/`'hi'`, default `'en'`) —
  `GET/PATCH /api/settings` extended to read/write it, same as
  `theme_preference`.
- Bottom navigation labels, the Settings screen itself, and this round's
  3 new feature screens (Scheduled Payments, Spending Analytics, Referral
  Leaderboard) are fully translated and switch instantly when the toggle
  changes (via `ValueListenableBuilder<String>`, same mechanism as Dark
  Mode's instant-apply).

**IMPORTANT SCOPE NOTE — read before telling users "the app is in
Hindi":** this is genuinely a large (3000+ line, 60+ screen) app built up
over many feature rounds, almost entirely with Hinglish (Hindi words in
Roman script mixed with English) as its existing voice throughout —
translating literally everything into proper Devanagari Hindi in one pass
was a much bigger, separate effort than fit in this round alongside 4
other full features. **What's translated now:** bottom nav, Settings
screen, and this round's 3 new screens. **What's NOT yet translated:**
every other existing screen (Login, Signup, KYC, Send/Receive Money,
Wallet, History, Support Chat, etc.) — these will continue showing their
existing Hinglish text even with Hindi mode selected. This is flagged
directly to the user in the Settings screen itself via a warning box, and
is an explicit, incremental rollout (same pattern as how Dark Mode was
rolled out to shared widgets first, then swept across screens in a later
round) — not a bug or an oversight. A natural follow-up round would be
"sweep the rest of the app's screens into `app_strings.dart` the same way
Dark Mode was swept."

## Testing performed this round

- New automated test suite covering: settings language get/patch/
  validation, scheduled-payments create/invalid-frequency-reject/
  self-send-reject/wrong-pin-reject/list/pause/resume/runs-history/
  cancel/cannot-reactivate-cancelled, full due-mandate execution
  (balance transfer + next-run-date advancement + notification +
  no-double-execution safety), cron endpoint (secret validation +
  execution), spending analytics (all 4 sub-objects + months param),
  referral leaderboard (shape) — run against **both backends**, all
  passing (18/18 on JSON including live mandate execution, 16/16 on
  Postgres for the non-DB-manipulation-dependent subset, plus a
  standalone 8/8 PostgreSQL-specific mandate-execution test using direct
  SQL manipulation to simulate a due mandate — same technique, adapted
  for SQL instead of JSON file editing).
- Route-count parity re-verified: **104 matching routes** on both
  backends (up from 96 in v1.10.2+21, +8 for scheduled-payments CRUD (4),
  analytics (1), leaderboard (1), and the scheduled-payments cron
  endpoint + admin monitoring endpoint (2)).
- Full regression re-check of core pre-existing flows (register, login,
  `/api/me`, wallet, watchlist, price-alerts, complaints, notifications)
  — all still return `200` on both backends, no regression introduced.
- `node -c` syntax check passed on `server.js`, `server_pg.js`,
  `scheduled_payments.js`, `analytics.js`.
- Python brace/bracket/paren balance check passed on `main.dart`,
  `api_service.dart`, `app_strings.dart`.
- `codemagic.yaml` validated as parseable YAML, and both new/modified
  embedded Python build-script blocks validated as syntactically correct
  Python via `compile()`.
- Admin Panel JS extracted and validated via `node -c`.

## Deferred / not done this round

- Full app-wide Hindi translation coverage (see Multi-Language section's
  scope note above) — only nav + Settings + 3 new screens translated so
  far.
- Real biometric hardware testing (no Flutter/Android emulator available
  in this sandbox — ask the user to verify on their real phone after the
  next build, see Biometric Login section above).
- Firebase push notifications — still deferred from earlier rounds,
  pending the user setting up their own free Firebase project.
- A production-grade external cron scheduler actually configured to hit
  `/api/cron/run-scheduled-payments` — the endpoint exists and is tested,
  but (like the sanctions-sync cron) requires the user to: (1) set
  `CRON_SECRET` on Render env vars, (2) set up an external pinger (GitHub
  Actions workflow, cron-job.org, etc.) with the same secret. Not done
  automatically as part of this round (same as sanctions-sync's cron
  setup, which is documented separately in
  `AUTOMATIC_SANCTIONS_SYNC_SETUP_GUIDE.md` as a manual one-time setup
  step).
