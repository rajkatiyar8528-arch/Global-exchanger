# Admin Broadcast Notifications — Guide

Ye feature admin ko ek hi jagah se **sabhi users** (ya kisi khaas group) ko custom announcement bhejne deta hai — jaise offers, maintenance notice, policy update, ya koi bhi important message.

## Kaise Use Karein

1. Admin Panel kholein: `https://rajkatiyar8528-arch.github.io/Global-exchanger/admin_panel/`
2. Login karein
3. Dashboard par **"📢 Broadcast Notification"** section dikhega
4. **Title** likhein (max 100 characters) — jaise "Diwali Offer! 🎉"
5. **Message** likhein (max 500 characters) — jaise "Aaj se 3 din tak exchange par 0% commission!"
6. **"Send To"** me audience choose karein:
   - **All Users** — har registered user ko jaayega
   - **Only KYC-Approved Users** — sirf jinki KYC approve ho chuki hai
   - **Only Users With Push Enabled & Device Registered** — sirf wo log jinke phone par abhi push notification jaa sakta hai
7. **"🚀 Send Broadcast"** dabayein, confirm karein
8. Neeche "Sent At" history table me record dikh jaayega — kitne logo ko gaya, kab gaya

## Ye Feature Kaise Kaam Karta Hai (Technical)

- Har user ko ek **in-app notification** (Notifications tab me, 📢 icon ke saath) turant milta hai
- Agar Firebase Push configure hai (dekhein `PUSH_NOTIFICATIONS_SETUP_GUIDE.md`), to user ke phone par **real background push notification** bhi jaata hai — chahe app band ho
- **User apni khud ki setting respect karta hai**: agar kisi user ne App Settings me push notifications OFF kar rakhe hain, to unhe sirf in-app notification milegi, push nahi jayega — broadcast is setting ko bypass NAHI karta
- **Email broadcast NAHI bheja jaata** — jaanbujh kar, kyunki mass marketing email ke liye proper unsubscribe link aur opt-in consent chahiye hota hai (ye app abhi wo support nahi karta). Email sirf account-specific messages (KYC approval, payment receipt, etc.) ke liye hai.
- **Rate limit**: ek admin account 1 ghante me max 20 broadcast bhej sakta hai — accidental spam se bachne ke liye

## Kaun Bhej Sakta Hai (Permission System)

Sirf wo admin jinke paas **"Send Broadcast Notifications"** (`notifications:broadcast`) permission hai:
- **Super Admin** — automatically ye permission hoti hai
- **Marketing Manager** (naya role preset) — users dekh sakta hai + broadcast bhej sakta hai + audit logs dekh sakta hai, lekin payments/KYC/refunds jaisi sensitive cheezein nahi chhoo sakta
- Koi bhi admin ko "Admin Role Assignment" section se custom permission bhi diya ja sakta hai

⚠️ **Purane admins ke liye**: Jab ye feature deploy hoga, sirf wo admins jo pehle se **Super Admin** hain ya jinke paas **"Manage Admin Roles"** permission hai, unhe automatically ye naya permission mil jayega — koi manual step nahi chahiye. Limited-scope admins (jaise KYC Manager, Finance Manager) ko ye permission automatically NAHI milega — unhe explicitly Admin Role Assignment se assign karna hoga agar zaroorat ho.

## Audit Trail

Har broadcast ek audit log entry banata hai (`admin.broadcast.sent`) — konsa admin, kab, kis audience ko, kitne logo ko bheja — "Admin Audit Logs" section me dikh jayega.

## Business Use-Cases

- Naya feature launch hua? Sabko batayein
- Koi maintenance window aane wala hai? Advance notice dein
- Referral bonus ya exchange fee discount ka offer? Marketing announcement bhejein
- Compliance/policy update? Sirf KYC-approved users ko relevant update bhejein
