# Global Exchanger - Complete Deployment Guide

This guide explains how to deploy the Global Exchanger backend, PostgreSQL database, admin panel, and Flutter app.

> Important: This is a financial/payment/forex/crypto style app. Before production launch, complete legal approvals, RBI/NPCI/FEMA/FIU/KYC/AML compliance, data protection, and payment gateway agreements.

---

## 1. Production Architecture

Recommended production architecture:

```text
Flutter Android/iOS App
        |
        | HTTPS
        v
Backend API - Node.js/Express
        |
        v
PostgreSQL Database
        |
        +-- Razorpay/Cashfree Payment Gateway
        +-- SMTP/SES/SendGrid Email OTP
        +-- KYC Provider
        +-- Forex/Crypto Rate APIs
        +-- Admin Web Panel
```

Recommended services:

- Backend: Render, Railway, DigitalOcean, AWS EC2, AWS ECS, GCP Cloud Run, Azure App Service
- Database: Supabase PostgreSQL, Neon, Railway PostgreSQL, AWS RDS, DigitalOcean Managed DB
- Admin Panel: Netlify, Vercel, Cloudflare Pages, or serve from backend/static hosting
- Mobile App: Google Play Console / Apple App Store

---

## 2. Backend Deployment

### 2.1 Required Environment Variables

Create production `.env`:

```env
NODE_ENV=production
PORT=5000
JWT_SECRET=use_a_long_random_64_char_secret
DATABASE_URL=postgres://user:password@host:5432/global_exchanger

ADMIN_EMAIL=admin@globalexchanger.com
ADMIN_PASSWORD=change_strong_password
ADMIN_SPECIAL_KEY=change_strong_special_key

PAYMENT_PROVIDER=razorpay
RAZORPAY_KEY_ID=rzp_live_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
RAZORPAY_WEBHOOK_SECRET=xxxxx

# Optional later
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
SMTP_FROM=support@globalexchanger.com
```

### 2.2 Install Dependencies

```bash
cd backend
npm install
```

### 2.3 Run Database Migration

```bash
npm run migrate
```

### 2.4 Start PostgreSQL Backend

```bash
npm run start:pg
```

For development:

```bash
npm run dev:pg
```

---

## 3. Deploy Backend on Render Example

1. Push project to GitHub.
2. Create new Render Web Service.
3. Root directory: `backend`
4. Build command:

```bash
npm install && npm run migrate
```

5. Start command:

```bash
npm run start:pg
```

6. Add all environment variables.
7. Attach PostgreSQL database or use external database URL.
8. Enable HTTPS.

---

## 4. Database Deployment

Recommended: Managed PostgreSQL.

Steps:

1. Create database `global_exchanger`.
2. Copy connection string.
3. Set `DATABASE_URL` in backend.
4. Run:

```bash
cd backend
npm run migrate
```

5. Enable automated backups.
6. Restrict public access if possible.

---

## 5. Razorpay Production Setup

1. Create Razorpay business account.
2. Complete KYC and activate live mode.
3. Get live key ID and secret.
4. Set:

```env
PAYMENT_PROVIDER=razorpay
RAZORPAY_KEY_ID=rzp_live_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
```

5. Add webhook URL:

```text
https://your-backend-domain.com/api/payments/webhook
```

6. Set webhook secret:

```env
RAZORPAY_WEBHOOK_SECRET=xxxxx
```

7. Test:

- Order creation
- Checkout
- Payment verification
- Webhook signature verification
- Refund API
- Settlement reconciliation

---

## 6. Admin Panel Deployment

Admin panel file:

```text
admin_panel/index.html
```

Options:

### Option A: Static Hosting

Upload `admin_panel/index.html` to Netlify/Vercel/Cloudflare Pages.

Update default API URL in the panel or type API URL on login screen:

```text
https://your-backend-domain.com
```

### Option B: Serve via Backend

Move admin panel to backend public/static folder and serve with Express. Recommended only after adding strict access control and HTTPS.

---

## 7. Flutter App Production Build

### 7.1 Update API URL

File:

```text
global_exchanger_flutter/lib/services/api_service.dart
```

Change:

```dart
static const String baseUrl = 'https://your-backend-domain.com';
```

### 7.2 Generate Android Platform Files

```bash
cd global_exchanger_flutter
flutter create --platforms=android,ios,web .
flutter pub get
```

### 7.3 Android App Signing

Create keystore:

```bash
keytool -genkey -v -keystore global-exchanger.jks -keyalg RSA -keysize 2048 -validity 10000 -alias globalexchanger
```

Configure `android/key.properties` and `android/app/build.gradle` according to Flutter release signing docs.

### 7.4 Build APK

```bash
flutter build apk --release
```

### 7.5 Build App Bundle for Play Store

```bash
flutter build appbundle --release
```

Output:

```text
build/app/outputs/bundle/release/app-release.aab
```

---

## 8. Google Play Store Checklist

Required:

- App name: Global Exchanger
- App icon
- Screenshots
- Privacy Policy URL
- Terms URL
- Support email
- Data safety form
- Financial services declaration
- Payment/UPI/forex/crypto compliance documents
- Demo account for review, if required
- Clear refund/dispute policy

---

## 9. Security Checklist

Before production:

- Use HTTPS only
- Strong JWT secret
- Admin 2FA
- Admin IP/device restrictions
- Rate limiting
- Request validation
- Audit logs enabled
- Database backups
- Encrypted KYC document storage
- Webhook idempotency
- Razorpay signature verification
- SMTP email OTP
- Error monitoring
- Server monitoring
- Fraud detection
- Legal compliance review

---

## 10. Production Commands Summary

Backend:

```bash
cd backend
npm install
npm run migrate
npm run start:pg
```

Flutter:

```bash
cd global_exchanger_flutter
flutter pub get
flutter build appbundle --release
```

Admin:

```text
Open deployed admin_panel/index.html and point it to backend API URL.
```
