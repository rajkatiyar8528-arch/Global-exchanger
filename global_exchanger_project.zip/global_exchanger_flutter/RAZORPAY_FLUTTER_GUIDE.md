# Razorpay Flutter Checkout

Added dependency:

```yaml
razorpay_flutter: ^1.3.7
```

Added service:

```text
lib/services/razorpay_checkout_service.dart
```

Wallet screen flow:

1. Calls backend `POST /api/payments/orders`
2. If backend provider is `razorpay`, opens Razorpay checkout
3. On success, calls backend `POST /api/payments/verify`
4. Backend verifies signature and tops up wallet

Backend `.env`:

```env
PAYMENT_PROVIDER=razorpay
RAZORPAY_KEY_ID=rzp_test_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
```
