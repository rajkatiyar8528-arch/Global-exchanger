#!/usr/bin/env bash
set -e
# Run this script on a computer where Flutter SDK is installed.
# It will generate missing Android/iOS/Web platform folders without deleting lib/main.dart.
flutter create --platforms=android,ios,web .
flutter pub get
echo "Project is ready. Build APK with: flutter build apk --release"
