# OTP Login and Email Verification UI

Added screens in `lib/main.dart`:

- `OtpLoginScreen`
- `EmailVerificationScreen`

Login screen has:

- Email/password login
- Login with Email OTP

Signup flow:

1. Create account
2. Request email verification OTP
3. Verify OTP
4. Continue to KYC

Development mode: backend returns `devOtp` and prints OTP in console.
