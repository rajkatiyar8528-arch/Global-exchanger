# Global Exchanger Flutter App

This is the Flutter starter code for Global Exchanger.

## Run in debug mode

```bash
cd global_exchanger_flutter
flutter pub get
flutter run
```

## Build APK

```bash
cd global_exchanger_flutter
flutter pub get
flutter build apk --release
```

APK output path usually:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Connect Backend

Backend local URL:

- Android emulator: `http://10.0.2.2:5000`
- Physical phone: use your computer LAN IP, e.g. `http://192.168.1.10:5000`

## Before Play Store

- Change app package name
- Add real app icon
- Add privacy policy URL
- Add terms URL
- Configure signing key
- Complete Google Play financial services declarations
- Add RBI/NPCI/FEMA/FIU/legal compliance documents if applicable

## Professional UI Added

Added:

- `lib/theme/app_theme.dart`
- `lib/widgets/pro_widgets.dart`

## Backend Connected Features

- Login/register
- KYC submit
- Rates
- Exchange order
- Complaint
- Admin dashboard
- Payment order/verify methods in `ApiService`

## Dispute UI

Support screen now includes dispute submission fields for wrong payment/failed transaction cases.
