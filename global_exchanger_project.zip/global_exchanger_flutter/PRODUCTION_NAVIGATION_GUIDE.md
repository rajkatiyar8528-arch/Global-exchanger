# Production Navigation

Added `MainNavigationScreen` with bottom navigation:

- Home
- Wallet
- Convert
- History
- Help

Login/signup/OTP flows now route to `MainNavigationScreen`.

Convert screen can create exchange order and lock escrow for the last order.
