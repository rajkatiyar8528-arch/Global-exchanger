import 'package:flutter/material.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';
import 'widgets/pro_widgets.dart';
import 'services/razorpay_checkout_service.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

void main() => runApp(const GlobalExchangerApp());

class GlobalExchangerApp extends StatelessWidget {
  const GlobalExchangerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Global Exchanger',
      theme: AppTheme.light(),
      home: const SplashScreen(),
    );
  }
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(17),
            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 12)],
          ),
          child: const Center(
            child: Text('GX', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0967FF), fontSize: 20)),
          ),
        ),
        const SizedBox(width: 12),
        const Text('Global Exchanger', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: Colors.white)),
      ],
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF0967FF), Color(0xFF00C48C)]),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppLogo(),
                      SizedBox(height: 10),
                      Text('Secure Money, Global Exchange', style: TextStyle(color: Colors.white70)),
                      Spacer(),
                      Text('Send, Receive & Convert Currency', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 36, height: 1.05)),
                      SizedBox(height: 14),
                      Text('UPI-style payments, wallet, forex, crypto exchange and secure KYC.', style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              ),
              PrimaryButton(text: 'User Login', onTap: () => go(context, const LoginScreen())),
              SecondaryButton(text: 'Admin Login', onTap: () => go(context, const AdminLoginScreen())),
              TextButton(onPressed: () => go(context, const TermsScreen()), child: const Text('Terms & Privacy')),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(text: 'test@example.com');
  final password = TextEditingController(text: 'Test@12345');
  bool loading = false;

  Future<void> doLogin() async {
    setState(() => loading = true);
    try {
      await ApiService.login(email.text.trim(), password.text.trim());
      if (mounted) replace(context, const MainNavigationScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'User Login',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const Text('Email/password se backend login karein.'),
          const SizedBox(height: 20),
          AppInput(label: 'Email', controller: email),
          AppInput(label: 'Password', obscure: true, controller: password),
          PrimaryButton(text: loading ? 'Please wait...' : 'Login with Backend', onTap: loading ? () {} : doLogin),
          SecondaryButton(text: 'Login with Email OTP', onTap: () => go(context, const OtpLoginScreen())),
          PrimaryButton(text: 'Create New Account', color: const Color(0xFF00B876), onTap: () => go(context, const SignupScreen())),
        ],
      ),
    );
  }
}

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});
  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final country = TextEditingController(text: 'India');
  final address = TextEditingController();
  final house = TextEditingController();
  final password = TextEditingController(text: 'Test@12345');
  bool loading = false;

  Future<void> doRegister() async {
    setState(() => loading = true);
    try {
      await ApiService.register({'name': name.text, 'email': email.text, 'phone': phone.text, 'country': country.text, 'address': address.text, 'houseNumber': house.text, 'password': password.text});
      await ApiService.requestOtp(email.text.trim(), purpose: 'email_verification');
      if (mounted) replace(context, EmailVerificationScreen(email: email.text.trim()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Create Account',
      child: ListView(
        children: [
          AppInput(label: 'Full Name', controller: name),
          AppInput(label: 'Email', controller: email),
          AppInput(label: 'Phone Number', controller: phone),
          AppInput(label: 'Country', controller: country),
          AppInput(label: 'Address', controller: address),
          AppInput(label: 'House Number', controller: house),
          AppInput(label: 'Password', obscure: true, controller: password),
          PrimaryButton(text: loading ? 'Creating...' : 'Create Account on Backend', onTap: loading ? () {} : doRegister),
        ],
      ),
    );
  }
}

class KycScreen extends StatefulWidget {
  const KycScreen({super.key});
  @override
  State<KycScreen> createState() => _KycScreenState();
}

class _KycScreenState extends State<KycScreen> {
  final nationalId = TextEditingController();
  final taxId = TextEditingController();
  final country = TextEditingController(text: 'India');
  bool loading = false;

  Future<void> submit() async {
    setState(() => loading = true);
    try {
      await ApiService.submitKyc({'nationalId': nationalId.text, 'taxId': taxId.text, 'country': country.text, 'documentNames': ['aadhaar_or_id.pdf', 'pan_or_tax_id.pdf']});
      if (mounted) replace(context, const MainNavigationScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'KYC Verification',
      child: ListView(
        children: [
          const InfoCard(title: 'India Documents', subtitle: 'Aadhaar Card, PAN Card, Passbook/Bank Statement, Selfie verification'),
          AppInput(label: 'Aadhaar / National ID Number', controller: nationalId),
          AppInput(label: 'PAN / Tax ID', controller: taxId),
          AppInput(label: 'Country', controller: country),
          const InfoCard(title: 'Upload Documents', subtitle: 'Demo API document file names save karta hai. Real upload backend storage ke sath add hoga.'),
          PrimaryButton(text: loading ? 'Submitting...' : 'Submit KYC to Backend', onTap: loading ? () {} : submit),
        ],
      ),
    );
  }
}


class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});
  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int index = 0;
  late final List<Widget> pages = const [
    UserDashboard(),
    WalletScreen(),
    ConvertScreen(),
    HistoryScreen(),
    SupportScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.currency_exchange), label: 'Convert'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'History'),
          NavigationDestination(icon: Icon(Icons.support_agent), label: 'Help'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class UserDashboard extends StatelessWidget {
  const UserDashboard({super.key});

  String _money(dynamic value, String currency) {
    final n = value is num ? value : num.tryParse('${value ?? 0}') ?? 0;
    if (currency == 'BTC' || currency == 'ETH' || currency == 'XRP') return '$n $currency';
    final symbol = currency == 'INR' ? '₹' : currency == 'USD' ? r'$' : currency == 'EUR' ? '€' : '$currency ';
    return '$symbol${n.toStringAsFixed(2)}';
  }

  @override
  Widget build(BuildContext context) {
    final items = [
      ('📤', 'Send', const SendMoneyScreen()),
      ('📥', 'Receive', const ReceiveMoneyScreen()),
      ('🔁', 'Convert', const ConvertScreen()),
      ('👛', 'Wallet', const WalletScreen()),
      ('📜', 'History', const HistoryScreen()),
      ('🤖', 'AI Help', const SupportScreen()),
    ];
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: FutureBuilder<Map<String, dynamic>>(
            future: ApiService.me(),
            builder: (context, meSnap) {
              final user = (meSnap.data?['user'] ?? {}) as Map<String, dynamic>;
              final wallet = (meSnap.data?['wallet'] ?? {}) as Map<String, dynamic>;
              final balances = (wallet['balances'] ?? {}) as Map<String, dynamic>;
              final name = user['name']?.toString().isNotEmpty == true ? user['name'].toString() : 'User';
              final kyc = user['kycStatus'] ?? user['kyc_status'] ?? 'pending';
              final inr = balances['INR'] ?? 0;
              return Column(
                children: [
                  GradientHeader(
                    title: 'Hello, $name',
                    subtitle: 'INR Wallet Balance • KYC: $kyc',
                    amount: _money(inr, 'INR'),
                    trailing: const StatusBadge(text: 'Secure'),
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      children: items.map((e) => FeatureTile(icon: e.$1, label: e.$2, onTap: () => go(context, e.$3))).toList(),
                    ),
                  ),
                  FutureBuilder<Map<String, dynamic>>(future: ApiService.rates(), builder: (context, snap) => InfoCard(title: 'Live Backend Rates', subtitle: snap.hasData ? 'USD/INR: ${snap.data!["forex"]["USD_INR"]}, BTC/USD: ${snap.data!["crypto"]["BTC_USD"]}' : 'Loading rates from backend...')),
                  const InfoCard(title: 'Referral Reward ₹100', subtitle: 'Reward tab unlock hoga jab referred user account create karega.'),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class SendMoneyScreen extends StatelessWidget {
  const SendMoneyScreen({super.key});
  @override
  Widget build(BuildContext context) => AppPage(title: 'Send Money', child: ListView(children: const [
    AppInput(label: 'QR / UPI ID / Phone / Bank Account / User ID'), AppInput(label: 'Amount'), AppInput(label: 'Wallet: INR / USD / BTC'), WarningBox(text: 'Payment send karne se pehle Security PIN ya Fingerprint zaruri hai.'), AppInput(label: 'Security PIN', obscure: true), SizedBox(height: 8),
  ]));
}

class ReceiveMoneyScreen extends StatelessWidget {
  const ReceiveMoneyScreen({super.key});
  @override
  Widget build(BuildContext context) => AppPage(title: 'Receive Money', child: Column(children: [
    const InfoCard(title: 'Your QR Code', subtitle: 'GXUSER123@global'),
    Container(width: 190, height: 190, decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(18))),
    PrimaryButton(text: 'Copy User ID', onTap: () {}),
  ]));
}

class ConvertScreen extends StatefulWidget {
  const ConvertScreen({super.key});
  @override
  State<ConvertScreen> createState() => _ConvertScreenState();
}

class _ConvertScreenState extends State<ConvertScreen> {
  final mode = TextEditingController(text: 'convert');
  final from = TextEditingController(text: 'INR');
  final to = TextEditingController(text: 'USD');
  final amount = TextEditingController(text: '1000');
  bool loading = false;
  String? lastOrderId;

  Future<void> createOrder() async {
    setState(() => loading = true);
    try {
      final result = await ApiService.createExchangeOrder({'mode': mode.text, 'fromCurrency': from.text, 'toCurrency': to.text, 'amount': double.tryParse(amount.text) ?? 0});
      lastOrderId = result['order']['id'];
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order created: ${result['order']['id']}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> lockEscrow() async {
    if (lastOrderId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Create order first')));
      return;
    }
    try {
      await ApiService.lockExchangeEscrow(lastOrderId!);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Escrow locked successfully')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Convert Currency', child: ListView(children: [
    AppInput(label: 'Option: convert / sell', controller: mode), AppInput(label: 'From: INR', controller: from), AppInput(label: 'To: USD / BTC', controller: to), AppInput(label: 'Amount', controller: amount),
    FutureBuilder<Map<String, dynamic>>(future: ApiService.rates(), builder: (context, snap) => InfoCard(title: 'Live Rate From Backend', subtitle: snap.hasData ? 'USD/INR: ${snap.data!["forex"]["USD_INR"]}' : 'Loading...')),
    const WarningBox(text: 'Exchange escrow/security hold ke through complete hoga. Admin commission 1%.'),
    PrimaryButton(text: loading ? 'Creating...' : 'Create Exchange Order', color: const Color(0xFF00B876), onTap: loading ? () {} : createOrder),
    SecondaryButton(text: 'Lock Escrow for Last Order', onTap: lockEscrow),
  ]));
}

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool loading = false;
  late Future<Map<String, dynamic>> walletFuture = ApiService.me();
  final RazorpayCheckoutService razorpay = RazorpayCheckoutService();
  Map<String, dynamic>? pendingOrder;
  Map<String, dynamic>? pendingGatewayOrder;

  void refreshWallet() => setState(() => walletFuture = ApiService.me());

  String _money(dynamic value, String currency) {
    final n = value is num ? value : num.tryParse('${value ?? 0}') ?? 0;
    if (currency == 'BTC' || currency == 'ETH' || currency == 'XRP') return '$n $currency';
    final symbol = currency == 'INR' ? '₹' : currency == 'USD' ? r'$' : currency == 'EUR' ? '€' : '$currency ';
    return '$symbol${n.toStringAsFixed(2)}';
  }

  @override
  void initState() {
    super.initState();
    razorpay.onSuccess = handleRazorpaySuccess;
    razorpay.onFailure = (PaymentFailureResponse response) {
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(response.message ?? 'Payment failed')));
    };
    razorpay.onExternalWallet = (ExternalWalletResponse response) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('External wallet: ${response.walletName}')));
    };
  }

  @override
  void dispose() {
    razorpay.dispose();
    super.dispose();
  }

  Future<void> handleRazorpaySuccess(PaymentSuccessResponse response) async {
    try {
      final order = pendingOrder!;
      final gatewayOrder = pendingGatewayOrder!;
      await ApiService.verifyPayment(
        orderId: order['id'],
        gatewayOrderId: response.orderId ?? gatewayOrder['gatewayOrderId'],
        gatewayPaymentId: response.paymentId ?? '',
        gatewaySignature: response.signature,
      );
      refreshWallet();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment verified and wallet topped up.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment verification failed')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> addMoney() async {
    setState(() => loading = true);
    try {
      final created = await ApiService.createPaymentOrder(amount: 500, currency: 'INR', purpose: 'wallet_topup');
      pendingOrder = created['order'];
      pendingGatewayOrder = created['gatewayOrder'];
      final gatewayOrder = pendingGatewayOrder!;

      if (gatewayOrder['provider'] == 'razorpay' && gatewayOrder['publicKey'] != null) {
        razorpay.openCheckout(
          key: gatewayOrder['publicKey'],
          orderId: gatewayOrder['gatewayOrderId'],
          amount: 500,
          currency: 'INR',
          name: 'Global Exchanger',
          description: 'Wallet Top-up',
        );
      } else {
        await ApiService.verifyPayment(orderId: pendingOrder!['id'], gatewayOrderId: gatewayOrder['gatewayOrderId'], gatewayPaymentId: 'mock_payment_${DateTime.now().millisecondsSinceEpoch}');
        refreshWallet();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('₹500 wallet top-up completed.')));
        if (mounted) setState(() => loading = false);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add money failed')));
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Multi Currency Wallet',
    child: FutureBuilder<Map<String, dynamic>>(
      future: walletFuture,
      builder: (context, snap) {
        final wallet = (snap.data?['wallet'] ?? {}) as Map<String, dynamic>;
        final balances = (wallet['balances'] ?? {}) as Map<String, dynamic>;
        final currencies = ['INR', 'USD', 'EUR', 'BTC', 'ETH', 'XRP'];
        return ListView(children: [
          if (snap.connectionState == ConnectionState.waiting) const InfoCard(title: 'Wallet', subtitle: 'Loading balances...'),
          ...currencies.map((c) => InfoCard(title: c, subtitle: _money(balances[c] ?? 0, c))),
          PrimaryButton(text: loading ? 'Processing...' : 'Add Money ₹500 using Mock Gateway', onTap: loading ? () {} : addMoney),
          SecondaryButton(text: 'Refresh Wallet', onTap: refreshWallet),
          SecondaryButton(text: 'Add Bank Account', onTap: () {}),
          SecondaryButton(text: 'Withdraw', onTap: () {}),
        ]);
      },
    ),
  );
}

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});
  @override
  Widget build(BuildContext context) => AppPage(title: 'Payment History', child: ListView(children: const [
    InfoCard(title: 'INR to USD - Complete', subtitle: 'TXN1001'), InfoCard(title: 'Send to Rahul - Pending', subtitle: 'TXN1002'), InfoCard(title: 'BTC Exchange - Cancelled', subtitle: 'TXN1003'),
  ]));
}

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});
  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final question = TextEditingController();
  final subject = TextEditingController();
  final message = TextEditingController();
  final disputeTxn = TextEditingController();
  final disputeReason = TextEditingController(text: 'Wrong payment');
  final disputeMessage = TextEditingController();
  bool loading = false;

  Future<void> sendComplaint() async {
    setState(() => loading = true);
    try {
      await ApiService.complaint(subject.text, message.text);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Complaint sent to admin')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }


  Future<void> sendDispute() async {
    setState(() => loading = true);
    try {
      await ApiService.createDispute(transactionId: disputeTxn.text.trim().isEmpty ? null : disputeTxn.text.trim(), reason: disputeReason.text, message: disputeMessage.text);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dispute submitted to admin')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Help & Complaint', child: ListView(children: [
    const InfoCard(title: 'AI Help Agent', subtitle: 'KYC, payment, wallet aur exchange help.'), AppInput(label: 'Apna question likhein', controller: question), PrimaryButton(text: 'Ask AI Demo', onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI agent integration next phase me add hoga.')))),
    AppInput(label: 'Complaint Subject', controller: subject), AppInput(label: 'Complaint Details', controller: message), PrimaryButton(text: loading ? 'Sending...' : 'Send Complaint to Backend', color: const Color(0xFF00B876), onTap: loading ? () {} : sendComplaint),
    const SizedBox(height: 18),
    const InfoCard(title: 'Dispute Management', subtitle: 'Wrong payment ya failed transaction dispute yahan submit karein.'),
    AppInput(label: 'Transaction ID optional', controller: disputeTxn),
    AppInput(label: 'Reason', controller: disputeReason),
    AppInput(label: 'Dispute Details', controller: disputeMessage),
    PrimaryButton(text: loading ? 'Submitting...' : 'Submit Dispute', color: Color(0xFF111827), onTap: loading ? () {} : sendDispute),
  ]));
}


class EmailVerificationScreen extends StatefulWidget {
  final String email;
  const EmailVerificationScreen({super.key, required this.email});
  @override
  State<EmailVerificationScreen> createState() => _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  final otp = TextEditingController();
  bool loading = false;

  Future<void> verify() async {
    setState(() => loading = true);
    try {
      await ApiService.verifyEmailOtp(widget.email, otp.text.trim());
      if (mounted) replace(context, const KycScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> resend() async {
    try {
      final result = await ApiService.requestOtp(widget.email, purpose: 'email_verification');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('OTP sent. Dev OTP: ${result['devOtp'] ?? 'check email'}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Email Verification', child: ListView(children: [
    InfoCard(title: 'Verify Email', subtitle: 'OTP sent to ${widget.email}. Development mode me OTP backend console/API response me milega.'),
    AppInput(label: '6 Digit OTP', controller: otp),
    PrimaryButton(text: loading ? 'Verifying...' : 'Verify Email', onTap: loading ? () {} : verify),
    SecondaryButton(text: 'Resend OTP', onTap: resend),
  ]));
}

class OtpLoginScreen extends StatefulWidget {
  const OtpLoginScreen({super.key});
  @override
  State<OtpLoginScreen> createState() => _OtpLoginScreenState();
}

class _OtpLoginScreenState extends State<OtpLoginScreen> {
  final email = TextEditingController();
  final otp = TextEditingController();
  bool otpSent = false;
  bool loading = false;

  Future<void> request() async {
    setState(() => loading = true);
    try {
      final result = await ApiService.requestOtp(email.text.trim(), purpose: 'login');
      setState(() => otpSent = true);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('OTP sent. Dev OTP: ${result['devOtp'] ?? 'check email'}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> login() async {
    setState(() => loading = true);
    try {
      await ApiService.loginWithOtp(email.text.trim(), otp.text.trim());
      if (mounted) replace(context, const MainNavigationScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'OTP Login', child: ListView(children: [
    const InfoCard(title: 'Secure OTP Login', subtitle: 'Email par 6 digit OTP receive karke login karein.'),
    AppInput(label: 'Email', controller: email),
    if (otpSent) AppInput(label: '6 Digit OTP', controller: otp),
    PrimaryButton(text: loading ? 'Please wait...' : (otpSent ? 'Login with OTP' : 'Send OTP'), onTap: loading ? () {} : (otpSent ? login : request)),
  ]));
}

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});
  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final email = TextEditingController(text: 'admin@globalexchanger.com');
  final password = TextEditingController(text: 'Admin@12345');
  final key = TextEditingController(text: 'GX-SUPER-KEY-2026');
  bool loading = false;

  Future<void> doLogin() async {
    setState(() => loading = true);
    try {
      await ApiService.adminLogin(email.text.trim(), password.text.trim(), key.text.trim());
      if (mounted) replace(context, const AdminDashboard());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Admin Login', child: Column(children: [
    const InfoCard(title: 'Secure Admin Access', subtitle: 'Email, password aur special key backend se verify honge.'),
    AppInput(label: 'Admin Email', controller: email),
    AppInput(label: 'Password', obscure: true, controller: password),
    AppInput(label: 'Special Key Password', obscure: true, controller: key),
    PrimaryButton(text: loading ? 'Please wait...' : 'Login Admin with Backend', color: const Color(0xFF111827), onTap: loading ? () {} : doLogin),
  ]));
}

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});
  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Admin Dashboard',
    child: FutureBuilder<Map<String, dynamic>>(
      future: ApiService.adminDashboard(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Text(snap.error.toString()));
        final d = snap.data!;
        return ListView(children: [
          InfoCard(title: 'Users', subtitle: '${d['users']}'),
          InfoCard(title: 'KYC Pending', subtitle: '${d['kycPending']}'),
          InfoCard(title: 'Transactions', subtitle: '${d['transactions']}'),
          InfoCard(title: 'Complaints', subtitle: '${d['complaints']}'),
          InfoCard(title: 'Commission', subtitle: '₹${d['adminCommission']} available'),
          PrimaryButton(text: 'View KYC Requests', onTap: () => go(context, const AdminKycRequestsScreen())),
          PrimaryButton(text: 'View Complaints', color: const Color(0xFF00B876), onTap: () => go(context, const AdminComplaintsScreen())),
          PrimaryButton(text: 'Claim 0.8% Admin Commission', color: const Color(0xFF111827), onTap: () {}),
        ]);
      },
    ),
  );
}

class AdminKycRequestsScreen extends StatefulWidget {
  const AdminKycRequestsScreen({super.key});
  @override
  State<AdminKycRequestsScreen> createState() => _AdminKycRequestsScreenState();
}

class _AdminKycRequestsScreenState extends State<AdminKycRequestsScreen> {
  late Future<List<dynamic>> future = ApiService.adminKycRequests();

  void reload() => setState(() => future = ApiService.adminKycRequests());

  Future<void> updateKyc(String id, String status) async {
    try {
      await ApiService.adminUpdateKyc(id, status);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('KYC $status')));
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('KYC update failed')));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'KYC Requests',
    child: FutureBuilder<List<dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Text(snap.error.toString()));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Center(child: Text('No KYC requests'));
        return ListView.builder(
          itemCount: rows.length,
          itemBuilder: (context, i) {
            final k = rows[i] as Map<String, dynamic>;
            final user = (k['user'] ?? {}) as Map<String, dynamic>;
            final id = '${k['id']}';
            final status = '${k['status'] ?? 'pending'}';
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE5EDFF))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user['name']?.toString() ?? 'User', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 4),
                Text(user['email']?.toString() ?? ''),
                const SizedBox(height: 8),
                Text('Country: ${k['country'] ?? ''}'),
                Text('National ID: ${k['nationalId'] ?? k['national_id'] ?? ''}'),
                Text('Tax ID: ${k['taxId'] ?? k['tax_id'] ?? ''}'),
                Text('Status: $status', style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: PrimaryButton(text: 'Approve', color: const Color(0xFF00B876), onTap: () => updateKyc(id, 'approved'))),
                  const SizedBox(width: 10),
                  Expanded(child: PrimaryButton(text: 'Reject', color: const Color(0xFFE53935), onTap: () => updateKyc(id, 'rejected'))),
                ]),
              ]),
            );
          },
        );
      },
    ),
  );
}

class AdminComplaintsScreen extends StatefulWidget {
  const AdminComplaintsScreen({super.key});
  @override
  State<AdminComplaintsScreen> createState() => _AdminComplaintsScreenState();
}

class _AdminComplaintsScreenState extends State<AdminComplaintsScreen> {
  late Future<List<dynamic>> future = ApiService.adminComplaints();

  void reload() => setState(() => future = ApiService.adminComplaints());

  Future<void> updateComplaint(String id, String status) async {
    try {
      await ApiService.adminUpdateComplaint(id, status);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Complaint $status')));
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Complaint update failed')));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Complaints',
    child: FutureBuilder<List<dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Text(snap.error.toString()));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Center(child: Text('No complaints'));
        return ListView.builder(
          itemCount: rows.length,
          itemBuilder: (context, i) {
            final c = rows[i] as Map<String, dynamic>;
            final id = '${c['id']}';
            final status = '${c['status'] ?? 'submitted'}';
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE5EDFF))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c['subject']?.toString() ?? 'Complaint', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 6),
                Text(c['message']?.toString() ?? ''),
                const SizedBox(height: 8),
                Text('Transaction: ${c['transactionId'] ?? c['transaction_id'] ?? 'N/A'}'),
                Text('Status: $status', style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: PrimaryButton(text: 'Review', onTap: () => updateComplaint(id, 'under_review'))),
                  const SizedBox(width: 10),
                  Expanded(child: PrimaryButton(text: 'Resolve', color: const Color(0xFF00B876), onTap: () => updateComplaint(id, 'resolved'))),
                ]),
              ]),
            );
          },
        );
      },
    ),
  );
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  String _field(Map<String, dynamic> user, String camel, String snake) =>
      (user[camel] ?? user[snake] ?? '').toString();

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'My Profile',
    child: FutureBuilder<Map<String, dynamic>>(
      future: ApiService.me(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return const Center(child: Text('Profile loading failed'));
        final user = (snap.data?['user'] ?? {}) as Map<String, dynamic>;
        return ListView(children: [
          InfoCard(title: 'Name', subtitle: _field(user, 'name', 'name')),
          InfoCard(title: 'Email', subtitle: _field(user, 'email', 'email')),
          InfoCard(title: 'Phone', subtitle: _field(user, 'phone', 'phone')),
          InfoCard(title: 'Country', subtitle: _field(user, 'country', 'country')),
          InfoCard(title: 'Address', subtitle: _field(user, 'address', 'address')),
          InfoCard(title: 'House Number', subtitle: _field(user, 'houseNumber', 'house_number')),
          InfoCard(title: 'KYC Status', subtitle: _field(user, 'kycStatus', 'kyc_status').isEmpty ? 'pending' : _field(user, 'kycStatus', 'kyc_status')),
          const InfoCard(title: 'Security', subtitle: 'Use strong password, PIN and biometric lock for payment safety.'),
          PrimaryButton(text: 'Logout', color: const Color(0xFFE53935), onTap: () {
            ApiService.token = null;
            Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const SplashScreen()), (route) => false);
          }),
        ]);
      },
    ),
  );
}

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});
  @override
  Widget build(BuildContext context) => AppPage(title: 'Terms & Privacy', child: const ListView(children: [
    InfoCard(title: 'Terms URL', subtitle: 'https://globalexchanger.com/terms'),
    InfoCard(title: 'Privacy', subtitle: 'User data secure rahega. Legal/KYC/payment needs ke liye required sharing ho sakti hai.'),
    WarningBox(text: 'Financial, forex, wallet aur crypto services ke liye RBI/NPCI/FEMA/FIU aur country-wise compliance zaruri hai.'),
  ]));
}

class AppPage extends StatelessWidget {
  final String title;
  final Widget child;
  const AppPage({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title), backgroundColor: const Color(0xFFF8FBFF)), body: Padding(padding: const EdgeInsets.all(22), child: child));
}

class AppInput extends StatelessWidget {
  final String label;
  final bool obscure;
  final TextEditingController? controller;
  const AppInput({super.key, required this.label, this.obscure = false, this.controller});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: controller, obscureText: obscure, decoration: InputDecoration(labelText: label, filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
  );
}

class PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final Color color;
  const PrimaryButton({super.key, required this.text, required this.onTap, this.color = const Color(0xFF0967FF)});
  @override
  Widget build(BuildContext context) => SizedBox(width: double.infinity, child: Padding(padding: const EdgeInsets.only(top: 10), child: FilledButton(style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.all(16)), onPressed: onTap, child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)))));
}

class SecondaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const SecondaryButton({super.key, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => SizedBox(width: double.infinity, child: Padding(padding: const EdgeInsets.only(top: 10), child: OutlinedButton(style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16)), onPressed: onTap, child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)))));
}

class FeatureTile extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;
  const FeatureTile({super.key, required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(22), child: Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE5EDFF))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(icon, style: const TextStyle(fontSize: 32)), const SizedBox(height: 10), Text(label, style: const TextStyle(fontWeight: FontWeight.w800))])));
}

class InfoCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const InfoCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE5EDFF))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.black54))]));
}

class WarningBox extends StatelessWidget {
  final String text;
  const WarningBox({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFFFF8E8), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFE2A8))), child: Text(text, style: const TextStyle(color: Color(0xFF815400))));
}

void go(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));
void replace(BuildContext context, Widget page) => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
