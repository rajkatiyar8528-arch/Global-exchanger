import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:image_picker/image_picker.dart';
import 'package:torch_light/torch_light.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart' as mlkit;
import 'services/api_service.dart';
import 'theme/app_theme.dart';
import 'widgets/pro_widgets.dart';
import 'services/razorpay_checkout_service.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const GlobalExchangerApp());

class GlobalExchangerApp extends StatelessWidget {
  const GlobalExchangerApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Rebuilds MaterialApp whenever ThemeController.mode changes (Settings
    // screen updates it directly) — this is how Dark Mode applies instantly
    // across the whole app without needing a full restart.
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: ThemeController.mode,
      builder: (context, mode, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Global Exchanger',
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: mode,
        home: const SplashScreen(),
      ),
    );
  }
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(17),
            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 12)],
          ),
          child: const Center(
            child: Text('GX', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0967FF), fontSize: 20)),
          ),
        ),
        const SizedBox(width: 12),
        const Text('Global Exchanger', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: Colors.white)),
      ],
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF0967FF), Color(0xFF00C48C)]),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppLogo(),
                      SizedBox(height: 10),
                      Text('Secure Money, Global Exchange', style: TextStyle(color: Colors.white70)),
                      Spacer(),
                      Text('Send, Receive & Convert Currency', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 36, height: 1.05)),
                      SizedBox(height: 14),
                      Text('UPI-style payments, wallet, forex, crypto exchange and secure KYC.', style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              ),
              PrimaryButton(text: 'User Login', onTap: () => go(context, const LoginScreen())),
              TextButton(onPressed: () => go(context, const TermsScreen()), child: const Text('Terms & Privacy')),
              const Text('Build v1.10.2+21', style: TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(text: 'test@example.com');
  final password = TextEditingController(text: 'Test@12345');
  bool loading = false;

  Future<void> doLogin() async {
    setState(() => loading = true);
    try {
      await ApiService.login(email.text.trim(), password.text.trim());
      if (mounted) replace(context, const MainNavigationScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'User Login',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const Text('Email/password se backend login karein.'),
          const SizedBox(height: 20),
          AppInput(label: 'Email', controller: email),
          AppInput(label: 'Password', obscure: true, controller: password),
          PrimaryButton(text: loading ? 'Please wait...' : 'Login with Backend', onTap: loading ? () {} : doLogin),
          SecondaryButton(text: 'Login with Email OTP', onTap: () => go(context, const OtpLoginScreen())),
          PrimaryButton(text: 'Create New Account', color: const Color(0xFF00B876), onTap: () => go(context, const SignupScreen())),
        ],
      ),
    );
  }
}

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});
  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final country = TextEditingController(text: 'India');
  final address = TextEditingController();
  final house = TextEditingController();
  final password = TextEditingController(text: 'Test@12345');
  final referralCode = TextEditingController();
  bool loading = false;

  Future<void> doRegister() async {
    setState(() => loading = true);
    try {
      await ApiService.register({
        'name': name.text,
        'email': email.text,
        'phone': phone.text,
        'country': country.text,
        'address': address.text,
        'houseNumber': house.text,
        'password': password.text,
        if (referralCode.text.trim().isNotEmpty) 'referralCode': referralCode.text.trim().toUpperCase(),
      });
      await ApiService.requestOtp(email.text.trim(), purpose: 'email_verification');
      if (mounted) replace(context, EmailVerificationScreen(email: email.text.trim()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Create Account',
      child: ListView(
        children: [
          AppInput(label: 'Full Name', controller: name),
          AppInput(label: 'Email', controller: email),
          AppInput(label: 'Phone Number', controller: phone),
          AppInput(label: 'Country', controller: country),
          AppInput(label: 'Address', controller: address),
          AppInput(label: 'House Number', controller: house),
          AppInput(label: 'Password', obscure: true, controller: password),
          AppInput(label: 'Referral Code (optional)', controller: referralCode),
          PrimaryButton(text: loading ? 'Creating...' : 'Create Account on Backend', onTap: loading ? () {} : doRegister),
        ],
      ),
    );
  }
}

class KycScreen extends StatefulWidget {
  const KycScreen({super.key});
  @override
  State<KycScreen> createState() => _KycScreenState();
}

class _KycDocSlot {
  final String key;
  final String label;
  File? file;
  _KycDocSlot(this.key, this.label);
}

class _KycScreenState extends State<KycScreen> {
  final nationalId = TextEditingController();
  final taxId = TextEditingController();
  final country = TextEditingController(text: 'India');
  bool loading = false;

  final List<_KycDocSlot> slots = [
    _KycDocSlot('aadhaar_front', 'Aadhaar Card - Front'),
    _KycDocSlot('aadhaar_back', 'Aadhaar Card - Back'),
    _KycDocSlot('pan_card', 'PAN Card'),
    _KycDocSlot('selfie', 'Live Selfie'),
  ];

  String? _mimeTypeFor(String path) {
    final lower = path.toLowerCase();
    if (lower.endsWith('.png')) return 'image/png';
    if (lower.endsWith('.webp')) return 'image/webp';
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    return null;
  }

  Future<void> _pickDocument(_KycDocSlot slot, {required bool useCamera}) async {
    try {
      final picked = await ImagePicker().pickImage(
        source: useCamera ? ImageSource.camera : ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 1600,
      );
      if (picked == null) return;
      final mimeType = _mimeTypeFor(picked.path);
      if (mimeType == null) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sirf JPG, PNG ya WEBP image allowed hai.')));
        return;
      }
      final file = File(picked.path);
      final sizeBytes = await file.length();
      if (sizeBytes > 4 * 1024 * 1024) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('File 4MB se badi hai. Kripya chhota/compressed photo choose karein.')));
        return;
      }
      setState(() => slot.file = file);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Upload failed: ${e.toString()}')));
    }
  }

  Future<List<Map<String, String>>> _buildDocumentsPayload() async {
    final result = <Map<String, String>>[];
    for (final slot in slots) {
      if (slot.file == null) continue;
      final bytes = await slot.file!.readAsBytes();
      result.add({
        'label': slot.label,
        'mimeType': _mimeTypeFor(slot.file!.path) ?? 'image/jpeg',
        'dataBase64': base64Encode(bytes),
      });
    }
    return result;
  }

  Future<void> submit() async {
    if (nationalId.text.trim().isEmpty || taxId.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Aadhaar/National ID aur PAN/Tax ID zaroori hai.')));
      return;
    }
    final uploadedCount = slots.where((s) => s.file != null).length;
    if (uploadedCount == 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kam se kam ek document upload karein (Aadhaar/PAN/Selfie).')));
      return;
    }
    setState(() => loading = true);
    try {
      final documents = await _buildDocumentsPayload();
      await ApiService.submitKyc({
        'nationalId': nationalId.text.trim(),
        'taxId': taxId.text.trim(),
        'country': country.text.trim(),
        'documents': documents,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('KYC submit ho gaya. Verification ke baad status update hoga.')));
        replace(context, const MainNavigationScreen());
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Widget _docSlotCard(_KycDocSlot slot) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: borderColor(context))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(slot.label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 10),
        if (slot.file != null)
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(slot.file!, height: 140, width: double.infinity, fit: BoxFit.cover),
          )
        else
          Container(
            height: 90,
            decoration: BoxDecoration(color: const Color(0xFFF3F6FF), borderRadius: BorderRadius.circular(12)),
            child: const Center(child: Text('Koi document choose nahi hua', style: TextStyle(color: Colors.grey))),
          ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: SecondaryButton(text: 'Camera', onTap: () => _pickDocument(slot, useCamera: true))),
          const SizedBox(width: 10),
          Expanded(child: SecondaryButton(text: 'Gallery', onTap: () => _pickDocument(slot, useCamera: false))),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'KYC Verification',
      child: ListView(
        children: [
          const InfoCard(title: 'India Documents', subtitle: 'Aadhaar Card, PAN Card, aur ek live Selfie upload karein verification ke liye.'),
          AppInput(label: 'Aadhaar / National ID Number', controller: nationalId),
          AppInput(label: 'PAN / Tax ID', controller: taxId),
          AppInput(label: 'Country', controller: country),
          const SizedBox(height: 6),
          const Text('Upload Documents', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 10),
          ...slots.map(_docSlotCard),
          const WarningBox(text: 'Har document clear aur readable hona chahiye. Max size 4MB per document.'),
          PrimaryButton(text: loading ? 'Submitting...' : 'Submit KYC to Backend', onTap: loading ? () {} : submit),
        ],
      ),
    );
  }
}


class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});
  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int index = 0;
  late final List<Widget> pages = const [
    UserDashboard(),
    WalletScreen(),
    ConvertScreen(),
    HistoryScreen(),
    SupportScreen(),
    ProfileScreen(),
  ];

  int helpUnreadCount = 0;
  Timer? unreadPollTimer;

  @override
  void initState() {
    super.initState();
    // Pull the account's saved theme/notification preferences once on login
    // so Dark Mode (if the user turned it on previously, maybe on another
    // device) applies immediately rather than only after visiting Settings.
    ApiService.getSettings().then((s) {
      if (mounted) ThemeController.setFromPreferenceString(s['themePreference']?.toString());
    }).catchError((_) {});

    _refreshUnreadCount();
    // Polling (not push) keeps the Help tab's unread badge reasonably fresh
    // while the app is open, without needing a websocket/push setup.
    unreadPollTimer = Timer.periodic(const Duration(seconds: 20), (_) => _refreshUnreadCount());
  }

  @override
  void dispose() {
    unreadPollTimer?.cancel();
    super.dispose();
  }

  void _refreshUnreadCount() {
    ApiService.myComplaintsUnreadCount().then((count) {
      if (mounted) setState(() => helpUnreadCount = count);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) {
          setState(() => index = i);
          if (i == 4) _refreshUnreadCount(); // opening Help tab — badge count may change once user reads messages there
        },
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          const NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          const NavigationDestination(icon: Icon(Icons.currency_exchange), label: 'Convert'),
          const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'History'),
          NavigationDestination(
            icon: Badge(isLabelVisible: helpUnreadCount > 0, label: Text('$helpUnreadCount'), child: const Icon(Icons.support_agent)),
            label: 'Help',
          ),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class UserDashboard extends StatefulWidget {
  const UserDashboard({super.key});
  @override
  State<UserDashboard> createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {
  late Future<Map<String, dynamic>> future = ApiService.me();

  void reload() => setState(() => future = ApiService.me());

  String _money(dynamic value, String currency) {
    final n = value is num ? value : num.tryParse('${value ?? 0}') ?? 0;
    if (currency == 'BTC' || currency == 'ETH' || currency == 'XRP') return '$n $currency';
    final symbol = currency == 'INR' ? '₹' : currency == 'USD' ? r'$' : currency == 'EUR' ? '€' : '$currency ';
    return '$symbol${n.toStringAsFixed(2)}';
  }

  @override
  Widget build(BuildContext context) {
    final items = [
      ('📤', 'Send', const SendMoneyScreen()),
      ('📥', 'Receive', const ReceiveMoneyScreen()),
      ('🔁', 'Convert', const ConvertScreen()),
      ('👛', 'Wallet', const WalletScreen()),
      ('📜', 'History', const HistoryScreen()),
      ('🤖', 'AI Help', const SupportScreen()),
      ('🔔', 'Price Alerts', const PriceAlertsScreen()),
      ('⭐', 'Watchlist', const WatchlistScreen()),
    ];
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: FutureBuilder<Map<String, dynamic>>(
            future: future,
            builder: (context, meSnap) {
              if (meSnap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
              if (meSnap.hasError) return ErrorRetryView(onRetry: reload, message: 'Home data load nahi ho paya. Internet connection check karein.');
              final user = (meSnap.data?['user'] ?? {}) as Map<String, dynamic>;
              final wallet = (meSnap.data?['wallet'] ?? {}) as Map<String, dynamic>;
              final balances = (wallet['balances'] ?? {}) as Map<String, dynamic>;
              final name = user['name']?.toString().isNotEmpty == true ? user['name'].toString() : 'User';
              final kyc = user['kycStatus'] ?? user['kyc_status'] ?? 'pending';
              final inr = balances['INR'] ?? 0;
              return RefreshIndicator(
                onRefresh: () async => reload(),
                child: ListView(
                  children: [
                    GradientHeader(
                      title: 'Hello, $name',
                      subtitle: 'INR Wallet Balance • KYC: $kyc',
                      amount: _money(inr, 'INR'),
                      trailing: const _NotificationBell(),
                    ),
                    const SizedBox(height: 16),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      children: items.map((e) => FeatureTile(icon: e.$1, label: e.$2, onTap: () => go(context, e.$3))).toList(),
                    ),
                    FutureBuilder<Map<String, dynamic>>(future: ApiService.rates(), builder: (context, snap) => InfoCard(title: 'Live Backend Rates', subtitle: snap.hasData ? 'USD/INR: ${snap.data!["forex"]["USD_INR"]}, BTC/USD: ${snap.data!["crypto"]["BTC_USD"]}' : 'Loading rates from backend...')),
                    const _WatchlistQuickView(),
                    InkWell(
                      onTap: () => go(context, const ReferralScreen()),
                      borderRadius: BorderRadius.circular(20),
                      child: const InfoCard(title: 'Refer & Earn ₹100', subtitle: 'Apna referral code share karein. Jab aapka refer kiya hua friend pehla transaction karega, aapko ₹100 reward milega. Tap karke apna code dekhein.'),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

/// Small, home-screen widget showing live rates for the currency/crypto
/// pairs the user has pinned in their Watchlist (see WatchlistScreen).
/// Hides itself entirely if the user has no pins yet — avoids cluttering
/// the home screen for users who haven't discovered the feature.
class _WatchlistQuickView extends StatefulWidget {
  const _WatchlistQuickView();
  @override
  State<_WatchlistQuickView> createState() => _WatchlistQuickViewState();
}

class _WatchlistQuickViewState extends State<_WatchlistQuickView> {
  late Future<List<dynamic>> watchlistFuture = ApiService.watchlist();

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
    future: watchlistFuture,
    builder: (context, watchSnap) {
      final pins = (watchSnap.data ?? []).map((w) => (w as Map<String, dynamic>)['pair'].toString()).toList();
      if (pins.isEmpty) return const SizedBox();
      return FutureBuilder<Map<String, dynamic>>(
        future: ApiService.rates(),
        builder: (context, ratesSnap) {
          final flat = <String, dynamic>{
            ...((ratesSnap.data?['forex'] ?? {}) as Map<String, dynamic>),
            ...((ratesSnap.data?['crypto'] ?? {}) as Map<String, dynamic>),
          };
          return InkWell(
            onTap: () => go(context, const WatchlistScreen()),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor(context))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Row(children: [Icon(Icons.star, color: Color(0xFFFFA000), size: 18), SizedBox(width: 6), Text('My Watchlist', style: TextStyle(fontWeight: FontWeight.w900))]),
                const SizedBox(height: 10),
                ...pins.map((p) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text(p.replaceAll('_', '/'), style: TextStyle(color: mutedText(context))),
                    Text(flat[p]?.toString() ?? '...', style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                )),
              ]),
            ),
          );
        },
      );
    },
  );
}

class _NotificationBell extends StatefulWidget {
  const _NotificationBell();
  @override
  State<_NotificationBell> createState() => _NotificationBellState();
}

class _NotificationBellState extends State<_NotificationBell> {
  late Future<Map<String, dynamic>> future = ApiService.notifications(limit: 1);

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
    future: future,
    builder: (context, snap) {
      final unread = (snap.data?['unreadCount'] ?? 0) as int;
      return GestureDetector(
        onTap: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
          if (mounted) setState(() => future = ApiService.notifications(limit: 1));
        },
        child: Stack(clipBehavior: Clip.none, children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.notifications, color: Colors.white, size: 22),
          ),
          if (unread > 0)
            Positioned(
              right: -2,
              top: -2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(10)),
                child: Text(unread > 9 ? '9+' : '$unread', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
              ),
            ),
        ]),
      );
    },
  );
}

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<Map<String, dynamic>> future = ApiService.notifications();

  void reload() => setState(() => future = ApiService.notifications());

  Future<void> markAllRead() async {
    try {
      await ApiService.markAllNotificationsRead();
      reload();
    } catch (_) {}
  }

  String _iconFor(String type) {
    switch (type) {
      case 'payment_success': return '💰';
      case 'payment_failed': return '⚠️';
      case 'kyc_approved': return '✅';
      case 'kyc_rejected': return '❌';
      case 'exchange_completed': return '🔁';
      case 'exchange_cancelled': return '🚫';
      case 'reward_credited': return '🎁';
      default: return '🔔';
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Notifications',
    child: FutureBuilder<Map<String, dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ErrorRetryView(onRetry: reload);
        final items = (snap.data?['notifications'] ?? []) as List<dynamic>;
        final unread = (snap.data?['unreadCount'] ?? 0) as int;
        if (items.isEmpty) {
          return RefreshIndicator(
            onRefresh: () async => reload(),
            child: ListView(children: const [
              SizedBox(height: 120),
              EmptyStateView(icon: Icons.notifications_none, title: 'No Notifications Yet', subtitle: 'Payment, KYC aur exchange updates yahan dikhengi.'),
            ]),
          );
        }
        return Column(children: [
          if (unread > 0)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: SecondaryButton(text: 'Mark All as Read ($unread unread)', onTap: markAllRead),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async => reload(),
              child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, i) {
                final n = items[i] as Map<String, dynamic>;
                final isRead = (n['isRead'] ?? n['is_read'] ?? false) == true;
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isRead ? cardColor(context) : (isDark(context) ? const Color(0xFF1A2A45) : const Color(0xFFEFF5FF)),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderColor(context)),
                  ),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_iconFor(n['type']?.toString() ?? ''), style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(n['title']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                        const SizedBox(height: 4),
                        Text(n['message']?.toString() ?? ''),
                      ]),
                    ),
                    if (!isRead)
                      IconButton(
                        icon: const Icon(Icons.check_circle_outline, size: 20),
                        onPressed: () async {
                          try {
                            await ApiService.markNotificationRead(n['id'].toString());
                            reload();
                          } catch (_) {}
                        },
                      ),
                  ]),
                );
              },
              ),
            ),
          ),
        ]);
      },
    ),
  );
}

class ReferralScreen extends StatefulWidget {
  const ReferralScreen({super.key});
  @override
  State<ReferralScreen> createState() => _ReferralScreenState();
}

class _ReferralScreenState extends State<ReferralScreen> {
  late Future<Map<String, dynamic>> future = ApiService.myReferrals();

  void reload() => setState(() => future = ApiService.myReferrals());

  Future<void> _copyCode(BuildContext context, String code) async {
    await Clipboard.setData(ClipboardData(text: code));
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Referral code copied!')));
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'rewarded':
        return const Color(0xFF00B876);
      case 'pending_first_transaction':
        return const Color(0xFFFFA000);
      default:
        return const Color(0xFF0967FF);
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'rewarded':
        return 'Reward Credited';
      case 'pending_first_transaction':
        return 'Waiting for First Transaction';
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Refer & Earn',
    child: FutureBuilder<Map<String, dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ErrorRetryView(onRetry: reload);
        final data = snap.data ?? {};
        final code = (data['referralCode'] ?? '').toString();
        final totalReferred = (data['totalReferred'] ?? 0).toString();
        final totalRewarded = (data['totalRewarded'] ?? 0).toString();
        final totalEarned = (data['totalEarned'] ?? 0).toString();
        final referrals = (data['referrals'] ?? []) as List<dynamic>;

        return RefreshIndicator(onRefresh: () async => reload(), child: ListView(children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0967FF), Color(0xFF00C48C)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(children: [
              const Text('Your Referral Code', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 8),
              Text(code.isEmpty ? '...' : code, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 32, letterSpacing: 2)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(backgroundColor: Colors.white, padding: const EdgeInsets.all(14)),
                  onPressed: code.isEmpty ? null : () => _copyCode(context, code),
                  child: const Text('Copy Code & Share with Friends', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          const WarningBox(text: 'Jab aapka refer kiya hua friend account banata hai aur apna pehla payment/exchange complete karta hai, aapko turant ₹100 reward mil jata hai aapke Reward Wallet mein.'),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: InfoCard(title: 'Total Referred', subtitle: totalReferred)),
            const SizedBox(width: 10),
            Expanded(child: InfoCard(title: 'Rewarded', subtitle: totalRewarded)),
          ]),
          InfoCard(title: 'Total Earned from Referrals', subtitle: '₹$totalEarned'),
          const SizedBox(height: 10),
          const Text('Referral History', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 10),
          if (referrals.isEmpty) const EmptyStateView(icon: Icons.group_add_outlined, title: 'No Referrals Yet', subtitle: 'Apna code share karke friends ko invite karein.'),
          ...referrals.map((r) {
            final ref = r as Map<String, dynamic>;
            final referredUser = (ref['referredUser'] ?? {}) as Map<String, dynamic>;
            final status = (ref['status'] ?? '').toString();
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor(context))),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(referredUser['name']?.toString() ?? 'User', style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(referredUser['email']?.toString() ?? '', style: TextStyle(color: mutedText(context), fontSize: 12)),
                ])),
                StatusBadge(text: _statusLabel(status), color: _statusColor(status)),
              ]),
            );
          }),
        ])); 
      },
    ),
  );
}

class SendMoneyScreen extends StatefulWidget {
  final String? initialReceiver;
  final String? initialAmount;
  final String? initialCurrency;
  final String? initialNote;
  const SendMoneyScreen({super.key, this.initialReceiver, this.initialAmount, this.initialCurrency, this.initialNote});
  @override
  State<SendMoneyScreen> createState() => _SendMoneyScreenState();
}

class _SendMoneyScreenState extends State<SendMoneyScreen> {
  final receiver = TextEditingController();
  final amount = TextEditingController();
  final currency = TextEditingController(text: 'INR');
  final note = TextEditingController();
  final pin = TextEditingController();
  bool loading = false;

  @override
  void initState() {
    super.initState();
    receiver.text = widget.initialReceiver ?? '';
    if ((widget.initialAmount ?? '').isNotEmpty) amount.text = widget.initialAmount!;
    if ((widget.initialCurrency ?? '').isNotEmpty) currency.text = widget.initialCurrency!;
    if ((widget.initialNote ?? '').isNotEmpty) note.text = widget.initialNote!;
  }

  Future<void> send() async {
    setState(() => loading = true);
    try {
      await ApiService.sendMoney(
        receiver: receiver.text.trim(),
        amount: double.tryParse(amount.text.trim()) ?? 0,
        currency: currency.text.trim().toUpperCase(),
        pin: pin.text.trim(),
        note: note.text.trim(),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Money sent successfully')));
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
          (route) => false,
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Send failed. Check receiver, balance and PIN.')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Send Money', child: ListView(children: [
    const WarningBox(text: 'Receiver ke email, phone ya User ID se money send karein. Payment ke liye Security PIN required hai.'),
    AppInput(label: 'Receiver Email / Phone / User ID', controller: receiver),
    SecondaryButton(text: 'Scan Receiver QR', onTap: () => go(context, const QrScannerScreen())),
    AppInput(label: 'Amount', controller: amount),
    AppInput(label: 'Currency e.g. INR, USD, BTC', controller: currency),
    AppInput(label: 'Note optional', controller: note),
    AppInput(label: 'Security PIN', obscure: true, controller: pin),
    PrimaryButton(text: loading ? 'Sending...' : 'Send Money', onTap: loading ? () {} : send),
    SecondaryButton(text: 'Create / Change Security PIN', onTap: () => go(context, const SecurityPinScreen())),
  ]));
}

class ReceiveMoneyScreen extends StatefulWidget {
  const ReceiveMoneyScreen({super.key});
  @override
  State<ReceiveMoneyScreen> createState() => _ReceiveMoneyScreenState();
}

class _ReceiveMoneyScreenState extends State<ReceiveMoneyScreen> {
  final requestAmount = TextEditingController();
  final requestCurrency = TextEditingController(text: 'INR');
  final requestNote = TextEditingController();
  bool showAmountFields = false;

  Future<void> _copy(BuildContext context, String text, String label) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$label copied')));
  }

  String _buildPayload(String id, String email) {
    final params = <String, String>{'userId': id, 'email': email};
    final amt = requestAmount.text.trim();
    if (amt.isNotEmpty && (double.tryParse(amt) ?? 0) > 0) {
      params['amount'] = amt;
      params['currency'] = requestCurrency.text.trim().isEmpty ? 'INR' : requestCurrency.text.trim().toUpperCase();
      if (requestNote.text.trim().isNotEmpty) params['note'] = requestNote.text.trim();
    }
    final query = params.entries.map((e) => '${e.key}=${Uri.encodeComponent(e.value)}').join('&');
    return 'gxpay://receive?$query';
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Receive Money',
    child: FutureBuilder<Map<String, dynamic>>(
      future: ApiService.me(),
      builder: (context, snap) {
        final user = (snap.data?['user'] ?? {}) as Map<String, dynamic>;
        final email = user['email']?.toString() ?? '';
        final id = user['id']?.toString() ?? '';
        final payload = (email.isEmpty || id.isEmpty) ? '' : _buildPayload(id, email);
        final requestedAmount = requestAmount.text.trim();
        final hasAmount = requestedAmount.isNotEmpty && (double.tryParse(requestedAmount) ?? 0) > 0;
        return ListView(children: [
          InfoCard(title: 'Receive using Email', subtitle: email.isEmpty ? 'Loading...' : email),
          InfoCard(title: 'Your User ID', subtitle: id.isEmpty ? 'Loading...' : id),
          const SizedBox(height: 10),
          SecondaryButton(
            text: showAmountFields ? 'Hide Amount Request' : 'Request a Specific Amount (optional)',
            onTap: () => setState(() => showAmountFields = !showAmountFields),
          ),
          if (showAmountFields) ...[
            AppInput(label: 'Amount to Request', controller: requestAmount, onChanged: (_) => setState(() {})),
            AppInput(label: 'Currency e.g. INR, USD, BTC', controller: requestCurrency, onChanged: (_) => setState(() {})),
            AppInput(label: 'Note optional', controller: requestNote, onChanged: (_) => setState(() {})),
          ],
          Container(
            margin: const EdgeInsets.symmetric(vertical: 16),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(24), border: Border.all(color: borderColor(context))),
            child: Column(children: [
              Text(hasAmount ? 'Payment Request QR' : 'Your Payment QR', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              if (hasAmount) Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('${requestCurrency.text.trim().toUpperCase()} $requestedAmount', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: Color(0xFF0967FF))),
              ),
              const SizedBox(height: 14),
              if (payload.isEmpty)
                const SizedBox(height: 220, child: Center(child: CircularProgressIndicator()))
              else
                QrImageView(data: payload, version: QrVersions.auto, size: 220, backgroundColor: Colors.white),
              const SizedBox(height: 10),
              Text(
                hasAmount
                    ? 'Sender is QR ko scan karega toh amount aur note pehle se bhara hua milega.'
                    : 'Sender is QR ko scan karke payment kar sakta hai.',
                textAlign: TextAlign.center,
              ),
            ]),
          ),
          PrimaryButton(text: 'Copy Email', onTap: () => _copy(context, email, 'Email')),
          SecondaryButton(text: 'Copy User ID', onTap: () => _copy(context, id, 'User ID')),
        ]);
      },
    ),
  );
}

class QrScannerScreen extends StatefulWidget {
  const QrScannerScreen({super.key});
  @override
  State<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen> {
  bool handled = false;
  bool torchOn = false;
  final manual = TextEditingController();
  final GlobalKey qrKey = GlobalKey(debugLabel: 'GX_QR');
  QRViewController? qrController;

  @override
  void dispose() {
    qrController?.dispose();
    manual.dispose();
    super.dispose();
  }

  // Parses a scanned/entered payload. Recognised Global Exchanger QR codes use
  // the `gxpay://receive?userId=...&email=...&amount=...&currency=...&note=...`
  // format. Anything else (manual entry, or a QR from another app) is treated
  // as a plain receiver identifier, same as before.
  Map<String, String> _parseQrPayload(String raw) {
    final trimmed = raw.trim();
    if (trimmed.startsWith('gxpay://')) {
      try {
        final uri = Uri.parse(trimmed);
        final receiver = uri.queryParameters['email']?.isNotEmpty == true
            ? uri.queryParameters['email']!
            : (uri.queryParameters['userId'] ?? '');
        return {
          'receiver': receiver,
          'amount': uri.queryParameters['amount'] ?? '',
          'currency': uri.queryParameters['currency'] ?? '',
          'note': uri.queryParameters['note'] ?? '',
          'valid': receiver.isNotEmpty ? 'true' : 'false',
        };
      } catch (_) {
        return {'receiver': '', 'amount': '', 'currency': '', 'note': '', 'valid': 'false'};
      }
    }
    // Plain text (manual entry or unrelated QR): only accept it if it looks
    // like an email or a reasonable ID, so a random/unrelated QR isn't
    // silently treated as a valid receiver.
    final looksLikeEmail = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(trimmed);
    final looksLikeId = RegExp(r'^[A-Za-z0-9_-]{6,}$').hasMatch(trimmed);
    return {
      'receiver': trimmed,
      'amount': '',
      'currency': '',
      'note': '',
      'valid': (trimmed.isNotEmpty && (looksLikeEmail || looksLikeId)) ? 'true' : 'false',
    };
  }

  void _handle(String raw) {
    if (handled) return;
    final parsed = _parseQrPayload(raw);
    if (parsed['valid'] != 'true') {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yeh ek valid Global Exchanger payment QR nahi hai. Dusra QR try karein ya receiver manually enter karein.')));
      return;
    }
    handled = true;
    qrController?.pauseCamera();
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => SendMoneyScreen(
      initialReceiver: parsed['receiver'],
      initialAmount: parsed['amount'],
      initialCurrency: parsed['currency'],
      initialNote: parsed['note'],
    )));
  }

  Future<void> _toggleTorch() async {
    try {
      if (qrController != null) {
        await qrController!.toggleFlash();
        final status = await qrController!.getFlashStatus();
        if (mounted) setState(() => torchOn = status ?? !torchOn);
      } else {
        if (torchOn) {
          await TorchLight.disableTorch();
        } else {
          await TorchLight.enableTorch();
        }
        if (mounted) setState(() => torchOn = !torchOn);
      }
    } catch (_) {
      try {
        if (torchOn) {
          await TorchLight.disableTorch();
        } else {
          await TorchLight.enableTorch();
        }
        if (mounted) setState(() => torchOn = !torchOn);
      } catch (_) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Torch control failed. Phone quick settings se torch ON karke try karein.')));
      }
    }
  }

  void _onQRViewCreated(QRViewController controller) {
    qrController = controller;
    controller.scannedDataStream.listen((scanData) {
      final code = scanData.code;
      if (code != null && code.trim().isNotEmpty) _handle(code);
    });
  }

  Future<void> _pickQrFromGallery() async {
    mlkit.BarcodeScanner? scanner;
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 100);
      if (image == null) return;

      final inputImage = mlkit.InputImage.fromFilePath(image.path);
      scanner = mlkit.BarcodeScanner();
      final barcodes = await scanner.processImage(inputImage);
      for (final b in barcodes) {
        final raw = b.rawValue;
        if (raw != null && raw.trim().isNotEmpty) {
          _handle(raw);
          return;
        }
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('QR image read nahi hua. Clear QR screenshot choose karein ya receiver email manually enter karein.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gallery QR failed: ${e.toString()}')));
    } finally {
      await scanner?.close();
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Scan QR',
    child: Column(children: [
      const WarningBox(text: 'Receiver ka QR code camera ke saamne rakhein. Night/dark me Torch ON karein ya Gallery se QR screenshot choose karein.'),
      Row(children: [
        Expanded(child: PrimaryButton(text: torchOn ? 'Torch OFF' : 'Torch ON', color: torchOn ? const Color(0xFFFFA000) : const Color(0xFF111827), onTap: _toggleTorch)),
        const SizedBox(width: 10),
        Expanded(child: PrimaryButton(text: 'Gallery QR', color: const Color(0xFF00B876), onTap: _pickQrFromGallery)),
      ]),
      const SizedBox(height: 12),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: QRView(
            key: qrKey,
            onQRViewCreated: _onQRViewCreated,
            overlay: QrScannerOverlayShape(
              borderColor: const Color(0xFF00B876),
              borderRadius: 16,
              borderLength: 32,
              borderWidth: 8,
              cutOutSize: 240,
            ),
          ),
        ),
      ),
      const SizedBox(height: 12),
      AppInput(label: 'Receiver Email / User ID manually', controller: manual),
      PrimaryButton(text: 'Continue With Manual Receiver', onTap: () => _handle(manual.text)),
      SecondaryButton(text: 'Back', onTap: () => Navigator.pop(context)),
    ]),
  );
}

class ConvertScreen extends StatefulWidget {
  const ConvertScreen({super.key});
  @override
  State<ConvertScreen> createState() => _ConvertScreenState();
}

class _ConvertScreenState extends State<ConvertScreen> {
  final mode = TextEditingController(text: 'convert');
  final from = TextEditingController(text: 'INR');
  final to = TextEditingController(text: 'USD');
  final amount = TextEditingController(text: '1000');
  bool loading = false;
  String? lastOrderId;

  Future<void> createOrder() async {
    setState(() => loading = true);
    try {
      final result = await ApiService.createExchangeOrder({'mode': mode.text, 'fromCurrency': from.text, 'toCurrency': to.text, 'amount': double.tryParse(amount.text) ?? 0});
      lastOrderId = result['order']['id'];
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order created: ${result['order']['id']}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> lockEscrow() async {
    if (lastOrderId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Create order first')));
      return;
    }
    try {
      await ApiService.lockExchangeEscrow(lastOrderId!);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Escrow locked successfully')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Convert Currency', child: ListView(children: [
    AppInput(label: 'Option: convert / sell', controller: mode), AppInput(label: 'From: INR', controller: from), AppInput(label: 'To: USD / BTC', controller: to), AppInput(label: 'Amount', controller: amount),
    FutureBuilder<Map<String, dynamic>>(future: ApiService.rates(), builder: (context, snap) => InfoCard(title: 'Live Rate From Backend', subtitle: snap.hasData ? 'USD/INR: ${snap.data!["forex"]["USD_INR"]}' : 'Loading...')),
    const WarningBox(text: 'Exchange escrow/security hold ke through complete hoga. Admin commission 1%.'),
    PrimaryButton(text: loading ? 'Creating...' : 'Create Exchange Order', color: const Color(0xFF00B876), onTap: loading ? () {} : createOrder),
    SecondaryButton(text: 'Lock Escrow for Last Order', onTap: lockEscrow),
    SecondaryButton(text: 'My Exchange Order History', onTap: () => go(context, const ExchangeHistoryScreen())),
  ]));
}

class ExchangeHistoryScreen extends StatefulWidget {
  const ExchangeHistoryScreen({super.key});
  @override
  State<ExchangeHistoryScreen> createState() => _ExchangeHistoryScreenState();
}

class _ExchangeHistoryScreenState extends State<ExchangeHistoryScreen> {
  late Future<List<dynamic>> future = ApiService.myExchangeOrders();

  void reload() => setState(() => future = ApiService.myExchangeOrders());

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return const Color(0xFF00B876);
      case 'pending_match':
      case 'escrow_locked':
        return const Color(0xFFFFA000);
      case 'cancelled':
        return const Color(0xFFE53935);
      default:
        return const Color(0xFF0967FF);
    }
  }

  Future<void> _openReceipt(BuildContext context, String orderId) async {
    try {
      final url = await ApiService.requestReceiptUrl(exchangeOrderId: orderId);
      final opened = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Receipt link nahi khul paya.')));
      }
    } catch (_) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Receipt generate nahi ho paya.')));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Exchange Order History',
    child: FutureBuilder<List<dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ErrorRetryView(onRetry: reload);
        final rows = snap.data ?? [];
        if (rows.isEmpty) {
          return RefreshIndicator(
            onRefresh: () async => reload(),
            child: ListView(children: const [
              SizedBox(height: 120),
              EmptyStateView(icon: Icons.swap_horiz, title: 'No Exchange Orders Yet', subtitle: 'Currency convert karke apna pehla exchange order banayein.'),
            ]),
          );
        }
        return RefreshIndicator(
          onRefresh: () async => reload(),
          child: ListView.builder(
          itemCount: rows.length,
          itemBuilder: (context, i) {
            final o = rows[i] as Map<String, dynamic>;
            final fromC = (o['fromCurrency'] ?? o['from_currency'] ?? '').toString();
            final toC = (o['toCurrency'] ?? o['to_currency'] ?? '').toString();
            final amount = (o['amount'] ?? '0').toString();
            final status = (o['status'] ?? '').toString();
            final id = (o['id'] ?? '').toString();
            final sellerCommission = (o['sellerCommission'] ?? o['seller_commission'] ?? '0').toString();
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor(context))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('$fromC → $toC', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  StatusBadge(text: status.isEmpty ? 'status' : status, color: _statusColor(status)),
                ]),
                const SizedBox(height: 6),
                Text('Amount: $fromC $amount', style: TextStyle(color: mutedText(context))),
                Text('Your Reward: $fromC $sellerCommission', style: TextStyle(color: mutedText(context), fontSize: 12)),
                const SizedBox(height: 10),
                SecondaryButton(text: 'View / Download Receipt', onTap: () => _openReceipt(context, id)),
              ]),
            );
          },
          ),
        );
      },
    ),
  );
}

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool loading = false;
  late Future<Map<String, dynamic>> walletFuture = ApiService.me();
  final RazorpayCheckoutService razorpay = RazorpayCheckoutService();
  Map<String, dynamic>? pendingOrder;
  Map<String, dynamic>? pendingGatewayOrder;

  void refreshWallet() => setState(() => walletFuture = ApiService.me());

  String _money(dynamic value, String currency) {
    final n = value is num ? value : num.tryParse('${value ?? 0}') ?? 0;
    if (currency == 'BTC' || currency == 'ETH' || currency == 'XRP') return '$n $currency';
    final symbol = currency == 'INR' ? '₹' : currency == 'USD' ? r'$' : currency == 'EUR' ? '€' : '$currency ';
    return '$symbol${n.toStringAsFixed(2)}';
  }

  @override
  void initState() {
    super.initState();
    razorpay.onSuccess = handleRazorpaySuccess;
    razorpay.onFailure = (PaymentFailureResponse response) {
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(response.message ?? 'Payment failed')));
    };
    razorpay.onExternalWallet = (ExternalWalletResponse response) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('External wallet: ${response.walletName}')));
    };
  }

  @override
  void dispose() {
    razorpay.dispose();
    super.dispose();
  }

  Future<void> handleRazorpaySuccess(PaymentSuccessResponse response) async {
    try {
      final order = pendingOrder!;
      final gatewayOrder = pendingGatewayOrder!;
      await ApiService.verifyPayment(
        orderId: order['id'],
        gatewayOrderId: response.orderId ?? gatewayOrder['gatewayOrderId'],
        gatewayPaymentId: response.paymentId ?? '',
        gatewaySignature: response.signature,
      );
      refreshWallet();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment verified and wallet topped up.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment verification failed')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> addMoney() async {
    setState(() => loading = true);
    try {
      final created = await ApiService.createPaymentOrder(amount: 500, currency: 'INR', purpose: 'wallet_topup');
      pendingOrder = created['order'];
      pendingGatewayOrder = created['gatewayOrder'];
      final gatewayOrder = pendingGatewayOrder!;

      if (gatewayOrder['provider'] == 'razorpay' && gatewayOrder['publicKey'] != null) {
        razorpay.openCheckout(
          key: gatewayOrder['publicKey'],
          orderId: gatewayOrder['gatewayOrderId'],
          amount: 500,
          currency: 'INR',
          name: 'Global Exchanger',
          description: 'Wallet Top-up',
        );
      } else {
        await ApiService.verifyPayment(orderId: pendingOrder!['id'], gatewayOrderId: gatewayOrder['gatewayOrderId'], gatewayPaymentId: 'mock_payment_${DateTime.now().millisecondsSinceEpoch}');
        refreshWallet();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('₹500 wallet top-up completed.')));
        if (mounted) setState(() => loading = false);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add money failed')));
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> redeemRewards(String currency) async {
    setState(() => loading = true);
    try {
      final result = await ApiService.redeemRewards(currency: currency);
      refreshWallet();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Redeemed ${_money(result['redeemed'], currency)} into your main wallet.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No reward balance to redeem for this currency.')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Multi Currency Wallet',
    child: FutureBuilder<Map<String, dynamic>>(
      future: walletFuture,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ErrorRetryView(onRetry: refreshWallet, message: 'Wallet load nahi ho paya. Internet connection check karein.');
        final wallet = (snap.data?['wallet'] ?? {}) as Map<String, dynamic>;
        final balances = (wallet['balances'] ?? {}) as Map<String, dynamic>;
        final rewardBalances = (wallet['rewardBalances'] ?? {}) as Map<String, dynamic>;
        final currencies = ['INR', 'USD', 'EUR', 'BTC', 'ETH', 'XRP'];
        final hasAnyReward = currencies.any((c) => (rewardBalances[c] ?? 0) > 0);
        return RefreshIndicator(onRefresh: () async => refreshWallet(), child: ListView(children: [
          ...currencies.map((c) => InfoCard(title: c, subtitle: _money(balances[c] ?? 0, c))),
          PrimaryButton(text: loading ? 'Processing...' : 'Add Money ₹500 using Mock Gateway', onTap: loading ? () {} : addMoney),
          SecondaryButton(text: 'Refresh Wallet', onTap: refreshWallet),
          SecondaryButton(text: 'Manage Bank Accounts', onTap: () => go(context, const BankAccountsScreen())),
          SecondaryButton(text: 'Withdraw to Bank', onTap: () => go(context, const WithdrawScreen())),
          const SizedBox(height: 16),
          const InfoCard(title: 'Reward Wallet', subtitle: 'Har convert/exchange par 0.2% reward yahan turant credit hota hai.'),
          ...currencies.where((c) => (rewardBalances[c] ?? 0) > 0).map((c) => InfoCard(title: '$c Reward', subtitle: _money(rewardBalances[c] ?? 0, c))),
          if (!hasAnyReward) const InfoCard(title: 'No Rewards Yet', subtitle: 'Ek exchange/convert karke apna pehla 0.2% reward kamaein.'),
          if (hasAnyReward)
            ...currencies.where((c) => (rewardBalances[c] ?? 0) > 0).map(
              (c) => PrimaryButton(text: loading ? 'Processing...' : 'Redeem $c Reward to Main Wallet', onTap: loading ? () {} : () => redeemRewards(c)),
            ),
        ]));
      },
    ),
  );
}

class BankAccountsScreen extends StatefulWidget {
  const BankAccountsScreen({super.key});
  @override
  State<BankAccountsScreen> createState() => _BankAccountsScreenState();
}

class _BankAccountsScreenState extends State<BankAccountsScreen> {
  final holderName = TextEditingController();
  final bankName = TextEditingController();
  final accountNumber = TextEditingController();
  final ifscSwiftIban = TextEditingController();
  final country = TextEditingController(text: 'India');
  bool showForm = false;
  bool loading = false;
  late Future<List<dynamic>> future = ApiService.myBankAccounts();

  void reload() => setState(() => future = ApiService.myBankAccounts());

  Future<void> addAccount() async {
    if (holderName.text.trim().isEmpty || bankName.text.trim().isEmpty || accountNumber.text.trim().isEmpty || ifscSwiftIban.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sab fields bharna zaroori hai.')));
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.addBank({
        'holderName': holderName.text.trim(),
        'bankName': bankName.text.trim(),
        'accountNumber': accountNumber.text.trim(),
        'ifscSwiftIban': ifscSwiftIban.text.trim(),
        'country': country.text.trim(),
      });
      holderName.clear();
      bankName.clear();
      accountNumber.clear();
      ifscSwiftIban.clear();
      if (mounted) {
        setState(() => showForm = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bank account add ho gaya. Verification ke baad withdraw kar sakenge.')));
        reload();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> deleteAccount(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove Bank Account?'),
        content: const Text('Kya aap is bank account ko remove karna chahte hain?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Remove')),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await ApiService.deleteBankAccount(id);
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Bank Accounts',
    child: RefreshIndicator(onRefresh: () async => reload(), child: ListView(children: [
      SecondaryButton(text: showForm ? 'Cancel' : 'Add New Bank Account', onTap: () => setState(() => showForm = !showForm)),
      if (showForm) ...[
        const SizedBox(height: 10),
        AppInput(label: 'Account Holder Name', controller: holderName),
        AppInput(label: 'Bank Name', controller: bankName),
        AppInput(label: 'Account Number', controller: accountNumber, keyboardType: TextInputType.number),
        AppInput(label: 'IFSC / SWIFT / IBAN', controller: ifscSwiftIban),
        AppInput(label: 'Country', controller: country),
        PrimaryButton(text: loading ? 'Saving...' : 'Save Bank Account', color: const Color(0xFF00B876), onTap: loading ? () {} : addAccount),
      ],
      const SizedBox(height: 16),
      const Text('My Bank Accounts', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      const SizedBox(height: 10),
      FutureBuilder<List<dynamic>>(
        future: future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snap.hasError) return ErrorRetryView(onRetry: reload);
          final rows = snap.data ?? [];
          if (rows.isEmpty) return const EmptyStateView(icon: Icons.account_balance_outlined, title: 'No Bank Accounts', subtitle: 'Withdraw karne ke liye pehle ek bank account add karein.');
          return Column(children: rows.map((a) {
            final account = a as Map<String, dynamic>;
            final isVerified = (account['verifiedAt'] ?? account['verified_at']) != null;
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor(context))),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(account['bankName']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text('${account['holderName'] ?? ''} • ${account['accountNumberMasked'] ?? account['account_number_masked'] ?? ''}', style: TextStyle(color: mutedText(context), fontSize: 12)),
                  const SizedBox(height: 6),
                  StatusBadge(text: isVerified ? 'Verified' : 'Pending Verification', color: isVerified ? const Color(0xFF00B876) : const Color(0xFFFFA000)),
                ])),
                IconButton(icon: const Icon(Icons.delete_outline, color: Color(0xFFE53935)), onPressed: () => deleteAccount(account['id'].toString())),
              ]),
            );
          }).toList());
        },
      ),
    ])),
  );
}

class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({super.key});
  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  String? selectedBankAccountId;
  final amount = TextEditingController();
  final currency = TextEditingController(text: 'INR');
  bool loading = false;
  late Future<List<dynamic>> bankAccountsFuture = ApiService.myBankAccounts();
  late Future<List<dynamic>> withdrawalsFuture = ApiService.myWithdrawals();

  void reloadWithdrawals() => setState(() => withdrawalsFuture = ApiService.myWithdrawals());

  Color _statusColor(String status) {
    switch (status) {
      case 'completed':
        return const Color(0xFF00B876);
      case 'rejected':
      case 'cancelled':
        return const Color(0xFFE53935);
      case 'approved':
      case 'processing':
        return const Color(0xFF0967FF);
      default:
        return const Color(0xFFFFA000);
    }
  }

  Future<void> submitWithdrawal() async {
    if (selectedBankAccountId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bank account select karein.')));
      return;
    }
    final amountValue = double.tryParse(amount.text.trim()) ?? 0;
    if (amountValue <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Valid amount daalein.')));
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.requestWithdrawal(bankAccountId: selectedBankAccountId!, amount: amountValue, currency: currency.text.trim().toUpperCase());
      amount.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Withdrawal request submit ho gayi. Admin approval ke baad process hogi.')));
        reloadWithdrawals();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> cancelWithdrawal(String id) async {
    try {
      await ApiService.cancelWithdrawal(id);
      reloadWithdrawals();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Withdraw to Bank',
    child: RefreshIndicator(onRefresh: () async => reloadWithdrawals(), child: ListView(children: [
      const WarningBox(text: 'Withdraw karne ke liye KYC approved hona zaroori hai aur bank account verified hona chahiye. Amount request karte hi wallet se lock ho jata hai.'),
      FutureBuilder<List<dynamic>>(
        future: bankAccountsFuture,
        builder: (context, snap) {
          final accounts = (snap.data ?? []).where((a) => (a as Map<String, dynamic>)['verifiedAt'] != null || (a)['verified_at'] != null).toList();
          if (snap.connectionState != ConnectionState.waiting && accounts.isEmpty) {
            return Column(children: [
              const InfoCard(title: 'No Verified Bank Account', subtitle: 'Withdraw karne ke liye pehle ek verified bank account chahiye.'),
              SecondaryButton(text: 'Manage Bank Accounts', onTap: () => go(context, const BankAccountsScreen())),
              const SizedBox(height: 16),
            ]);
          }
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: DropdownButtonFormField<String>(
              value: selectedBankAccountId,
              decoration: InputDecoration(labelText: 'Select Verified Bank Account', filled: true, fillColor: cardColor(context), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
              items: accounts.map((a) {
                final acc = a as Map<String, dynamic>;
                final id = acc['id'].toString();
                final label = '${acc['bankName']} - ${acc['accountNumberMasked'] ?? acc['account_number_masked'] ?? ''}';
                return DropdownMenuItem<String>(value: id, child: Text(label, overflow: TextOverflow.ellipsis));
              }).toList(),
              onChanged: (value) => setState(() => selectedBankAccountId = value),
            ),
          );
        },
      ),
      AppInput(label: 'Amount', controller: amount, keyboardType: TextInputType.number),
      AppInput(label: 'Currency (e.g. INR, USD)', controller: currency),
      PrimaryButton(text: loading ? 'Submitting...' : 'Request Withdrawal', color: const Color(0xFF111827), onTap: loading ? () {} : submitWithdrawal),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('My Withdrawals', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        IconButton(icon: const Icon(Icons.refresh), onPressed: reloadWithdrawals),
      ]),
      FutureBuilder<List<dynamic>>(
        future: withdrawalsFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
          if (snap.hasError) return ErrorRetryView(onRetry: reloadWithdrawals);
          final rows = snap.data ?? [];
          if (rows.isEmpty) return const EmptyStateView(icon: Icons.account_balance_wallet_outlined, title: 'No Withdrawals Yet', subtitle: 'Aapne abhi tak koi withdrawal request nahi ki hai.');
          return Column(children: rows.map((w) {
            final withdrawal = w as Map<String, dynamic>;
            final status = (withdrawal['status'] ?? 'pending').toString();
            final currencyVal = (withdrawal['currency'] ?? '').toString();
            final amountVal = (withdrawal['amount'] ?? '0').toString();
            final id = (withdrawal['id'] ?? '').toString();
            final adminNote = (withdrawal['adminNote'] ?? withdrawal['admin_note'] ?? '').toString();
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor(context))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('$currencyVal $amountVal', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  StatusBadge(text: status, color: _statusColor(status)),
                ]),
                if (adminNote.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text('Note: $adminNote', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: mutedText(context))),
                ],
                const SizedBox(height: 6),
                Text((withdrawal['createdAt'] ?? withdrawal['created_at'] ?? '').toString(), style: TextStyle(color: faintText(context), fontSize: 11)),
                if (status == 'pending') ...[
                  const SizedBox(height: 8),
                  SecondaryButton(text: 'Cancel Request', onTap: () => cancelWithdrawal(id)),
                ],
              ]),
            );
          }).toList());
        },
      ),
    ])),
  );
}

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final searchController = TextEditingController();
  String? typeFilter;
  String? statusFilter;
  late Future<Map<String, dynamic>> future = _load();

  Future<Map<String, dynamic>> _load() async {
    final me = await ApiService.me();
    final txns = await ApiService.transactions(
      type: typeFilter,
      status: statusFilter,
      search: searchController.text.trim(),
    );
    return {'me': me, 'transactions': txns};
  }

  void _applyFilters() => setState(() => future = _load());

  String _direction(Map<String, dynamic> t, String myId) {
    final from = (t['fromUserId'] ?? t['from_user_id'] ?? '').toString();
    final to = (t['toUserId'] ?? t['to_user_id'] ?? '').toString();
    final type = (t['type'] ?? '').toString();
    if (type == 'wallet_topup') return 'Top-up';
    if (type == 'refund') return 'Refund';
    if (from == myId) return 'Sent';
    if (to == myId) return 'Received';
    return type.isEmpty ? 'Transaction' : type;
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return const Color(0xFF00B876);
      case 'pending':
      case 'under_review':
        return const Color(0xFFFFA000);
      case 'failed':
      case 'cancelled':
      case 'rejected':
        return const Color(0xFFE53935);
      default:
        return const Color(0xFF0967FF);
    }
  }

  Widget _filterChip(String label, String? value, String? current, ValueChanged<String?> onSelect) {
    final selected = current == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) {
          onSelect(selected ? null : value);
          _applyFilters();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Payment History',
    child: Column(children: [
      TextField(
        controller: searchController,
        decoration: InputDecoration(
          hintText: 'Search by Transaction ID or Currency',
          filled: true,
          fillColor: cardColor(context),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _applyFilters),
        ),
        onSubmitted: (_) => _applyFilters(),
      ),
      const SizedBox(height: 10),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          _filterChip('Sent', 'send', typeFilter, (v) => typeFilter = v),
          _filterChip('Top-up', 'wallet_topup', typeFilter, (v) => typeFilter = v),
          _filterChip('Exchange', 'exchange_complete', typeFilter, (v) => typeFilter = v),
          _filterChip('Refund', 'refund', typeFilter, (v) => typeFilter = v),
          const SizedBox(width: 8),
          _filterChip('Completed', 'completed', statusFilter, (v) => statusFilter = v),
          _filterChip('Pending', 'pending', statusFilter, (v) => statusFilter = v),
          _filterChip('Failed', 'failed', statusFilter, (v) => statusFilter = v),
        ]),
      ),
      const SizedBox(height: 12),
      Expanded(
        child: FutureBuilder<Map<String, dynamic>>(
          future: future,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
            if (snap.hasError) return ErrorRetryView(onRetry: _applyFilters);
            final me = (snap.data?['me']?['user'] ?? {}) as Map<String, dynamic>;
            final myId = (me['id'] ?? '').toString();
            final rows = (snap.data?['transactions'] ?? []) as List<dynamic>;
            if (rows.isEmpty) {
              return RefreshIndicator(
                onRefresh: () async => _applyFilters(),
                child: ListView(children: const [
                  SizedBox(height: 120),
                  EmptyStateView(icon: Icons.receipt_long, title: 'No Transactions Found', subtitle: 'Filters badal kar dekhein ya koi transaction karein.'),
                ]),
              );
            }
            return RefreshIndicator(
              onRefresh: () async => _applyFilters(),
              child: ListView.builder(
              itemCount: rows.length,
              itemBuilder: (context, i) {
                final t = rows[i] as Map<String, dynamic>;
                final direction = _direction(t, myId);
                final amount = t['amount']?.toString() ?? '0';
                final currency = t['currency']?.toString() ?? '';
                final status = t['status']?.toString() ?? '';
                final id = t['id']?.toString() ?? '';
                final date = (t['createdAt'] ?? t['created_at'] ?? '').toString();
                return InkWell(
                  onTap: () => go(context, TransactionDetailScreen(transaction: t, myUserId: myId)),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor(context))),
                    child: Row(children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(color: _statusColor(status).withOpacity(.12), borderRadius: BorderRadius.circular(16)),
                        child: Icon(direction == 'Sent' ? Icons.arrow_upward : direction == 'Received' ? Icons.arrow_downward : Icons.account_balance_wallet, color: _statusColor(status)),
                      ),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(direction, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                        const SizedBox(height: 4),
                        Text(date.isEmpty ? 'No date' : date, style: TextStyle(color: mutedText(context), fontSize: 12)),
                        const SizedBox(height: 4),
                        Text('ID: ${id.length > 12 ? id.substring(0, 12) : id}', style: TextStyle(color: subtleText(context), fontSize: 11)),
                      ])),
                      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                        Text('$currency $amount', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                        const SizedBox(height: 6),
                        StatusBadge(text: status.isEmpty ? 'status' : status, color: _statusColor(status)),
                      ]),
                    ]),
                  ),
                );
              },
              ),
            );
          },
        ),
      ),
    ]),
  );
}

class TransactionDetailScreen extends StatelessWidget {
  final Map<String, dynamic> transaction;
  final String myUserId;
  const TransactionDetailScreen({super.key, required this.transaction, required this.myUserId});

  String get _id => (transaction['id'] ?? '').toString();
  String get _from => (transaction['fromUserId'] ?? transaction['from_user_id'] ?? '').toString();
  String get _to => (transaction['toUserId'] ?? transaction['to_user_id'] ?? '').toString();
  String get _type => (transaction['type'] ?? 'transaction').toString();
  String get _status => (transaction['status'] ?? '').toString();
  String get _currency => (transaction['currency'] ?? '').toString();
  String get _amount => (transaction['amount'] ?? '0').toString();
  String get _date => (transaction['createdAt'] ?? transaction['created_at'] ?? '').toString();

  String _direction() {
    if (_type == 'wallet_topup') return 'Wallet Top-up';
    if (_type == 'refund') return 'Refund';
    if (_from == myUserId) return 'Money Sent';
    if (_to == myUserId) return 'Money Received';
    return _type;
  }

  Color _statusColor() {
    switch (_status.toLowerCase()) {
      case 'completed':
        return const Color(0xFF00B876);
      case 'pending':
      case 'under_review':
        return const Color(0xFFFFA000);
      case 'failed':
      case 'cancelled':
      case 'rejected':
        return const Color(0xFFE53935);
      default:
        return const Color(0xFF0967FF);
    }
  }

  Future<void> _copy(BuildContext context, String text, String label) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$label copied')));
  }

  Future<void> _openReceipt(BuildContext context) async {
    try {
      final url = await ApiService.requestReceiptUrl(transactionId: _id);
      final uri = Uri.parse(url);
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Receipt link nahi khul paya. Browser install hai check karein.')));
      }
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Receipt generate nahi ho paya. Dobara try karein.')));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Transaction Receipt',
    child: ListView(children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: cardColor(context),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: borderColor(context)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(color: _statusColor().withOpacity(.12), borderRadius: BorderRadius.circular(24)),
            child: Icon(Icons.receipt_long, color: _statusColor(), size: 36),
          ),
          const SizedBox(height: 16),
          Text(_direction(), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Text('$_currency $_amount', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          StatusBadge(text: _status.isEmpty ? 'status' : _status, color: _statusColor()),
        ]),
      ),
      const SizedBox(height: 16),
      InfoCard(title: 'Date & Time', subtitle: _date.isEmpty ? 'N/A' : _date),
      InfoCard(title: 'Transaction ID', subtitle: _id.isEmpty ? 'N/A' : _id),
      SecondaryButton(text: 'Copy Transaction ID', onTap: () => _copy(context, _id, 'Transaction ID')),
      InfoCard(title: 'From User ID', subtitle: _from.isEmpty ? 'System / Gateway' : _from),
      InfoCard(title: 'To User ID', subtitle: _to.isEmpty ? 'System / Gateway' : _to),
      InfoCard(title: 'Type', subtitle: _type),
      PrimaryButton(text: 'View / Download Receipt', color: const Color(0xFF00B876), onTap: () => _openReceipt(context)),
      InfoCard(title: 'Security Note', subtitle: 'Agar transaction galat person ko gaya hai to 2 days ke andar complaint/dispute raise karein.'),
      PrimaryButton(text: 'Raise Complaint / Dispute', color: const Color(0xFFE53935), onTap: () => go(context, const SupportScreen())),
    ]),
  );
}

// ---------------------------------------------------------------------------
// In-App Support Chat — real back-and-forth messages within a single
// complaint ("case"). Polling-based (no websockets) to keep the Render
// free-tier deployment simple: refreshes every few seconds while the
// screen is open, plus pull-to-refresh.
// ---------------------------------------------------------------------------
class ComplaintChatScreen extends StatefulWidget {
  final String complaintId;
  final String subject;
  const ComplaintChatScreen({super.key, required this.complaintId, required this.subject});
  @override
  State<ComplaintChatScreen> createState() => _ComplaintChatScreenState();
}

class _ComplaintChatScreenState extends State<ComplaintChatScreen> {
  final messageController = TextEditingController();
  final scrollController = ScrollController();
  late Future<Map<String, dynamic>> future = ApiService.complaintMessages(widget.complaintId);
  bool sending = false;
  Timer? pollTimer;

  @override
  void initState() {
    super.initState();
    pollTimer = Timer.periodic(const Duration(seconds: 8), (_) => _silentRefresh());
  }

  @override
  void dispose() {
    pollTimer?.cancel();
    messageController.dispose();
    scrollController.dispose();
    super.dispose();
  }

  void _silentRefresh() {
    if (!mounted) return;
    ApiService.complaintMessages(widget.complaintId).then((data) {
      if (mounted) setState(() => future = Future.value(data));
    }).catchError((_) {});
  }

  void reload() => setState(() => future = ApiService.complaintMessages(widget.complaintId));

  Future<void> send() async {
    final text = messageController.text.trim();
    if (text.isEmpty) return;
    setState(() => sending = true);
    try {
      await ApiService.sendComplaintMessage(widget.complaintId, text);
      messageController.clear();
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.subject, overflow: TextOverflow.ellipsis)),
    body: Column(children: [
      Expanded(
        child: FutureBuilder<Map<String, dynamic>>(
          future: future,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
            if (snap.hasError) return ErrorRetryView(onRetry: reload);
            final messages = (snap.data?['messages'] ?? []) as List<dynamic>;
            if (messages.isEmpty) {
              return const EmptyStateView(icon: Icons.chat_bubble_outline, title: 'No Messages Yet', subtitle: 'Neeche se pehla message bhejein — support team jald reply karegi.');
            }
            return RefreshIndicator(
              onRefresh: () async => reload(),
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: messages.length,
                itemBuilder: (context, i) {
                  final msg = messages[i] as Map<String, dynamic>;
                  final isUser = (msg['senderType'] ?? msg['sender_type'] ?? 'user') == 'user';
                  final text = (msg['message'] ?? '').toString();
                  final senderName = (msg['senderName'] ?? msg['sender_name'] ?? (isUser ? 'You' : 'Support')).toString();
                  return Align(
                    alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                      decoration: BoxDecoration(
                        color: isUser ? const Color(0xFF0967FF) : cardColor(context),
                        borderRadius: BorderRadius.circular(16),
                        border: isUser ? null : Border.all(color: borderColor(context)),
                      ),
                      child: Column(crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
                        if (!isUser) Text(senderName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11, color: Color(0xFF0967FF))),
                        Text(text, style: TextStyle(color: isUser ? Colors.white : (isDark(context) ? Colors.white : Colors.black87))),
                      ]),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
      SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: messageController,
                decoration: InputDecoration(hintText: 'Apna message likhein...', filled: true, fillColor: cardColor(context), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24))),
                onSubmitted: (_) => sending ? null : send(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(icon: const Icon(Icons.send), onPressed: sending ? null : send),
          ]),
        ),
      ),
    ]),
  );
}

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});
  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> with SingleTickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'resolved':
        return const Color(0xFF00B876);
      case 'rejected':
        return const Color(0xFFE53935);
      case 'under_review':
        return const Color(0xFFFFA000);
      default:
        return const Color(0xFF0967FF);
    }
  }

  bool openingChat = false;

  // Opens (or reuses) the user's direct "General Support Chat" thread
  // instantly — no subject/details form needed first, unlike a normal
  // complaint. This is the fast path for "I just want to talk to someone".
  Future<void> _openDirectChat() async {
    if (openingChat) return;
    setState(() => openingChat = true);
    try {
      final data = await ApiService.openSupportChat();
      final complaint = data['complaint'] as Map<String, dynamic>;
      if (mounted) {
        await Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => ComplaintChatScreen(complaintId: (complaint['id'] ?? '').toString(), subject: 'Chat with Support'),
        ));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => openingChat = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Help & Support'),
      bottom: TabBar(controller: tabController, tabs: const [Tab(text: 'Complaints'), Tab(text: 'Disputes')]),
    ),
    body: TabBarView(controller: tabController, children: [
      _ComplaintsTab(statusColor: _statusColor),
      _DisputesTab(statusColor: _statusColor),
    ]),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: openingChat ? null : _openDirectChat,
      icon: openingChat ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.chat_bubble),
      label: Text(openingChat ? 'Opening...' : 'Chat with Support'),
      backgroundColor: const Color(0xFF0967FF),
    ),
  );
}

class _ComplaintsTab extends StatefulWidget {
  final Color Function(String) statusColor;
  const _ComplaintsTab({required this.statusColor});
  @override
  State<_ComplaintsTab> createState() => _ComplaintsTabState();
}

class _ComplaintsTabState extends State<_ComplaintsTab> {
  final subject = TextEditingController();
  final message = TextEditingController();
  bool loading = false;
  late Future<List<dynamic>> future = ApiService.myComplaints();

  void reload() => setState(() => future = ApiService.myComplaints());

  Future<void> sendComplaint() async {
    if (subject.text.trim().isEmpty || message.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Subject aur details dono zaroori hain.')));
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.complaint(subject.text.trim(), message.text.trim());
      subject.clear();
      message.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Complaint submit ho gayi. Status neeche track kar sakte hain.')));
        reload();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(onRefresh: () async => reload(), child: ListView(padding: const EdgeInsets.all(16), children: [
    const InfoCard(title: 'Submit a Complaint', subtitle: 'App/service se related koi bhi issue yahan submit karein.'),
    AppInput(label: 'Subject', controller: subject),
    AppInput(label: 'Complaint Details', controller: message),
    PrimaryButton(text: loading ? 'Sending...' : 'Submit Complaint', color: const Color(0xFF00B876), onTap: loading ? () {} : sendComplaint),
    const SizedBox(height: 20),
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      const Text('My Complaints', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      IconButton(icon: const Icon(Icons.refresh), onPressed: reload),
    ]),
    FutureBuilder<List<dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
        if (snap.hasError) return ErrorRetryView(onRetry: reload);
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const EmptyStateView(icon: Icons.support_agent_outlined, title: 'No Complaints Yet', subtitle: 'Aapne abhi tak koi complaint submit nahi ki hai.');
        return Column(children: rows.map((c) {
          final complaint = c as Map<String, dynamic>;
          final status = (complaint['status'] ?? 'submitted').toString();
          final hasUnread = complaint['hasUnread'] == true;
          final isDirectChat = (complaint['isGeneralChat'] ?? complaint['is_general_chat']) == true;
          return InkWell(
            onTap: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => ComplaintChatScreen(complaintId: (complaint['id'] ?? '').toString(), subject: complaint['subject']?.toString() ?? 'Complaint'),
              ));
              reload(); // refresh unread indicator now that messages were (likely) read
            },
            borderRadius: BorderRadius.circular(16),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor(context),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: hasUnread ? const Color(0xFF0967FF) : borderColor(context), width: hasUnread ? 1.5 : 1),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Expanded(child: Row(children: [
                    if (hasUnread) Container(width: 8, height: 8, margin: const EdgeInsets.only(right: 6), decoration: const BoxDecoration(color: Color(0xFF0967FF), shape: BoxShape.circle)),
                    Flexible(child: Text(complaint['subject']?.toString() ?? 'Complaint', style: const TextStyle(fontWeight: FontWeight.w800))),
                  ])),
                  StatusBadge(text: isDirectChat ? 'Direct Chat' : status, color: isDirectChat ? const Color(0xFF00B876) : widget.statusColor(status)),
                ]),
                const SizedBox(height: 6),
                Text(complaint['message']?.toString() ?? '', style: TextStyle(color: mutedText(context))),
                const SizedBox(height: 6),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(
                    (complaint['createdAt'] ?? complaint['created_at'] ?? '').toString(),
                    style: TextStyle(color: faintText(context), fontSize: 11),
                  ),
                  Row(children: [
                    Icon(Icons.chat_bubble_outline, size: 14, color: hasUnread ? const Color(0xFF0967FF) : const Color(0xFF0967FF)),
                    const SizedBox(width: 4),
                    Text(hasUnread ? 'New reply' : 'Chat', style: const TextStyle(color: Color(0xFF0967FF), fontWeight: FontWeight.w800, fontSize: 12)),
                  ]),
                ]),
              ]),
            ),
          );
        }).toList());
      },
    ),
  ]));
}

class _DisputesTab extends StatefulWidget {
  final Color Function(String) statusColor;
  const _DisputesTab({required this.statusColor});
  @override
  State<_DisputesTab> createState() => _DisputesTabState();
}

class _DisputesTabState extends State<_DisputesTab> {
  String? selectedTransactionId;
  final disputeReason = TextEditingController(text: 'Wrong payment');
  final disputeMessage = TextEditingController();
  bool loading = false;
  late Future<List<dynamic>> disputesFuture = ApiService.myDisputes();
  late Future<List<dynamic>> transactionsFuture = ApiService.transactions();

  void reload() => setState(() => disputesFuture = ApiService.myDisputes());

  Future<void> sendDispute() async {
    if (disputeMessage.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dispute details likhna zaroori hai.')));
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.createDispute(transactionId: selectedTransactionId, reason: disputeReason.text.trim(), message: disputeMessage.text.trim());
      disputeMessage.clear();
      setState(() => selectedTransactionId = null);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dispute submit ho gaya. 2 din ke andar review hoga.')));
        reload();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(onRefresh: () async => reload(), child: ListView(padding: const EdgeInsets.all(16), children: [
    const InfoCard(title: 'Raise a Dispute', subtitle: 'Wrong payment ya failed transaction ke liye dispute submit karein. 2 din ke andar raise karna behtar hai.'),
    FutureBuilder<List<dynamic>>(
      future: transactionsFuture,
      builder: (context, snap) {
        final txns = snap.data ?? [];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: DropdownButtonFormField<String>(
            value: selectedTransactionId,
            decoration: InputDecoration(labelText: 'Related Transaction (optional)', filled: true, fillColor: cardColor(context), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
            items: [
              const DropdownMenuItem<String>(value: null, child: Text('No specific transaction')),
              ...txns.map((t) {
                final txn = t as Map<String, dynamic>;
                final id = (txn['id'] ?? '').toString();
                final label = '${txn['type'] ?? 'txn'} - ${txn['currency'] ?? ''} ${txn['amount'] ?? ''} (${id.length > 8 ? id.substring(0, 8) : id})';
                return DropdownMenuItem<String>(value: id, child: Text(label, overflow: TextOverflow.ellipsis));
              }),
            ],
            onChanged: (value) => setState(() => selectedTransactionId = value),
          ),
        );
      },
    ),
    AppInput(label: 'Reason', controller: disputeReason),
    AppInput(label: 'Dispute Details', controller: disputeMessage),
    PrimaryButton(text: loading ? 'Submitting...' : 'Submit Dispute', color: const Color(0xFF111827), onTap: loading ? () {} : sendDispute),
    const SizedBox(height: 20),
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      const Text('My Disputes', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      IconButton(icon: const Icon(Icons.refresh), onPressed: reload),
    ]),
    FutureBuilder<List<dynamic>>(
      future: disputesFuture,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
        if (snap.hasError) return ErrorRetryView(onRetry: reload);
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const EmptyStateView(icon: Icons.gavel_outlined, title: 'No Disputes Yet', subtitle: 'Aapne abhi tak koi dispute submit nahi kiya hai.');
        return Column(children: rows.map((d) {
          final dispute = d as Map<String, dynamic>;
          final status = (dispute['status'] ?? 'submitted').toString();
          final resolution = (dispute['resolution'] ?? '').toString();
          final adminNote = (dispute['adminNote'] ?? dispute['admin_note'] ?? '').toString();
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor(context))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Expanded(child: Text(dispute['reason']?.toString() ?? 'Dispute', style: const TextStyle(fontWeight: FontWeight.w800))),
                StatusBadge(text: status, color: widget.statusColor(status)),
              ]),
              const SizedBox(height: 6),
              Text(dispute['message']?.toString() ?? '', style: TextStyle(color: mutedText(context))),
              if (adminNote.isNotEmpty) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: const Color(0xFFF3F6FF), borderRadius: BorderRadius.circular(10)),
                  child: Text('Admin Note: $adminNote', style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
                ),
              ],
              if (resolution.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text('Resolution: $resolution', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF00B876))),
              ],
              const SizedBox(height: 6),
              Text(
                (dispute['createdAt'] ?? dispute['created_at'] ?? '').toString(),
                style: TextStyle(color: faintText(context), fontSize: 11),
              ),
            ]),
          );
        }).toList());
      },
    ),
  ]));
}


class EmailVerificationScreen extends StatefulWidget {
  final String email;
  const EmailVerificationScreen({super.key, required this.email});
  @override
  State<EmailVerificationScreen> createState() => _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  final otp = TextEditingController();
  bool loading = false;

  Future<void> verify() async {
    setState(() => loading = true);
    try {
      await ApiService.verifyEmailOtp(widget.email, otp.text.trim());
      if (mounted) replace(context, const KycScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> resend() async {
    try {
      final result = await ApiService.requestOtp(widget.email, purpose: 'email_verification');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('OTP sent. Dev OTP: ${result['devOtp'] ?? 'check email'}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Email Verification', child: ListView(children: [
    InfoCard(title: 'Verify Email', subtitle: 'OTP sent to ${widget.email}. Development mode me OTP backend console/API response me milega.'),
    AppInput(label: '6 Digit OTP', controller: otp),
    PrimaryButton(text: loading ? 'Verifying...' : 'Verify Email', onTap: loading ? () {} : verify),
    SecondaryButton(text: 'Resend OTP', onTap: resend),
  ]));
}

class OtpLoginScreen extends StatefulWidget {
  const OtpLoginScreen({super.key});
  @override
  State<OtpLoginScreen> createState() => _OtpLoginScreenState();
}

class _OtpLoginScreenState extends State<OtpLoginScreen> {
  final email = TextEditingController();
  final otp = TextEditingController();
  bool otpSent = false;
  bool loading = false;

  Future<void> request() async {
    setState(() => loading = true);
    try {
      final result = await ApiService.requestOtp(email.text.trim(), purpose: 'login');
      setState(() => otpSent = true);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('OTP sent. Dev OTP: ${result['devOtp'] ?? 'check email'}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> login() async {
    setState(() => loading = true);
    try {
      await ApiService.loginWithOtp(email.text.trim(), otp.text.trim());
      if (mounted) replace(context, const MainNavigationScreen());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'OTP Login', child: ListView(children: [
    const InfoCard(title: 'Secure OTP Login', subtitle: 'Email par 6 digit OTP receive karke login karein.'),
    AppInput(label: 'Email', controller: email),
    if (otpSent) AppInput(label: '6 Digit OTP', controller: otp),
    PrimaryButton(text: loading ? 'Please wait...' : (otpSent ? 'Login with OTP' : 'Send OTP'), onTap: loading ? () {} : (otpSent ? login : request)),
  ]));
}

class SecurityPinScreen extends StatefulWidget {
  const SecurityPinScreen({super.key});
  @override
  State<SecurityPinScreen> createState() => _SecurityPinScreenState();
}

class _SecurityPinScreenState extends State<SecurityPinScreen> {
  final pin = TextEditingController();
  final confirm = TextEditingController();
  bool loading = false;

  Future<void> savePin() async {
    final pinValue = pin.text.trim();
    if (!RegExp(r'^\d{4,6}$').hasMatch(pinValue)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN sirf 4 se 6 numbers (0-9) ka hona chahiye, koi letter/symbol nahi.')));
      return;
    }
    if (pinValue != confirm.text.trim()) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN match nahi kar raha')));
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.createPin(pin.text.trim());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Security PIN saved')));
        Navigator.pop(context);
      }
    } catch (e) {
      // Show the backend's actual reason (e.g. "PIN must be 4-6 digits" or
      // "too easy to guess") instead of a generic message, so the user knows
      // exactly what to fix instead of just seeing a repeated failure.
      final message = e.toString().replaceFirst('Exception: ', '');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message.isNotEmpty ? message : 'PIN save failed')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Security PIN', child: ListView(children: [
    const WarningBox(text: 'PIN sirf 4 se 6 numbers (0-9) ka hota hai — jaise 4829. Letters ya symbols allowed nahi hain. Money send karne ke liye Security PIN required hai, kisi ke saath share na karein.'),
    AppInput(
      label: 'Create PIN (4-6 digits only)',
      obscure: true,
      controller: pin,
      keyboardType: TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
    ),
    AppInput(
      label: 'Confirm PIN',
      obscure: true,
      controller: confirm,
      keyboardType: TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
    ),
    PrimaryButton(text: loading ? 'Saving...' : 'Save Security PIN', onTap: loading ? () {} : savePin),
  ]));
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late Future<Map<String, dynamic>> future = ApiService.me();

  void reload() => setState(() => future = ApiService.me());

  String _field(Map<String, dynamic> user, String camel, String snake) =>
      (user[camel] ?? user[snake] ?? '').toString();

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'My Profile',
    child: FutureBuilder<Map<String, dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ErrorRetryView(onRetry: reload, message: 'Profile load nahi ho paya. Internet connection check karein.');
        final user = (snap.data?['user'] ?? {}) as Map<String, dynamic>;
        return RefreshIndicator(onRefresh: () async => reload(), child: ListView(children: [
          InfoCard(title: 'Name', subtitle: _field(user, 'name', 'name')),
          InfoCard(title: 'Email', subtitle: _field(user, 'email', 'email')),
          InfoCard(title: 'Phone', subtitle: _field(user, 'phone', 'phone')),
          InfoCard(title: 'Country', subtitle: _field(user, 'country', 'country')),
          InfoCard(title: 'Address', subtitle: _field(user, 'address', 'address')),
          InfoCard(title: 'House Number', subtitle: _field(user, 'houseNumber', 'house_number')),
          InfoCard(title: 'KYC Status', subtitle: _field(user, 'kycStatus', 'kyc_status').isEmpty ? 'pending' : _field(user, 'kycStatus', 'kyc_status')),
          const InfoCard(title: 'Security', subtitle: 'Use strong password, PIN and biometric lock for payment safety.'),
          const InfoCard(title: 'App Build Version', subtitle: 'v1.10.2+21 (Direct Chat with Support Button, Unread Support Chat Badges, Dark Mode Visual Polish, Price Alerts, In-App Support Chat, Statement Export (PDF/CSV), Dark Mode & App Settings, Favorites Watchlist, Launch Readiness Review: 59-Check E2E Test Suite, PIN-Error Status-Code Consistency Fix, India MHA Sanctions Lists, Fully Automatic Sanctions Sync, Sanctions/PEP Screening, Travel Rule Data Capture, STR Case Tracking, FIU-IND Registration Guide, Legal Docs Published on Website, Technical Safeguards: KYC-tier Transaction Limits, AML Flagging, Crypto TDS, Server Crash-Safety Fix, UI/UX Polish, Wallet Withdraw & Bank Accounts, Dispute/Complaint Management, Login Security Upgrade, Referral System, Receipts, Notifications, KYC Document Upload, Live Rates, QR Payment Requests)'),
          ProfessionalCard(title: 'App Settings', subtitle: 'Dark mode, notification preferences', icon: Icons.settings_outlined, onTap: () => go(context, const AppSettingsScreen())),
          ProfessionalCard(title: 'Price Alerts', subtitle: 'Currency/crypto rate ke liye alerts set karein', icon: Icons.notifications_active_outlined, onTap: () => go(context, const PriceAlertsScreen())),
          ProfessionalCard(title: 'Favorites / Watchlist', subtitle: 'Apni pasandeeda currency pairs pin karein', icon: Icons.star_outline, onTap: () => go(context, const WatchlistScreen())),
          ProfessionalCard(title: 'Download Statement', subtitle: 'Apna poora transaction history PDF/CSV mein download karein', icon: Icons.description_outlined, onTap: () => go(context, const StatementExportScreen())),
          const SizedBox(height: 4),
          PrimaryButton(text: 'Create / Change Security PIN', color: const Color(0xFF111827), onTap: () => go(context, const SecurityPinScreen())),
          PrimaryButton(text: 'Logout', color: const Color(0xFFE53935), onTap: () async {
            // Revokes the refresh token server-side (real logout) rather than
            // just forgetting it locally — under the old design, deleting the
            // token from the app still left it valid on the server for up to
            // 7 more days if someone had a copy of it.
            await ApiService.logout();
            if (context.mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const SplashScreen()), (route) => false);
          }),
          SecondaryButton(text: 'Logout From All Devices', onTap: () async {
            final confirmed = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Logout Everywhere?'),
                content: const Text('Yeh aapko is account ke saare devices/sessions se logout kar dega, sirf is phone se nahi.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                  TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Logout Everywhere')),
                ],
              ),
            );
            if (confirmed == true) {
              await ApiService.logoutEverywhere();
              if (context.mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const SplashScreen()), (route) => false);
            }
          }),
        ]));
      },
    ),
  );
}

// ---------------------------------------------------------------------------
// App Settings — Dark Mode + notification preference toggles, synced to
// the account via ApiService.getSettings/updateSettings.
// ---------------------------------------------------------------------------
class AppSettingsScreen extends StatefulWidget {
  const AppSettingsScreen({super.key});
  @override
  State<AppSettingsScreen> createState() => _AppSettingsScreenState();
}

class _AppSettingsScreenState extends State<AppSettingsScreen> {
  late Future<Map<String, dynamic>> future = ApiService.getSettings();
  bool saving = false;

  void reload() => setState(() => future = ApiService.getSettings());

  Future<void> _updateTheme(ThemeMode mode) async {
    ThemeController.mode.value = mode; // instant UI feedback
    setState(() => saving = true);
    try {
      await ApiService.updateSettings(themePreference: ThemeController.toPreferenceString(mode));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _toggleNotification({bool? email, bool? push}) async {
    setState(() => saving = true);
    try {
      await ApiService.updateSettings(emailNotificationsEnabled: email, pushNotificationsEnabled: push);
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'App Settings',
    child: FutureBuilder<Map<String, dynamic>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ErrorRetryView(onRetry: reload, message: 'Settings load nahi ho paye. Internet connection check karein.');
        final data = snap.data ?? {};
        final emailOn = data['emailNotificationsEnabled'] != false;
        final pushOn = data['pushNotificationsEnabled'] != false;
        return RefreshIndicator(onRefresh: () async => reload(), child: ListView(children: [
          const Text('Theme', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 10),
          ValueListenableBuilder<ThemeMode>(
            valueListenable: ThemeController.mode,
            builder: (context, mode, _) => Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor(context))),
              child: Column(children: [
                RadioListTile<ThemeMode>(
                  value: ThemeMode.system, groupValue: mode, onChanged: saving ? null : (v) => _updateTheme(v!),
                  title: const Text('System Default'), subtitle: const Text('Follow phone theme'),
                ),
                RadioListTile<ThemeMode>(
                  value: ThemeMode.light, groupValue: mode, onChanged: saving ? null : (v) => _updateTheme(v!),
                  title: const Text('Light Mode'),
                ),
                RadioListTile<ThemeMode>(
                  value: ThemeMode.dark, groupValue: mode, onChanged: saving ? null : (v) => _updateTheme(v!),
                  title: const Text('Dark Mode'),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 20),
          const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor(context))),
            child: Column(children: [
              SwitchListTile(
                value: emailOn, onChanged: saving ? null : (v) => _toggleNotification(email: v),
                title: const Text('Email Notifications'), subtitle: const Text('Payment, KYC, exchange updates email par bhi bhejein'),
              ),
              SwitchListTile(
                value: pushOn, onChanged: saving ? null : (v) => _toggleNotification(push: v),
                title: const Text('Push / In-App Notifications'), subtitle: const Text('App ke andar notification bell mein dikhayein'),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          const WarningBox(text: 'Push notifications yahan sirf in-app notification bell ke liye hai — background push (jab app band ho) is version mein support nahi hai.'),
        ]));
      },
    ),
  );
}

// ---------------------------------------------------------------------------
// Price Alerts
// ---------------------------------------------------------------------------
class PriceAlertsScreen extends StatefulWidget {
  const PriceAlertsScreen({super.key});
  @override
  State<PriceAlertsScreen> createState() => _PriceAlertsScreenState();
}

class _PriceAlertsScreenState extends State<PriceAlertsScreen> {
  static const pairs = ['USD_INR', 'EUR_INR', 'GBP_INR', 'AED_INR', 'BTC_USD', 'ETH_USD', 'XRP_USD', 'BTC_INR'];
  String pair = 'USD_INR';
  String direction = 'above';
  final targetPrice = TextEditingController();
  bool loading = false;
  late Future<List<dynamic>> future = ApiService.priceAlerts();

  void reload() => setState(() => future = ApiService.priceAlerts());

  Future<void> _checkNow() async {
    try {
      await ApiService.rates(); // GET /api/rates opportunistically evaluates + triggers alerts server-side
    } catch (_) {}
    reload();
  }

  Future<void> create() async {
    final price = double.tryParse(targetPrice.text.trim());
    if (price == null || price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sahi target price daalein.')));
      return;
    }
    setState(() => loading = true);
    try {
      await ApiService.createPriceAlert(pair: pair, direction: direction, targetPrice: price);
      targetPrice.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Price alert set ho gaya!')));
        reload();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> cancel(String id) async {
    try {
      await ApiService.cancelPriceAlert(id);
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'triggered':
        return const Color(0xFF00B876);
      case 'cancelled':
        return const Color(0xFFE53935);
      default:
        return const Color(0xFF0967FF);
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Price Alerts',
    child: RefreshIndicator(onRefresh: _checkNow, child: ListView(children: [
      const InfoCard(title: 'Set a Price Alert', subtitle: 'Jab target price cross ho jaye to aapko notification milega. Alerts app khulne/rates refresh hone par check hote hain (real-time push nahi).'),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: borderColor(context))),
        child: Column(children: [
          DropdownButtonFormField<String>(
            value: pair,
            decoration: const InputDecoration(labelText: 'Currency / Crypto Pair'),
            items: pairs.map((p) => DropdownMenuItem(value: p, child: Text(p.replaceAll('_', '/')))).toList(),
            onChanged: (v) => setState(() => pair = v!),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: direction,
            decoration: const InputDecoration(labelText: 'Alert When Price Goes'),
            items: const [
              DropdownMenuItem(value: 'above', child: Text('Above target')),
              DropdownMenuItem(value: 'below', child: Text('Below target')),
            ],
            onChanged: (v) => setState(() => direction = v!),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: targetPrice,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Target Price'),
          ),
          PrimaryButton(text: loading ? 'Saving...' : 'Set Alert', onTap: loading ? () {} : create),
        ]),
      ),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('My Alerts', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        IconButton(icon: const Icon(Icons.refresh), onPressed: _checkNow),
      ]),
      FutureBuilder<List<dynamic>>(
        future: future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
          if (snap.hasError) return ErrorRetryView(onRetry: reload);
          final rows = snap.data ?? [];
          if (rows.isEmpty) return const EmptyStateView(icon: Icons.notifications_off_outlined, title: 'No Alerts Yet', subtitle: 'Upar se apna pehla price alert set karein.');
          return Column(children: rows.map((a) {
            final alert = a as Map<String, dynamic>;
            final status = (alert['status'] ?? 'active').toString();
            final alertPair = (alert['pair'] ?? '').toString().replaceAll('_', '/');
            final dir = (alert['direction'] ?? '').toString();
            final target = (alert['targetPrice'] ?? alert['target_price'] ?? '').toString();
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor(context))),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('$alertPair — $dir $target', style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  StatusBadge(text: status, color: _statusColor(status)),
                ])),
                if (status == 'active') IconButton(icon: const Icon(Icons.close), onPressed: () => cancel(alert['id'].toString())),
              ]),
            );
          }).toList());
        },
      ),
    ])),
  );
}

// ---------------------------------------------------------------------------
// Favorites / Watchlist
// ---------------------------------------------------------------------------
class WatchlistScreen extends StatefulWidget {
  const WatchlistScreen({super.key});
  @override
  State<WatchlistScreen> createState() => _WatchlistScreenState();
}

class _WatchlistScreenState extends State<WatchlistScreen> {
  static const allPairs = ['USD_INR', 'EUR_INR', 'GBP_INR', 'AED_INR', 'BTC_USD', 'ETH_USD', 'XRP_USD', 'BTC_INR'];
  late Future<List<dynamic>> future = ApiService.watchlist();

  void reload() => setState(() => future = ApiService.watchlist());

  Future<void> add(String pair) async {
    try {
      await ApiService.addToWatchlist(pair);
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Future<void> remove(String id) async {
    try {
      await ApiService.removeFromWatchlist(id);
      reload();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Favorites / Watchlist',
    child: RefreshIndicator(onRefresh: () async => reload(), child: ListView(children: [
      const InfoCard(title: 'Your Watchlist', subtitle: 'Pasandeeda currency/crypto pairs pin karein — home screen par quick access ke liye.'),
      FutureBuilder<List<dynamic>>(
        future: future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
          if (snap.hasError) return ErrorRetryView(onRetry: reload);
          final rows = snap.data ?? [];
          final pinnedPairs = rows.map((r) => (r as Map<String, dynamic>)['pair'].toString()).toSet();
          return Column(children: [
            if (rows.isEmpty)
              const EmptyStateView(icon: Icons.star_border, title: 'No Favorites Yet', subtitle: 'Neeche se pairs pin karein.')
            else
              ...rows.map((w) {
                final item = w as Map<String, dynamic>;
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor(context))),
                  child: Row(children: [
                    const Icon(Icons.star, color: Color(0xFFFFA000)),
                    const SizedBox(width: 10),
                    Expanded(child: Text((item['pair'] ?? '').toString().replaceAll('_', '/'), style: const TextStyle(fontWeight: FontWeight.w800))),
                    IconButton(icon: const Icon(Icons.close), onPressed: () => remove(item['id'].toString())),
                  ]),
                );
              }),
            const SizedBox(height: 16),
            const Align(alignment: Alignment.centerLeft, child: Text('Add a pair', style: TextStyle(fontWeight: FontWeight.w900))),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: allPairs.where((p) => !pinnedPairs.contains(p)).map((p) => ActionChip(
              label: Text(p.replaceAll('_', '/')),
              avatar: const Icon(Icons.add, size: 16),
              onPressed: () => add(p),
            )).toList()),
          ]);
        },
      ),
    ])),
  );
}

// ---------------------------------------------------------------------------
// Transaction Statement Export (PDF-via-print + CSV)
// ---------------------------------------------------------------------------
class StatementExportScreen extends StatefulWidget {
  const StatementExportScreen({super.key});
  @override
  State<StatementExportScreen> createState() => _StatementExportScreenState();
}

class _StatementExportScreenState extends State<StatementExportScreen> {
  DateTime? fromDate;
  DateTime? toDate;
  bool loading = false;

  String _fmt(DateTime? d) => d == null ? 'Not set' : '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  String? _iso(DateTime? d) => d == null ? null : '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pickDate({required bool isFrom}) async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: now, firstDate: DateTime(2020), lastDate: now);
    if (picked != null) setState(() => isFrom ? fromDate = picked : toDate = picked);
  }

  Future<void> _open(String url) async {
    setState(() => loading = true);
    try {
      final opened = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link nahi khul paya. Browser install hai check karein.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Statement generate nahi ho paya. Dobara try karein.')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> viewPdf() async {
    try {
      final urls = await ApiService.requestStatementUrls(fromDate: _iso(fromDate), toDate: _iso(toDate));
      await _open(urls['url']!);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Future<void> downloadCsv() async {
    try {
      final urls = await ApiService.requestStatementUrls(fromDate: _iso(fromDate), toDate: _iso(toDate));
      await _open(urls['csvUrl']!);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'Download Statement',
    child: ListView(children: [
      const InfoCard(title: 'Account Statement', subtitle: 'Apna poora transaction history ek printable/PDF page ya CSV file mein download karein. Date range optional hai — chhod dein to poora history milega.'),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: borderColor(context))),
        child: Column(children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('From Date'),
            subtitle: Text(_fmt(fromDate)),
            trailing: const Icon(Icons.calendar_today, size: 18),
            onTap: () => _pickDate(isFrom: true),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('To Date'),
            subtitle: Text(_fmt(toDate)),
            trailing: const Icon(Icons.calendar_today, size: 18),
            onTap: () => _pickDate(isFrom: false),
          ),
          if (fromDate != null || toDate != null)
            SecondaryButton(text: 'Clear Dates', onTap: () => setState(() { fromDate = null; toDate = null; })),
        ]),
      ),
      const SizedBox(height: 16),
      PrimaryButton(text: loading ? 'Please wait...' : 'View / Print Statement (PDF)', color: const Color(0xFF00B876), onTap: loading ? () {} : viewPdf),
      SecondaryButton(text: loading ? 'Please wait...' : 'Download as CSV', onTap: loading ? () {} : downloadCsv),
      const SizedBox(height: 12),
      const WarningBox(text: 'Statement link 15 minute ke liye valid hota hai. PDF page browser mein khulega jahan se "Print / Save as PDF" kar sakte hain.'),
    ]),
  );
}

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  Future<void> _open(BuildContext context, String url) async {
    try {
      final opened = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link nahi khul paya. Browser install hai check karein.')));
      }
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link nahi khul paya.')));
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(title: 'Terms & Privacy', child: ListView(children: [
    InkWell(onTap: () => _open(context, 'https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/terms.html'), child: const InfoCard(title: 'Terms & Conditions', subtitle: 'Tap to read full Terms & Conditions')),
    InkWell(onTap: () => _open(context, 'https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/privacy.html'), child: const InfoCard(title: 'Privacy Policy', subtitle: 'Tap to read full Privacy Policy')),
    InkWell(onTap: () => _open(context, 'https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/refund.html'), child: const InfoCard(title: 'Refund & Cancellation Policy', subtitle: 'Tap to read full Refund & Cancellation Policy')),
    InkWell(onTap: () => _open(context, 'https://rajkatiyar8528-arch.github.io/Global-exchanger/legal/grievance.html'), child: const InfoCard(title: 'Grievance Redressal Policy', subtitle: 'Complaint resolve nahi hua? Tap karke poori grievance policy padhein — grievance@globalexchanger.com')),
    const WarningBox(text: 'Financial, forex, wallet aur crypto services ke liye RBI/NPCI/FEMA/FIU aur country-wise compliance zaruri hai.'),
  ]));
}

class AppPage extends StatelessWidget {
  final String title;
  final Widget child;
  const AppPage({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: Padding(padding: const EdgeInsets.all(22), child: child));
}

class AppInput extends StatelessWidget {
  final String label;
  final bool obscure;
  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  const AppInput({super.key, required this.label, this.obscure = false, this.controller, this.onChanged, this.keyboardType, this.inputFormatters});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(
      controller: controller,
      obscureText: obscure,
      onChanged: onChanged,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      decoration: InputDecoration(labelText: label, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
    ),
  );
}

class PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final Color color;
  const PrimaryButton({super.key, required this.text, required this.onTap, this.color = const Color(0xFF0967FF)});
  @override
  Widget build(BuildContext context) => SizedBox(width: double.infinity, child: Padding(padding: const EdgeInsets.only(top: 10), child: FilledButton(style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.all(16)), onPressed: onTap, child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)))));
}

class SecondaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const SecondaryButton({super.key, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => SizedBox(width: double.infinity, child: Padding(padding: const EdgeInsets.only(top: 10), child: OutlinedButton(style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16)), onPressed: onTap, child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)))));
}

class FeatureTile extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;
  const FeatureTile({super.key, required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(22), child: Container(decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(22), border: Border.all(color: borderColor(context))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(icon, style: const TextStyle(fontSize: 32)), const SizedBox(height: 10), Text(label, style: const TextStyle(fontWeight: FontWeight.w800))])));
}

class InfoCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const InfoCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor(context))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: TextStyle(color: mutedText(context)))]));
}

class WarningBox extends StatelessWidget {
  final String text;
  const WarningBox({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: warningBg(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFE2A8))), child: Text(text, style: const TextStyle(color: Color(0xFF815400))));
}

/// Shown instead of a bare error string whenever a FutureBuilder's fetch
/// fails (network problem, server hiccup, etc). Gives the user an obvious
/// way to try again without having to leave the screen or restart the app —
/// previously most screens just showed a static "X load nahi ho paya" text
/// with no way to recover except backing out and re-entering the screen.
class ErrorRetryView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const ErrorRetryView({super.key, this.message = 'Kuch gadbad ho gayi. Internet connection check karein.', required this.onRetry});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.wifi_off_rounded, size: 40, color: faintText(context)),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center, style: TextStyle(color: mutedText(context))),
        const SizedBox(height: 16),
        SizedBox(
          width: 160,
          child: OutlinedButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Retry')),
        ),
      ]),
    ),
  );
}

/// A small, empty-state placeholder used consistently across list screens
/// (previously each screen wrote its own one-off "No X yet" text/InfoCard,
/// with inconsistent styling/wording).
class EmptyStateView extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  const EmptyStateView({super.key, required this.title, required this.subtitle, this.icon = Icons.inbox_outlined});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 40, color: faintText(context)),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 6),
        Text(subtitle, textAlign: TextAlign.center, style: TextStyle(color: subtleText(context), fontSize: 13)),
      ]),
    ),
  );
}

void go(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));
void replace(BuildContext context, Widget page) => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
