import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GradientHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final String amount;
  final Widget? trailing;
  const GradientHeader({super.key, required this.title, required this.subtitle, required this.amount, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [GXColors.primary, GXColors.secondary]),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [BoxShadow(color: GXColors.primary.withOpacity(.24), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)), trailing ?? const SizedBox()]),
        const SizedBox(height: 10),
        Text(subtitle, style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 8),
        Text(amount, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 34)),
      ]),
    );
  }
}

class ProfessionalCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onTap;
  const ProfessionalCard({super.key, required this.title, required this.subtitle, required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: cardColor(context), borderRadius: BorderRadius.circular(22), border: Border.all(color: borderColor(context))),
        child: Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(color: GXColors.primary.withOpacity(.10), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: GXColors.primary)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, style: TextStyle(color: mutedText(context), fontSize: 12))])),
          Icon(Icons.chevron_right, color: mutedText(context))
        ]),
      ),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final String text;
  final Color color;
  const StatusBadge({super.key, required this.text, this.color = GXColors.secondary});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(999)),
    child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
  );
}
