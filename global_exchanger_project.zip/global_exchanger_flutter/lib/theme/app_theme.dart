import 'package:flutter/material.dart';

class GXColors {
  static const primary = Color(0xFF0967FF);
  static const secondary = Color(0xFF00C48C);
  static const dark = Color(0xFF102033);
  static const bg = Color(0xFFF4F8FF);
  static const card = Colors.white;
  static const muted = Color(0xFF65768C);
  static const warning = Color(0xFFFFF8E8);
}

class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(seedColor: GXColors.primary, primary: GXColors.primary, secondary: GXColors.secondary);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: GXColors.bg,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: GXColors.bg,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(color: GXColors.dark, fontWeight: FontWeight.w900, fontSize: 20),
        iconTheme: IconThemeData(color: GXColors.dark),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFDDE8FF))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFDDE8FF))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: GXColors.primary, width: 1.5)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: GXColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: Color(0xFFE5EDFF))),
      ),
    );
  }
}
