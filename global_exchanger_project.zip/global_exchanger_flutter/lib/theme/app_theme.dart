import 'package:flutter/material.dart';

class GXColors {
  static const primary = Color(0xFF0967FF);
  static const secondary = Color(0xFF00C48C);
  static const dark = Color(0xFF102033);
  static const bg = Color(0xFFF4F8FF);
  static const card = Colors.white;
  static const muted = Color(0xFF65768C);
  static const warning = Color(0xFFFFF8E8);

  // Dark-mode variants — used by the theme-aware helper functions below so
  // widgets throughout the app (cards, borders, muted text) automatically
  // adapt when the user switches on Dark Mode from Profile > App Settings,
  // instead of every screen needing its own light/dark branching logic.
  static const darkBg = Color(0xFF0B1220);
  static const darkCard = Color(0xFF141E30);
  static const darkBorder = Color(0xFF223049);
  static const darkMuted = Color(0xFF93A4BF);
  static const darkWarning = Color(0xFF3A2E12);
}

/// Global, app-wide theme mode control. There's no external state
/// management package in this project (kept dependency-light on purpose),
/// so a simple ValueNotifier is used: MaterialApp listens to it via
/// ValueListenableBuilder, and the Settings screen updates it directly
/// (plus persists the choice to the backend via ApiService.updateSettings
/// so it follows the user's account across devices/reinstalls).
class ThemeController {
  static final ValueNotifier<ThemeMode> mode = ValueNotifier(ThemeMode.system);

  static void setFromPreferenceString(String? preference) {
    switch (preference) {
      case 'dark':
        mode.value = ThemeMode.dark;
        break;
      case 'light':
        mode.value = ThemeMode.light;
        break;
      default:
        mode.value = ThemeMode.system;
    }
  }

  static String toPreferenceString(ThemeMode m) {
    switch (m) {
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.light:
        return 'light';
      case ThemeMode.system:
        return 'system';
    }
  }
}

// ---------------------------------------------------------------------------
// Theme-aware color helpers. Screens across the app were originally written
// with hardcoded `Colors.white` card backgrounds, `Color(0xFFE5EDFF)`
// borders, and `Colors.black54`/`Colors.black45`/`Colors.black38` muted text
// — these helper functions let existing widgets adopt Dark Mode with a
// small, consistent change (swap the hardcoded constant for a call to the
// matching helper) rather than needing a full design-system rewrite.
// ---------------------------------------------------------------------------
bool isDark(BuildContext context) => Theme.of(context).brightness == Brightness.dark;
Color cardColor(BuildContext context) => isDark(context) ? GXColors.darkCard : Colors.white;
Color borderColor(BuildContext context) => isDark(context) ? GXColors.darkBorder : const Color(0xFFE5EDFF);
Color mutedText(BuildContext context) => isDark(context) ? GXColors.darkMuted : Colors.black54;
Color subtleText(BuildContext context) => isDark(context) ? GXColors.darkMuted.withOpacity(.75) : Colors.black45;
Color faintText(BuildContext context) => isDark(context) ? GXColors.darkMuted.withOpacity(.55) : Colors.black38;
Color warningBg(BuildContext context) => isDark(context) ? GXColors.darkWarning : GXColors.warning;

class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(seedColor: GXColors.primary, primary: GXColors.primary, secondary: GXColors.secondary);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: scheme,
      scaffoldBackgroundColor: GXColors.bg,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: GXColors.bg,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(color: GXColors.dark, fontWeight: FontWeight.w900, fontSize: 20),
        iconTheme: IconThemeData(color: GXColors.dark),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFDDE8FF))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFDDE8FF))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: GXColors.primary, width: 1.5)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: GXColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: Color(0xFFE5EDFF))),
      ),
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(seedColor: GXColors.primary, brightness: Brightness.dark, primary: GXColors.primary, secondary: GXColors.secondary);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: GXColors.darkBg,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: GXColors.darkBg,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: GXColors.darkCard,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        hintStyle: TextStyle(color: GXColors.darkMuted.withOpacity(.7)),
        labelStyle: const TextStyle(color: GXColors.darkMuted),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: GXColors.darkBorder)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: GXColors.darkBorder)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: GXColors.primary, width: 1.5)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: GXColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      cardTheme: CardThemeData(
        color: GXColors.darkCard,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: GXColors.darkBorder)),
      ),
      textTheme: ThemeData.dark().textTheme.apply(bodyColor: Colors.white, displayColor: Colors.white),
    );
  }
}
