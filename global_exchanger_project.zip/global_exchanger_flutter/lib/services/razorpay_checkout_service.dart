import 'package:razorpay_flutter/razorpay_flutter.dart';

class RazorpayCheckoutService {
  late final Razorpay _razorpay;
  Function(PaymentSuccessResponse)? onSuccess;
  Function(PaymentFailureResponse)? onFailure;
  Function(ExternalWalletResponse)? onExternalWallet;

  RazorpayCheckoutService() {
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handleSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handleFailure);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  void _handleSuccess(PaymentSuccessResponse response) => onSuccess?.call(response);
  void _handleFailure(PaymentFailureResponse response) => onFailure?.call(response);
  void _handleExternalWallet(ExternalWalletResponse response) => onExternalWallet?.call(response);

  void openCheckout({
    required String key,
    required String orderId,
    required num amount,
    required String currency,
    required String name,
    required String description,
    String? userEmail,
    String? userPhone,
  }) {
    final options = {
      'key': key,
      'amount': (amount * 100).round(), // Razorpay amount in paise
      'currency': currency,
      'name': name,
      'description': description,
      'order_id': orderId,
      'prefill': {
        'contact': userPhone ?? '',
        'email': userEmail ?? '',
      },
      'theme': {'color': '#0967FF'}
    };
    _razorpay.open(options);
  }

  void dispose() => _razorpay.clear();
}
