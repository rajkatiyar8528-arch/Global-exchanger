import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {
  // Android emulator: http://10.0.2.2:5000
  // Physical phone: replace with your computer LAN IP, e.g. http://192.168.1.10:5000
  static const String baseUrl = 'https://global-exchanger.onrender.com';

  // How long we wait for the backend before giving up and showing a
  // friendly "connection problem" message instead of letting the UI spin
  // forever. Render's free tier can have a slow "cold start" after
  // inactivity, so this is generous rather than aggressive.
  static const Duration _requestTimeout = Duration(seconds: 25);

  /// Wraps every raw HTTP call so that network failures (no internet, DNS
  /// failure, connection refused, slow/cold-starting server) surface as a
  /// single, user-friendly message instead of a raw exception like
  /// "SocketException: Failed host lookup" — which used to bubble straight
  /// up to snackbars verbatim and confuse users.
  static Future<http.Response> _guarded(Future<http.Response> Function() call) async {
    try {
      return await call().timeout(_requestTimeout);
    } on TimeoutException {
      throw Exception('Server is taking too long to respond. Please check your internet and try again.');
    } on SocketException {
      throw Exception('No internet connection. Please check your network and try again.');
    } on HttpException {
      throw Exception('Could not reach the server. Please try again in a moment.');
    } on FormatException {
      throw Exception('Received an unexpected response from the server. Please try again.');
    }
  }

  static Future<http.Response> _get(Uri url, {Map<String, String>? headers}) => _guarded(() => http.get(url, headers: headers));
  static Future<http.Response> _post(Uri url, {Map<String, String>? headers, Object? body}) => _guarded(() => http.post(url, headers: headers, body: body));
  static Future<http.Response> _patch(Uri url, {Map<String, String>? headers, Object? body}) => _guarded(() => http.patch(url, headers: headers, body: body));
  static Future<http.Response> _delete(Uri url, {Map<String, String>? headers}) => _guarded(() => http.delete(url, headers: headers));

  // --- Session state -------------------------------------------------------
  // `token` is a short-lived (15 min) access token used for every normal API
  // call. `refreshToken` is a long-lived (30 day), rotating, server-revocable
  // token used ONLY to silently obtain a new access token when the current
  // one expires — the user is never bounced back to the login screen just
  // because 15 minutes passed. Same pair exists separately for the admin
  // session so a user login and an admin login can't interfere with each
  // other's tokens.
  static String? token;
  static String? refreshToken;
  static String? adminToken;
  static String? adminRefreshToken;

  static Map<String, String> get _jsonHeaders => {'Content-Type': 'application/json'};
  static Map<String, String> get _authHeaders => {'Content-Type': 'application/json', if (token != null) 'Authorization': 'Bearer $token'};
  static Map<String, String> get _adminHeaders => {'Content-Type': 'application/json', if (adminToken != null) 'Authorization': 'Bearer $adminToken'};

  static Future<dynamic> _decode(http.Response res) async {
    final body = res.body.isEmpty ? '{}' : res.body;
    final data = jsonDecode(body);
    if (res.statusCode >= 400) throw Exception(data['error'] ?? 'Something went wrong (error ${res.statusCode}). Please try again.');
    return data;
  }


  static Map<String, dynamic>? _tryDecodeRaw(String body) {
    try {
      return jsonDecode(body.isEmpty ? '{}' : body) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  // Refreshes the USER access token using the stored user refresh token.
  // Returns true if a new access token was obtained.
  static Future<bool> _refreshUserToken() async {
    if (refreshToken == null) return false;
    try {
      final res = await _post(Uri.parse('$baseUrl/api/auth/refresh'), headers: _jsonHeaders, body: jsonEncode({'refreshToken': refreshToken}));
      if (res.statusCode != 200) {
        // Refresh token itself is invalid/expired/revoked (e.g. reused-token
        // theft detection) — clear the session so the app routes back to login.
        token = null;
        refreshToken = null;
        return false;
      }
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      token = data['token'];
      refreshToken = data['refreshToken'];
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _refreshAdminToken() async {
    if (adminRefreshToken == null) return false;
    try {
      final res = await _post(Uri.parse('$baseUrl/api/auth/refresh'), headers: _jsonHeaders, body: jsonEncode({'refreshToken': adminRefreshToken}));
      if (res.statusCode != 200) {
        adminToken = null;
        adminRefreshToken = null;
        return false;
      }
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      adminToken = data['token'];
      adminRefreshToken = data['refreshToken'];
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Runs [makeRequest] (which should read `_authHeaders`/`token` fresh each
  /// time it's called, e.g. via a closure) and, if the access token turns out
  /// to be expired, transparently refreshes it once and retries — the caller
  /// never sees the expiry, so no screen needs its own retry/refresh logic.
  static Future<http.Response> _withUserRefresh(Future<http.Response> Function() makeRequest) async {
    var res = await makeRequest();
    if (res.statusCode == 401) {
      final decoded = _tryDecodeRaw(res.body);
      if (decoded?['code'] == 'TOKEN_EXPIRED') {
        final refreshed = await _refreshUserToken();
        if (refreshed) res = await makeRequest();
      }
    }
    return res;
  }

  static Future<http.Response> _withAdminRefresh(Future<http.Response> Function() makeRequest) async {
    var res = await makeRequest();
    if (res.statusCode == 401) {
      final decoded = _tryDecodeRaw(res.body);
      if (decoded?['code'] == 'TOKEN_EXPIRED') {
        final refreshed = await _refreshAdminToken();
        if (refreshed) res = await makeRequest();
      }
    }
    return res;
  }

  /// True once a user session (however briefly used) exists — the app can
  /// use this to decide whether to attempt a silent refresh/session restore
  /// instead of forcing straight to the login screen.
  static bool get hasUserSession => refreshToken != null;
  static bool get hasAdminSession => adminRefreshToken != null;

  static void _setUserSession(Map<String, dynamic> decoded) {
    token = decoded['token'];
    refreshToken = decoded['refreshToken'];
  }

  static void _setAdminSession(Map<String, dynamic> decoded) {
    adminToken = decoded['token'];
    adminRefreshToken = decoded['refreshToken'];
  }

  /// Revokes the current user session server-side (real logout — the old
  /// design only deleted the token from the app, leaving it valid on the
  /// server for up to 7 more days if it had leaked).
  static Future<void> logout() async {
    final rt = refreshToken;
    token = null;
    refreshToken = null;
    if (rt != null) {
      try {
        await _post(Uri.parse('$baseUrl/api/auth/logout'), headers: _jsonHeaders, body: jsonEncode({'refreshToken': rt}));
      } catch (_) {
        // Best-effort: even if this network call fails, the app has already
        // forgotten the token locally.
      }
    }
  }

  /// Logs the user out of every device/session, not just this one — useful
  /// if they suspect their account or another device is compromised.
  static Future<void> logoutEverywhere() async {
    try {
      await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/auth/logout-all'), headers: _authHeaders));
    } catch (_) {}
    token = null;
    refreshToken = null;
  }

  static Future<void> adminLogout() async {
    final rt = adminRefreshToken;
    adminToken = null;
    adminRefreshToken = null;
    if (rt != null) {
      try {
        await _post(Uri.parse('$baseUrl/api/auth/logout'), headers: _jsonHeaders, body: jsonEncode({'refreshToken': rt}));
      } catch (_) {}
    }
  }

  static Future<Map<String, dynamic>> requestOtp(String email, {String purpose = 'email_verification'}) async {
    final res = await _post(Uri.parse('$baseUrl/api/auth/request-otp'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'purpose': purpose}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> verifyEmailOtp(String email, String otp) async {
    final res = await _post(Uri.parse('$baseUrl/api/auth/verify-email-otp'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'otp': otp}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> loginWithOtp(String email, String otp) async {
    final res = await _post(Uri.parse('$baseUrl/api/auth/login-otp'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'otp': otp}));
    final decoded = await _decode(res) as Map<String, dynamic>;
    _setUserSession(decoded);
    return decoded;
  }

  static Future<Map<String, dynamic>> adminRefund({required String orderId, String? gatewayPaymentId, double? amount, String reason = 'admin_refund'}) async {
    final res = await _withAdminRefresh(() => _post(Uri.parse('$baseUrl/api/payments/refund'), headers: _adminHeaders, body: jsonEncode({'orderId': orderId, 'gatewayPaymentId': gatewayPaymentId, 'amount': amount, 'reason': reason})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> register(Map<String, dynamic> data) async {
    final res = await _post(Uri.parse('$baseUrl/api/auth/register'), headers: _jsonHeaders, body: jsonEncode(data));
    final decoded = await _decode(res) as Map<String, dynamic>;
    _setUserSession(decoded);
    return decoded;
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await _post(Uri.parse('$baseUrl/api/auth/login'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'password': password}));
    final decoded = await _decode(res) as Map<String, dynamic>;
    _setUserSession(decoded);
    return decoded;
  }

  static Future<Map<String, dynamic>> adminLogin(String email, String password, String specialKey) async {
    final res = await _post(Uri.parse('$baseUrl/api/admin/login'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'password': password, 'specialKey': specialKey}));
    final decoded = await _decode(res) as Map<String, dynamic>;
    _setAdminSession(decoded);
    return decoded;
  }

  static Future<Map<String, dynamic>> me() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/me'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> myReferrals() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/referrals/mine'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> notifications({int limit = 30, int offset = 0}) async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/notifications?limit=$limit&offset=$offset'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<void> markNotificationRead(String id) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/notifications/$id/read'), headers: _authHeaders));
    await _decode(res);
  }

  static Future<void> markAllNotificationsRead() async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/notifications/read-all'), headers: _authHeaders));
    await _decode(res);
  }

  static Future<Map<String, dynamic>> rates() async {
    final res = await _get(Uri.parse('$baseUrl/api/rates'));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> createPin(String pin) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/security/pin'), headers: _authHeaders, body: jsonEncode({'pin': pin})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> submitKyc(Map<String, dynamic> data) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/kyc'), headers: _authHeaders, body: jsonEncode(data)));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> myKycStatus() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/kyc/me'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> addBank(Map<String, dynamic> data) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/bank-accounts'), headers: _authHeaders, body: jsonEncode(data)));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> myBankAccounts() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/bank-accounts'), headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<void> deleteBankAccount(String id) async {
    final res = await _withUserRefresh(() => _delete(Uri.parse('$baseUrl/api/bank-accounts/$id'), headers: _authHeaders));
    await _decode(res);
  }

  static Future<Map<String, dynamic>> requestWithdrawal({required String bankAccountId, required double amount, String currency = 'INR'}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/withdrawals'), headers: _authHeaders, body: jsonEncode({'bankAccountId': bankAccountId, 'amount': amount, 'currency': currency})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> myWithdrawals() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/withdrawals'), headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> cancelWithdrawal(String id) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/withdrawals/$id/cancel'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> transactions({String? type, String? status, String? search}) async {
    final params = <String, String>{};
    if (type != null && type.isNotEmpty) params['type'] = type;
    if (status != null && status.isNotEmpty) params['status'] = status;
    if (search != null && search.isNotEmpty) params['search'] = search;
    final uri = Uri.parse('$baseUrl/api/transactions').replace(queryParameters: params.isEmpty ? null : params);
    final res = await _withUserRefresh(() => _get(uri, headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> myExchangeOrders({String? status}) async {
    final params = <String, String>{};
    if (status != null && status.isNotEmpty) params['status'] = status;
    final uri = Uri.parse('$baseUrl/api/exchange/orders/mine').replace(queryParameters: params.isEmpty ? null : params);
    final res = await _withUserRefresh(() => _get(uri, headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<String> requestReceiptUrl({String? transactionId, String? exchangeOrderId}) async {
    final res = await _withUserRefresh(() => _post(
          Uri.parse('$baseUrl/api/receipts/token'),
          headers: _authHeaders,
          body: jsonEncode({if (transactionId != null) 'transactionId': transactionId, if (exchangeOrderId != null) 'exchangeOrderId': exchangeOrderId}),
        ));
    final data = await _decode(res) as Map<String, dynamic>;
    return '$baseUrl${data['url']}';
  }

  static Future<Map<String, dynamic>> createExchangeOrder(Map<String, dynamic> data) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/exchange/orders'), headers: _authHeaders, body: jsonEncode(data)));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> sendMoney({required String receiver, required double amount, required String currency, required String pin, String note = ''}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/transactions/send'), headers: _authHeaders, body: jsonEncode({'receiver': receiver, 'amount': amount, 'currency': currency, 'pin': pin, 'note': note})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> complaint(String subject, String message, {String? transactionId}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/complaints'), headers: _authHeaders, body: jsonEncode({'subject': subject, 'message': message, 'transactionId': transactionId})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> myComplaints() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/complaints'), headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> createPaymentOrder({required double amount, String currency = 'INR', String purpose = 'wallet_topup'}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/payments/orders'), headers: _authHeaders, body: jsonEncode({'amount': amount, 'currency': currency, 'purpose': purpose})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> verifyPayment({required String orderId, required String gatewayOrderId, required String gatewayPaymentId, String? gatewaySignature}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/payments/verify'), headers: _authHeaders, body: jsonEncode({'orderId': orderId, 'gatewayOrderId': gatewayOrderId, 'gatewayPaymentId': gatewayPaymentId, 'gatewaySignature': gatewaySignature})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> adminKycRequests() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/kyc-requests'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminPaymentOrders() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/payment-orders'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> adminLedger() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/ledger'), headers: _adminHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> lockExchangeEscrow(String orderId) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/exchange/orders/$orderId/lock-escrow'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  // Redeem the 0.2% reward wallet balance (for one currency) into the main spendable wallet.
  static Future<Map<String, dynamic>> redeemRewards({String currency = 'INR'}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/wallet/redeem-rewards'), headers: _authHeaders, body: jsonEncode({'currency': currency})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> adminExchangeOrders() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/exchange/orders'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminAuditLogs() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/audit-logs'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> createDispute({String? transactionId, required String reason, required String message}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/disputes'), headers: _authHeaders, body: jsonEncode({'transactionId': transactionId, 'reason': reason, 'message': message})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> myDisputes() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/disputes'), headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminDisputes() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/disputes'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminListAdmins() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/admins'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> adminUpdateRole(String adminId, {required String role, required List<String> permissions}) async {
    final res = await _withAdminRefresh(() => _patch(Uri.parse('$baseUrl/api/admin/admins/$adminId/role'), headers: _adminHeaders, body: jsonEncode({'role': role, 'permissions': permissions})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> adminUpdateKyc(String kycId, String status) async {
    final res = await _withAdminRefresh(() => _patch(Uri.parse('$baseUrl/api/admin/kyc/$kycId'), headers: _adminHeaders, body: jsonEncode({'status': status})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> adminComplaints() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/complaints'), headers: _adminHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> adminUpdateComplaint(String complaintId, String status) async {
    final res = await _withAdminRefresh(() => _patch(Uri.parse('$baseUrl/api/admin/complaints/$complaintId'), headers: _adminHeaders, body: jsonEncode({'status': status})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> adminDashboard() async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/dashboard'), headers: _adminHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  // --- App Settings (Dark Mode / Notifications) ----------------------------
  static Future<Map<String, dynamic>> getSettings() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/settings'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> updateSettings({String? themePreference, bool? emailNotificationsEnabled, bool? pushNotificationsEnabled}) async {
    final body = <String, dynamic>{};
    if (themePreference != null) body['themePreference'] = themePreference;
    if (emailNotificationsEnabled != null) body['emailNotificationsEnabled'] = emailNotificationsEnabled;
    if (pushNotificationsEnabled != null) body['pushNotificationsEnabled'] = pushNotificationsEnabled;
    final res = await _withUserRefresh(() => _patch(Uri.parse('$baseUrl/api/settings'), headers: _authHeaders, body: jsonEncode(body)));
    return await _decode(res) as Map<String, dynamic>;
  }

  // --- Price Alerts ----------------------------------------------------------
  static Future<Map<String, dynamic>> createPriceAlert({required String pair, required String direction, required double targetPrice}) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/price-alerts'), headers: _authHeaders, body: jsonEncode({'pair': pair, 'direction': direction, 'targetPrice': targetPrice})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> priceAlerts() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/price-alerts'), headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<void> cancelPriceAlert(String id) async {
    final res = await _withUserRefresh(() => _delete(Uri.parse('$baseUrl/api/price-alerts/$id'), headers: _authHeaders));
    await _decode(res);
  }

  // --- Favorites / Watchlist --------------------------------------------------
  static Future<Map<String, dynamic>> addToWatchlist(String pair) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/watchlist'), headers: _authHeaders, body: jsonEncode({'pair': pair})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> watchlist() async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/watchlist'), headers: _authHeaders));
    return await _decode(res) as List<dynamic>;
  }

  static Future<void> removeFromWatchlist(String id) async {
    final res = await _withUserRefresh(() => _delete(Uri.parse('$baseUrl/api/watchlist/$id'), headers: _authHeaders));
    await _decode(res);
  }

  // --- Transaction Statement Export (PDF-via-print + CSV) ---------------------
  static Future<Map<String, dynamic>> requestStatementUrls({String? fromDate, String? toDate}) async {
    final body = <String, dynamic>{};
    if (fromDate != null) body['fromDate'] = fromDate;
    if (toDate != null) body['toDate'] = toDate;
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/statements/token'), headers: _authHeaders, body: jsonEncode(body)));
    final data = await _decode(res) as Map<String, dynamic>;
    return {'url': '$baseUrl${data['url']}', 'csvUrl': '$baseUrl${data['csvUrl']}'};
  }

  // --- In-App Support Chat (per-complaint messages) ---------------------------
  static Future<Map<String, dynamic>> sendComplaintMessage(String complaintId, String message) async {
    final res = await _withUserRefresh(() => _post(Uri.parse('$baseUrl/api/complaints/$complaintId/messages'), headers: _authHeaders, body: jsonEncode({'message': message})));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> complaintMessages(String complaintId) async {
    final res = await _withUserRefresh(() => _get(Uri.parse('$baseUrl/api/complaints/$complaintId/messages'), headers: _authHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> adminComplaintMessages(String complaintId) async {
    final res = await _withAdminRefresh(() => _get(Uri.parse('$baseUrl/api/admin/complaints/$complaintId/messages'), headers: _adminHeaders));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> adminSendComplaintMessage(String complaintId, String message) async {
    final res = await _withAdminRefresh(() => _post(Uri.parse('$baseUrl/api/admin/complaints/$complaintId/messages'), headers: _adminHeaders, body: jsonEncode({'message': message})));
    return await _decode(res) as Map<String, dynamic>;
  }
}

