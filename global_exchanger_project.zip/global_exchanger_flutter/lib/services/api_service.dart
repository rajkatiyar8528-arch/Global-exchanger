import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Android emulator: http://10.0.2.2:5000
  // Physical phone: replace with your computer LAN IP, e.g. http://192.168.1.10:5000
  static const String baseUrl = 'https://global-exchanger.onrender.com';
  static String? token;
  static String? adminToken;

  static Map<String, String> get _jsonHeaders => {'Content-Type': 'application/json'};
  static Map<String, String> get _authHeaders => {'Content-Type': 'application/json', if (token != null) 'Authorization': 'Bearer $token'};
  static Map<String, String> get _adminHeaders => {'Content-Type': 'application/json', if (adminToken != null) 'Authorization': 'Bearer $adminToken'};

  static Future<dynamic> _decode(http.Response res) async {
    final body = res.body.isEmpty ? '{}' : res.body;
    final data = jsonDecode(body);
    if (res.statusCode >= 400) throw Exception(data['error'] ?? 'API error ${res.statusCode}');
    return data;
  }


  static Future<Map<String, dynamic>> requestOtp(String email, {String purpose = 'email_verification'}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/auth/request-otp'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'purpose': purpose}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> verifyEmailOtp(String email, String otp) async {
    final res = await http.post(Uri.parse('$baseUrl/api/auth/verify-email-otp'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'otp': otp}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> loginWithOtp(String email, String otp) async {
    final res = await http.post(Uri.parse('$baseUrl/api/auth/login-otp'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'otp': otp}));
    final decoded = await _decode(res) as Map<String, dynamic>;
    token = decoded['token'];
    return decoded;
  }

  static Future<Map<String, dynamic>> adminRefund({required String orderId, String? gatewayPaymentId, double? amount, String reason = 'admin_refund'}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/payments/refund'), headers: _adminHeaders, body: jsonEncode({'orderId': orderId, 'gatewayPaymentId': gatewayPaymentId, 'amount': amount, 'reason': reason}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> register(Map<String, dynamic> data) async {
    final res = await http.post(Uri.parse('$baseUrl/api/auth/register'), headers: _jsonHeaders, body: jsonEncode(data));
    final decoded = await _decode(res) as Map<String, dynamic>;
    token = decoded['token'];
    return decoded;
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await http.post(Uri.parse('$baseUrl/api/auth/login'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'password': password}));
    final decoded = await _decode(res) as Map<String, dynamic>;
    token = decoded['token'];
    return decoded;
  }

  static Future<Map<String, dynamic>> adminLogin(String email, String password, String specialKey) async {
    final res = await http.post(Uri.parse('$baseUrl/api/admin/login'), headers: _jsonHeaders, body: jsonEncode({'email': email, 'password': password, 'specialKey': specialKey}));
    final decoded = await _decode(res) as Map<String, dynamic>;
    adminToken = decoded['token'];
    return decoded;
  }

  static Future<Map<String, dynamic>> me() async {
    final res = await http.get(Uri.parse('$baseUrl/api/me'), headers: _authHeaders);
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> notifications({int limit = 30, int offset = 0}) async {
    final res = await http.get(Uri.parse('$baseUrl/api/notifications?limit=$limit&offset=$offset'), headers: _authHeaders);
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<void> markNotificationRead(String id) async {
    final res = await http.post(Uri.parse('$baseUrl/api/notifications/$id/read'), headers: _authHeaders);
    await _decode(res);
  }

  static Future<void> markAllNotificationsRead() async {
    final res = await http.post(Uri.parse('$baseUrl/api/notifications/read-all'), headers: _authHeaders);
    await _decode(res);
  }

  static Future<Map<String, dynamic>> rates() async {
    final res = await http.get(Uri.parse('$baseUrl/api/rates'));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> createPin(String pin) async {
    final res = await http.post(Uri.parse('$baseUrl/api/security/pin'), headers: _authHeaders, body: jsonEncode({'pin': pin}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> submitKyc(Map<String, dynamic> data) async {
    final res = await http.post(Uri.parse('$baseUrl/api/kyc'), headers: _authHeaders, body: jsonEncode(data));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> myKycStatus() async {
    final res = await http.get(Uri.parse('$baseUrl/api/kyc/me'), headers: _authHeaders);
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> addBank(Map<String, dynamic> data) async {
    final res = await http.post(Uri.parse('$baseUrl/api/bank-accounts'), headers: _authHeaders, body: jsonEncode(data));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> transactions({String? type, String? status, String? search}) async {
    final params = <String, String>{};
    if (type != null && type.isNotEmpty) params['type'] = type;
    if (status != null && status.isNotEmpty) params['status'] = status;
    if (search != null && search.isNotEmpty) params['search'] = search;
    final uri = Uri.parse('$baseUrl/api/transactions').replace(queryParameters: params.isEmpty ? null : params);
    final res = await http.get(uri, headers: _authHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> myExchangeOrders({String? status}) async {
    final params = <String, String>{};
    if (status != null && status.isNotEmpty) params['status'] = status;
    final uri = Uri.parse('$baseUrl/api/exchange/orders/mine').replace(queryParameters: params.isEmpty ? null : params);
    final res = await http.get(uri, headers: _authHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<String> requestReceiptUrl({String? transactionId, String? exchangeOrderId}) async {
    final res = await http.post(
      Uri.parse('$baseUrl/api/receipts/token'),
      headers: _authHeaders,
      body: jsonEncode({if (transactionId != null) 'transactionId': transactionId, if (exchangeOrderId != null) 'exchangeOrderId': exchangeOrderId}),
    );
    final data = await _decode(res) as Map<String, dynamic>;
    return '$baseUrl${data['url']}';
  }

  static Future<Map<String, dynamic>> createExchangeOrder(Map<String, dynamic> data) async {
    final res = await http.post(Uri.parse('$baseUrl/api/exchange/orders'), headers: _authHeaders, body: jsonEncode(data));
    return await _decode(res) as Map<String, dynamic>;
  }


  static Future<Map<String, dynamic>> sendMoney({required String receiver, required double amount, required String currency, required String pin, String note = ''}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/transactions/send'), headers: _authHeaders, body: jsonEncode({'receiver': receiver, 'amount': amount, 'currency': currency, 'pin': pin, 'note': note}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> complaint(String subject, String message, {String? transactionId}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/complaints'), headers: _authHeaders, body: jsonEncode({'subject': subject, 'message': message, 'transactionId': transactionId}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> createPaymentOrder({required double amount, String currency = 'INR', String purpose = 'wallet_topup'}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/payments/orders'), headers: _authHeaders, body: jsonEncode({'amount': amount, 'currency': currency, 'purpose': purpose}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> verifyPayment({required String orderId, required String gatewayOrderId, required String gatewayPaymentId, String? gatewaySignature}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/payments/verify'), headers: _authHeaders, body: jsonEncode({'orderId': orderId, 'gatewayOrderId': gatewayOrderId, 'gatewayPaymentId': gatewayPaymentId, 'gatewaySignature': gatewaySignature}));
    return await _decode(res) as Map<String, dynamic>;
  }


  static Future<List<dynamic>> adminKycRequests() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/kyc-requests'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminPaymentOrders() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/payment-orders'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> adminLedger() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/ledger'), headers: _adminHeaders);
    return await _decode(res) as Map<String, dynamic>;
  }


  static Future<Map<String, dynamic>> lockExchangeEscrow(String orderId) async {
    final res = await http.post(Uri.parse('$baseUrl/api/exchange/orders/$orderId/lock-escrow'), headers: _authHeaders);
    return await _decode(res) as Map<String, dynamic>;
  }

  // Redeem the 0.2% reward wallet balance (for one currency) into the main spendable wallet.
  static Future<Map<String, dynamic>> redeemRewards({String currency = 'INR'}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/wallet/redeem-rewards'), headers: _authHeaders, body: jsonEncode({'currency': currency}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> adminExchangeOrders() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/exchange/orders'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminAuditLogs() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/audit-logs'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }


  static Future<Map<String, dynamic>> createDispute({String? transactionId, required String reason, required String message}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/disputes'), headers: _authHeaders, body: jsonEncode({'transactionId': transactionId, 'reason': reason, 'message': message}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> myDisputes() async {
    final res = await http.get(Uri.parse('$baseUrl/api/disputes'), headers: _authHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminDisputes() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/disputes'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<List<dynamic>> adminListAdmins() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/admins'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> adminUpdateRole(String adminId, {required String role, required List<String> permissions}) async {
    final res = await http.patch(Uri.parse('$baseUrl/api/admin/admins/$adminId/role'), headers: _adminHeaders, body: jsonEncode({'role': role, 'permissions': permissions}));
    return await _decode(res) as Map<String, dynamic>;
  }


  static Future<Map<String, dynamic>> adminUpdateKyc(String kycId, String status) async {
    final res = await http.patch(Uri.parse('$baseUrl/api/admin/kyc/$kycId'), headers: _adminHeaders, body: jsonEncode({'status': status}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> adminComplaints() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/complaints'), headers: _adminHeaders);
    return await _decode(res) as List<dynamic>;
  }

  static Future<Map<String, dynamic>> adminUpdateComplaint(String complaintId, String status) async {
    final res = await http.patch(Uri.parse('$baseUrl/api/admin/complaints/$complaintId'), headers: _adminHeaders, body: jsonEncode({'status': status}));
    return await _decode(res) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> adminDashboard() async {
    final res = await http.get(Uri.parse('$baseUrl/api/admin/dashboard'), headers: _adminHeaders);
    return await _decode(res) as Map<String, dynamic>;
  }
}
