import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'api_service.dart';

/// Real background push notifications via Firebase Cloud Messaging.
/// -----------------------------------------------------------------------
/// This is intentionally written so the ENTIRE app keeps working normally
/// even if Firebase was never configured for this build (no
/// google-services.json present at build time) — every method here is
/// wrapped so a missing/failed Firebase init just silently disables push,
/// exactly like how the backend's push.js becomes a no-op without
/// FIREBASE_SERVICE_ACCOUNT_JSON configured. This matters because this
/// project ships as a ZIP that gets rebuilt by Codemagic — a user who
/// hasn't yet completed the Firebase setup steps (see
/// PUSH_NOTIFICATIONS_SETUP_GUIDE.md) must still get a working APK with
/// in-app notifications, just without background push until they do.
/// -----------------------------------------------------------------------
class PushService {
  static bool _initialized = false;
  static bool _firebaseAvailable = false;
  static final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();

  static bool get isAvailable => _firebaseAvailable;

  /// Call once, early in app startup (see main()). Safe to call multiple
  /// times — only does real work on the first call.
  static Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    try {
      await Firebase.initializeApp();
      _firebaseAvailable = true;
    } catch (e) {
      // No google-services.json was bundled at build time (Firebase not
      // yet set up for this deployment), or some other init failure —
      // either way, push is simply unavailable this run. Not a crash.
      debugPrint('[push] Firebase.initializeApp() failed — push notifications disabled this run: $e');
      _firebaseAvailable = false;
      return;
    }

    try {
      await _setupLocalNotificationChannel();
      FirebaseMessaging.onMessage.listen(_showForegroundNotification);
    } catch (e) {
      debugPrint('[push] Local notification channel setup failed (foreground push banners may not show): $e');
    }
  }

  /// Android needs an explicit high-importance notification channel for
  /// heads-up banners to show while the app is in the foreground — FCM
  /// only auto-displays notifications when the app is backgrounded/killed.
  static Future<void> _setupLocalNotificationChannel() async {
    const androidChannel = AndroidNotificationChannel(
      'global_exchanger_default',
      'Global Exchanger Notifications',
      description: 'Payment, KYC, exchange, and support updates',
      importance: Importance.high,
    );
    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(androidChannel);
    await _localNotifications.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
    );
  }

  static void _showForegroundNotification(RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return;
    _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'global_exchanger_default',
          'Global Exchanger Notifications',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }

  /// Requests OS notification permission (required on Android 13+ and all
  /// iOS versions) and, if granted, registers the device's FCM token with
  /// the backend. Call this once after a successful login/session-restore
  /// — a token registered before the user is authenticated has no
  /// `Authorization` header to attach it to a specific account.
  static Future<void> requestPermissionAndRegister() async {
    if (!_firebaseAvailable) return;
    try {
      final messaging = FirebaseMessaging.instance;
      final settings = await messaging.requestPermission(alert: true, badge: true, sound: true);
      if (settings.authorizationStatus == AuthorizationStatus.denied) {
        debugPrint('[push] User denied notification permission — push disabled until they enable it in phone Settings.');
        return;
      }
      final token = await messaging.getToken();
      if (token != null) await _registerToken(token);

      // FCM tokens can rotate (app reinstall, Google Play Services
      // update, etc.) — keep the backend's copy in sync automatically for
      // as long as the app process is alive.
      FirebaseMessaging.instance.onTokenRefresh.listen(_registerToken);
    } catch (e) {
      debugPrint('[push] Failed to request permission / register token: $e');
    }
  }

  static Future<void> _registerToken(String token) async {
    try {
      await ApiService.registerPushToken(token: token, platform: Platform.isIOS ? 'ios' : 'android');
    } catch (e) {
      debugPrint('[push] Failed to register push token with backend: $e');
    }
  }

  /// Call on logout — best-effort, so a network failure here never blocks
  /// the actual logout flow.
  static Future<void> unregisterCurrentDevice() async {
    if (!_firebaseAvailable) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await ApiService.unregisterPushToken(token);
    } catch (e) {
      debugPrint('[push] Failed to unregister push token on logout: $e');
    }
  }
}
