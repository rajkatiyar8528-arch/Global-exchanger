import 'package:flutter/material.dart';

/// Lightweight, dependency-free Multi-Language support (English / Hindi).
/// This app's existing voice was already "Hinglish" (Hindi words written in
/// Roman script, mixed with English) across most in-app copy — that stays
/// as the default ('en' mode) since users are already used to it. Switching
/// to 'hi' mode translates the app's core navigation/chrome (bottom nav
/// labels, screen titles, common buttons, and the 5 newest feature
/// screens' key text) into proper Devanagari Hindi.
///
/// SCOPE NOTE: given the size of this app (3000+ lines across 60+ screens
/// built up over many feature rounds), fully translating every single
/// string in every screen in one pass was not attempted here — that would
/// be a much larger, dedicated effort. This round translates the
/// highest-traffic/most-visible chrome (bottom navigation, home screen,
/// settings, and the 5 new feature screens from this same round) as a
/// solid, working foundation. Screens not yet in the `_hi` map below will
/// continue to show their existing Hinglish text even when Hindi mode is
/// selected — this is a deliberate, incremental rollout (same pattern used
/// for Dark Mode across earlier rounds), not a bug. See
/// MULTI_LANGUAGE_GUIDE.md for the exact list of what's translated vs. not
/// yet, and how to extend this map in a future round.
class LanguageController {
  static final ValueNotifier<String> locale = ValueNotifier('en');

  static void setFromPreferenceString(String? preference) {
    locale.value = (preference == 'hi') ? 'hi' : 'en';
  }
}

class AppStrings {
  static String t(String key) {
    final lang = LanguageController.locale.value;
    if (lang == 'hi' && _hi.containsKey(key)) return _hi[key]!;
    return _en[key] ?? key;
  }

  static const Map<String, String> _en = {
    // Bottom navigation
    'nav_home': 'Home',
    'nav_wallet': 'Wallet',
    'nav_convert': 'Convert',
    'nav_history': 'History',
    'nav_help': 'Help',
    'nav_profile': 'Profile',

    // Common actions
    'action_send': 'Send',
    'action_receive': 'Receive',
    'action_login': 'Login',
    'action_logout': 'Logout',
    'action_submit': 'Submit',
    'action_cancel': 'Cancel',
    'action_save': 'Save',
    'action_retry': 'Retry',
    'action_refresh': 'Refresh',
    'action_delete': 'Delete',
    'action_close': 'Close',

    // Home screen
    'home_greeting': 'Hello',
    'home_wallet_balance': 'INR Wallet Balance',
    'home_kyc': 'KYC',
    'home_live_rates': 'Live Backend Rates',
    'home_refer_earn': 'Refer & Earn ₹100',
    'home_watchlist': 'My Watchlist',

    // Settings
    'settings_title': 'App Settings',
    'settings_theme': 'Theme',
    'settings_language': 'Language',
    'settings_notifications': 'Notifications',
    'settings_biometric': 'Biometric Login',
    'settings_system_default': 'System Default',
    'settings_light_mode': 'Light Mode',
    'settings_dark_mode': 'Dark Mode',
    'settings_english': 'English',
    'settings_hindi': 'Hindi (हिन्दी)',

    // Scheduled Payments
    'scheduled_payments_title': 'Scheduled Payments',
    'scheduled_payments_set_up': 'Set Up a Scheduled Payment',
    'scheduled_payments_my': 'My Scheduled Payments',
    'scheduled_payments_frequency': 'Frequency',
    'scheduled_payments_daily': 'Daily',
    'scheduled_payments_weekly': 'Weekly',
    'scheduled_payments_monthly': 'Monthly',
    'scheduled_payments_pause': 'Pause',
    'scheduled_payments_resume': 'Resume',
    'scheduled_payments_cancel_mandate': 'Cancel',
    'scheduled_payments_history': 'History',

    // Spending Analytics
    'analytics_title': 'Spending Analytics',
    'analytics_total_in': 'Total In',
    'analytics_total_out': 'Total Out',
    'analytics_net': 'Net',
    'analytics_monthly_trend': 'Monthly Trend',
    'analytics_category_breakdown': 'Category Breakdown',
    'analytics_top_counterparties': 'Top People You Send To',

    // Referral Leaderboard
    'leaderboard_title': 'Referral Leaderboard',
    'leaderboard_your_rank': 'Your Rank',
    'leaderboard_top_referrers': 'Top Referrers',
    'leaderboard_referrals': 'referrals',

    // Biometric
    'biometric_enable': 'Enable Biometric Login',
    'biometric_unlock': 'Unlock with Fingerprint/Face',
    'biometric_not_available': 'Biometric login is not available on this device.',
  };

  static const Map<String, String> _hi = {
    // Bottom navigation
    'nav_home': 'होम',
    'nav_wallet': 'वॉलेट',
    'nav_convert': 'कन्वर्ट',
    'nav_history': 'हिस्ट्री',
    'nav_help': 'सहायता',
    'nav_profile': 'प्रोफाइल',

    // Common actions
    'action_send': 'भेजें',
    'action_receive': 'प्राप्त करें',
    'action_login': 'लॉगिन',
    'action_logout': 'लॉगआउट',
    'action_submit': 'सबमिट करें',
    'action_cancel': 'रद्द करें',
    'action_save': 'सेव करें',
    'action_retry': 'फिर से कोशिश करें',
    'action_refresh': 'रिफ्रेश करें',
    'action_delete': 'हटाएं',
    'action_close': 'बंद करें',

    // Home screen
    'home_greeting': 'नमस्ते',
    'home_wallet_balance': 'INR वॉलेट बैलेंस',
    'home_kyc': 'केवाईसी',
    'home_live_rates': 'लाइव बैकएंड रेट्स',
    'home_refer_earn': 'रेफर करें और ₹100 कमाएं',
    'home_watchlist': 'मेरी वॉचलिस्ट',

    // Settings
    'settings_title': 'ऐप सेटिंग्स',
    'settings_theme': 'थीम',
    'settings_language': 'भाषा',
    'settings_notifications': 'नोटिफिकेशन',
    'settings_biometric': 'बायोमेट्रिक लॉगिन',
    'settings_system_default': 'सिस्टम डिफ़ॉल्ट',
    'settings_light_mode': 'लाइट मोड',
    'settings_dark_mode': 'डार्क मोड',
    'settings_english': 'अंग्रेज़ी',
    'settings_hindi': 'हिन्दी',

    // Scheduled Payments
    'scheduled_payments_title': 'शेड्यूल्ड पेमेंट्स',
    'scheduled_payments_set_up': 'नया शेड्यूल्ड पेमेंट बनाएं',
    'scheduled_payments_my': 'मेरे शेड्यूल्ड पेमेंट्स',
    'scheduled_payments_frequency': 'फ्रीक्वेंसी',
    'scheduled_payments_daily': 'रोज़ाना',
    'scheduled_payments_weekly': 'साप्ताहिक',
    'scheduled_payments_monthly': 'मासिक',
    'scheduled_payments_pause': 'रोकें',
    'scheduled_payments_resume': 'फिर से शुरू करें',
    'scheduled_payments_cancel_mandate': 'रद्द करें',
    'scheduled_payments_history': 'हिस्ट्री',

    // Spending Analytics
    'analytics_title': 'खर्च विश्लेषण',
    'analytics_total_in': 'कुल जमा',
    'analytics_total_out': 'कुल खर्च',
    'analytics_net': 'नेट',
    'analytics_monthly_trend': 'मासिक ट्रेंड',
    'analytics_category_breakdown': 'श्रेणी अनुसार विवरण',
    'analytics_top_counterparties': 'सबसे ज़्यादा भेजा गया',

    // Referral Leaderboard
    'leaderboard_title': 'रेफरल लीडरबोर्ड',
    'leaderboard_your_rank': 'आपकी रैंक',
    'leaderboard_top_referrers': 'टॉप रेफरर्स',
    'leaderboard_referrals': 'रेफरल्स',

    // Biometric
    'biometric_enable': 'बायोमेट्रिक लॉगिन चालू करें',
    'biometric_unlock': 'फिंगरप्रिंट/फेस से अनलॉक करें',
    'biometric_not_available': 'इस डिवाइस पर बायोमेट्रिक लॉगिन उपलब्ध नहीं है।',
  };
}
