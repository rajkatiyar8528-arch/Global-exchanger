# Global Exchanger - Privacy Policy

Effective Date: 18 June 2026

This Privacy Policy explains how Global Exchanger collects, uses, stores, protects, and shares user data.

## 1. Data We Collect

We may collect:

- Name, email, phone number
- Address, house number, city, state, country, postal code
- Date of birth and profile information
- National ID details such as Aadhaar, PAN, passport, tax ID, or other country-specific documents
- Bank account details required for verification
- Device details, IP address, login history, location signals, and security logs
- Transaction history, wallet activity, exchange orders, complaint details, and referral data
- Uploaded documents and selfies for KYC

## 2. Why We Collect Data

We use data for:

- Account creation and login
- KYC and identity verification
- Bank verification
- Payment processing
- Wallet and currency exchange services
- Fraud prevention and security
- Customer support and complaint handling
- Referral reward processing
- Legal and regulatory compliance
- Improving app experience

## 3. Payment Security

Payments are protected using security PIN, biometric verification where available, encrypted communication, fraud checks, and transaction monitoring. Sensitive credentials should never be shared by users.

## 4. Data Sharing

We do not sell user personal data. We may share necessary data with:

- Banks and payment gateways
- KYC/identity verification providers
- Fraud monitoring and AML providers
- Cloud infrastructure providers
- Legal authorities, regulators, or law enforcement when required
- Support and email service providers

Only required data is shared for lawful and operational purposes.

## 5. Data Protection

We use security measures such as encryption in transit, access controls, password hashing, restricted admin access, logs, and monitoring. No system is 100% hack-proof, but we work to protect user data with strong security practices.

## 6. User Controls

Users may request:

- Profile correction
- Account closure
- Complaint review
- Data access where legally allowed
- Consent withdrawal where applicable

Some financial records may be retained for legal, audit, tax, fraud prevention, or regulatory reasons.

## 7. KYC Document Storage

KYC documents are stored securely and accessed only for verification, compliance, fraud checks, or legal requirements.

## 8. Cookies and Analytics

The app or website may use cookies, analytics, crash reporting, and performance monitoring tools to improve services and security.

## 9. Children's Privacy

Users must meet the legal age requirement in their country. We do not knowingly provide financial services to underage users without required legal permission.

## 10. International Transfers

If services use international infrastructure or providers, data may be processed in other countries with appropriate safeguards.

## 11. Data Retention

We keep data only as long as required for service, legal, audit, tax, AML, fraud prevention, and dispute resolution purposes.

## 12. Contact

Support Email: support@globalexchanger.com  
Privacy URL: https://globalexchanger.com/privacy-policy
