# Global Exchanger - Terms and Conditions

Effective Date: 18 June 2026

Welcome to Global Exchanger. By creating an account or using our services, you agree to these Terms and Conditions.

## 1. Services

Global Exchanger provides app-based wallet, payment, currency conversion, exchange marketplace, complaint support, referral reward, and related financial technology features. Some services may be available only after legal approvals, KYC verification, bank verification, and country-wise compliance.

## 2. Eligibility

You must be legally eligible in your country to use financial, forex, wallet, and crypto-related services. You must provide correct personal information and documents.

## 3. Account Registration

Users may register through email/password, Google login, or other approved login methods. You are responsible for keeping your password, device, security PIN, and biometric access safe.

## 4. KYC and Verification

KYC is mandatory for payment, wallet, currency exchange, crypto exchange, withdrawal, and other sensitive features. Required documents depend on your country. For India, documents may include Aadhaar Card, PAN Card, bank passbook/bank statement, address proof, and selfie verification.

We may reject, suspend, or limit accounts if documents are invalid, expired, suspicious, or incomplete.

## 5. Bank Account Verification

To make smooth payments, users must add and verify a valid bank account. The bank account name should match the KYC name.

## 6. Payments

Users can send or receive money using supported methods such as QR code, UPI ID, phone number, user ID, bank account, or wallet features, depending on availability and legal permission.

Every payment may require security PIN or biometric verification.

## 7. Wrong Payment

If you send payment to a wrong person, you must inform Global Exchanger within 2 days with transaction details. Recovery is not guaranteed because bank, UPI, wallet, and crypto transactions may be irreversible. We will make best-effort support according to law and partner policies.

## 8. Currency Exchange and Escrow

Currency exchange may happen through an app wallet, exchange marketplace, or approved liquidity partner. Global Exchanger may use escrow/security hold to reduce fraud. Funds may remain pending until verification, partner confirmation, or admin review is complete.

## 9. Crypto Risk

Crypto assets are highly volatile and risky. Prices can change rapidly. Blockchain transfers may be irreversible. You are responsible for understanding crypto risks before using crypto features.

## 10. Commission

Global Exchanger may charge 1% commission on currency exchange/convert transactions. From this, 0.8% may be admin/platform commission and 0.2% may be shown as earning to the eligible exchange-providing user. Commission rules may change with notice.

## 11. Referral Reward

Referral reward may be ₹100 or as displayed in the app. Reward will be credited only when the referred user creates an account and passes required checks. We may withhold rewards for fake accounts, duplicate accounts, fraud, device abuse, or policy violation.

## 12. User Responsibilities

You agree not to use the app for fraud, money laundering, illegal trading, scams, terrorist financing, stolen funds, unauthorized access, or any illegal activity.

## 13. Account Suspension

We may suspend, freeze, limit, or close accounts for suspicious activity, legal requests, KYC failure, payment disputes, fraud risk, or violation of these Terms.

## 14. Data and Privacy

Your data is handled according to our Privacy Policy. We do not sell your personal data. Required data may be shared with banks, payment gateways, KYC providers, fraud prevention providers, regulators, and law enforcement when legally required.

## 15. Service Availability

Services may be interrupted due to maintenance, bank/payment network downtime, API provider issues, cyber incidents, or legal restrictions.

## 16. Limitation of Liability

Global Exchanger is not responsible for losses caused by wrong recipient details, market volatility, user negligence, device compromise, irreversible blockchain transfers, third-party downtime, or legal restrictions, except where required by law.

## 17. Changes to Terms

We may update these Terms from time to time. Continued use of the app means you accept updated Terms.

## 18. Contact

Support Email: support@globalexchanger.com  
Terms URL: https://globalexchanger.com/terms
