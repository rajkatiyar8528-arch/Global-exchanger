# Global Exchanger Admin Web Panel

Open `admin_panel/index.html` in browser.

Default API URL:

```text
http://localhost:5000
```

Start backend first:

```bash
cd backend
npm install
npm run dev
```

Or PostgreSQL backend:

```bash
cd backend
cp .env.postgres.example .env
npm install
npm run migrate
npm run dev:pg
```

## Added Admin Features

- KYC requests list
- Approve/reject KYC
- Payment orders list

## Added More Admin Features

- Admin role assignment
- Permission editing
- Dispute management
- Dispute status update
